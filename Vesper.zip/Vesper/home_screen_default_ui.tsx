// Scripting 首頁入口（Home Screen Tab UI）：Vesper 的 Mini Hub。
// 長駐於 Scripting 首頁分頁，不可調用 Navigation.present 與 Script.exit()。
//
// 全螢幕 App 不再塞進來：這裡只有四件事，資料全在本機（不抓 Bangumi）——
//   續讀 Hero、最新追更、閱讀熱力圖（順序與開關見 app/miniHubLayout.ts），加上導覽列的「開啟完整 App」。
// 背景檢查是靜默的：資料載入完成、每次切回首頁各跑一輪，先漫畫源更新再追更；
// TTL 各自把關（見 app/sourceUpdates.ts、app/updates.ts），所以這裡放心呼叫。

import {
  Button,
  Circle,
  Divider,
  Device,
  GeometryReader,
  HStack,
  Image,
  NavigationLink,
  NavigationStack,
  ProgressView,
  RoundedRectangle,
  Script,
  ScrollView,
  Spacer,
  Text,
  VStack,
  ZStack,
  useEffect,
  useState,
  type VirtualNode,
} from "scripting"

import { createComicLibrary } from "./app/comic"
import { onBeforeExit } from "./app/lifecycle"
import { installLocaleSetting } from "./app/localeSetting"
import { getMiniHubLayout, type MiniHubSection } from "./app/miniHubLayout"
import { comicLibrary, installComicLibrary } from "./app/services"
import { resumeEntry, unreadCountOf, type ResumeEntry } from "./app/shelf"
import { checkSourceUpdates } from "./app/sourceUpdates"
import { PageBackground, reloadThemeFromStorage, useAppearanceOverride, useTint } from "./app/theme"
import { parseUpdateTime, updatesScheduler } from "./app/updates"
import { useSubscription } from "./app/useSubscription"
import { CoverImage } from "./components/CoverImage"
import { composeImage } from "./components/ModifyImageRenderer"
import { WidthReporter } from "./components/WidthReporter"
import { Card, GroupHeader, PageScroll } from "./design/layout"
import { Chevron } from "./design/rows"
import { EmptyState } from "./design/status"
import { capsule, cardBackground, cardGap, fill, pageInsets, rowPadding } from "./design/tokens"
import { ensureFileAccess, fileAccess } from "./engine/fs"
import { comicGroupKey } from "./engine/offline"
import { setImageCompositor } from "./engine/imagecache"
import { subscribe as subscribeLocale, t } from "./i18n"
import {
  allComicUpdates,
  dayKey,
  flushLibrary,
  listFavorites,
  listProgress,
  readingActivity,
  reloadLibraryFromDisk,
  subscribeLibrary,
  type ComicUpdateRecord,
  type DayActivity,
  type Favorite,
} from "./library/bookshelf"
import { ReadingLogScreen } from "./screens/home/ReadingLogScreen"
import { ComicDetailScreen } from "./screens/shared/ComicDetailScreen"
import { launchResumeReader } from "./screens/shared/ResumeReaderScreen"
import { reloadRegistry } from "./sources/registry"

/** 追更看板最多幾部（橫向滾動列可多放幾部）。 */
const UPDATE_LIMIT = 10

const HERO_COVER = { width: 84, height: 120 }
const RAIL_COVER = { width: 84, height: 118 }
/** 封面與文字之間。 */
const COVER_GAP = 12
const DORMANT_AFTER_DAYS = 90
const DAY_MS = 24 * 60 * 60 * 1000

const HEATMAP_COLS = 14
const HEATMAP_ROWS = 5
/** 量到卡片寬度前的暫用格子邊長。 */
const HEATMAP_CELL = 20
const HEATMAP_GAP = 3
/** 第 1–4 階的 tint 不透明度（0 階用中性底色）。 */
const HEATMAP_OPACITY = [0.45, 0.65, 0.85, 1]

let isInitialized = false

function initVesperForHomeScreen() {
  if (isInitialized) return
  isInitialized = true

  // 語言要在 render 期同步注入（讀 KV 是同步的，不需要授權也不用 await）：
  // 這個入口不能 await，第一輪 render 就該是對的語言。
  installLocaleSetting(Device.systemLocales)

  // 註冊退出/銷毀時落盤
  onBeforeExit(() => flushLibrary())

  // 圖片離屏合成器
  setImageCompositor(composeImage)

  // 畫面都透過 ComicLibrary 取資料，這個入口也是 composition root。
  installComicLibrary(createComicLibrary())
}

/**
 * 檔案授權確認後加載本機資料（若尚未授權則退守 KV 備援）。
 */
async function loadVesperData() {
  const granted = await ensureFileAccess()
  // 沒授權時 source 走 KV 備援，仍然是「現在該載的那份」，所以兩種情況都要 reload。
  reloadRegistry()
  if (granted) {
    reloadLibraryFromDisk()
  }
}

/**
 * 背景靜默查一輪：先漫畫源更新，查完（不論成敗）再查追更。
 * 兩邊都自己守 TTL 與去重，這裡不需要再判斷。
 */
async function checkQuietly(alive: () => boolean) {
  try {
    await checkSourceUpdates()
  } finally {
    if (alive()) void updatesScheduler().checkUpdates({ background: true })
  }
}

/** 完整 App 走 run URL scheme：首頁分頁不能 present，那會再疊一層殼在分頁裡。
 *  這版 API 沒有 `Script.openUrl`，用 `createRunURLScheme` 組出同一個網址交給系統。 */
function openFullApp() {
  void Safari.openURL(Script.createRunURLScheme("Vesper"))
}

export default function HomeScreenDefaultUI() {
  // 於 render 階段建立服務實例（子畫面在 render 期間即依賴 ComicLibrary）
  initVesperForHomeScreen()

  const [dataReady, setDataReady] = useState(() => fileAccess() !== null)
  const tint = useTint()
  // 這裡是 Scripting 自己的首頁分頁：`preferredColorScheme` 會連宿主 App 一起切，只能用區域覆蓋。
  const scheme = useAppearanceOverride()
  const environments = scheme ? { colorScheme: scheme } : undefined

  // 收藏、已讀、追更快取、離線層與語言一變就重繪：背景檢查寫回 library.json 時看板自己跟上。
  const refresh = useSubscription(subscribeLibrary, comicLibrary().onChange, subscribeLocale)

  useEffect(() => {
    let mounted = true
    const alive = () => mounted

    // 授權結算後才載得到源與書架。在載入完成前不渲染看板，
    // 避免續讀卡在源尚未進入記憶體時就判斷成「源失效」。載完就開始背景檢查。
    void loadVesperData().finally(() => {
      setDataReady(true)
      if (mounted) void checkQuietly(alive)
    })

    // 監聽 Scripting 首頁分頁事件
    const unsubscribeTab = Script.onHomeTabEvent(event => {
      switch (event) {
        case "selected":
          // 從其他分頁切換回首頁。完整 App 可能同時在寫 library.json（閱讀進度、追更），
          // 先重讀盤上的那一份：不只看板要是新的，接下來的背景檢查也才不會蓋掉完整 App 的寫入。
          reloadRegistry()
          reloadLibraryFromDisk()
          reloadThemeFromStorage()
          refresh()
          void checkQuietly(alive)
          break
        case "deselected":
          // 切換至其他分頁，將資料落盤
          void flushLibrary()
          break
      }
    })

    return () => {
      mounted = false
      unsubscribeTab()
      void flushLibrary()
    }
  }, [])

  if (!dataReady) {
    return (
      <ZStack tint={tint.tint} environments={environments} frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
        <PageBackground />
        <ProgressView />
      </ZStack>
    )
  }

  // 順序與開關在完整 App 的設定裡改；切回首頁的 refresh() 會重讀。
  const sections: Record<MiniHubSection, () => VirtualNode | null> = {
    resume: () => {
      const resume = listProgress()[0]
      return resume ? <ResumeHero key="resume" entry={resumeEntry(resume)} /> : null
    },
    updates: () => (
      <UpdatesSection key="updates" items={pendingUpdates()} shelfEmpty={listFavorites().length === 0} />
    ),
    activity: () => <ActivitySection key="activity" activity={readingActivity()} />,
  }

  return (
    <NavigationStack environments={environments}>
      <ZStack tint={tint.tint} frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
        <PageScroll title="Vesper" trailing={OpenAppButton}>
          {getMiniHubLayout().enabled.map(section => sections[section]())}
        </PageScroll>
      </ZStack>
    </NavigationStack>
  )
}

/** 導覽列右上：交給完整的五個分頁 App。 */
function OpenAppButton() {
  const tint = useTint()
  return (
    <Button
      action={openFullApp}
      buttonStyle="plain"
      accessibilityLabel={t("home.miniHub.openApp")}
    >
      <Image
        systemName="arrow.up.forward.app"
        font="body"
        fontWeight="semibold"
        foregroundStyle={tint.tint}
      />
    </Button>
  )
}

/** 續讀 Hero：封面、作品名、上次那一話與進度；卡片推詳情，「繼續閱讀」按鈕內嵌右下角直接開閱讀器。 */
function ResumeHero({ entry }: { entry: ResumeEntry }) {
  const tint = useTint()
  const [opening, setOpening] = useState(false)
  const fraction = entry.readFraction

  return (
    <VStack spacing={cardGap} alignment="leading" frame={{ maxWidth: "infinity" }}>
      <GroupHeader title={t("home.resumeTitle")} />
      <Card>
        <HStack spacing={COVER_GAP} alignment="top" padding={rowPadding} frame={{ maxWidth: "infinity" }}>
          {/* 點封面進詳情 */}
          <NavigationLink
            destination={<ComicDetailScreen sourceKey={entry.sourceKey} comicId={entry.comicId} title={entry.title} />}
            buttonStyle="plain"
          >
            <CoverImage
              sourceKey={entry.sourceKey}
              url={entry.cover}
              width={HERO_COVER.width}
              height={HERO_COVER.height}
              title={entry.title}
              lifted={true}
            />
          </NavigationLink>

          {/* 右側資訊與操作欄：高度對齊封面，上下分佈更勻稱 */}
          <VStack
            alignment="leading"
            frame={{ maxWidth: "infinity", height: HERO_COVER.height, alignment: "leading" }}
          >
            {/* 標題與進入詳情箭頭 */}
            <NavigationLink
              destination={<ComicDetailScreen sourceKey={entry.sourceKey} comicId={entry.comicId} title={entry.title} />}
              buttonStyle="plain"
            >
              <VStack spacing={3} alignment="leading" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                <HStack alignment="top" spacing={6} frame={{ maxWidth: "infinity" }}>
                  <Text font="headline" fontWeight="bold" lineLimit={2}>
                    {entry.title}
                  </Text>
                  <Spacer />
                  <Chevron />
                </HStack>
                <Text font="subheadline" foregroundStyle="secondaryLabel" lineLimit={1}>
                  {entry.epTitle || t("home.lastRead")}
                </Text>
              </VStack>
            </NavigationLink>

            <Spacer />

            {/* 進度條與頁碼 */}
            <VStack spacing={3} alignment="leading" frame={{ maxWidth: "infinity" }}>
              <ProgressView
                value={fraction ?? 0}
                progressViewStyle="linear"
                frame={{ maxWidth: "infinity" }}
                opacity={fraction === undefined ? 0 : 1}
              />
              {entry.pageLabel ? (
                <Text font="caption2" foregroundStyle="tertiaryLabel">
                  {entry.pageLabel.total
                    ? t("bookshelf.pageOfTotal", { page: entry.pageLabel.page, total: entry.pageLabel.total })
                    : t("bookshelf.pageOf", { page: entry.pageLabel.page })}
                </Text>
              ) : null}
            </VStack>

            <Spacer />

            {/* 繼續閱讀按鈕：緊湊膠囊內嵌於右側欄底部，不再全寬墊底 */}
            {entry.openable ? (
              <Button
                buttonStyle="plain"
                disabled={opening}
                action={() => {
                  setOpening(true)
                  void launchResumeReader({ sourceKey: entry.sourceKey, comicId: entry.comicId }).finally(() =>
                    setOpening(false)
                  )
                }}
              >
                <HStack
                  spacing={5}
                  alignment="center"
                  padding={{ horizontal: 12, vertical: 6 }}
                  background={tint.tint}
                  clipShape={capsule()}
                  opacity={opening ? 0.6 : 1}
                >
                  <Image systemName="play.fill" font="caption2" foregroundStyle={tint.onTint} />
                  <Text font="caption" fontWeight="semibold" foregroundStyle={tint.onTint}>
                    {t("home.resumeTitle")}
                  </Text>
                </HStack>
              </Button>
            ) : (
              <HStack spacing={4} alignment="center">
                <Image systemName="exclamationmark.triangle" font="caption2" foregroundStyle="secondaryLabel" />
                <Text font="caption2" foregroundStyle="secondaryLabel">
                  {t("home.sourceInvalid")}
                </Text>
              </HStack>
            )}
          </VStack>
        </HStack>
      </Card>
    </VStack>
  )
}

interface HeatmapCell {
  day: string
  level: number
}

/** 深淺看讀完的話數；只翻了頁沒讀完也算第 1 階。 */
function heatLevel(activity: DayActivity | undefined): number {
  if (!activity) return 0
  if (activity.chapters >= 5) return 4
  if (activity.chapters >= 3) return 3
  if (activity.chapters >= 2) return 2
  return activity.chapters > 0 || activity.pages > 0 ? 1 : 0
}

/** 最近 `HEATMAP_COLS × HEATMAP_ROWS` 天逐欄由上而下排（5 列），舊→新；今天固定在右下角。 */
function heatmapColumns(activity: Record<string, DayActivity>, now: number): HeatmapCell[][] {
  const totalDays = HEATMAP_COLS * HEATMAP_ROWS
  // 取中午，逐日加減時不會因日光節約時間跳日。
  const start = new Date(now)
  start.setHours(12, 0, 0, 0)
  start.setDate(start.getDate() - (totalDays - 1))

  const cols: HeatmapCell[][] = []
  for (let col = 0; col < HEATMAP_COLS; col++) {
    const cells: HeatmapCell[] = []
    for (let row = 0; row < HEATMAP_ROWS; row++) {
      const date = new Date(start)
      date.setDate(start.getDate() + col * HEATMAP_ROWS + row)
      const day = dayKey(date.getTime())
      cells.push({ day, level: heatLevel(activity[day]) })
    }
    cols.push(cells)
  }
  return cols
}

/** 連續閱讀天數：今天還沒讀就從昨天算起，不讓一大早的紀錄歸零。 */
function readingStreak(activity: Record<string, DayActivity>, now: number): number {
  const cursor = new Date(now)
  cursor.setHours(12, 0, 0, 0)
  if (heatLevel(activity[dayKey(cursor.getTime())]) === 0) cursor.setDate(cursor.getDate() - 1)
  let days = 0
  while (heatLevel(activity[dayKey(cursor.getTime())]) > 0) {
    days++
    cursor.setDate(cursor.getDate() - 1)
  }
  return days
}

/** 閱讀熱力圖：最近 70 天（14 欄 × 5 列）的每日閱讀量；範圍內完全沒紀錄就整塊不顯示。整塊點下去推閱讀紀錄頁。 */
function ActivitySection({ activity }: { activity: Record<string, DayActivity> }) {
  const tint = useTint()
  const [gridWidth, setGridWidth] = useState(0)
  const now = Date.now()
  const cols = heatmapColumns(activity, now)
  if (!cols.some(col => col.some(cell => cell.level > 0))) return null
  const streak = readingStreak(activity, now)
  // 格子平分卡片內的寬度，左右貼齊卡片內距。
  const size = gridWidth > 0 ? (gridWidth - HEATMAP_GAP * (HEATMAP_COLS - 1)) / HEATMAP_COLS : HEATMAP_CELL

  return (
    <NavigationLink destination={<ReadingLogScreen />} buttonStyle="plain">
      <VStack spacing={cardGap} alignment="leading" frame={{ maxWidth: "infinity" }}>
        <HStack spacing={6} alignment="center" padding={{ trailing: 4 }} frame={{ maxWidth: "infinity" }}>
          <GroupHeader title={t("home.miniHub.activityTitle")} />
          <Spacer />
          {streak >= 2 ? (
            <Text font="footnote" fontWeight="medium" foregroundStyle={tint.tint}>
              {t("home.miniHub.streak", { days: streak })}
            </Text>
          ) : null}
          <Chevron />
        </HStack>
        <Card>
          <VStack padding={rowPadding} frame={{ maxWidth: "infinity" }}>
            <HStack
              spacing={HEATMAP_GAP}
              frame={{ maxWidth: "infinity" }}
              background={
                <GeometryReader>
                  {geometry => <WidthReporter width={geometry.size.width} onWidth={setGridWidth} />}
                </GeometryReader>
              }
            >
              {cols.map(col => (
                <VStack key={col[0].day} spacing={HEATMAP_GAP}>
                  {col.map(cell => (
                    <RoundedRectangle
                      key={cell.day}
                      cornerRadius={4}
                      fill={cell.level > 0 ? tint.tint : fill.tag}
                      opacity={cell.level > 0 ? HEATMAP_OPACITY[cell.level - 1] : 1}
                      frame={{ width: size, height: size }}
                    />
                  ))}
                </VStack>
              ))}
            </HStack>
          </VStack>
        </Card>
      </VStack>
    </NavigationLink>
  )
}

/** 看板的一列：收藏接上追更紀錄與未讀數。 */
interface UpdateItem {
  favorite: Favorite
  record: ComicUpdateRecord
  unreadCount: number
}

/** 判斷是否為近期活躍的更新作品（完結或超過 90 天未更的老漫畫不列入）。 */
function isRecentUpdate(record: ComicUpdateRecord, now: number): boolean {
  if (record.status === "completed") return false
  if (record.updateTime) {
    const time = parseUpdateTime(record.updateTime)
    if (time !== undefined && now - time > DORMANT_AFTER_DAYS * DAY_MS) {
      return false
    }
  }
  return true
}

/** 有未讀的活躍作品，最新檢查的在前。沒有追更紀錄＝還沒查過，不算更新。 */
function pendingUpdates(): UpdateItem[] {
  const favorites = new Map(listFavorites().map(favorite => [comicGroupKey(favorite), favorite]))
  const items: UpdateItem[] = []
  const now = Date.now()
  for (const record of Object.values(allComicUpdates())) {
    const favorite = favorites.get(comicGroupKey(record))
    if (!favorite) continue
    if (!isRecentUpdate(record, now)) continue
    const unreadCount = unreadCountOf(favorite)
    if (unreadCount > 0) items.push({ favorite, record, unreadCount })
  }
  return items.sort((a, b) => b.record.checkedAt - a.record.checkedAt).slice(0, UPDATE_LIMIT)
}

function UpdatesSection({ items, shelfEmpty }: { items: UpdateItem[]; shelfEmpty: boolean }) {
  const tint = useTint()

  return (
    <VStack spacing={cardGap} alignment="leading" frame={{ maxWidth: "infinity" }}>
      <GroupHeader
        title={items.length > 0 ? `${t("home.miniHub.updatesTitle")} (${items.length})` : t("home.miniHub.updatesTitle")}
      />
      {items.length === 0 ? (
        <Card>
          <HStack spacing={10} alignment="center" padding={rowPadding} frame={{ maxWidth: "infinity" }}>
            <Image
              systemName={shelfEmpty ? "books.vertical" : "checkmark.circle.fill"}
              font="body"
              foregroundStyle={shelfEmpty ? "secondaryLabel" : tint.tint}
            />
            <Text font="subheadline" foregroundStyle="secondaryLabel">
              {shelfEmpty ? t("bookshelf.emptyFavoritesDetail") : t("home.miniHub.allUpToDate")}
            </Text>
          </HStack>
        </Card>
      ) : (
        <ScrollView axes="horizontal" scrollIndicator="hidden" padding={{ horizontal: -pageInsets.horizontal }}>
          <HStack spacing={12} padding={{ horizontal: pageInsets.horizontal, top: 4, bottom: 18 }}>
            {items.map(item => (
              <NavigationLink
                key={comicGroupKey(item.favorite)}
                destination={
                  <ComicDetailScreen
                    sourceKey={item.favorite.sourceKey}
                    comicId={item.favorite.comicId}
                    title={item.favorite.title}
                  />
                }
                buttonStyle="plain"
              >
                <VStack spacing={6} alignment="leading" frame={{ width: RAIL_COVER.width }}>
                  <ZStack alignment="topTrailing">
                    <CoverImage
                      sourceKey={item.favorite.sourceKey}
                      url={item.favorite.cover}
                      width={RAIL_COVER.width}
                      height={RAIL_COVER.height}
                      title={item.favorite.title}
                      lifted={true}
                    />
                    {/* 封面右上角未讀亮點 */}
                    <HStack padding={5}>
                      <Circle
                        frame={{ width: 8, height: 8 }}
                        fill={tint.tint}
                        stroke={cardBackground}
                      />
                    </HStack>
                  </ZStack>

                  {/* 作品名稱（一行截斷） */}
                  <Text
                    font="caption"
                    fontWeight="semibold"
                    lineLimit={1}
                    frame={{ width: RAIL_COVER.width, alignment: "leading" }}
                  >
                    {item.favorite.title}
                  </Text>

                  {/* 最新話數（一行截斷） */}
                  {item.record.latestEpTitle ? (
                    <Text
                      font="caption2"
                      foregroundStyle="secondaryLabel"
                      lineLimit={1}
                      frame={{ width: RAIL_COVER.width, alignment: "leading" }}
                    >
                      {item.record.latestEpTitle}
                    </Text>
                  ) : null}
                </VStack>
              </NavigationLink>
            ))}
          </HStack>
        </ScrollView>
      )}
    </VStack>
  )
}
