// 漫畫詳情、收藏與章節閱讀入口。

import {
  Button,
  Divider,
  GeometryReader,
  Group,
  HStack,
  Image,
  LazyVStack,
  LazyHStack,
  Menu,
  NamespaceReader,
  Navigation,
  NavigationLink,
  NavigationStack,
  ScrollView,
  Section,
  Spacer,
  Text,
  Toolbar,  ToolbarItem,
  ToolbarSpacer,
  VStack,
  ZStack,
  useEffect,
  useColorScheme,
  useMemo,
  useState,
  type Color,
  type VirtualNode,
} from "scripting"

import { CoverBadge } from "../../design/CoverBadge"
import { CoverImage } from "../../components/CoverImage"
import { WidthReporter } from "../../components/WidthReporter"
import { CoverViewerScreen } from "./CoverViewerScreen"
import { isActive, type ChapterDownloadState, type ComicLibrary, type ComicPage, type ComicRef } from "../../app/comic"
import { comicLibrary } from "../../app/services"
import { comicUpdateRecord, pauseUpdates, resumeUpdates } from "../../app/updates"
import { useSubscription } from "../../app/useSubscription"
import { subscribe as subscribeLocale, t } from "../../i18n"
import {
  isFavorite,
  markAllChaptersRead,
  markChapterRead,
  readChapterIds,
  setComicUpdate,
  toggleFavorite,
} from "../../library/bookshelf"
import { formatStars } from "../../design/rating"
import { sourcesRevision } from "../../sources/registry"
import { CommentScreen } from "./CommentScreen"
import { SourceSwitchSheet } from "./SourceSwitchSheet"
import {
  ChapterListHeader,
  ChapterSelectionBar,
  selectionAnimation,
  selectionBarClearance,
  SelectionTabBarHider,
} from "./ChapterSelection"
import { heroCoverSize, recommendCardSize } from "./comicMetrics"
import { presentReader } from "./ResumeReaderScreen"
import { type ChapterRef } from "./ReaderScreen"
import { groupChapters, resolveInitialGroupName, type ChapterGroup } from "./chapterGrouping"
import { PageBackground, useTint } from "../../app/theme"
import { cardBackground, cardShape, capsule, fill, pageInsets, pageSpacing, palette, radius, rect, rowPadding } from "../../design/tokens"
import { Card } from "../../design/layout"
import { Tag } from "../../design/Tag"
import { Chip } from "../../design/chip"
import { NoticeBanner } from "../../design/status"
import { SkeletonBlock, SkeletonText } from "../../design/skeleton"
import { GlassSurface } from "../../design/GlassSurface"
import { liquidGlass, scrollTopBar } from "../../design/glass"

/**
 * 批次解析章節下載狀態映射表（單次重繪單一章節僅查詢一次，提升效能）。
 */
export function chapterDownloadStates(
  library: Pick<ComicLibrary, "downloadState">,
  ref: ComicRef,
  epIds: string[]
): Record<string, ChapterDownloadState> {
  const states = new Map<string, ChapterDownloadState>()
  for (const epId of epIds) {
    if (!states.has(epId)) states.set(epId, library.downloadState({ ...ref, epId }))
  }
  // 攤成物件：呼叫端只讀自己問過的 epId，取值不必再判 undefined。
  return Object.fromEntries(states)
}

/** 「全部已讀」算的章節：鎖定的看不到內容，標了也沒意義，直接排除。 */
export function readableChapters<T extends { locked?: boolean }>(chapters: readonly T[]): T[] {
  return chapters.filter(chapter => chapter.locked !== true)
}

/** 連載狀態的介面字（源只給代碼，畫面負責翻）。 */
function statusText(status: NonNullable<ComicPage["status"]>): string {
  switch (status) {
    case "ongoing":
      return t("detail.statusOngoing")
    case "completed":
      return t("detail.statusCompleted")
    case "cancelled":
      return t("detail.statusCancelled")
    case "hiatus":
      return t("detail.statusHiatus")
    case "notPublished":
      return t("detail.statusNotPublished")
  }
}

/** 選取圓點的欄位寬：平常 0，選取時擐開把標題推向右，圓點從卡片左緣外滑入。 */
const markSlotWidth = 28

/** 只有 `suggestive`／`nsfw` 會走到這裡（safe 不占位置）。 */
function ratingText(rating: NonNullable<ComicPage["contentRating"]>): string {
  return rating === "nsfw" ? t("detail.ratingNsfw") : t("detail.ratingSuggestive")
}

/** hero 右欄顯示的資訊；抽出來是為了讓預覽用假資料畫同一份版面。 */
export type ComicHeroData = Pick<
  ComicPage,
  | "title"
  | "sourceName"
  | "uploader"
  | "artists"
  | "status"
  | "contentRating"
  | "stars"
  | "likesCount"
  | "updateTime"
  | "uploadTime"
>

/** 分級角標（R18 紅字、建議級白字）貼在封面右上角；safe 不畫。 */
export function ComicRatingBadge({ rating }: { rating?: ComicPage["contentRating"] }) {
  if (!rating || rating === "safe") return null
  return (
    <HStack offset={{ x: -6, y: 6 }}>
      <CoverBadge
        text={ratingText(rating)}
        icon={rating === "nsfw" ? "exclamationmark.triangle.fill" : "info.circle"}
        tone={rating === "nsfw" ? "danger" : "default"}
      />
    </HStack>
  )
}

export function ComicHeroMeta({
  meta,
  onSwitchSource,
}: {
  meta: ComicHeroData
  /** 點來源 chip：開換源 sheet。 */
  onSwitchSource: () => void
}) {
  const rating = formatStars(meta.stars)

  return (
    <VStack
      alignment="leading"
      spacing={8}
      frame={{ maxWidth: "infinity", alignment: "leading" }}
      fixedSize={{ horizontal: false, vertical: true }}
    >
      <Text
        font="title3"
        fontWeight="bold"
        lineLimit={3}
        multilineTextAlignment="leading"
        fixedSize={{ horizontal: false, vertical: true }}
      >
        {meta.title}
      </Text>

      {/* 來源是可點的 chip（玻璃＝可操作）。 */}
      <Chip
        compact
        text={meta.sourceName}
        chevron
        onTap={onSwitchSource}
        accessibilityLabel={t("detail.switchSource")}
      />

      {/* 唯讀星等與喜愛數：源有給才出現。分級不在這裡，它是封面的角標。 */}
      {rating || (meta.likesCount != null && meta.likesCount > 0) ? (
        <HStack spacing={8} alignment="center">
          {rating ? <Tag text={`${rating.glyphs} ${rating.score}`} tone="warning" /> : null}

          {meta.likesCount != null && meta.likesCount > 0 ? (
            <Tag
              icon="heart.fill"
              tone="love"
              accessibilityLabel={t("detail.likesCount", { n: meta.likesCount })}
              text={
                meta.likesCount >= 10000
                  ? `${(meta.likesCount / 10000).toFixed(1)}w`
                  : meta.likesCount >= 1000
                  ? `${(meta.likesCount / 1000).toFixed(1)}k`
                  : String(meta.likesCount)
              }
            />
          ) : null}
        </HStack>
      ) : null}

      {/* 連載狀態、作者作畫、時間：共三層，各自一行。 */}
      {meta.status ? <Tag text={statusText(meta.status)} /> : null}

      {meta.uploader ? (
        <Text font="footnote" foregroundStyle="secondaryLabel" lineLimit={2}>
          {t("detail.author", { name: meta.uploader })}
        </Text>
      ) : null}

      {meta.artists ? (
        <Text font="footnote" foregroundStyle="secondaryLabel" lineLimit={2}>
          {t("detail.artist", { name: meta.artists })}
        </Text>
      ) : null}

      {meta.updateTime || meta.uploadTime ? (
        <Text font="caption2" foregroundStyle="tertiaryLabel" lineLimit={1}>
          {meta.updateTime
            ? t("detail.updatedAt", { time: meta.updateTime })
            : t("detail.uploadedAt", { time: meta.uploadTime! })}
        </Text>
      ) : null}
    </VStack>
  )
}

/**
 * 詳情頁的「第一幀」快取：只在記憶體、跟著 app 一起消失。
 *
 * 用途只有一個——退回詳情頁時不要閃骨架：重掛時先畫上次的內容，背景照樣重抓一次最新。
 * 刻意**不**做 TTL、也**不**跳過重抓：詳情頁的職責是顯示最新話，跳過只會讓新章晚到。
 * 源變過（安裝／移除／更新）就靠 revision 換 key，舊資料自然淘汰。
 */
const DETAIL_CACHE_LIMIT = 8
const detailCache = new Map<string, ComicPage>()

function detailCacheKey(sourceKey: string, comicId: string): string {
  return `${sourcesRevision()}\n${sourceKey}\n${comicId}`
}

function readDetailCache(sourceKey: string, comicId: string): ComicPage | undefined {
  return detailCache.get(detailCacheKey(sourceKey, comicId))
}

function writeDetailCache(sourceKey: string, comicId: string, page: ComicPage): void {
  const key = detailCacheKey(sourceKey, comicId)
  // 重新寫入要排到最後：Map 的插入序就是我們的 LRU。
  detailCache.delete(key)
  detailCache.set(key, page)
  while (detailCache.size > DETAIL_CACHE_LIMIT) {
    const oldest = detailCache.keys().next().value
    if (oldest === undefined) break
    detailCache.delete(oldest)
  }
}

export function ComicDetailScreen({
  sourceKey: initialSourceKey,
  comicId: initialComicId,
  title: initialTitle,
  zoomTransition,
}: {
  sourceKey: string
  comicId: string
  title: string
  zoomTransition?: {
    sourceID: string | number
    namespace: NamespaceID
  }
}) {
  const library = comicLibrary()
  // 換源＝就地換掉這一頁看的作品：以下全部讀這兩個名字，不必再推一層詳情頁。
  const [active, setActive] = useState<ComicRef>({ sourceKey: initialSourceKey, comicId: initialComicId })
  const sourceKey = active.sourceKey
  const comicId = active.comicId
  // 換源後、新詳情回來前先顯示新書名（不然會停在舊的那本）。
  const [pendingTitle, setPendingTitle] = useState(initialTitle)
  // 帶色玻璃只吃 Color：先拿目前的方案解成字串。
  const tint = useTint()
  const tintColor = String(tint.tint[useColorScheme()]) as Color
  const [detail, setDetail] = useState<ComicPage | null>(() => readDetailCache(initialSourceKey, initialComicId) ?? null)
  // 載入失敗的原因；null＝沒話要說（載入中也算，那一句在 render 時才算）。
  const [status, setStatus] = useState<string | null>(null)
  const [reverseOrder, setReverseOrder] = useState(false)
  const [descExpanded, setDescExpanded] = useState(false)
  // 多選下載模式：已勾選待下載的章節 ID 清單
  const [selecting, setSelecting] = useState(false)
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  // 依容器實測寬度動態計算 hero 封面尺寸
  const [heroContainerWidth, setHeroContainerWidth] = useState(0)
  // 頂部氛圍光暈圖片
  const [ambientImage, setAmbientImage] = useState<UIImage | null>(null)
  // 滾動離開視線時才在導航欄顯示書名
  const [showNavTitle, setShowNavTitle] = useState(false)

  // 訂閱來源變更、下載進度、書架狀態與語言切換
  const refresh = useSubscription(library.onChange, subscribeLocale)

  // 收藏狀態直接從書架讀取
  const favorite = isFavorite(sourceKey, comicId)

  // 詳情頁在畫面上（含被閱讀器蓋住的期間）就是前台：背景追更先讓路，別跟這裡搶連線。
  useEffect(() => {
    pauseUpdates()
    return () => resumeUpdates()
  }, [])

  useEffect(() => {
    let alive = true
    // 換源時先把舊作品收掉：留著會短暫顯示上一個來源的封面與章節。
    // 有快取就直接當第一幀（退回來不閃骨架），背景照樣重抓最新。
    setDetail(readDetailCache(sourceKey, comicId) ?? null)
    setStatus(null)
    // 詳情走 ComicLibrary：這一頁不再自己 loadDetail，也不必知道源回傳的原始形狀。
    // 找不到源／沒載入成功都在庫的邊界變成可讀的錯誤訊息。
    library
      .comic({ sourceKey, comicId })
      .then(
        result => {
          if (!alive) return
          setDetail(result)
          setStatus(null)
          writeDetailCache(sourceKey, comicId, result)
          // 零成本同步：章節清單已經在手上，不必再為了「有沒有新話」問一次源。
          if (result.chapters.length > 0) setComicUpdate(comicUpdateRecord(result))
        },
        error => {
          if (alive) setStatus(error instanceof Error ? error.message : String(error))
        }
      )
    return () => {
      alive = false
    }
  }, [sourceKey, comicId])

  // 章節清單的轉換只有一份（`ComicLibrary.readerChapters`）：詳情頁與續讀拿到的是同一個形狀。
  const chapters: ChapterRef[] = detail ? library.readerChapters(detail) : []

  // 續讀點：ComicLibrary 會把越界的頁碼 clamp 到合法範圍；沒讀過就是 null。
  const resumed = library.resume({ sourceKey, comicId })
  const comicTitle = detail?.title ?? pendingTitle
  const comicCover = detail?.cover

  // 章節分組（當源有多個不同 group 時支援分組分頁切換）
  const chapterGroups: ChapterGroup<ChapterRef>[] = useMemo(() => groupChapters(chapters), [chapters])
  const isGrouped = chapterGroups.length > 1
  const initialGroupName = useMemo(
    () => resolveInitialGroupName(chapterGroups, resumed?.chapter.epId),
    [chapterGroups, resumed?.chapter.epId]
  )
  const [selectedGroup, setSelectedGroup] = useState<string>("")
  const activeGroup = selectedGroup && chapterGroups.some((g: ChapterGroup<ChapterRef>) => g.name === selectedGroup)
    ? selectedGroup
    : initialGroupName

  // 當前選取分組中的章節（若無分組則為全部章節）
  const currentGroupChapters: ChapterRef[] = useMemo(() => {
    if (!isGrouped) return chapters
    const matched = chapterGroups.find((g: ChapterGroup<ChapterRef>) => g.name === activeGroup)
    return matched ? matched.chapters : chapters
  }, [isGrouped, chapterGroups, activeGroup, chapters])

  // 已讀章節：手動標記與閱讀結算共用同一份紀錄（`Progress.readEpIds`）。
  const readIds = readChapterIds(sourceKey, comicId)

  useEffect(() => {
    if (!comicCover) {
      // 換源後新作品還沒回來：舊作品的氛圍光暈要一起收掉。
      setAmbientImage(null)
      return
    }
    let alive = true
    void comicLibrary()
      .thumbnailPath(sourceKey, comicCover)
      .then(path => {
        if (!alive) return
        const img = UIImage.fromFile(path)
        if (img) setAmbientImage(img)
      })
      .catch(() => {})
    return () => {
      alive = false
    }
  }, [sourceKey, comicCover])

  const readerProps = {
    sourceKey,
    comicId,
    chapters,
    comicTitle,
    comicCover,
    viewer: detail?.viewer,
  }

  // 確定首選閱讀章節：優先續讀上次進度，無進度則自第一話起算（鎖定的章節不自動開）。
  const firstReadable = chapters.find(chapter => !chapter.locked)
  const resumedReadable =
    resumed && chapters.some(c => c.id === resumed.chapter.epId && !c.locked) ? resumed.chapter.epId : undefined
  const targetEpId = resumedReadable ?? firstReadable?.id

  const targetEpTitle = chapters.find(chapter => chapter.id === targetEpId)?.title

  // 上次讀到的頁碼（只有續讀同一話時才帶，換話從頭）。
  const resumePage = resumed && resumed.chapter.epId === targetEpId ? resumed.page : undefined

  // 整理所有標籤
  const allTags = (detail?.tags ?? []).flatMap(g => g.values)

  // 簡介文字清洗
  const cleanDescription = (detail?.description ?? "")
    .replace(/\\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim()

  const isLongDescription = cleanDescription.length > 60 || cleanDescription.split("\n").length > 2

  // 章節排序（針對當前分組）
  const displayChapters = reverseOrder ? [...currentGroupChapters].reverse() : currentGroupChapters

  // 依當前重繪單一快照查詢章節下載狀態表
  const chapterStates = chapterDownloadStates(library, { sourceKey, comicId }, [
    ...chapters.map(chapter => chapter.id),
    ...selectedIds,
  ])

  // 選取模式的兩個數字：都只算「尚未下載」且非鎖定的章節（鎖定的不能下載）。
  function pendingOf(epIds: string[]): string[] {
    return epIds.filter(epId => {
      if (chapters.find(chapter => chapter.id === epId)?.locked) return false
      return chapterStates[epId].state !== "done"
    })
  }

  const pendingAll = pendingOf(currentGroupChapters.map(chapter => chapter.id))
  const pendingSelected = pendingOf(selectedIds)

  // 「全部已讀」只看當前分組裡沒被源鎖定的章節。
  const readable = readableChapters(currentGroupChapters)
  const unreadCount = readable.filter(chapter => !readIds.has(chapter.id)).length
  const allSelected = readable.length > 0 && readable.every(chapter => selectedIds.includes(chapter.id))

  /** 選取模式：「全選 / 取消全選」切換。 */
  function toggleSelectAll() {
    if (allSelected) {
      setSelectedIds([])
    } else {
      setSelectedIds(readable.map(chapter => chapter.id))
    }
  }

  /** 這一組章的漫畫資訊（下載頁要顯示的名稱與封面）；詳情還沒到就沒有。 */
  const downloadMeta = detail ? { comicTitle: detail.title, cover: detail.cover } : undefined

  /** 換源 sheet：選了就把這一頁換成該來源的作品（同一個導覽位置，不推新頁）。 */
  async function openSwitch() {
    await Navigation.present({
      element: (
        <NavigationStack>
          <SourceSwitchSheet
            sourceKey={sourceKey}
            title={comicTitle}
            onPick={(ref, nextTitle) => {
              setPendingTitle(nextTitle)
              setSelecting(false)
              setSelectedIds([])
              setActive(ref)
            }}
          />
        </NavigationStack>
      ),
      modalPresentationStyle: "pageSheet",
    })
  }

  /** 選取模式：點列＝切換勾選（不是進閱讀器）；鎖定的章節不能選。 */
  function toggleSelected(epId: string) {
    if (chapters.find(chapter => chapter.id === epId)?.locked) return
    setSelectedIds(previous =>
      previous.includes(epId) ? previous.filter(item => item !== epId) : [...previous, epId]
    )
  }

  /** 「下載 (n)」：只送還沒下載的章節，送出後退出選取模式。 */
  function downloadSelected() {
    const requests = pendingSelected.map(epId => ({
      sourceKey,
      comicId,
      epId,
      title: chapters.find(chapter => chapter.id === epId)?.title,
    }))
    if (requests.length > 0) void library.download(requests, downloadMeta)
    setSelectionMode(false)
  }

  /** 「下載全部」：僅下載當前選中組別（避免多語言源一次下載所有語言）。 */
  function downloadAll() {
    const requests = currentGroupChapters.map(chapter => ({ sourceKey, comicId, epId: chapter.id, title: chapter.title }))
    if (requests.length > 0) void library.download(requests, downloadMeta)
  }

  /** 單章下載的觸發（章節列左滑）。 */
  function downloadChapter(chapter: ChapterRef) {
    void library.download(
      [{ sourceKey, comicId, epId: chapter.id, title: chapter.title }],
      downloadMeta
    )
  }

  /** 章節列左滑：反轉這一話的已讀狀態。 */
  function toggleRead(chapter: ChapterRef) {
    markChapterRead(sourceKey, comicId, [chapter.id], !readIds.has(chapter.id))
  }

  /** 這一話之前（章節順序，不是畫面排序）、同一分組裡讀得到的章節。 */
  function chaptersBefore(chapter: ChapterRef): ChapterRef[] {
    const index = currentGroupChapters.findIndex(item => item.id === chapter.id)
    return index > 0 ? readableChapters(currentGroupChapters.slice(0, index)) : []
  }

  /** 長按選單「之前的章節」：一次標成已讀或未讀。 */
  function markChaptersBefore(chapter: ChapterRef, read: boolean) {
    const ids = chaptersBefore(chapter).map(item => item.id)
    if (ids.length > 0) markChapterRead(sourceKey, comicId, ids, read)
  }

  function cancelChapterDownload(chapter: ChapterRef) {
    library.cancelDownload({ sourceKey, comicId, epId: chapter.id })
  }

  /** 刪掉這一話的離線檔（下載中的先取消、等任務收尾再刪，見 offline.deleteChapter）。 */
  function removeChapterDownload(chapter: ChapterRef) {
    void library.offline.deleteChapter({ sourceKey, comicId, epId: chapter.id })
  }

  /** 「全部標為已讀」：一次標完當前分組裡還讀得到的章節。 */
  function markGroupRead() {
    markAllChaptersRead(
      sourceKey,
      comicId,
      readable.map(chapter => chapter.id)
    )
  }

  /** 選取模式的「標為已讀」：勾起來的一次標完，然後退出選取。 */
  function markSelectedRead() {
    if (selectedIds.length === 0) return
    markChapterRead(sourceKey, comicId, selectedIds, true)
    setSelectionMode(false)
  }

  /** 進出選取模式：清空勾選，工具列與圓點用動畫切換。 */
  function setSelectionMode(on: boolean) {
    void withAnimation(selectionAnimation, () => {
      setSelecting(on)
      setSelectedIds([])
    })
  }

  // 封面尺寸：容器給多少寬度就用多少（見 comicHeroMetrics 與 docs/ui-ux-liquid-glass.md）。
  const hero = heroCoverSize(heroContainerWidth)

  return (
    <ZStack
      navigationTransition={
        zoomTransition
          ? {
              type: "zoom",
              sourceID: zoomTransition.sourceID,
              namespace: zoomTransition.namespace,
            }
          : undefined
      }
      // 被閱讀器蓋住時不會重繪；退回來要靠 onAppear 重新讀一次書架/進度，
      // 否則收藏愛心與「上次讀到」會停在進閱讀器前的舊狀態。
      onAppear={() => refresh()}
    >
      <PageBackground />

      {/* 頂部封面 Ambient Glow 氛圍漫射光暈。
          氛圍圖一定要用「量到的容器寬」：`maxWidth: "infinity"` 會讓圖片拿自己的寬高比
          （380 × 寬/高）當理想寬度，橫式封面就變成整頁寬度，把整頁推歪（內容偏左、標題切到右緣）。
          實測：同一個橫式封面，量寬前 798、量寬後 402。 */}
      {ambientImage ? (
        <GeometryReader>
          {geometry => (
            <VStack
              frame={{ width: geometry.size.width, height: 380, alignment: "top" }}
              offset={{ x: 0, y: -60 }}
              allowsHitTesting={false}
            >
              <Image
                image={ambientImage}
                resizable={true}
                scaleToFill={true}
                frame={{ width: geometry.size.width, height: 380 }}
                blur={70}
                opacity={0.35}
              />
            </VStack>
          )}
        </GeometryReader>
      ) : null}

      <VStack
        spacing={0}
        navigationTitle={showNavTitle ? comicTitle : ""}
        navigationBarTitleDisplayMode="inline"
        toolbar={
          <Toolbar>
            {detail?.url ? (
              <ToolbarItem placement="topBarTrailing">
                <Button
                  buttonStyle="plain"
                  accessibilityLabel={t("detail.openInBrowser")}
                  action={() => {
                    void Safari.openURL(detail.url!)
                  }}
                >
                  <Image
                    systemName="safari"
                    font="body"
                    fontWeight="medium"
                    foregroundStyle="label"
                  />
                </Button>
              </ToolbarItem>
            ) : null}
            {detail?.url && liquidGlass ? (
              <ToolbarSpacer sizing="fixed" placement="topBarTrailing" />
            ) : null}
            <ToolbarItem placement="topBarTrailing">
              <Button
                buttonStyle="plain"
                accessibilityLabel={favorite ? t("detail.unfavorite") : t("detail.favorite")}
                action={() => {
                  toggleFavorite({
                    sourceKey,
                    comicId,
                    title: comicTitle,
                    cover: comicCover,
                  })
                }}
              >
                <Image
                  systemName={favorite ? "heart.fill" : "heart"}
                  font="body"
                  fontWeight="medium"
                  foregroundStyle={favorite ? "systemRed" : "label"}
                />
              </Button>
            </ToolbarItem>
          </Toolbar>
        }
    >
      <SelectionTabBarHider selecting={selecting} />

      {/* 載入初態；失敗時同一個位置顯示錯誤訊息 */}
      {!detail && status ? (
        <VStack padding={pageInsets} frame={{ maxWidth: "infinity" }}>
          <NoticeBanner tone="error" text={status} />
        </VStack>
      ) : null}
      {!detail && !status ? <DetailSkeleton cover={heroCoverSize(heroContainerWidth)} /> : null}

      {detail ? (
        <ScrollView
          scrollContentBackground="hidden"
          frame={{ maxWidth: "infinity" }}
          // 跟首頁一樣：內容捲到導覽列下面時是柔和淡出，不是硬邊的分隔線。
          {...scrollTopBar(null)}
          overlay={{
            alignment: "bottom",
            content: (
              <ChapterSelectionBar
                visible={selecting}
                allSelected={allSelected}
                downloadCount={pendingSelected.length}
                readCount={selectedIds.length}
                onToggleAll={toggleSelectAll}
                onDownload={downloadSelected}
                onMarkRead={markSelectedRead}
              />
            ),
          }}
          onScrollTargetVisibilityChange={{
            idType: "string",
            threshold: 0.1,
            onChanged: ids => {
              setShowNavTitle(!(ids as string[]).includes("hero-title"))
            },
          }}
          // 量到的容器寬（hero 封面尺寸用）。`maxWidth: "infinity"` 會讓圖片拿自己的寬高比
          // （380 × 寬/高）當理想寬度，橫式封面就變成整頁寬度，把整頁推歪
          // （實測：同一個橫式封面，量寬前 798、量寬後 402）。
          background={
            <GeometryReader>
              {geometry => (
                <WidthReporter
                  width={geometry.size.width}
                  onWidth={width => setHeroContainerWidth(Math.round(width))}
                />
              )}
            </GeometryReader>
          }
        >
          <VStack
            spacing={pageSpacing}
            padding={pageInsets}
            scrollTargetLayout={true}
            frame={{ maxWidth: "infinity" }}
          >

            {/* 1. Hero 頂部海報與元資訊 */}
            <HStack
              key="hero-title"
              spacing={16}
              alignment="top"
              frame={{ maxWidth: "infinity" }}
            >
            <NamespaceReader>
              {heroNs => (
                // 點 hero 封面 → 全螢幕看原圖（不裁切的完整封面）。
                // 用 NavigationLink **推入**（不是 modal）：只有推入頁面才會有 zoom 轉場動畫
                // （modal 的 navigationTransition 引擎不觸發，實測過）。
                <NavigationLink
                  destination={
                    <CoverViewerScreen
                      sourceKey={sourceKey}
                      url={comicCover}
                      title={comicTitle}
                      zoomTransition={{ sourceID: `detail-hero:${sourceKey}:${comicId}`, namespace: heroNs }}
                    />
                  }
                  buttonStyle="plain"
                >
                  <ZStack
                    alignment="topTrailing"
                    matchedTransitionSource={{ id: `detail-hero:${sourceKey}:${comicId}`, namespace: heroNs }}
                  >
                    <CoverImage
                      sourceKey={sourceKey}
                      url={comicCover}
                      width={hero.width}
                      height={hero.height}
                      cornerRadius={radius.md}
                      title={comicTitle}
                      lifted={true}
                    />
                    <ComicRatingBadge rating={detail.contentRating} />
                  </ZStack>
                </NavigationLink>
              )}
            </NamespaceReader>

              <ComicHeroMeta meta={detail} onSwitchSource={() => void openSwitch()} />
            </HStack>

            {/* 閱讀入口與動作列（開始閱讀 + 收藏 + 評論留言） */}
            <HStack spacing={10} alignment="center" frame={{ maxWidth: "infinity" }}>
              {targetEpId ? (
                // 閱讀器一律用全螢幕呈現（不是推入）：推入的話狀態列與 tab bar 的修飾子會被導覽容器吃掉。
                <Button
                  action={() => void presentReader({ ...readerProps, epId: targetEpId, initialPage: resumePage })}
                  buttonStyle="plain"
                >
                  <GlassSurface shape={rect(radius.lg)} tint={tintColor} interactive={true}>
                    <HStack
                      spacing={10}
                      alignment="center"
                      padding={{ horizontal: 16, vertical: 0 }}
                      frame={{ maxWidth: "infinity", height: 64 }}
                    >
                      <Spacer />
                      <Image
                        systemName="book.fill"
                        font="title3"
                        foregroundStyle={tint.onTint}
                      />
                      <VStack alignment="leading" spacing={2}>
                        <Text font="headline" fontWeight="bold" foregroundStyle={tint.onTint}>
                          {resumed ? t("detail.resumeReading") : t("detail.startReading")}
                        </Text>
                        <Text font="caption2" fontWeight="medium" foregroundStyle={tint.onTint} opacity={0.75} lineLimit={1}>
                          {targetEpTitle
                            ? resumePage !== undefined
                              ? t("detail.chapterAtPage", { chapter: targetEpTitle, n: resumePage + 1 })
                              : targetEpTitle
                            : t("detail.firstChapter")}
                        </Text>
                      </VStack>
                      <Spacer />
                    </HStack>
                  </GlassSurface>
                </Button>
              ) : chapters.length > 0 ? (
                // 有章節但全部鎖定：不讓入口消失，改成看得懂的狀態。
                <GlassSurface shape={rect(radius.lg)}>
                  <HStack
                    spacing={10}
                    alignment="center"
                    padding={{ horizontal: 16, vertical: 0 }}
                    frame={{ maxWidth: "infinity", height: 64 }}
                  >
                    <Spacer />
                    <Image systemName="lock.fill" font="title3" foregroundStyle="secondaryLabel" />
                    <Text font="headline" fontWeight="semibold" foregroundStyle="secondaryLabel">
                      {t("detail.allChaptersLocked")}
                    </Text>
                    <Spacer />
                  </HStack>
                </GlassSurface>
              ) : null}

              {/* 收藏按鈕 */}
              <Button
                buttonStyle="plain"
                accessibilityLabel={favorite ? t("detail.unfavorite") : t("detail.favorite")}
                action={() => {
                  toggleFavorite({
                    sourceKey,
                    comicId,
                    title: comicTitle,
                    cover: comicCover,
                  })
                }}
              >
                <GlassSurface shape={rect(radius.lg)} interactive={true}>
                  <VStack alignment="center" spacing={4} frame={{ width: 54, height: 64 }}>
                    <Image
                      systemName={favorite ? "heart.fill" : "heart"}
                      font="title3"
                      foregroundStyle={favorite ? "systemRed" : "label"}
                    />
                    <Text
                      font="caption2"
                      fontWeight="medium"
                      foregroundStyle={favorite ? "systemRed" : "secondaryLabel"}
                    >
                      {favorite ? t("detail.favorited") : t("detail.favorite")}
                    </Text>
                  </VStack>
                </GlassSurface>
              </Button>

              {/* 評論留言入口：源沒宣告 loadComments 就完全不出現 */}
              {detail.comments ? (
                <NavigationLink
                  destination={
                    <CommentScreen sourceKey={sourceKey} comicId={comicId} subId={detail.subId} />
                  }
                  buttonStyle="plain"
                  accessibilityLabel={t("comments.title")}
                >
                  <GlassSurface shape={rect(radius.lg)} interactive={true}>
                    <VStack alignment="center" spacing={4} frame={{ width: 54, height: 64 }}>
                      <Image
                        systemName="bubble.left.and.bubble.right"
                        font="title3"
                        foregroundStyle="label"
                      />
                      <Text font="caption2" fontWeight="medium" foregroundStyle="secondaryLabel">
                        {t("comments.title")}
                      </Text>
                    </VStack>
                  </GlassSurface>
                </NavigationLink>
              ) : null}
            </HStack>

            <Divider />

            {/* 3. 標籤膠囊群 (Pills)：約束在 maxWidth: "infinity" 內，防止大量 tags 撐破父容器 */}
            {allTags.length > 0 ? (
              <ScrollView axes="horizontal" scrollIndicator="hidden" frame={{ maxWidth: "infinity" }}>
                <HStack spacing={8}>
                  {allTags.map((tag, i) => (
                    <Tag key={`tag:${i}:${tag}`} text={tag} />
                  ))}
                </HStack>
              </ScrollView>
            ) : null}

            {/* 4. 故事簡介（長文本自然漸隱淡出，短文本完整清晰不模糊） */}
            {cleanDescription ? (
              <VStack alignment="leading" spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                <HStack>
                  <Text font="headline" fontWeight="bold">
                    {t("detail.summary")}
                  </Text>
                  <Spacer />
                  {isLongDescription ? (
                    <Button
                      buttonStyle="plain"
                      action={() => setDescExpanded(!descExpanded)}
                    >
                      <HStack spacing={2} alignment="center">
                        <Text font="caption2" foregroundStyle={tint.tint} fontWeight="medium">
                          {descExpanded ? t("detail.collapse") : t("detail.expand")}
                        </Text>
                        <Image
                          systemName={descExpanded ? "chevron.up" : "chevron.down"}
                          font="caption2"
                          foregroundStyle={tint.tint}
                        />
                      </HStack>
                    </Button>
                  ) : null}
                </HStack>
                <Text
                  font="footnote"
                  foregroundStyle={
                    !isLongDescription || descExpanded
                      ? "secondaryLabel"
                      : {
                          colors: ["secondaryLabel", "secondaryLabel", fill.fade],
                          startPoint: "top",
                          endPoint: "bottom",
                        }
                  }
                  lineLimit={!isLongDescription || descExpanded ? undefined : 3}
                  frame={{ maxWidth: "infinity", alignment: "leading" }}
                  multilineTextAlignment="leading"
                  onTapGesture={isLongDescription ? () => setDescExpanded(!descExpanded) : undefined}
                >
                  {cleanDescription}
                </Text>
              </VStack>
            ) : null}

            {/* 4.5 相關推薦漫畫（若源有提供，置於簡介下方與章節列表上方） */}
            {detail.recommend && detail.recommend.length > 0 ? (
              <VStack spacing={10} alignment="leading" frame={{ maxWidth: "infinity" }}>
                <HStack alignment="firstTextBaseline" spacing={6}>
                  <Text font="headline" fontWeight="bold">
                    {t("detail.recommendTitle")}
                  </Text>
                  <Text font="caption" fontWeight="medium" foregroundStyle="tertiaryLabel">
                    {detail.recommend.length}
                  </Text>
                  <Spacer />
                </HStack>

                <ScrollView axes="horizontal" scrollIndicator="hidden" padding={{ horizontal: -pageInsets.horizontal }}>
                  <LazyHStack spacing={10} padding={{ horizontal: pageInsets.horizontal, vertical: 8 }}>
                    {detail.recommend.map((item, idx) => {
                      const recCard = recommendCardSize(heroContainerWidth)
                      return (
                        <NavigationLink
                          key={item.id ?? idx}
                          buttonStyle="plain"
                          destination={
                            <ComicDetailScreen
                              sourceKey={sourceKey}
                              comicId={item.id}
                              title={item.title}
                            />
                          }
                        >
                          <VStack alignment="center" spacing={5} frame={{ width: recCard.width }}>
                            <CoverImage
                              sourceKey={sourceKey}
                              url={item.cover}
                              width={recCard.width}
                              height={recCard.height}
                              cornerRadius={radius.md}
                              title={item.title}
                              lifted={true}
                            />
                            <Text
                              font="caption"
                              fontWeight="medium"
                              foregroundStyle="label"
                              lineLimit={1}
                              frame={{ width: recCard.width, alignment: "center" }}
                            >
                              {item.title}
                            </Text>
                          </VStack>
                        </NavigationLink>
                      )
                    })}
                  </LazyHStack>
                </ScrollView>
              </VStack>
            ) : null}

            {/* 5. 章節列表頭部（緊湊合一工具列，大幅減少垂直佔位） */}
            <VStack spacing={12}>
              <ChapterListHeader
                selecting={selecting}
                selectedCount={selectedIds.length}
                countText={isGrouped ? `${currentGroupChapters.length} / ${chapters.length}` : String(chapters.length)}
                reverseOrder={reverseOrder}
                canMarkAllRead={unreadCount > 0}
                canDownloadAll={pendingAll.length > 0}
                onToggleSort={() => setReverseOrder(!reverseOrder)}
                onToggleSelecting={() => setSelectionMode(!selecting)}
                onMarkAllRead={markGroupRead}
                onDownloadAll={downloadAll}
              />

              {/* 5.1 分組切換標籤列（僅在有多個分組時顯示，水平滾動膠囊列） */}
              {isGrouped ? (
                <ScrollView axes="horizontal" scrollIndicator="hidden">
                  <HStack spacing={8} padding={{ vertical: 2 }}>
                    {chapterGroups.map((group: ChapterGroup<ChapterRef>) => {
                      const isCurrentGroup = group.name === activeGroup
                      return (
                        <Chip
                          key={group.name}
                          compact
                          text={group.name}
                          detail={String(group.chapters.length)}
                          selected={isCurrentGroup}
                          onTap={() => {
                            setSelectedGroup(group.name)
                            setSelectedIds([])
                          }}
                        />
                      )
                    })}
                  </HStack>
                </ScrollView>
              ) : null}

              {/* 章節卡片流（左滑＝切換已讀 ／ 單章下載；自訂列的滑動要外層 swipeActionsContainer） */}
              <LazyVStack spacing={8} swipeActionsContainer={true}>
                {displayChapters.map(chapter => {
                  const isCurrent = resumed?.chapter.epId === chapter.id
                  const locked = chapter.locked === true
                  // 已讀＝淡化；當前話的強調色優先，看得到自己讀到哪。
                  const read = readIds.has(chapter.id)
                  // 這一列的狀態是上面那一輪算好的（與「下載 (n)」共用），不再自己問一次。
                  const download = chapterStates[chapter.id]
                  const settled = isActive(download.state) || download.state === "done"
                  const checked = selectedIds.includes(chapter.id)
                  const highlight = selecting ? checked : isCurrent
                  const markVisible = selecting && !locked

                  // 章節卡片內容
                  const body = (
                    <Card background={highlight ? tint.selectedRow : cardBackground}>
                      <HStack
                        spacing={0}
                        padding={rowPadding}
                        frame={{ maxWidth: "infinity" }}
                        contentShape="rect"
                      >
                        {/* 圓點常駐：進出選取只動寬度與位移，標題才會被推著走（插入新元件標題會被當成新的）。 */}
                        <ZStack frame={{ width: markVisible ? markSlotWidth : 0, alignment: "leading" }}>
                          <Image
                            systemName={checked ? "checkmark.circle.fill" : "circle"}
                            font="subheadline"
                            fontWeight="medium"
                            foregroundStyle={checked ? tint.tint : "tertiaryLabel"}
                            offset={{ x: markVisible ? 0 : -markSlotWidth - rowPadding.horizontal, y: 0 }}
                            opacity={markVisible ? 1 : 0}
                          />
                        </ZStack>
                        <HStack>
                          {locked ? (
                            <Image systemName="lock.fill" font="caption2" foregroundStyle="tertiaryLabel" />
                          ) : null}
                          <Text
                            font="subheadline"
                            fontWeight={isCurrent ? "bold" : "regular"}
                            foregroundStyle={isCurrent ? tint.tint : read ? "secondaryLabel" : "label"}
                            lineLimit={1}
                          >
                            {chapter.title}
                          </Text>
                          <Spacer />
                          <DownloadStateText state={download} />
                          {isCurrent ? (
                            <HStack
                              spacing={3}
                              padding={{ horizontal: 8, vertical: 3 }}
                              background={tint.tint}
                              clipShape={capsule()}
                            >
                              <Image
                                systemName="clock.arrow.circlepath"
                                font="caption2"
                                foregroundStyle={tint.onTint}
                              />
                              <Text font="caption2" foregroundStyle={tint.onTint} fontWeight="semibold">
                                {resumed ? t("detail.lastReadAtPage", { n: resumed.page + 1 }) : t("detail.lastRead")}
                              </Text>
                            </HStack>
                          ) : selecting || locked ? null : (
                            <Image
                              systemName="chevron.right"
                              font="caption2"
                              foregroundStyle="tertiaryLabel"
                              transition={Transition.opacity()}
                            />
                          )}
                        </HStack>
                      </HStack>
                    </Card>
                  )

                  // 鎖定的章節只顯示，不包按鈕（點了不會進去）。
                  // 非鎖定章節一律包 Button：選取模式下點整張卡片任何地方都能切換勾選，正常模式下進閱讀器。
                  const row = locked ? (
                    body
                  ) : (
                    <Button
                      buttonStyle="plain"
                      frame={{ maxWidth: "infinity" }}
                      action={() => {
                        if (selecting) {
                          toggleSelected(chapter.id)
                        } else {
                          void presentReader({
                            ...readerProps,
                            epId: chapter.id,
                            initialPage: isCurrent ? resumed?.page : undefined,
                          })
                        }
                      }}
                    >
                      {body}
                    </Button>
                  )

                  // 左滑：切換已讀＋（還沒下載完才有的）下載。選取模式與鎖定章節不給左滑。
                  // 外層也裁成卡片形狀：滑動容器會在列的矩形範圍畫一層底。
                  const actions: VirtualNode[] = [
                    <Button
                      key="read"
                      title={read ? t("detail.markUnread") : t("detail.markRead")}
                      systemImage={read ? "arrow.uturn.backward.circle" : "checkmark.circle"}
                      action={() => toggleRead(chapter)}
                    />,
                  ]
                  // 全滑只做第一顆（已讀切換）；下載完的就不必再擺一顆。
                  if (!settled) {
                    actions.push(
                      <Button
                        key="download"
                        title={download.state === "none" ? t("detail.download") : t("detail.resumeDownload")}
                        systemImage="arrow.down.circle"
                        action={() => downloadChapter(chapter)}
                      />
                    )
                  }

                  // 長按：左滑的全部再加上「之前的章節」與取消／移除下載。選取模式給空選單（空的不會彈出）。
                  const before = chaptersBefore(chapter)
                  const removable = download.state === "done" || download.state === "partial" || download.state === "failed"
                  const menuItems = selecting ? (
                    <Group />
                  ) : (
                    <Group>
                      <Section>
                        {isActive(download.state) ? (
                          <Button
                            title={t("detail.cancelDownload")}
                            systemImage="xmark.circle"
                            action={() => cancelChapterDownload(chapter)}
                          />
                        ) : download.state !== "done" ? (
                          <Button
                            title={download.state === "none" ? t("detail.download") : t("detail.resumeDownload")}
                            systemImage="arrow.down.circle"
                            action={() => downloadChapter(chapter)}
                          />
                        ) : null}
                      </Section>
                      <Section>
                        <Button
                          title={read ? t("detail.markUnread") : t("detail.markRead")}
                          systemImage={read ? "arrow.uturn.backward.circle" : "checkmark.circle"}
                          action={() => toggleRead(chapter)}
                        />
                        {before.length > 0 ? (
                          <Menu title={t("detail.previousChapters")} systemImage="text.line.first.and.arrowtriangle.forward">
                            <Button
                              title={t("detail.markRead")}
                              systemImage="checkmark.circle"
                              action={() => markChaptersBefore(chapter, true)}
                            />
                            <Button
                              title={t("detail.markUnread")}
                              systemImage="arrow.uturn.backward.circle"
                              action={() => markChaptersBefore(chapter, false)}
                            />
                          </Menu>
                        ) : null}
                      </Section>
                      {removable ? (
                        <Section>
                          <Button
                            title={t("detail.removeDownload")}
                            systemImage="trash"
                            role="destructive"
                            action={() => removeChapterDownload(chapter)}
                          />
                        </Section>
                      ) : null}
                    </Group>
                  )

                  // 選取模式只清空動作、不拿掉修飾子：結構一變整列會被換掉，圓點與位移就沒有動畫。
                  return locked ? (
                    <VStack key={chapter.id} spacing={0} clipShape={cardShape}>
                      {row}
                    </VStack>
                  ) : (
                    <VStack
                      key={chapter.id}
                      spacing={0}
                      clipShape={cardShape}
                      trailingSwipeActions={{ allowsFullSwipe: !selecting, actions: selecting ? [] : actions }}
                      contextMenu={{ menuItems }}
                    >
                      {row}
                    </VStack>
                  )
                })}
              </LazyVStack>
              {/* 選取時讓出底部列的高度。 */}
              <VStack frame={{ height: selecting ? selectionBarClearance : 0 }} />
            </VStack>

          </VStack>
        </ScrollView>
      ) : null}
    </VStack>
  </ZStack>
  )
}

/** 章節列的離線狀態：未下載 / 下載中 x/y / 已下載（未完成是誠實的「有缺」，不假裝下載好了）。 */
/** 詳情頁動作列：兩顆方形按鈕 54×64，中間間距 10；剩下的寬是「開始閱讀」。 */
const ACTION_BUTTON = 54
const ACTION_HEIGHT = 64
const ACTION_GAP = 10
/**
 * 詳情載入中：照載入後的排法一區一區搭——hero（封面＋標題／來源 chip／星等／作者）、
 * 閱讀列、標籤膠囊、簡介、章節工具列與一話一張卡。區塊少一個或多一個，內容一來就會抽。
 */
export function DetailSkeleton({ cover }: { cover: { width: number; height: number } }) {
  return (
    <ScrollView scrollDisabled={true} scrollContentBackground="hidden">
      <VStack spacing={pageSpacing} padding={pageInsets} frame={{ maxWidth: "infinity" }} accessibilityLabel={t("common.loading")}>
        <HStack spacing={16} alignment="top" frame={{ maxWidth: "infinity" }}>
          <SkeletonBlock width={cover.width} height={cover.height} />
          <VStack alignment="leading" spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            <SkeletonText font="title3" fontWeight="bold" lineLimit={2} length={6} />
            {/* 來源 chip（compact）：caption2 加上下 5 */}
            <SkeletonBlock width={78} height={24} shape="capsule" />
            {/* 星等與喜愛數（Tag：caption2 加上下 4） */}
            <HStack spacing={8}>
              <SkeletonBlock width={46} height={21} />
              <SkeletonBlock width={54} height={21} />
            </HStack>
            {/* 連載狀態、作者、時間：三行，跟真的同字級 */}
            <SkeletonBlock width={52} height={21} />
            <SkeletonText font="footnote" length={2} />
            <SkeletonText font="caption2" length={3} />
          </VStack>
        </HStack>

        {/* 開始閱讀（撐滿）＋收藏 54＋留言 54，都是 64 高 */}
        <HStack spacing={ACTION_GAP} alignment="center" frame={{ maxWidth: "infinity" }}>
          <SkeletonBlock height={ACTION_HEIGHT} />
          <SkeletonBlock width={ACTION_BUTTON} height={ACTION_HEIGHT} />
          <SkeletonBlock width={ACTION_BUTTON} height={ACTION_HEIGHT} />
        </HStack>

        {/* 標籤膠囊列（真的那排靠左） */}
        <HStack spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <SkeletonBlock width={52} height={21} shape="capsule" />
          <SkeletonBlock width={68} height={21} shape="capsule" />
          <SkeletonBlock width={60} height={21} shape="capsule" />
        </HStack>

        {/* 簡介：標題＋收合時的三行 */}
        <VStack alignment="leading" spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <SkeletonText font="headline" fontWeight="bold" length={2} />
          <SkeletonText font="footnote" lineLimit={3} length={14} />
        </VStack>

        {/* 章節：工具列（標題＋兩顆圖示膠囊）＋一話一張卡 */}
        <VStack spacing={12} frame={{ maxWidth: "infinity" }}>
          <HStack spacing={6} alignment="center" frame={{ maxWidth: "infinity" }}>
            <SkeletonText font="title3" fontWeight="bold" length={2} />
            <SkeletonText font="subheadline" length={1} />
            <Spacer />
            <SkeletonBlock width={28} height={28} shape="capsule" />
            <SkeletonBlock width={28} height={28} shape="capsule" />
          </HStack>
          <VStack spacing={8} frame={{ maxWidth: "infinity" }}>
            {Array.from({ length: 6 }, (_, index) => (
              // 外面要包一層 clipShape：`Card` 的底色不會被它自己的 clipShape 裁圓，
              // 包在外層才會裁（跟上面真正的章節列同一個寫法，不然圓角外會露出方框）。
              <VStack key={index} spacing={0} clipShape={cardShape}>
                <Card background={cardBackground}>
                  <HStack padding={rowPadding} frame={{ maxWidth: "infinity" }}>
                    <SkeletonText font="subheadline" length={3} />
                    <Spacer />
                  </HStack>
                </Card>
              </VStack>
            ))}
          </VStack>
        </VStack>
      </VStack>
    </ScrollView>
  )
}

function DownloadStateText({ state }: { state: ChapterDownloadState }) {
  const tint = useTint()
  if (state.state === "queued") {
    return (
      <Text font="caption2" foregroundStyle={tint.tint}>
        {t("detail.downloadQueued")}
      </Text>
    )
  }
  if (state.state === "running") {
    return (
      <Text font="caption2" foregroundStyle={tint.tint}>
        {t("detail.downloadRunning", { done: state.completed, total: state.total })}
      </Text>
    )
  }
  if (state.state === "done") {
    return (
      <Text font="caption2" foregroundStyle={palette.green}>
        {t("detail.downloaded")}
      </Text>
    )
  }
  if (state.state === "partial" || state.state === "failed") {
    return (
      <Text font="caption2" foregroundStyle={palette.orange}>
        {state.total > 0
          ? t("detail.incompleteProgress", { done: state.completed, total: state.total })
          : t("detail.incomplete")}
      </Text>
    )
  }
  return null
}
