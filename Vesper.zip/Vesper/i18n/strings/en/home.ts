// English. **LLM 產出、未經母語者校對**。

export default {
  title: "Home",

  resumeTitle: "Continue reading",
  trendingTitle: "New & trending",
  followingTitle: "Everyone's reading",
  feedLoading: "Fetching Bangumi picks…",
  feedErrorTitle: "Can't reach Bangumi right now",
  feedErrorDetail: "Check your network connection, or tap retry in the top right later.",

  lastRead: "Last read",
  sourceInvalid: "Source broken",
  sourceRemoved: "Source removed",

  miniHub: {
    openApp: "Open App",
    sourceUpdates: { one: "{n} source update available", other: "{n} source updates available" },
    updatesTitle: "Latest updates",
    allUpToDate: "All favorites are up to date",
    notChecked: "Not checked yet",
    newChapters: { one: "{n} new chapter", other: "{n} new chapters" },
    backlogTitle: "To read",
    activityTitle: "Reading activity",
    searchPrompt: "Search manga",
    streak: "{days}-day streak",
    weekChapters: { one: "{n} chapter in 7 days", other: "{n} chapters in 7 days" },
    dayChapters: { one: "{n} chapter", other: "{n} chapters" },
    episodes: { one: "{n} chapter · {last}", other: "{n} chapters · {last}" },
  },

  bangumi: {
    originalName: "Original: {name}",
    author: "Author: {author}",
    releaseDate: "Released: {date}",
    summary: "Summary",
    expand: "More",
    collapse: "Less",
    sourcesTitle: "Available manga sources",
    manualSearch: "Search all sources",
    matching: "Matching “{title}” across manga sources…",
    notFoundTitle: "Not found in the enabled sources",
    notFoundDetail: "The title may differ, or you may need to install more manga sources in Settings or Browse.",
  },
}
