// English. Machine-translated, not reviewed by a native speaker.

export default {
  title: "Browse",
  manageSources: "Manage comic sources",
  enabledSources: "Enabled sources ({n})",
  searchSources: "Search enabled sources",
  searchResults: "Results ({n})",
  findInRepositories: "Search repositories",
  disableSource: "Disable",
  emptyTitle: "No enabled sources",
  emptyDetail: "Install and enable comic sources in Settings → Comic Sources. Aidoku indexes can be added under Source repositories.",
  pickSources: "Choose sources",

  source: "Source",
  explore: "Explore",
  category: "Categories",
  ranking: "Ranking",
  viewLabel: "Source view: {label}",

  noResults: "No results",
  /** The source declares no ranking options. */
  noRankingOptions: "This source has no rankings",
  refresh: "Refresh",
  reload: "Reload",

  searchInSource: "Search {name}",
  searching: "Searching…",

  hotPicks: "Popular picks",
  home: "Home",
  homeEmpty: "This source's home page is empty",
  all: "All",

  searchOnly: "This source only supports search",

  noCategories: "This source has no categories available",
  partError: "Couldn't load: {error}",
  categoryLabel: "Category: {label}",
}
