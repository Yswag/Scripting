// English. **LLM 產出、未經母語者校對**。

export default {
  working: "Working…",
  input: "Enter text",
  confirm: "OK",
  untitled: "(Untitled)",
  noCover: "No cover",
  undecodable: "Can't decode",
  exitLabel: "Quit Vesper, back to Scripting",
  exitBlockedTitle: "Can't minimize to background",
  exitBlockedMessage:
    "You may have more than one window open. Quitting will stop the download (pages already fetched are kept).",
  exitContinue: "Keep downloading",
  exitAnyway: "Quit anyway",
  allShown: "— End of list —",
  loadFailed: "Couldn't load: {message}",
  retry: "Retry",
  imageFailed: "(image failed to load)",
  offlineTag: "Offline",

  pageMissing: "Page {n} does not exist ({total} pages in all)",
  pages: { one: "{n} page", other: "{n} pages" },

  tabs: {
    home: "Home",
    bookshelf: "Bookshelf",
    browse: "Browse",
    settings: "Settings",
    search: "Search",
  },
  sectionMenu: "Switch section, currently {title}",

  cancel: "Cancel",
  save: "Save",
  add: "Add",
  delete: "Delete",
  remove: "Remove",
  clear: "Clear",
  inProgress: "{label}…",
  failed: "Failed: {message}",

  loading: "Loading…",
  loadingMore: "Loading more…",

  preparingEnv: "Preparing reader environment…",
  installingCoreDeps: "Installing required core dependencies (cheerio, crypto-js) on first launch, please wait…",
  depsInstallFailed: "Failed to install core dependencies. Check your connection and try again.",
  depsRetryInstall: "Retry install",
  depsMissing: "Core dependency {name} is missing. Reinstall it in Settings → Core dependencies, then try again.",
}
