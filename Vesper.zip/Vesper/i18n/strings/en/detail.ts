// English. **LLM 產出、未經母語者校對**。

export default {
  singleChapter: "Single chapter",
  author: "Author: {name}",
  artist: "Artist: {name}",
  updatedAt: "Updated {time}",
  uploadedAt: "Uploaded {time}",
  likesCount: { one: "{n} like", other: "{n} likes" },

  /** Publishing status from the source. */
  statusOngoing: "Ongoing",
  statusCompleted: "Completed",
  statusCancelled: "Cancelled",
  statusHiatus: "Hiatus",
  statusNotPublished: "Not published",
  /** Content rating: only suggestive and nsfw are shown. */
  ratingSuggestive: "Suggestive",
  ratingNsfw: "18+",

  resumeReading: "Continue reading",
  startReading: "Start reading",
  chapterAtPage: "{chapter} · Page {n}",
  firstChapter: "Read from the start",
  /** Shown when the source locks every chapter (paid / login only). */
  allChaptersLocked: "All chapters are locked",

  favorite: "Favorite",
  unfavorite: "Remove from favorites",
  favorited: "Favorited",

  summary: "Summary",
  expand: "More",
  collapse: "Less",

  chaptersTitle: "Chapters",
  select: "Select",
  selectedCount: "{n} selected",
  selectDone: "Done",
  sortAscending: "Sort chapters oldest first",
  sortDescending: "Sort chapters newest first",
  downloadSelected: "Download ({n})",
  downloadAll: "Download all",
  markSelectedRead: "Read ({n})",
  markAllRead: "Mark all read",
  selectAll: "Select all",
  deselectAll: "Deselect all",
  moreActions: "More actions",

  downloadQueued: "Queued",
  downloadRunning: "Downloading {done}/{total}",
  downloaded: "Downloaded",
  incomplete: "Incomplete",
  incompleteProgress: "Incomplete {done}/{total}",
  download: "Download",
  resumeDownload: "Resume download",
  markRead: "Mark read",
  markUnread: "Mark unread",
  previousChapters: "Previous chapters",
  cancelDownload: "Cancel download",
  removeDownload: "Remove download",

  lastRead: "Last read",
  lastReadAtPage: "Last read · Page {n}",

  coverFailed: "Couldn't load the cover",

  /** More actions and recommendations. */
  openInBrowser: "Open in Browser",
  recommendTitle: "Recommended",

  /** Switching source: find the same title on another source. */
  switchSource: "Switch source",
  switchSourceSearching: "Searching other sources",
  switchSourceEmpty: "No other source has this title",
  switchSourceNoOthers: "No other sources are enabled",
}
