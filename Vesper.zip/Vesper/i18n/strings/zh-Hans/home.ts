// 简体中文。**LLM 產出、未經母語者校對**。

export default {
  title: "首页",

  resumeTitle: "继续阅读",
  trendingTitle: "热门新作",
  followingTitle: "大家都在追",
  feedLoading: "正在获取 Bangumi 推荐…",
  feedErrorTitle: "暂时无法连接 Bangumi",
  feedErrorDetail: "请检查网络连接，或稍后点击右上角重试。",

  lastRead: "上次阅读",
  sourceInvalid: "源失效",
  sourceRemoved: "源已移除",

  miniHub: {
    openApp: "打开 App",
    sourceUpdates: { one: "{n} 个漫画源可更新", other: "{n} 个漫画源可更新" },
    updatesTitle: "最新追更",
    allUpToDate: "所有收藏已是最新",
    notChecked: "尚未检查更新",
    newChapters: { one: "新增 {n} 话", other: "新增 {n} 话" },
    backlogTitle: "待读",
    activityTitle: "阅读记录",
    searchPrompt: "搜索漫画",
    streak: "连续 {days} 天",
    weekChapters: { one: "近 7 天 {n} 话", other: "近 7 天 {n} 话" },
    dayChapters: { one: "{n} 话", other: "{n} 话" },
    episodes: { one: "{n} 话 · {last}", other: "{n} 话 · {last}" },
  },

  bangumi: {
    originalName: "原名：{name}",
    author: "作者：{author}",
    releaseDate: "发售：{date}",
    summary: "简介",
    expand: "展开",
    collapse: "收起",
    sourcesTitle: "可用漫画来源",
    manualSearch: "手动聚合搜索",
    matching: "正在各漫画源中匹配《{title}》…",
    notFoundTitle: "已启用的源中未找到此作品",
    notFoundDetail: "可能译名不同，或需要到「设置」或「浏览」安装更多漫画源。",
  },
}
