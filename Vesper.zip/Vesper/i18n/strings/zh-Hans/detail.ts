// 简体中文。**LLM 產出、未經母語者校對**。

export default {
  singleChapter: "单章",
  author: "作者：{name}",
  artist: "作画：{name}",
  updatedAt: "更新于 {time}",
  uploadedAt: "发布于 {time}",
  likesCount: { one: "{n} 人喜爱", other: "{n} 人喜爱" },

  /** 源的连载状态。 */
  statusOngoing: "连载中",
  statusCompleted: "已完结",
  statusCancelled: "腰斩",
  statusHiatus: "休刊中",
  statusNotPublished: "未出版",
  /** 内容分级：只有「建议」与 R18 会显示。 */
  ratingSuggestive: "建议 15+",
  ratingNsfw: "R18",

  resumeReading: "继续阅读",
  startReading: "开始阅读",
  chapterAtPage: "{chapter} · 第 {n} 页",
  firstChapter: "首话阅读",
  /** 有章节但全部被源锁定（付费／登录）时，阅读入口显示的状态。 */
  allChaptersLocked: "所有章节已锁定",

  favorite: "收藏",
  unfavorite: "取消收藏",
  favorited: "已收藏",

  summary: "简介",
  expand: "展开",
  collapse: "收起",

  chaptersTitle: "章节列表",
  select: "选择",
  selectedCount: "已选 {n} 话",
  selectDone: "完成",
  sortAscending: "章节改为正序",
  sortDescending: "章节改为倒序",
  downloadSelected: "下载 ({n})",
  downloadAll: "全部下载",
  markAllRead: "全部标为已读",
  selectAll: "全选",
  deselectAll: "取消全选",
  moreActions: "更多操作",

  downloadQueued: "等待下载",
  downloadRunning: "下载中 {done}/{total}",
  downloaded: "已下载",
  incomplete: "未完成",
  incompleteProgress: "未完成 {done}/{total}",
  download: "下载",
  resumeDownload: "继续下载",
  markRead: "标为已读",
  markUnread: "标为未读",
  previousChapters: "之前的章节",
  cancelDownload: "取消下载",
  removeDownload: "移除下载",

  lastRead: "上次读到",
  lastReadAtPage: "上次读到 · 第 {n} 页",

  coverFailed: "无法载入封面",

  /** 更多操作与相关推荐。 */
  openInBrowser: "在浏览器中打开",
  recommendTitle: "相关推荐",

  /** 换源：在当前来源之外找同一部作品。 */
  switchSource: "切换来源",
  switchSourceSearching: "正在搜索其他来源",
  switchSourceEmpty: "其他来源找不到这部作品",
  switchSourceNoOthers: "没有其他已启用的来源",
}
