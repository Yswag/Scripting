#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# CIA Dropper
# Copyright (c) 2026 ykusu — MIT License
# Inspired by SFYGameTransferrer: https://github.com/socksprox/SFYGameTransferrer

import json
import os
import socket
import struct
import sys
import threading
import time
import traceback
from urllib.parse import quote, unquote

# --- tuning -----------------------------------------------------------------
MAX_REQUEST_BYTES = 8192            # request head cap
FLUSH_SECONDS = 0.5                 # progress flush: at most once per 0.5 s ...
FLUSH_BYTES = 2 * 1024 * 1024       # ... or once per 2 MB, whichever comes first
ACCEPT_TIMEOUT = 0.5                # accept() timeout -> cancel/idle poll cadence
PEER_PROBE_TIMEOUT = 0.3            # FIN/RST probe after the last body byte
HEADER_TIMEOUT = 15.0               # a client that never finishes its request
DEFAULT_CHUNK = 65536
DEFAULT_IDLE = 300.0

TERMINAL_STATES = ("cancelled", "finished", "error")


def _now():
    return time.time()


# ---------------------------------------------------------------------------
# Server
# ---------------------------------------------------------------------------
class Server(object):
    def __init__(self, cfg):
        self.cfg = cfg
        self.bind_addr = str(cfg.get("bind") or "0.0.0.0")
        self.port = int(cfg.get("port") or 0)
        self.progress_path = cfg.get("progressPath") or ""
        self.cancel_path = cfg.get("cancelPath") or ""
        idle = cfg.get("idleTimeoutSeconds")
        self.idle_timeout = DEFAULT_IDLE if idle is None else float(idle)
        self.chunk_size = int(cfg.get("chunkSize") or 0) or DEFAULT_CHUNK

        self.lock = threading.RLock()      # RLock: write_progress may nest
        self.sock = None
        self.state = "listening"
        self.message = ""
        self.request_count = 0
        self.current = None                # file dict currently being sent
        self.active = 0                    # connections being handled right now
        self.started_at = _now()
        self.last_request_at = self.started_at
        self._flush_at = 0.0
        self._flush_bytes = 0

        # notify (send the URL list to the 3DS) -- see module docstring
        self.lan_ip = str(cfg.get("lanIp") or "")
        notify = cfg.get("notify") or {}
        self.notify_host = str(notify.get("host") or "").strip()
        self.notify_port = int(notify.get("port") or 0)
        self.notify_ack = float(notify.get("ackWaitSeconds") or 0.5)
        self.notify_items = list(notify.get("items") or [])
        self.payload_state = "idle"        # idle | sending | sent | failed
        self.payload_detail = ""

        self.files = []
        for spec in (cfg.get("files") or []):
            name = str(spec.get("name"))
            path = str(spec.get("path"))
            size = spec.get("size")
            try:
                if size is None:
                    size = os.path.getsize(path)
                size = int(size)
            except OSError as exc:
                size = 0
                self.message = "cannot stat %s: %s" % (path, exc)
            self.files.append({
                "name": name,
                "path": path,
                "size": size,
                "sentBytes": 0,
                "state": "pending",
                "startedAt": 0,
                "finishedAt": 0,
                "peerClosed": None,
            })

    # -- progress file -------------------------------------------------------
    def _snapshot(self):
        files = []
        total_bytes = 0
        sent_bytes = 0
        for f in self.files:
            total_bytes += f["size"]
            sent_bytes += f["sentBytes"]
            files.append({
                "name": f["name"],
                "size": f["size"],
                "sentBytes": f["sentBytes"],
                "state": f["state"],
                "startedAt": f["startedAt"],
                "finishedAt": f["finishedAt"],
                "peerClosed": f["peerClosed"],
            })
        return {
            "state": self.state,
            "port": self.port,
            "files": files,
            "currentName": self.current["name"] if self.current else None,
            "totalBytes": total_bytes,
            "sentBytes": sent_bytes,
            "requestCount": self.request_count,
            "startedAt": self.started_at,
            "updatedAt": _now(),
            "message": self.message,
            "payloadState": self.payload_state,
            "payloadDetail": self.payload_detail,
        }

    def write_progress(self, force=False):
        """Atomically dump the progress JSON. Rate limited unless force=True."""
        try:
            with self.lock:
                now = _now()
                sent = sum(f["sentBytes"] for f in self.files)
                if not force:
                    if (now - self._flush_at) < FLUSH_SECONDS and \
                       (sent - self._flush_bytes) < FLUSH_BYTES:
                        return
                payload = self._snapshot()
                self._flush_at = now
                self._flush_bytes = sent
            if not self.progress_path:
                return
            tmp = self.progress_path + ".tmp"
            with open(tmp, "w") as fh:
                json.dump(payload, fh)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, self.progress_path)
        except Exception:
            # progress reporting must never be able to kill the server
            pass

    def fail(self, tb):
        with self.lock:
            self.state = "error"
            self.message = tb
            for f in self.files:
                if f["state"] == "sending":
                    f["state"] = "aborted"
                    f["finishedAt"] = _now()
            self.current = None
        self.write_progress(force=True)

    # -- notify: hand the URL list to the 3DS -------------------------------
    def build_urls(self):
        """URLs in the user's order; local items get this server's real port."""
        urls = []
        for item in self.notify_items:
            url = item.get("url")
            if url:
                urls.append(str(url))
                continue
            name = str(item.get("name") or "")
            urls.append("http://%s:%d/f/%s" % (self.lan_ip, self.port, quote(name, safe="")))
        return urls

    def notify_target(self):
        """Send 4-byte big-endian length + newline-terminated URL list to the 3DS.

        Runs in its own thread so the accept loop keeps working while we wait for
        connect/ack.  Never raises: the result lands in the progress file.
        """
        with self.lock:
            self.payload_state = "sending"
            self.payload_detail = ""
        self.write_progress(force=True)

        state = "failed"
        detail = ""
        try:
            body = "".join(u + "\n" for u in self.build_urls()).encode("utf-8")
            packet = struct.pack(">I", len(body)) + body
            s = socket.create_connection((self.notify_host, self.notify_port), 5)
            try:
                s.sendall(packet)
                state = "sent"
                detail = "sent %d bytes" % len(packet)
                try:
                    s.settimeout(self.notify_ack)
                    data = s.recv(1)
                    detail += " (peer answered)" if data else " (peer closed)"
                except socket.timeout:
                    detail += " (no ack: FBI 2.6.1 never answers)"
                except Exception as exc:
                    detail += " (ack error: %s)" % type(exc).__name__
            finally:
                try:
                    s.close()
                except Exception:
                    pass
        except Exception as exc:
            detail = "%s: %s" % (type(exc).__name__, exc)

        with self.lock:
            self.payload_state = state
            self.payload_detail = detail
            if state == "failed" and not self.message:
                self.message = "cannot reach %s:%d (%s)" % (self.notify_host, self.notify_port, detail)
        self.write_progress(force=True)

    # -- lifecycle -----------------------------------------------------------
    def bind(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((self.bind_addr, self.port))
        s.listen(16)
        self.port = s.getsockname()[1]
        s.settimeout(ACCEPT_TIMEOUT)
        self.sock = s

    def serve(self):
        """Bind, announce `listening`, accept until cancelled/finished/error."""
        try:
            self.bind()
        except BaseException:
            self.fail(traceback.format_exc())
            return 1
        self.write_progress(force=True)          # state == "listening" + real port
        if self.notify_host and self.notify_port > 0:
            t = threading.Thread(target=self.notify_target)
            t.daemon = True
            t.start()
        try:
            self.loop()
        except BaseException:
            self.fail(traceback.format_exc())
            return 1
        finally:
            try:
                if self.sock is not None:
                    self.sock.close()
            except Exception:
                pass
            # guarantee a terminal (or at least last) snapshot reaches disk
            self.write_progress(force=True)
        return 0

    def loop(self):
        while True:
            # 1) cancel flag -> stop within ~0.5 s
            if self.cancel_path and os.path.exists(self.cancel_path):
                with self.lock:
                    self.state = "cancelled"
                    self.message = "cancel flag detected"
                    self.current = None
                return
            # 2) idle timeout, only when nothing is in flight
            with self.lock:
                idle_for = _now() - self.last_request_at
                busy = self.active > 0
            if self.idle_timeout > 0 and not busy and idle_for > self.idle_timeout:
                with self.lock:
                    self.state = "finished"
                    self.message = "idle timeout after %.1fs" % idle_for
                    self.current = None
                return

            try:
                conn, addr = self.sock.accept()
            except socket.timeout:
                continue
            except OSError:
                with self.lock:
                    if self.state in TERMINAL_STATES:
                        return
                raise
            t = threading.Thread(target=self.handle, args=(conn, addr))
            t.daemon = True
            t.start()

    # -- connection handling -------------------------------------------------
    def handle(self, conn, addr):
        with self.lock:
            self.active += 1
        try:
            head = self.read_request(conn)
            if head is None:
                return
            method, target, version = head
            with self.lock:
                self.request_count += 1
                self.last_request_at = _now()
                self.write_progress()
            self.route(conn, method, target)
        except (ConnectionResetError, BrokenPipeError):
            pass        # peer went away before/while we answered; nothing fatal
        except Exception:
            # a bug in routing must not take the server down; log it into message
            with self.lock:
                if not self.message:
                    self.message = traceback.format_exc()
            self.write_progress(force=True)
            try:
                self.send_simple(conn, 500, "Internal Server Error", method="GET")
            except Exception:
                pass
        finally:
            try:
                conn.close()
            except Exception:
                pass
            with self.lock:
                self.active -= 1
                self.last_request_at = _now()
            self.write_progress(force=True)

    def read_request(self, conn):
        """Read up to \\r\\n\\r\\n. Returns (method, target, version) or None."""
        conn.settimeout(HEADER_TIMEOUT)
        data = b""
        while b"\r\n\r\n" not in data:
            if len(data) > MAX_REQUEST_BYTES:
                self.send_simple(conn, 431, "Request Header Fields Too Large")
                return None
            try:
                chunk = conn.recv(2048)
            except socket.timeout:
                return None
            if not chunk:
                return None
            data += chunk
            if len(data) > MAX_REQUEST_BYTES and b"\r\n\r\n" not in data:
                self.send_simple(conn, 431, "Request Header Fields Too Large")
                return None
        raw_head = data.split(b"\r\n\r\n", 1)[0]
        line = raw_head.split(b"\r\n", 1)[0].decode("latin-1", "replace").strip()
        parts = line.split()
        if len(parts) < 2:
            self.send_simple(conn, 400, "Bad Request")
            return None
        method = parts[0].upper()
        target = parts[1]
        version = parts[2] if len(parts) > 2 else "HTTP/1.1"
        return (method, target, version)

    def route(self, conn, method, target):
        path = target.split("?", 1)[0].split("#", 1)[0]
        if method not in ("GET", "HEAD"):
            self.send_simple(conn, 405, "Method Not Allowed")
            return
        if path == "/" or path == "":
            self.send_index(conn, method)
            return
        if path.startswith("/f/"):
            f = self.lookup(unquote(path[3:]))
            if f is None:
                self.send_simple(conn, 404, "Not Found")
                return
            self.send_file(conn, f, head_only=(method == "HEAD"))
            return
        self.send_simple(conn, 404, "Not Found", method=method)

    def lookup(self, decoded):
        for f in self.files:
            if f["name"] == decoded:
                return f
        for f in self.files:                     # tolerate a client sending a path
            if os.path.basename(f["name"]) == os.path.basename(decoded):
                return f
        return None

    # -- responses -----------------------------------------------------------
    def send_simple(self, conn, code, reason, body=None, method="GET"):
        if body is None:
            body = "%d %s\n" % (code, reason)
        payload = body.encode("utf-8")
        head = (
            "HTTP/1.1 %d %s\r\n"
            "Content-Type: text/plain; charset=utf-8\r\n"
            "Content-Length: %d\r\n"
            "Connection: close\r\n"
            "\r\n" % (code, reason, len(payload))
        ).encode("latin-1")
        if method == "HEAD":
            conn.sendall(head)
        else:
            conn.sendall(head + payload)

    def index_html(self):
        rows = []
        for f in self.files:
            rows.append(
                '<li><a href="/f/%s">%s</a> &mdash; %d bytes</li>'
                % (quote(f["name"], safe=""), _escape(f["name"]), f["size"])
            )
        return (
            "<!DOCTYPE html><html><head><meta charset=\"utf-8\">"
            "<title>CIA Dropper</title></head><body>"
            "<h1>CIA Dropper</h1><ul>%s</ul></body></html>"
        ) % ("".join(rows) or "<li>(no files)</li>")

    def send_index(self, conn, method="GET"):
        payload = self.index_html().encode("utf-8")
        head = (
            "HTTP/1.1 200 OK\r\n"
            "Content-Type: text/html; charset=utf-8\r\n"
            "Content-Length: %d\r\n"
            "Connection: close\r\n"
            "\r\n" % len(payload)
        ).encode("latin-1")
        conn.sendall(head if method == "HEAD" else head + payload)

    def send_file(self, conn, f, head_only=False):
        # Open first: a file that vanished must be a clean 404, not a dropped socket.
        try:
            fh = open(f["path"], "rb")
        except OSError as exc:
            with self.lock:
                self.message = "cannot open %s: %s" % (f["name"], exc)
            self.write_progress(force=True)
            try:
                self.send_simple(conn, 404, "Not Found")
            except Exception:
                pass
            return

        with fh:
            size = os.fstat(fh.fileno()).st_size         # trust the file, not the config
            with self.lock:
                f["size"] = size
            head = (
                "HTTP/1.1 200 OK\r\n"
                "Content-Type: application/octet-stream\r\n"
                "Content-Length: %d\r\n"
                "Content-Disposition: attachment; filename=\"%s\"\r\n"
                "Connection: close\r\n"
                "\r\n" % (size, quote(f["name"], safe=""))
            ).encode("latin-1")

            if head_only:                                # HEAD: headers only, no state change
                conn.sendall(head)
                return

            started = _now()
            with self.lock:
                self.state = "serving"
                self.current = f
                f["state"] = "sending"
                f["startedAt"] = started
                f["sentBytes"] = 0
                f["finishedAt"] = 0
                f["peerClosed"] = None
                self.last_request_at = started
            self.write_progress(force=True)

            sent = 0
            try:
                conn.settimeout(None)                    # blocking: real back pressure
                conn.sendall(head)
                while True:
                    chunk = fh.read(self.chunk_size)
                    if not chunk:
                        break
                    conn.sendall(chunk)
                    sent += len(chunk)
                    with self.lock:
                        f["sentBytes"] = sent
                    self.write_progress()                # rate limited to 0.5s / 2MB
            except (ConnectionResetError, BrokenPipeError, OSError) as exc:
                with self.lock:
                    f["state"] = "aborted"
                    f["finishedAt"] = _now()
                    f["sentBytes"] = sent
                    self.current = None
                    self.state = "idle"
                    self.message = "%s while sending %s after %d/%d bytes" % (
                        type(exc).__name__, f["name"], sent, size)
                self.write_progress(force=True)
                return

        peer_closed = self.probe_peer(conn)
        with self.lock:
            f["sentBytes"] = sent
            f["finishedAt"] = _now()
            f["peerClosed"] = peer_closed
            f["state"] = "done"
            self.current = None
            self.state = "idle"
            if sent != size:
                self.message = "short send for %s: %d/%d" % (f["name"], sent, size)
        self.write_progress(force=True)

    def probe_peer(self, conn):
        """After the body: did the peer already close? (the only '3DS got it' clue)"""
        try:
            conn.sendall(b"")
            try:
                conn.shutdown(socket.SHUT_WR)
            except OSError:
                pass
            conn.settimeout(PEER_PROBE_TIMEOUT)
            data = conn.recv(1)
            return True if data == b"" else False
        except (ConnectionResetError, BrokenPipeError):
            return True
        except socket.timeout:
            return False
        except OSError:
            return True


def _escape(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;")
             .replace(">", "&gt;").replace('"', "&quot;"))


# ---------------------------------------------------------------------------
# entry point
# ---------------------------------------------------------------------------
def _write_raw_error(progress_path, tb):
    try:
        payload = {
            "state": "error", "port": 0, "files": [], "currentName": None,
            "totalBytes": 0, "sentBytes": 0, "requestCount": 0,
            "startedAt": _now(), "updatedAt": _now(), "message": tb,
            "payloadState": "failed", "payloadDetail": tb,
        }
        tmp = progress_path + ".tmp"
        with open(tmp, "w") as fh:
            json.dump(payload, fh)
        os.replace(tmp, progress_path)
    except Exception:
        pass


def main():
    cfg_path = os.environ.get("CIA_SERVE_CONFIG")
    server = None
    try:
        if not cfg_path:
            raise RuntimeError("CIA_SERVE_CONFIG is not set")
        with open(cfg_path, "r") as fh:
            cfg = json.load(fh)
        server = Server(cfg)
        return server.serve()
    except SystemExit as exc:
        return exc.code if isinstance(exc.code, int) else 1
    except BaseException:
        tb = traceback.format_exc()
        if server is not None:
            server.fail(tb)
        elif cfg_path:
            try:
                with open(cfg_path, "r") as fh:
                    pp = json.load(fh).get("progressPath")
                if pp:
                    _write_raw_error(pp, tb)
            except Exception:
                pass
        return 1


if __name__ == "__main__":
    sys.exit(main())
