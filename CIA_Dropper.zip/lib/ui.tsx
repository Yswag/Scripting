/*
 * CIA Dropper
 * Copyright (c) 2026 ykusu — MIT License
 * Inspired by SFYGameTransferrer: https://github.com/socksprox/SFYGameTransferrer
 */

import {
  AppEvents,
  Button,
  Divider,
  HStack,
  Image,
  List,
  Menu,
  Navigation,
  NavigationStack,
  ProgressView,
  ScenePhase,
  Script,
  Section,
  Spacer,
  Text,
  TextField,
  VirtualNode,
  VStack,
  useEffect,
  useRef,
  useState,
} from "scripting"
import {
  DEFAULT_PORT,
  NotifyTarget,
  ServedFile,
  TransferProgress,
  cleanupServerFiles,
  fileSize,
  formatSize,
  getLanIp,
  getProgress,
  startFileServer,
  stopFileServer,
} from "./fbi"
import { ConsoleEntry, FileEntry, forgetConsole, lastPickDirectory, loadConsoles, recentConsole, rememberConsole, rememberPickDirectory } from "./store"

const CONFIRM_TIMEOUT_SECONDS = 180
const QUIET_WARNING_SECONDS = 45
const SENDING_TIMEOUT_SECONDS = 30
const AUTO_FINISH_QUIET_SECONDS = 25

type Phase =
  | { kind: "idle" }
  | { kind: "sending"; since: number }
  | { kind: "waiting"; since: number; deadline: number }
  | { kind: "downloading"; since: number }
  | { kind: "done"; since: number; finishedAt: number; allSent: boolean; note: string }
  | { kind: "failed"; reason: string }

const PHASE_TITLE: Record<Phase["kind"], string> = {
  idle: "待機",
  sending: "正在準備",
  waiting: "等待 3DS 確認",
  downloading: "3DS 正在安裝",
  done: "傳輸結束",
  failed: "發生問題",
}

function phaseIcon(phase: Phase): string {
  switch (phase.kind) {
    case "sending": return "paperplane"
    case "waiting": return "hourglass"
    case "downloading": return "arrow.down.circle"
    case "done": return "checkmark.circle.fill"
    case "failed": return "exclamationmark.triangle.fill"
    default: return "wifi"
  }
}

function phaseTint(phase: Phase): "green" | "red" | "tintColor" | "orange" | "secondaryLabel" {
  switch (phase.kind) {
    case "done": return "green"
    case "failed": return "red"
    case "downloading": return "tintColor"
    case "waiting": return "orange"
    default: return "secondaryLabel"
  }
}

// ─── 小工具 ────────────────────────────────────────────────

export function basename(path: string): string {
  const parts = path.split("/")
  return parts[parts.length - 1] || path
}

/**
 * 把 file:// 路徑正規化成純路徑。
 * DocumentPicker 給的是純路徑，但其他來源偶爾會帶 file:// 前綴，保險起見處理一下。
 */
export function normalizeFilePath(raw: string): string {
  let value = raw.trim()
  if (value.startsWith("file://")) {
    value = value.slice("file://".length)
    if (!value.startsWith("/")) {
      const slash = value.indexOf("/")
      value = slash >= 0 ? value.slice(slash) : "/" + value
    }
    try { value = decodeURIComponent(value) } catch { /* keep */ }
  }
  return value
}

export function nameFromUrl(url: string): string {
  try {
    const parsed = new URL(url)
    const last = parsed.pathname.split("/").filter(Boolean).pop()
    return last ? decodeURIComponent(last) : parsed.hostname
  } catch {
    return url.split("/").filter(Boolean).pop() || url
  }
}

/** 檔案是否讀得到 */
export function fileExists(path: string): boolean {
  try { FileManager.statSync(path); return true } catch { return false }
}

/** 從路徑找出現在可用的檔案位置 */
function resolvedPath(entry: FileEntry): string | null {
  if (entry.path && fileExists(entry.path)) return entry.path
  return null
}

/** 秒數 → 「1 分 05 秒」 */
function clockText(seconds: number): string {
  const total = Math.max(0, Math.round(seconds))
  const minutes = Math.floor(total / 60)
  const rest = total % 60
  return minutes > 0 ? `${minutes} 分 ${String(rest).padStart(2, "0")} 秒` : `${rest} 秒`
}

/** 時間戳 → 「剛剛 / 12 分鐘前 / 3 小時前 / 9/16」 */
function relativeTime(timestamp: number): string {
  const diff = Date.now() - timestamp
  if (diff < 60_000) return "剛剛"
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)} 分鐘前`
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)} 小時前`
  const date = new Date(timestamp)
  return `${date.getMonth() + 1}/${date.getDate()}`
}

function isValidIPv4(value: string): boolean {
  const parts = value.trim().split(".")
  if (parts.length !== 4) return false
  return parts.every(part => /^\d{1,3}$/.test(part) && Number(part) <= 255)
}

/** 格式化傳輸速率 */
function formatSpeed(bytesPerSecond: number | null | undefined): string {
  if (!bytesPerSecond || bytesPerSecond <= 0) return "--"
  if (bytesPerSecond < 1048576) return `${(bytesPerSecond / 1024).toFixed(0)} KB/s`
  return `${(bytesPerSecond / 1048576).toFixed(1)} MB/s`
}

/** 取得檔案副檔名圖示與色調 */
function fileIconAndTint(entry: FileEntry, broken: boolean): { icon: string; tint: "tintColor" | "green" | "purple" | "orange" } {
  if (broken) return { icon: "exclamationmark.triangle.fill", tint: "orange" }
  if (entry.kind === "url") return { icon: "link.icloud.fill", tint: "purple" }
  const ext = entry.name.split(".").pop()?.toLowerCase()
  if (ext === "cia") return { icon: "gamecontroller.fill", tint: "tintColor" }
  if (ext === "tik") return { icon: "key.fill", tint: "green" }
  return { icon: "doc.fill", tint: "tintColor" }
}

// ─── 說明 Sheet ─────────────────────────────────────────────

function GuideSheet({ onClose }: { onClose: () => void }) {
  return (
    <NavigationStack>
      <List
        navigationTitle="使用指南"
        navigationBarTitleDisplayMode="inline"
        toolbar={{
          confirmationAction: <Button title="知道了" action={onClose} />,
        }}
      >
        <Section header={<Text>安裝步驟</Text>}>
          <HStack spacing={12} alignment="top">
            <Text font="headline" foregroundStyle="blue">1</Text>
            <VStack alignment="leading" spacing={2}>
              <Text font="subheadline">在 3DS 上開啟 FBI</Text>
              <Text font="footnote" foregroundStyle="secondaryLabel">
                進入主選單選擇「Remote Install」→「Receive URLs over the network」。
              </Text>
            </VStack>
          </HStack>
          <HStack spacing={12} alignment="top">
            <Text font="headline" foregroundStyle="blue">2</Text>
            <VStack alignment="leading" spacing={2}>
              <Text font="subheadline">設定 3DS 主機</Text>
              <Text font="footnote" foregroundStyle="secondaryLabel">
                將 3DS 螢幕上顯示的 IP 與 Port 填入本 App 的「3DS 主機」欄位中。
              </Text>
            </VStack>
          </HStack>
          <HStack spacing={12} alignment="top">
            <Text font="headline" foregroundStyle="blue">3</Text>
            <VStack alignment="leading" spacing={2}>
              <Text font="subheadline">加入安裝檔案並傳送</Text>
              <Text font="footnote" foregroundStyle="secondaryLabel">
                點擊右上角「+」或底部按鈕加入 CIA / TIK 檔案，點擊「傳送到 3DS」。
              </Text>
            </VStack>
          </HStack>
          <HStack spacing={12} alignment="top">
            <Text font="headline" foregroundStyle="blue">4</Text>
            <VStack alignment="leading" spacing={2}>
              <Text font="subheadline">在 3DS 按「A」鍵確認安裝</Text>
              <Text font="footnote" foregroundStyle="secondaryLabel">
                清單送出後，3DS 畫面會跳出確認視窗。安裝期間請讓手機盡量保持在前景。
              </Text>
            </VStack>
          </HStack>
        </Section>

        <Section header={<Text>常見注意事項</Text>}>
          <Text font="footnote" foregroundStyle="secondaryLabel">
            • 確保 iPhone 與 3DS 連接至相同 Wi-Fi 區域網路。
          </Text>
          <Text font="footnote" foregroundStyle="secondaryLabel">
            • 原地串流讀取，不佔用額外儲存空間。
          </Text>
          <Text font="footnote" foregroundStyle="secondaryLabel">
            • 傳輸期間請保持 App 於前景運作。
          </Text>
        </Section>
      </List>
    </NavigationStack>
  )
}

function LogSheet({ logs, onClear, onClose }: { logs: string[]; onClear: () => void; onClose: () => void }) {
  return (
    <NavigationStack>
      <List
        navigationTitle={`記錄（${logs.length}）`}
        navigationBarTitleDisplayMode="inline"
        toolbar={{
          cancellationAction: <Button title="完成" action={onClose} />,
          ...(logs.length > 0 ? { confirmationAction: <Button title="清除" role="destructive" action={onClear} /> } : {}),
        }}
      >
        {logs.length === 0 ? (
          <Text foregroundStyle="secondaryLabel">尚無記錄</Text>
        ) : (
          logs.map((line, index) => (
            <Text key={index} font="caption" fontDesign="monospaced" textSelection>{line}</Text>
          ))
        )}
      </List>
    </NavigationStack>
  )
}

// ─── 選擇 / 輸入 3DS 主機 ───────────────────────────────────

function TargetSheet({
  consoles,
  initialIp,
  initialPort,
  onApply,
  onForget,
  onClose,
}: {
  consoles: ConsoleEntry[]
  initialIp: string
  initialPort: string
  onApply: (ip: string, port: number) => void
  onForget: (entry: ConsoleEntry) => void
  onClose: () => void
}) {
  const [ip, setIp] = useState(initialIp)
  const [port, setPort] = useState(initialPort)
  const valid = isValidIPv4(ip)
  const selected = (entry: ConsoleEntry) => entry.ip === ip.trim() && String(entry.port) === port.trim()

  function apply() {
    if (!valid) return
    onApply(ip.trim(), Number.parseInt(port, 10) || DEFAULT_PORT)
    onClose()
  }

  return (
    <NavigationStack>
      <List
        navigationTitle="3DS 主機"
        toolbar={{
          cancellationAction: <Button title="取消" action={onClose} />,
          confirmationAction: <Button title="完成" disabled={!valid} action={apply} />,
        }}
      >
        {consoles.length > 0 ? (
          <Section
            header={<Text>已記住的 3DS</Text>}
            footer={<Text>點一下套用；左滑可以忘記這台（例如換了 IP 或賣掉了）。</Text>}
          >
            {consoles.map(entry => (
              <Button
                key={`${entry.ip}:${entry.port}`}
                action={() => { setIp(entry.ip); setPort(String(entry.port)) }}
                trailingSwipeActions={{
                  allowsFullSwipe: true,
                  actions: [
                    <Button
                      key="forget"
                      title="忘記"
                      systemImage="trash"
                      role="destructive"
                      action={() => onForget(entry)}
                    />,
                  ],
                }}
              >
                <HStack
                  spacing={12}
                  frame={{ maxWidth: "infinity", alignment: "leading" }}
                  foregroundStyle="label"
                >
                  <Image
                    systemName={selected(entry) ? "checkmark.circle.fill" : "circle"}
                    foregroundStyle={selected(entry) ? "tintColor" : "tertiaryLabel"}
                  />
                  <VStack alignment="leading" spacing={2}>
                    <Text>{entry.ip}:{entry.port}</Text>
                    <Text font="footnote" foregroundStyle="secondaryLabel">
                      上次使用 {relativeTime(entry.lastUsed)}
                    </Text>
                  </VStack>
                </HStack>
              </Button>
            ))}
          </Section>
        ) : null}

        <Section
          header={<Text>手動輸入</Text>}
          footer={
            <Text>
              在 3DS 上開啟 FBI →「Receive URLs over the network」，畫面顯示的 IP:Port 就是這裡要填的。
              成功傳過一次之後就會自動記住。
            </Text>
          }
        >
          <TextField title="IP" prompt="192.168.1.23" value={ip} onChanged={setIp} keyboardType="numbersAndPunctuation" />
          <TextField title="連接埠" prompt="5000" value={port} onChanged={setPort} keyboardType="numberPad" />
          {ip.trim().length > 0 && !valid ? (
            <Text font="footnote" foregroundStyle="red">這不是有效的 IPv4 位址（例如 192.168.1.23）</Text>
          ) : null}
        </Section>
      </List>
    </NavigationStack>
  )
}

// ─── 主畫面 ────────────────────────────────────────────────

export function MainView({
  seed = [],
  initialLogs = [],
  fileAccess: initialFileAccess = null,
}: {
  seed?: FileEntry[]
  initialLogs?: string[]
  /** 啟動時已知的檔案權限狀態（null = 還沒問過） */
  fileAccess?: boolean | null
} = {}) {
  const dismiss = Navigation.useDismiss()
  const known = recentConsole()

  const [targetIp, setTargetIp] = useState(known ? known.ip : "")
  const [targetPort, setTargetPort] = useState(String(known ? known.port : DEFAULT_PORT))
  const [localIp, setLocalIp] = useState<string | null>(null)
  const [consoles, setConsoles] = useState<ConsoleEntry[]>(loadConsoles)
  const [entries, setEntries] = useState<FileEntry[]>(seed)
  /** 檔案讀寫權限（false 時連伺服器的設定／進度檔都寫不了） */
  const [fileAccess, setFileAccess] = useState<boolean | null>(initialFileAccess)
  const [logs, setLogs] = useState<string[]>(initialLogs)
  const [phase, setPhase] = useState<Phase>({ kind: "idle" })
  const [progress, setProgress] = useState<TransferProgress | null>(null)
  const [now, setNow] = useState(() => Date.now())
  const [serverInfo, setServerInfo] = useState<{ lanIp: string; port: number } | null>(null)
  const [activeSheet, setActiveSheet] = useState<"log" | "target" | "guide" | null>(null)
  const [error, setError] = useState<{ title: string; message: string } | null>(null)
  const [toastText, setToastText] = useState("")
  const [toastPresented, setToastPresented] = useState(false)
  const [confirmStop, setConfirmStop] = useState(false)

  const toastTimerRef = useRef<number | null>(null)

  useEffect(() => {
    const ip = getLanIp()
    if (ip) setLocalIp(ip)
  }, [])

  const phaseRef = useRef<Phase>(phase)
  const completedSeenRef = useRef(0)
  /** 這一輪傳送的目的地與項目數（輪詢時要用，值不會在傳輸中改變） */
  const sendTargetRef = useRef<{ host: string; port: number; localCount: number; totalCount: number } | null>(null)

  useEffect(() => { phaseRef.current = phase }, [phase])

  function log(message: string) {
    const stamp = new Date().toTimeString().slice(0, 8)
    setLogs(prev => [...prev, `${stamp}  ${message}`].slice(-300))
  }

  function notify(message: string) {
    if (toastTimerRef.current !== null) {
      clearTimeout(toastTimerRef.current)
      toastTimerRef.current = null
    }
    setToastText(message)
    setToastPresented(true)
    toastTimerRef.current = setTimeout(() => {
      setToastPresented(false)
      toastTimerRef.current = null
    }, 2400) as unknown as number
  }

  useEffect(() => {
    const listener = (scene: ScenePhase) => {
      if (Script.env !== "index") return
      try {
        if (scene === "background") {
          BackgroundKeeper.keepAlive().then(ok => {
            if (ok) log("已要求背景保持（鎖屏時盡量維持傳輸；仍可能被系統中止）")
          })
        } else if (scene === "active") {
          BackgroundKeeper.stopKeepAlive()
        }
      } catch { /* not supported */ }
    }
    AppEvents.scenePhase.addListener(listener)
    return () => AppEvents.scenePhase.removeListener(listener)
  }, [])

  const live = phase.kind === "sending" || phase.kind === "waiting" || phase.kind === "downloading"
  const showSetup = phase.kind === "idle" || phase.kind === "failed"
  useEffect(() => {
    if (!live) return
    let cancelled = false
    let announcedAllSent = false

    const tick = () => {
      if (cancelled) return
      const nowMs = Date.now()
      const snapshot = getProgress()
      setNow(nowMs)
      setProgress(snapshot)

      const current = phaseRef.current
      let retry = true
      const started = snapshot !== null && (snapshot.requestCount > 0 || snapshot.currentName !== null)

      if (snapshot && snapshot.state === "error") {
        fail("伺服器發生錯誤", snapshot.message || "python 伺服器回報了未預期的錯誤，請再試一次。")
        retry = false
      } else if (snapshot && snapshot.payloadState === "failed") {
        stopFileServer()
        setServerInfo(null)
        fail(
          "無法連上 3DS",
          `請確認 3DS 停在 FBI 的「Receive URLs over the network」畫面，而且 IP 與連接埠跟畫面上顯示的一模一樣。\n\n（${snapshot.payloadDetail}）`,
        )
        retry = false
      } else if (snapshot && snapshot.aborted) {
        fail(
          "3DS 中斷了傳輸",
          "其中一個檔案只送了一部分就被對方關閉連線。請確認 3DS 還停在 FBI 的安裝畫面、Wi-Fi 沒斷，然後再試一次。",
        )
        retry = false
      } else if (current.kind === "sending" && snapshot && snapshot.payloadState === "sent") {
        const target = sendTargetRef.current
        if (target) {
          rememberConsole(target.host, target.port)
          setConsoles(loadConsoles())
        }
        const localCount = target ? target.localCount : 1
        const totalCount = target ? target.totalCount : 1
        if (localCount === 0) {
          log(`✓ 清單已送出（${totalCount} 個外部網址），3DS 會直接下載`)
          setPhase({ kind: "downloading", since: nowMs })
        } else {
          log(`✓ 清單已送出（${totalCount} 個項目），等待 3DS 取檔`)
          setPhase({ kind: "waiting", since: nowMs, deadline: nowMs + CONFIRM_TIMEOUT_SECONDS * 1000 })
        }
      } else if (current.kind === "sending" && nowMs - current.since > SENDING_TIMEOUT_SECONDS * 1000) {
        stopFileServer()
        setServerInfo(null)
        fail(
          "傳輸沒有開始",
          "本機伺服器沒有在預期時間內把清單送出去。請再試一次；若一直失敗，請確認 Scripting 的 python 環境正常（這是送出清單與伺服器都需要的）。",
        )
        retry = false
      } else {
        if (snapshot && snapshot.completedCount > completedSeenRef.current) {
          completedSeenRef.current = snapshot.completedCount
          log(`✓ 已完成 ${snapshot.completedCount}/${snapshot.totalCount} 個檔案`)
        }

        if (snapshot && snapshot.allSent && !announcedAllSent) {
          announcedAllSent = true
          log("✓ 所有檔案都已送出，3DS 應該正在安裝")
        }

        // 自動收尾：手機的工作在「位元組全部送出」（或清單只剩外部網址）就結束了，
        // 不需要使用者每次自己按。手動按鈕仍然保留。
        if (current.kind === "downloading" && snapshot && snapshot.payloadState === "sent") {
          if (snapshot.totalCount === 0) {
            // 全部都是外部網址：手機沒有東西要服務，3DS 自己下載
            finish(true, "清單已送出，3DS 會自己下載（手機這邊不需要再做任何事）")
            retry = false
          } else if (snapshot.allSent) {
            if (snapshot.peerClosed) {
              finish(true, "3DS 已收完所有檔案並關閉連線")
              retry = false
            } else if (snapshot.idleMs > AUTO_FINISH_QUIET_SECONDS * 1000) {
              finish(true, `所有檔案都已送出，已 ${Math.round(snapshot.idleMs / 1000)} 秒沒有新動態`)
              retry = false
            }
          }
        }

        if (started && current.kind === "waiting") {
          log(snapshot?.currentName ? `→ 3DS 開始取檔：${snapshot.currentName}` : "→ 3DS 開始取檔")
          setPhase({ kind: "downloading", since: nowMs })
        } else if (current.kind === "waiting" && nowMs > current.deadline) {
          fail(
            "等不到 3DS 取檔",
            "清單送出去了，但 3DS 一直沒有回來下載。請確認它停在 FBI 的接收畫面並且按下了確認，也要確認這個 IP 真的是 3DS（不是其他也開著 5000 埠的裝置）。",
          )
          retry = false
        }
      }

      if (retry && !cancelled) setTimeout(tick, 500)
    }

    tick()
    return () => { cancelled = true }
  }, [live])

  /** 結束傳輸。`note` 會寫明是「對方關了連線」、「安靜太久」還是使用者自己按的。 */
  function finish(allSent: boolean, note: string) {
    const current = phaseRef.current
    const since = current.kind === "waiting" || current.kind === "downloading" ? current.since : Date.now()
    setConfirmStop(false)
    stopFileServer()
    setServerInfo(null)
    setPhase({ kind: "done", since, finishedAt: Date.now(), allSent, note })
    log(allSent ? `✓ 傳輸結束：${note}` : `✓ 已標記為完成：${note}`)
  }

  /**
   * 傳完一輪後回到待機，讓使用者挑下一批檔案。
   * 清單一律清掉（舊的那批已經裝完了，清單只屬於一次傳送），主機清單則保留。
   */
  function resetForNewTransfer() {
    stopFileServer()
    setServerInfo(null)
    setProgress(null)
    setConfirmStop(false)
    completedSeenRef.current = 0
    sendTargetRef.current = null
    setEntries([])
    setPhase({ kind: "idle" })
    notify("請選擇要安裝的檔案")
    log("已清空清單，可以加入下一批檔案")
  }

  function fail(title: string, reason: string) {
    setConfirmStop(false)
    setPhase({ kind: "failed", reason: title })
    log(`✗ ${title}`)
    setError({ title, message: reason })
  }

  function stopEverything() {
    stopFileServer()
    setServerInfo(null)
    setConfirmStop(false)
    setPhase({ kind: "idle" })
    setProgress(null)
    log("已停止傳輸並關閉本機伺服器")
    notify("已停止")
  }

  function shutdown() {
    stopFileServer()
    dismiss()
  }

  function requestClose() {
    if (phase.kind === "waiting" || phase.kind === "downloading" || phase.kind === "sending") {
      setConfirmStop(true)
    } else {
      shutdown()
    }
  }

  // ─── 清單操作 ─────────────────────────────────────────────

  /**
   * 確認檔案讀寫權限。
   * 已經被拒絕過的能力不會再跳提示，所以這裡只回報狀態；要恢復得自己去
   * 長按腳本 →「權限」→ 開啟「檔案讀寫」（開完再呼叫一次就會拿到 true）。
   * 回傳 true 也包含「無法判斷」的情況（沒有 UI 的環境），以免誤擋。
   */
  async function refreshFileAccess(): Promise<boolean> {
    try {
      const granted = await Script.requestAccess(["fileSystem"])
      const ok = granted.includes("fileSystem")
      setFileAccess(ok)
      return ok
    } catch (e) {
      log(`檔案權限檢查失敗：${String(e)}`)
      return true
    }
  }

  async function addFiles() {
    try {
      const initialDirectory = lastPickDirectory()
      const options: PickFilesOption = { types: ["public.data"], allowsMultipleSelection: true }
      let picked: string[] | null = null
      try {
        picked = await DocumentPicker.pickFiles(initialDirectory ? { ...options, initialDirectory } : options)
      } catch (e) {
        if (!initialDirectory) throw e
        log(`讀取上次目錄失敗，改用系統預設：${String(e)}`)
        picked = await DocumentPicker.pickFiles(options)
      }
      if (!picked || picked.length === 0) return
      rememberPickDirectory(normalizeFilePath(picked[0]))
      const added = picked.map(path => toLocalEntry(path))
      const merged = mergeEntries(entries, added)
      const skipped = added.length - (merged.length - entries.length)
      await withAnimation(Animation.spring({ duration: 0.35, bounce: 0.25 }), () => {
        setEntries(merged)
      })
      log(`加入 ${added.length - skipped} 個檔案${skipped > 0 ? `（${skipped} 個重複已略過）` : ""}`)
      if (skipped > 0) notify(`已加入 ${added.length - skipped} 個（略過 ${skipped} 個重複）`)
    } catch (e) {
      log(`✗ 選擇檔案失敗：${String(e)}`)
      setError({ title: "無法選擇檔案", message: String(e) })
    }
  }

  async function addUrl() {
    const input = await Dialog.prompt("輸入 CIA / TIK 的直接下載網址（3DS 會自己去下載）")
    if (!input) return
    const url = input.trim()
    if (!/^https?:\/\//i.test(url)) {
      setError({ title: "網址格式不對", message: "請貼上以 http:// 或 https:// 開頭的完整網址。" })
      return
    }
    if (entries.some(e => e.kind === "url" && e.url === url)) {
      notify("這個網址已經在清單裡了")
      return
    }
    const entry: FileEntry = { kind: "url", name: nameFromUrl(url), url }
    await withAnimation(Animation.spring({ duration: 0.35, bounce: 0.25 }), () => {
      setEntries([...entries, entry])
    })
    log(`加入網址 ${entry.name}`)
    notify("已加入網址")
  }

  function removeEntry(index: number) {
    const removed = entries[index]
    void withAnimation(Animation.spring({ duration: 0.3, bounce: 0.2 }), () => {
      setEntries(prev => prev.filter((_, i) => i !== index))
    })
    if (removed) log(`移除 ${removed.name}`)
  }

  // ─── 傳送 ────────────────────────────────────────────────

  function buildServed(): { served: ServedFile[]; missing: FileEntry[] } {
    const served: ServedFile[] = []
    const missing: FileEntry[] = []
    for (const entry of entries) {
      if (entry.kind === "url") { served.push({ path: "", name: entry.name, externalUrl: entry.url }); continue }
      const path = resolvedPath(entry)
      if (!path) { missing.push(entry); continue }
      served.push({ path, name: entry.name })
    }
    return { served, missing }
  }

  async function ensureServer(
    served: ServedFile[],
    notify: NotifyTarget,
  ): Promise<{ info: { lanIp: string; port: number } | null; error: string | null }> {
    stopFileServer()
    setServerInfo(null)
    const started = await startFileServer(served, log, { notify })
    if (started.error || !started.port || !started.lanIp) {
      const error = started.error ?? "未知錯誤"
      log(`✗ 伺服器啟動失敗：${error}`)
      return { info: null, error }
    }
    const info = { lanIp: started.lanIp, port: started.port }
    setServerInfo(info)
    return { info, error: null }
  }

  async function send() {
    if (entries.length === 0) {
      notify("請先加入要安裝的項目")
      return
    }
    const host = targetIp.trim()
    const port = Number.parseInt(targetPort, 10) || DEFAULT_PORT
    if (!isValidIPv4(host)) {
      setActiveSheet("target")
      notify("請先填 3DS 的 IP")
      return
    }

    setConfirmStop(false)
    setProgress(null)
    completedSeenRef.current = 0
    sendTargetRef.current = null
    setPhase({ kind: "sending", since: Date.now() })

    try {
      const { served, missing } = buildServed()
      if (missing.length > 0) {
        fail(
          "找不到檔案",
          `清單裡有 ${missing.length} 個檔案讀不到（可能被刪除或移動）：${missing.map(m => m.name).join("、")}。左滑移除後重新加入就可以了。`,
        )
        return
      }
      if (served.length === 0) {
        fail("清單是空的", "請先加入要安裝的檔案或網址。")
        return
      }

      if (!(await refreshFileAccess())) {
        fail(
          "需要「檔案讀寫」權限",
          "此腳本需要讀取選取的檔案並寫入進度。\n\n請長按此腳本 →「權限」→ 開啟「檔案讀寫」後重試。",
        )
        return
      }

      const { info: server, error: serverError } = await ensureServer(served, { host, port })
      if (!server) {
        fail(
          "無法啟動本機伺服器",
          `${serverError ? `原因：${serverError}\n\n` : ""}請確認 iPhone 連的是 Wi-Fi 而不是行動網路，並允許 Scripting 的「本地網路」權限（設定 → 隱私權 → 本地網路）。`,
        )
        return
      }

      sendTargetRef.current = {
        host,
        port,
        localCount: served.filter(file => !file.externalUrl).length,
        totalCount: served.length,
      }
      log(`伺服器 http://${server.lanIp}:${server.port}，傳送中...`)
    } catch (e) {
      fail("發生未預期的錯誤", String(e))
    }
  }

  // ─── 畫面資料 ─────────────────────────────────────────────

  const totalBytes = entries.reduce((sum, entry) => {
    if (entry.kind === "url") return sum
    const path = resolvedPath(entry)
    return sum + (path ? fileSize(path) : 0)
  }, 0)
  const brokenCount = entries.filter(entry => entry.kind === "local" && !resolvedPath(entry)).length
  const elapsed = phase.kind === "waiting" || phase.kind === "downloading" ? (now - phase.since) / 1000 : 0
  const targetLabel = targetIp.trim() ? `${targetIp.trim()}:${targetPort}` : "尚未設定"

  // 網段檢測：本機 IP 與 3DS IP 前 3 段是否相符
  const isSubnetMismatch = (() => {
    if (!localIp || !isValidIPv4(targetIp.trim())) return false
    const localParts = localIp.split(".").slice(0, 3).join(".")
    const targetParts = targetIp.trim().split(".").slice(0, 3).join(".")
    return localParts !== targetParts
  })()

  function renderStatus() {
    if (phase.kind === "idle") return null

    const rows: VirtualNode[] = [
      <HStack key="head" spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <Image systemName={phaseIcon(phase)} foregroundStyle={phaseTint(phase)} imageScale="large" />
        <VStack alignment="leading" spacing={2}>
          <Text font="headline">{PHASE_TITLE[phase.kind]}</Text>
          <Text font="footnote" foregroundStyle="secondaryLabel">{statusDetail()}</Text>
        </VStack>
      </HStack>,
    ]

    if (phase.kind === "waiting") {
      const left = Math.max(0, (phase.deadline - now) / 1000)
      rows.push(<ProgressView key="bar" value={1 - left / CONFIRM_TIMEOUT_SECONDS} />)
      rows.push(
        <Text key="hint" font="footnote" foregroundStyle="secondaryLabel">
          請在 3DS 的 FBI 上按確認；超過 {clockText(left)} 沒有回應就會停止等待。
        </Text>,
      )
    }

    if (phase.kind === "downloading") {
      rows.push(<ProgressView key="bar" value={progress?.fraction ?? 0} />)

      rows.push(
        <HStack key="dashboard" spacing={12} padding={{ vertical: 4 }} frame={{ maxWidth: "infinity" }}>
          <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            <Text font="caption2" foregroundStyle="secondaryLabel">已送出</Text>
            <Text font="subheadline" fontDesign="monospaced">
              {progress ? `${formatSize(progress.sentBytes)} / ${formatSize(progress.totalBytes)}` : "--"}
            </Text>
          </VStack>
          <Divider key="d1" />
          <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            <Text font="caption2" foregroundStyle="secondaryLabel">{progress?.allSent ? "平均速率" : "傳輸速率"}</Text>
            <Text font="subheadline" fontDesign="monospaced">
              {progress?.allSent && elapsed > 0
                ? `${formatSize(progress.totalBytes / elapsed)}/s`
                : formatSpeed(progress?.bytesPerSecond)}
            </Text>
          </VStack>
          <Divider key="d2" />
          <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            <Text font="caption2" foregroundStyle="secondaryLabel">預估剩餘</Text>
            <Text font="subheadline" fontDesign="monospaced">
              {progress && progress.remainingSeconds !== null && progress.remainingSeconds > 0
                ? clockText(progress.remainingSeconds)
                : "--"}
            </Text>
          </VStack>
        </HStack>,
      )

      if (progress?.currentName) {
        rows.push(
          <HStack key="currentFile" spacing={6} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            <Image systemName="arrow.down.circle.fill" foregroundStyle="tintColor" imageScale="small" />
            <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1} truncationMode="middle">
              傳輸中：{progress.currentName}
            </Text>
          </HStack>,
        )
      } else if (progress && progress.completedCount > 0 && !progress.allSent) {
        rows.push(
          <HStack key="waitingNext" spacing={6} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            <Image systemName="hourglass" foregroundStyle="orange" imageScale="small" />
            <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1} truncationMode="middle">
              3DS 正在安裝已收到的檔案，等待下一個請求…
            </Text>
          </HStack>,
        )
      }

      rows.push(
        <Text key="keepOpen" font="footnote" foregroundStyle="orange">
          {progress?.allSent
            ? "所有內容已傳送完畢。請確認 3DS 螢幕顯示安裝完成，再按「標記為完成」。"
            : "請保持這個畫面開啟。切到別的 App 或鎖屏都可能讓傳輸中斷。"}
        </Text>,
      )
    }

    if (phase.kind === "downloading" && progress && progress.totalCount > 1) {
      rows.push(
        <VStack key="files" alignment="leading" spacing={6} padding={{ top: 4 }}>
          {progress.files.map(file => (
            <HStack key={file.name} spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" }}>
              <Image
                systemName={
                  file.state === "done"
                    ? "checkmark.circle.fill"
                    : file.state === "sending"
                      ? "arrow.down.circle.fill"
                      : file.state === "aborted"
                        ? "exclamationmark.triangle.fill"
                        : "circle"
                }
                foregroundStyle={
                  file.state === "done"
                    ? "green"
                    : file.state === "sending"
                      ? "blue"
                      : file.state === "aborted"
                        ? "red"
                        : "tertiaryLabel"
                }
                imageScale="small"
              />
              <Text
                font="footnote"
                lineLimit={1}
                truncationMode="middle"
                foregroundStyle={file.state === "pending" ? "secondaryLabel" : "label"}
              >
                {file.name}
              </Text>
              {file.state === "sending" && file.size > 0 ? (
                <>
                  <Spacer />
                  <Text font="caption2" fontDesign="monospaced" foregroundStyle="secondaryLabel">
                    {Math.floor((file.sentBytes / file.size) * 100)}%
                  </Text>
                </>
              ) : null}
            </HStack>
          ))}
        </VStack>,
      )
    }

    if (phase.kind === "done") {
      rows.push(
        <Text key="hint" font="footnote" foregroundStyle="secondaryLabel">{phase.note}</Text>,
      )
      if (phase.allSent) {
        rows.push(
          <Text key="hint2" font="footnote" foregroundStyle="secondaryLabel">
            手機這邊已經没事做了；FBI 不會回報自己的安裝結果，請以 3DS 螢幕上的提示為準。
          </Text>,
        )
      }
    }

    if (phase.kind === "downloading" && progress && now - progress.lastActivityAt > QUIET_WARNING_SECONDS * 1000) {
      rows.push(
        <Text key="quiet" font="footnote" foregroundStyle="orange">
          已經 {clockText((now - progress.lastActivityAt) / 1000)} 沒有新進度。3DS 安裝大檔案時屬於正常現象；
          若 3DS 已中斷，可在下方停止。
        </Text>,
      )
    }

    if (serverInfo) {
      rows.push(
        <HStack key="server" spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Image systemName="externaldrive.connected.to.line.below" foregroundStyle="secondaryLabel" imageScale="small" />
          <Text font="caption" fontDesign="monospaced" foregroundStyle="secondaryLabel" textSelection>
            http://{serverInfo.lanIp}:{serverInfo.port}
          </Text>
          <Spacer />
          <Button title="停止伺服器" role="destructive" action={stopEverything} />
        </HStack>,
      )
    }

    return <VStack alignment="leading" spacing={12}>{rows}</VStack>
  }

  function statusDetail(): string {
    switch (phase.kind) {
      case "sending":
        if (progress?.payloadState === "sending") return `正在把清單送到 ${targetLabel}…`
        if (serverInfo) return `伺服器 ${serverInfo.lanIp}:${serverInfo.port} 已就緒`
        return "啟動本機伺服器…"
      case "waiting":
        return `清單已送至 ${targetLabel}`
      case "downloading":
        return `已用時 ${clockText(elapsed)}`
      case "done": {
        const total = phase.finishedAt - phase.since
        return `總計用時 ${clockText(total / 1000)}`
      }
      case "failed":
        return phase.reason
      default:
        return ""
    }
  }

  // 底部主按鈕：文案隨狀態改變；空清單且待機時不顯示，避免和卡片內的加入按鈕重複
  const primary = (() => {
    switch (phase.kind) {
      case "sending":
        return {
          title: progress?.payloadState === "sending" ? "正在通知 3DS…" : "正在準備…",
          icon: "hourglass",
          disabled: true,
          action: () => {},
        }
      case "waiting":
        return { title: "等待 3DS 確認…", icon: "hourglass", disabled: true, action: () => {} }
      case "downloading":
        return { title: "標記為完成", icon: "checkmark", disabled: false, action: () => finish(progress?.allSent ?? false, "你手動標記為完成") }
      case "done":
        return { title: "完成並關閉", icon: "checkmark.circle", disabled: false, action: shutdown }
      case "failed":
        return { title: "重試", icon: "arrow.clockwise", disabled: false, action: () => { void send() } }
      default:
        // idle 狀態：只有清單內有檔案時才顯示「傳送到 3DS」，空清單時不顯示懸浮按鈕
        return entries.length > 0
          ? { title: "傳送到 3DS", icon: "paperplane.fill", disabled: false, action: () => { void send() } }
          : null
    }
  })()

  const secondary = (() => {
    switch (phase.kind) {
      case "sending":
      case "waiting":
      case "downloading":
        return { title: "停止", action: () => setConfirmStop(true) }
      case "done":
        return { title: "傳送其他檔案", action: resetForNewTransfer }
      case "failed":
        return { title: "關閉", action: shutdown }
      default:
        return null
    }
  })()

  const entriesHeader = entries.length > 0
    ? `要安裝的項目（${entries.length} 個 · ${formatSize(totalBytes)}）`
    : "要安裝的項目"

  const statusCard = renderStatus()

  return (
    <NavigationStack>
      <List
        listStyle="insetGroup"
        listSectionSpacing="compact"
        navigationTitle="CIA Dropper"
        navigationBarTitleDisplayMode="inline"
        navigationSubtitle={targetLabel}
        toolbar={{
          cancellationAction: <Button title="關閉" action={requestClose} />,
          confirmationAction: (
            <HStack spacing={14}>
              <Button
                title="說明"
                systemImage="questionmark.circle"
                action={() => setActiveSheet("guide")}
              />
              <Button
                title="記錄"
                systemImage="doc.text.magnifyingglass"
                action={() => setActiveSheet("log")}
              />
              <Menu title="加入" systemImage="plus" disabled={!showSetup}>
                <Button
                  title="加入檔案"
                  systemImage="doc.badge.plus"
                  action={() => { void addFiles() }}
                />
                <Button
                  title="貼上下載網址"
                  systemImage="link"
                  action={() => { void addUrl() }}
                />
              </Menu>
            </HStack>
          ),
        }}
        alert={{
          title: error?.title ?? "",
          message: <Text>{error?.message ?? ""}</Text>,
          actions: <Button title="知道了" action={() => setError(null)} />,
          isPresented: error !== null,
          onChanged: presented => { if (!presented) setError(null) },
        }}
        toast={{
          message: toastText,
          isPresented: toastPresented,
          onChanged: presented => {
            setToastPresented(presented)
          },
          position: "bottom",
          duration: 2.2,
        }}
        sheet={{
          isPresented: activeSheet !== null,
          onChanged: presented => {
            if (!presented) setActiveSheet(null)
          },
          content: activeSheet === "log"
            ? <LogSheet logs={logs} onClear={() => setLogs([])} onClose={() => setActiveSheet(null)} />
            : activeSheet === "guide"
              ? <GuideSheet onClose={() => setActiveSheet(null)} />
              : (
                <TargetSheet
                  key={`${targetIp}:${targetPort}`}
                  consoles={consoles}
                  initialIp={targetIp}
                  initialPort={targetPort}
                  onApply={(ip, port) => { setTargetIp(ip); setTargetPort(String(port)) }}
                  onForget={entry => {
                    forgetConsole(entry.ip, entry.port)
                    setConsoles(loadConsoles())
                    log(`已忘記 ${entry.ip}:${entry.port}`)
                  }}
                  onClose={() => setActiveSheet(null)}
                />
              ),
        }}
        safeAreaInset={
          confirmStop || primary !== null || secondary !== null
            ? {
              bottom: {
                spacing: 0,
                content: (
                  <VStack
                    spacing={8}
                    padding={{ horizontal: 24, vertical: 12 }}
                    frame={{ maxWidth: "infinity" }}
                    transition={Transition.asymmetric(
                      Transition.move("bottom").combined(Transition.opacity()),
                      Transition.move("bottom").combined(Transition.opacity()),
                    )}
                  >
                    {confirmStop
                      ? [
                        <Button
                          key="stop"
                          title="確定停止傳輸"
                          systemImage="stop.circle.fill"
                          role="destructive"
                          buttonStyle="borderedProminent"
                          controlSize="large"
                          frame={{ maxWidth: "infinity" }}
                          shadow={{ color: "rgba(0,0,0,0.15)", radius: 10, y: 4 }}
                          action={stopEverything}
                        />,
                        <Button
                          key="back"
                          title="繼續"
                          buttonStyle="bordered"
                          controlSize="regular"
                          frame={{ maxWidth: "infinity" }}
                          action={() => setConfirmStop(false)}
                        />,
                      ]
                      : [
                        ...(primary
                          ? [
                            <Button
                              key="primary"
                              title={primary.title}
                              systemImage={primary.icon}
                              buttonStyle="borderedProminent"
                              controlSize="large"
                              frame={{ maxWidth: "infinity" }}
                              shadow={{ color: "rgba(0,0,0,0.15)", radius: 12, y: 5 }}
                              disabled={primary.disabled}
                              action={primary.action}
                            />,
                          ]
                          : []),
                        ...(secondary
                          ? [
                            <Button
                              key="secondary"
                              title={secondary.title}
                              buttonStyle="plain"
                              foregroundStyle="secondaryLabel"
                              font="subheadline"
                              action={secondary.action}
                            />,
                          ]
                          : []),
                      ]}
                  </VStack>
                ),
              },
            }
            : undefined
        }
      >
        {statusCard !== null ? <Section>{statusCard}</Section> : null}

        {/* 權限沒開時先在畫面上講清楚（不然傳送時只能看到「伺服器啟動失敗」） */}
        {showSetup && fileAccess === false ? (
          <Section>
            <Button action={() => { void refreshFileAccess() }}>
              <HStack spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                <Image systemName="exclamationmark.triangle.fill" foregroundStyle="orange" />
                <VStack alignment="leading" spacing={2}>
                  <Text foregroundStyle="orange">未取得「檔案讀寫」權限</Text>
                  <Text font="footnote" foregroundStyle="secondaryLabel">
                    沒有它無法讀取檔案、也無法寫入傳輸進度。長按這個腳本 →「權限」→ 開啟「檔案讀寫」，然後點一下這裡重新檢查。
                  </Text>
                </VStack>
              </HStack>
            </Button>
          </Section>
        ) : null}

        {/* 傳輸中與結束後只留狀態卡：設定與清單只在待機／出錯時出現 */}
        {showSetup ? (
        <Section
          header={<Text>3DS 主機</Text>}
          footer={
            isSubnetMismatch ? (
              <Text foregroundStyle="orange">
                ⚠️ 注意：iPhone 目前 IP 為 {localIp}，與 3DS 的網段不同，傳輸可能會失敗。請確認兩者連接至相同的 Wi-Fi。
              </Text>
            ) : localIp ? (
              <Text>
                本機 iPhone Wi-Fi：{localIp} · 區域網路通訊良好
              </Text>
            ) : undefined
          }
        >
          <Button action={() => setActiveSheet("target")}>
            <HStack spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }} foregroundStyle="label">
              <Image
                systemName={isValidIPv4(targetIp) ? "wifi.router.fill" : "wifi.router"}
                foregroundStyle={isValidIPv4(targetIp) ? (isSubnetMismatch ? "orange" : "tintColor") : "secondaryLabel"}
              />
              <VStack alignment="leading" spacing={2}>
                <Text>{targetLabel}</Text>
                <Text font="footnote" foregroundStyle="secondaryLabel">
                  {isValidIPv4(targetIp) ? "點一下可以更換或選擇已記住的 3DS" : "還沒設定，點一下輸入 FBI 畫面上的 IP"}
                </Text>
              </VStack>
              <Spacer />
              <Image systemName="chevron.right" font="footnote" foregroundStyle="tertiaryLabel" />
            </HStack>
          </Button>
        </Section>
        ) : null}

        {showSetup ? (
        <Section
          header={
            <HStack frame={{ maxWidth: "infinity" }}>
              <Text>{entriesHeader}</Text>
              <Spacer />
              {entries.length > 0 ? (
                <Button
                  title="清空"
                  role="destructive"
                  action={() => {
                    void withAnimation(Animation.spring({ duration: 0.3, bounce: 0.2 }), () => {
                      setEntries([])
                    })
                  }}
                />
              ) : null}
            </HStack>
          }
          footer={
            entries.length > 0 ? (
              <Text>
                清單只屬於這次傳送，關閉即清空。選檔透過系統書籤存取，不會產生多餘的複本。
                {brokenCount > 0 ? `目前有 ${brokenCount} 個檔案讀不到，傳送前請先移除。` : ""}
              </Text>
            ) : undefined
          }
        >
          {entries.length === 0 ? (
            // 一列只能有一個 Button：同一列放兩個的話，整列的點擊都會落到第一個（SwiftUI List 的行為）
            [
              <Button key="addFile" action={() => { void addFiles() }}>
                <HStack spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }} foregroundStyle="label">
                  <Image systemName="doc.badge.plus" foregroundStyle="tintColor" />
                  <Text>選擇 CIA / TIK 檔案</Text>
                </HStack>
              </Button>,
              <Button key="addUrl" action={() => { void addUrl() }}>
                <HStack spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }} foregroundStyle="label">
                  <Image systemName="link" foregroundStyle="tintColor" />
                  <Text>貼上下載網址</Text>
                </HStack>
              </Button>,
            ]
          ) : (
            entries.map((entry, index) => {
              const path = entry.kind === "local" ? resolvedPath(entry) : null
              const broken = entry.kind === "local" && !path
              const meta = fileIconAndTint(entry, broken)
              return (
                <HStack
                  key={`${entry.name}-${index}`}
                  spacing={12}
                  frame={{ maxWidth: "infinity", alignment: "leading" }}
                  trailingSwipeActions={{
                    allowsFullSwipe: true,
                    actions: [
                      <Button key="remove" title="移除" systemImage="trash" role="destructive" action={() => removeEntry(index)} />,
                    ],
                  }}
                >
                  <Image
                    systemName={meta.icon}
                    foregroundStyle={meta.tint}
                  />
                  <VStack alignment="leading" spacing={2}>
                    <Text lineLimit={1} truncationMode="middle">{entry.name}</Text>
                    <Text font="footnote" foregroundStyle={broken ? "orange" : "secondaryLabel"}>
                      {entry.kind === "url"
                        ? "外部網址 · 由 3DS 直接下載"
                        : broken
                          ? "找不到此檔案"
                          : `本機檔案 · ${formatSize(fileSize(path as string))}`}
                    </Text>
                  </VStack>
                </HStack>
              )
            })
          )}
          {entries.length > 0 ? (
            [
              <Button key="addFile" action={() => { void addFiles() }}>
                <HStack spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }} foregroundStyle="label">
                  <Image systemName="doc.badge.plus" foregroundStyle="tintColor" imageScale="small" />
                  <Text font="subheadline">繼續加入檔案</Text>
                </HStack>
              </Button>,
              <Button key="addUrl" action={() => { void addUrl() }}>
                <HStack spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }} foregroundStyle="label">
                  <Image systemName="link" foregroundStyle="tintColor" imageScale="small" />
                  <Text font="subheadline">加入下載網址</Text>
                </HStack>
              </Button>,
            ]
          ) : null}
        </Section>
        ) : null}
      </List>
    </NavigationStack>
  )
}

/** 把選擇器給的路徑轉成清單項目 */
export function toLocalEntry(rawPath: string): FileEntry {
  const path = normalizeFilePath(rawPath)
  return { kind: "local", name: basename(path), path }
}

export function mergeEntries(current: FileEntry[], incoming: FileEntry[]): FileEntry[] {
  const merged = [...current]
  for (const item of incoming) {
    const duplicate = merged.some(
      e => e.name === item.name || (e.kind === "url" && item.kind === "url" && e.url === item.url),
    )
    if (!duplicate) merged.push(item)
  }
  return merged
}

export async function presentUI(seed: FileEntry[] = [], initialLogs: string[] = []): Promise<void> {
  const logs = [...initialLogs]
  let fileAccess: boolean | null = null
  try {
    const granted = await Script.requestAccess(["fileSystem"])
    fileAccess = granted.includes("fileSystem")
    if (!fileAccess) {
      logs.push("檔案權限未取得，請長按腳本開啟權限")
    }
  } catch (e) {
    logs.push(`權限檢查失敗：${String(e)}`)
  }
  const initial = mergeEntries([], seed)
  await Navigation.present(<MainView seed={initial} initialLogs={logs} fileAccess={fileAccess} />)
  await cleanupServerFiles()
  Script.exit()
}
