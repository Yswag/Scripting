/*
 * CIA Dropper
 * Copyright (c) 2026 ykusu — MIT License
 * Inspired by SFYGameTransferrer: https://github.com/socksprox/SFYGameTransferrer
 */

import { Script } from "scripting"

export const DEFAULT_PORT = 5000

export type ServedFile = {
  path: string
  name: string
  externalUrl?: string
}

export type FilePhase = "pending" | "sending" | "done" | "aborted"

export type ServerState =
  | "listening"
  | "serving"
  | "idle"
  | "finished"
  | "cancelled"
  | "error"

export interface FileProgress {
  name: string
  size: number
  sentBytes: number
  state: FilePhase
  peerClosed?: boolean
}

export type PayloadState = "idle" | "sending" | "sent" | "failed"

export interface TransferProgress {
  state: ServerState
  port: number
  files: FileProgress[]
  currentName: string | null
  totalBytes: number
  sentBytes: number
  requestCount: number
  lastActivityAt: number
  idleMs: number
  message: string
  peerClosed: boolean
  aborted: boolean
  payloadState: PayloadState
  payloadDetail: string
  completedCount: number
  totalCount: number
  allSent: boolean
  fraction: number
  bytesPerSecond: number | null
  remainingSeconds: number | null
}

// ─── 內部狀態 ───────────────────────────────────────────────

let progressPath: string | null = null
let cancelPath: string | null = null
let configPath: string | null = null
let serverPort: number | null = null
let serverRunning = false

/**
 * 速率取樣：保留最近幾秒的 (時間, 已送出位元組) 快照，用滑動窗平均。
 * （瞬時值不能用：socket buffer 會讓 sentBytes 一次跳 1 MB 以上。）
 */
let samples: { at: number; bytes: number }[] = []

const SPEED_WINDOW_MS = 4000
const SPEED_MIN_SECONDS = 0.8
const PROGRESS_STALE_MS = 4000

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms))
}

function serveScriptPath(): string {
  return `${Script.directory}/python/serve.py`
}

function serverRoot(): string {
  return `${FileManager.temporaryDirectory}/cia-dropper`
}

export function isServerRunning(): boolean {
  return serverRunning
}

export function runningPort(): number | null {
  return serverPort
}

export function getLanIp(): string | null {
  try {
    const interfaces = Device.networkInterfaces() as Record<
      string,
      Array<{ address: string; family: string; isInternal: boolean }>
    >
    const fromInterface = (name: string): string | null => {
      const list = interfaces[name]
      if (!list) return null
      const v4 = list.find(item => item.family === "IPv4" && !item.isInternal)
      return v4 ? v4.address : null
    }

    const wifi = fromInterface("en0")
    if (wifi) return wifi

    for (const name of Object.keys(interfaces)) {
      if (name === "lo0" || name.startsWith("utun") || name.startsWith("ipsec") || name.startsWith("pdp_ip")) continue
      const address = fromInterface(name)
      if (address) return address
    }
  } catch {
    // 忽略
  }
  return null
}

export async function startFileServer(
  files: ServedFile[],
  log: (message: string) => void,
  options: StartServerOptions = {},
): Promise<StartServerResult> {
  const requested = options.port ?? 0
  const first = await startFileServerOnce(files, log, requested, options.notify)
  if (first.error !== null && requested !== 0) {
    log(`Port ${requested} 啟動失敗，改用系統隨機指派`)
    return await startFileServerOnce(files, log, 0, options.notify)
  }
  return first
}

export interface NotifyTarget {
  host: string
  port: number
  ackWaitSeconds?: number
}

export interface StartServerOptions {
  port?: number
  notify?: NotifyTarget
}

export interface StartServerResult {
  lanIp: string | null
  port: number | null
  error: string | null
}

async function startFileServerOnce(
  files: ServedFile[],
  log: (message: string) => void,
  port: number,
  notify?: NotifyTarget,
): Promise<StartServerResult> {
  stopFileServer()
  serverRunning = false
  serverPort = null

  const lanIp = getLanIp()
  if (!lanIp) {
    return { lanIp: null, port: null, error: "找不到 Wi-Fi 的 IPv4 位址（請確認已連上 Wi-Fi 或熱點）" }
  }

  const script = serveScriptPath()
  if (!FileManager.existsSync(script)) {
    return { lanIp, port: null, error: `找不到伺服器腳本：${script}` }
  }

  const root = serverRoot()
  const run = `${root}/${Date.now()}`
  try {
    FileManager.createDirectorySync(run, true)
  } catch (e) {
    return { lanIp, port: null, error: `無法建立暫存目錄：${String(e)}` }
  }

  progressPath = `${run}/progress.json`
  cancelPath = `${run}/cancel.flag`
  configPath = `${run}/config.json`

  const localFiles = files
    .filter(file => !file.externalUrl)
    .map(file => ({ name: file.name, path: file.path, size: fileSize(file.path) }))

  const items = files.map(file =>
    file.externalUrl ? { url: file.externalUrl } : { name: file.name },
  )

  const config: Record<string, unknown> = {
    port,
    bind: "0.0.0.0",
    lanIp,
    files: localFiles,
    progressPath,
    cancelPath,
    idleTimeoutSeconds: 900,
    chunkSize: 65536,
  }
  if (notify && notify.host) {
    config.notify = {
      host: notify.host,
      port: notify.port,
      ackWaitSeconds: notify.ackWaitSeconds ?? 0.5,
      items,
    }
  }

  try {
    FileManager.writeAsStringSync(configPath, JSON.stringify(config))
  } catch (e) {
    return { lanIp, port: null, error: `無法寫入設定檔：${String(e)}` }
  }

  try {
    const state: { exited: number | null } = { exited: null }
    Python.runFile(script, {
      env: { CIA_SERVE_CONFIG: configPath },
      timeout: 86400,
    })
      .then(result => {
        state.exited = result.exitCode
        serverRunning = false
        log(`伺服器結束（exit=${result.exitCode}）`)
      })
      .catch(error => {
        state.exited = -1
        serverRunning = false
        log(`伺服器異常結束：${String(error)}`)
      })

    for (let attempt = 0; attempt < 60; attempt++) {
      await sleep(100)
      if (state.exited !== null) {
        const tail = readRawProgress()
        return {
          lanIp,
          port: null,
          error: `伺服器啟動後異常退出（exit=${state.exited}）${tail?.message ? `：${tail.message}` : ""}`,
        }
      }
      const snapshot = readRawProgress()
      if (!snapshot) continue
      if (snapshot.state === "error") {
        return { lanIp, port: null, error: snapshot.message || "伺服器啟動失敗" }
      }
      if (snapshot.port > 0) {
        serverPort = snapshot.port
        serverRunning = true
        log(`HTTP 伺服器已啟動：http://${lanIp}:${snapshot.port}`)
        return { lanIp, port: snapshot.port, error: null }
      }
    }

    const tail = readRawProgress()
    return {
      lanIp,
      port: null,
      error: `伺服器未在時限內就緒${tail?.message ? `（${tail.message}）` : ""}`,
    }
  } catch (e) {
    return { lanIp, port: null, error: `無法啟動伺服器：${String(e)}` }
  }
}

export function stopFileServer(): void {
  if (cancelPath) {
    try {
      if (!FileManager.existsSync(cancelPath)) FileManager.writeAsStringSync(cancelPath, String(Date.now()))
    } catch {
      // 忽略
    }
  }
  serverRunning = false
}

export async function cleanupServerFiles(): Promise<void> {
  stopFileServer()
  await sleep(700)
  try {
    const root = serverRoot()
    if (FileManager.existsSync(root)) FileManager.removeSync(root)
  } catch {
    // 忽略
  }
  progressPath = null
  cancelPath = null
  configPath = null
  serverPort = null
  serverRunning = false
  samples = []
}

// ─── 進度讀取 ───────────────────────────────────────────────

interface RawProgress {
  state: ServerState
  port: number
  files: FileProgress[]
  currentName: string | null
  totalBytes: number
  sentBytes: number
  requestCount: number
  updatedAt: number
  message: string
  payloadState: PayloadState
  payloadDetail: string
}

/** 直接讀 python 寫的 JSON；讀不到或格式不對回 null */
function readRawProgress(): RawProgress | null {
  if (!progressPath) return null
  try {
    if (!FileManager.existsSync(progressPath)) return null
    const text = FileManager.readAsStringSync(progressPath)
    if (!text) return null
    const parsed = JSON.parse(text) as Partial<RawProgress>
    if (typeof parsed !== "object" || parsed === null) return null
    return {
      state: (parsed.state ?? "listening") as ServerState,
      port: Number(parsed.port ?? 0),
      files: Array.isArray(parsed.files) ? parsed.files : [],
      currentName: parsed.currentName ?? null,
      totalBytes: Number(parsed.totalBytes ?? 0),
      sentBytes: Number(parsed.sentBytes ?? 0),
      requestCount: Number(parsed.requestCount ?? 0),
      updatedAt: Number(parsed.updatedAt ?? 0),
      message: String(parsed.message ?? ""),
      payloadState: (parsed.payloadState ?? "idle") as PayloadState,
      payloadDetail: String(parsed.payloadDetail ?? ""),
    }
  } catch {
    return null
  }
}

export function getProgress(): TransferProgress | null {
  const raw = readRawProgress()
  if (!raw) return null

  const nowMs = Date.now()
  const updatedAtMs = raw.updatedAt > 0 ? raw.updatedAt * 1000 : nowMs

  if (samples.length > 0 && raw.sentBytes < samples[samples.length - 1].bytes) {
    samples = []
  }
  samples.push({ at: nowMs, bytes: raw.sentBytes })
  while (samples.length > 2 && nowMs - samples[0].at > SPEED_WINDOW_MS) samples.shift()
  const spanSeconds = (nowMs - samples[0].at) / 1000
  const spanBytes = raw.sentBytes - samples[0].bytes
  const measuredSpeed = spanSeconds >= SPEED_MIN_SECONDS && spanBytes > 0 ? spanBytes / spanSeconds : null

  const files: FileProgress[] = raw.files.map(file => ({
    name: String(file.name ?? ""),
    size: Number(file.size ?? 0),
    sentBytes: Number(file.sentBytes ?? 0),
    state: (file.state ?? "pending") as FilePhase,
    peerClosed: Boolean(file.peerClosed),
  }))

  const completedCount = files.filter(file => file.state === "done").length
  const totalBytes = raw.totalBytes || files.reduce((sum, file) => sum + file.size, 0)
  const sentBytes = files.reduce((sum, file) => sum + file.sentBytes, 0)
  const allSent = files.length > 0 && completedCount === files.length
  const fraction = totalBytes > 0 ? Math.max(0, Math.min(1, sentBytes / totalBytes)) : 0
  const bytesPerSecond = measuredSpeed
  const remainingSeconds = bytesPerSecond !== null
    ? Math.max(0, (totalBytes - sentBytes) / bytesPerSecond)
    : null

  return {
    state: raw.state,
    port: raw.port,
    files,
    currentName: raw.currentName,
    totalBytes,
    sentBytes,
    requestCount: raw.requestCount,
    lastActivityAt: updatedAtMs,
    idleMs: Math.max(0, nowMs - updatedAtMs),
    message: raw.message,
    peerClosed: files.some(file => file.state === "done" && file.peerClosed === true),
    aborted: files.some(file => file.state === "aborted"),
    payloadState: raw.payloadState,
    payloadDetail: raw.payloadDetail,
    completedCount,
    totalCount: files.length,
    allSent,
    fraction,
    bytesPerSecond,
    remainingSeconds,
  }
}

export function progressIsStale(progress: TransferProgress): boolean {
  return progress.idleMs > PROGRESS_STALE_MS
}

export function fileSize(path: string): number {
  try {
    return FileManager.statSync(path).size
  } catch {
    return 0
  }
}

export function formatSize(bytes: number): string {
  if (!bytes) return "0 B"
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`
  if (bytes < 1073741824) return `${(bytes / 1048576).toFixed(1)} MB`
  return `${(bytes / 1073741824).toFixed(2)} GB`
}
