/*
 * CIA Dropper
 * Copyright (c) 2026 ykusu — MIT License
 * Inspired by SFYGameTransferrer: https://github.com/socksprox/SFYGameTransferrer
 */

export type ConsoleEntry = {
  name: string
  ip: string
  port: number
  lastUsed: number
}

export type FileEntry = {
  kind: "local" | "url"
  name: string
  path?: string
  url?: string
}

const CONSOLE_KEY = "consoles"
const MAX_CONSOLES = 20

export function loadConsoles(): ConsoleEntry[] {
  try {
    const list = Storage.get<ConsoleEntry[]>(CONSOLE_KEY)
    if (!Array.isArray(list)) return []
    return list.filter(
      c => !!c && typeof c.ip === "string" && typeof c.port === "number" && typeof c.lastUsed === "number",
    )
  } catch {
    return []
  }
}

export function saveConsoles(list: ConsoleEntry[]): boolean {
  try {
    return Storage.set(CONSOLE_KEY, list.slice(0, MAX_CONSOLES))
  } catch {
    return false
  }
}

export function rememberConsole(ip: string, port: number, name?: string): boolean {
  const list = loadConsoles().filter(c => !(c.ip === ip && c.port === port))
  list.unshift({ name: name || ip, ip, port, lastUsed: Date.now() })
  return saveConsoles(list)
}

export function forgetConsole(ip: string, port: number): boolean {
  return saveConsoles(loadConsoles().filter(c => !(c.ip === ip && c.port === port)))
}

export function recentConsole(): ConsoleEntry | null {
  const list = loadConsoles()
  if (list.length === 0) return null
  return [...list].sort((a, b) => b.lastUsed - a.lastUsed)[0]
}

const LAST_DIR_KEY = "lastPickDirectory"

export function lastPickDirectory(): string | null {
  try {
    const saved = Storage.get<string>(LAST_DIR_KEY)
    if (typeof saved !== "string" || !saved) return null
    return FileManager.existsSync(saved) ? saved : null
  } catch {
    return null
  }
}

export function rememberPickDirectory(filePath: string): void {
  try {
    const slash = filePath.lastIndexOf("/")
    const dir = slash > 0 ? filePath.slice(0, slash) : ""
    if (dir) Storage.set(LAST_DIR_KEY, dir)
  } catch {
    // 忽略
  }
}
