# CIA Dropper

透過 Wi-Fi 將 CIA / TIK 檔案從 iPhone / iPad 傳送到 Nintendo 3DS 並安裝，免用電腦。
基於 [Scripting](https://scripting.fun) App 開發；靈感來自 [SFYGameTransferrer](https://github.com/socksprox/SFYGameTransferrer)。

## 需求

- iPhone / iPad：安裝 [Scripting](https://scripting.fun)，並開啟「區域網路」與「檔案讀寫」權限
- Nintendo 3DS：安裝 [FBI](https://github.com/Steveice10/FBI)
- 兩台裝置需連線至相同 Wi-Fi
- 無需安裝額外 Python 或 Node 套件

## 安裝

將 `CIA Dropper` 資料夾放入 Scripting 的 `scripts` 目錄（或透過 App 匯入）即可直接執行。

## 使用步驟

1. **3DS**：打開 FBI → 選擇 **Remote Install** → **Receive URLs over the network**，記下螢幕顯示的 `IP:Port`（預設 Port 為 5000）。
2. **手機**：點擊頂部 **3DS 主機** 輸入該 `IP:Port`（成功連線後會自動記住）。
3. **加入項目**：點擊 **加入檔案** 選取 CIA / TIK，或 **加入網址** 貼上直接下載連結；亦支援在「檔案」App 分享選單中直接分享 `.cia` / `.tik`。
4. **傳送**：點擊 **傳送到 3DS**，並在 3DS 上按 A 鍵確認安裝。
5. 傳輸完成且 3DS 安裝完畢後，點擊 **標記為完成**。

## 特色

- **即時進度**：顯示傳輸進度、速率、預估剩餘時間與多檔進度
- **原地讀取**：直接串流選定路徑，不額外複製檔案佔用儲存空間
- **外部網址**：支援傳送 HTTP(S) 下載連結供 3DS 直接下載
- **記錄主機與目錄**：自動記憶上次連線的 3DS IP 與選檔目錄
- **分享表整合**：支援自「檔案」App 或 Safari 分享 CIA / TIK 檔與網址

## 常見問題

**顯示「讀不到這個檔案」**
- 請確認已開啟 Scripting 的檔案存取權限（長按腳本 → 權限 → 檔案讀寫）。
- 若透過分享選單開啟仍讀不到，請改由 App 內的「加入檔案」手動選取。

**3DS 未出現確認畫面**
- 確認 3DS 停留在 FBI 接收畫面，且 IP/Port 與手機輸入一致。
- 確認兩台裝置在相同區域網路子網段。
- 若有開啟 VPN / 代理軟體（如 Surge / Shadowrocket），請確認區網流量未被轉發至 TUN 虛擬網卡。

**進度停在安裝中**
- 多檔案傳輸時，FBI 裝完前一個檔案才會請求下一個，中間有短暫等待為正常現象。
- 若 3DS 端已取消或中斷，可手動點擊「停止」。

## 運作原理

1. 手機端啟動本機 HTTP 伺服器，將選定的檔案串流提供給 3DS。
2. 伺服器綁定 Port 後，主動向 3DS 的 FBI 監聽埠建立 TCP 連線，送出「4-byte 大端長度 + `\n` 分隔的 URL 清單」。
3. 3DS 收到後回連手機下載檔案並安裝。

伺服器採用 Python Socket 實作，利用 `socket.sendall` 傳輸背壓以取得精確的已傳送 Byte 數與速率。

## 授權

MIT License（詳見 `LICENSE`）。

- 作者：**ykusu**
- 靈感來源：[SFYGameTransferrer](https://github.com/socksprox/SFYGameTransferrer) by **socksprox**
- 協定參考：[3DS FBI Link](https://github.com/smartperson/3DS-FBI-Link) by **Varun Mehta**
- 3DS 端工具：[FBI](https://github.com/Steveice10/FBI) by **Steveice10**
