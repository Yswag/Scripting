/*
 * CIA Dropper
 * Copyright (c) 2026 ykusu — MIT License
 * Inspired by SFYGameTransferrer: https://github.com/socksprox/SFYGameTransferrer
 */
import { presentUI } from "./lib/ui"

presentUI()
