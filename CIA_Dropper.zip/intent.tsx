/*
 * CIA Dropper
 * Copyright (c) 2026 ykusu — MIT License
 * Inspired by SFYGameTransferrer: https://github.com/socksprox/SFYGameTransferrer
 */
import { Intent, Script } from "scripting"
import { FileEntry } from "./lib/store"
import { basename, fileExists, nameFromUrl, normalizeFilePath, presentUI, toLocalEntry } from "./lib/ui"

const GUARD_KEY = "intentLaunchedAt"
const GUARD_WINDOW_MS = 2500

const INSTALLABLE = /\.(cia|tik)$/i

function isDuplicateLaunch(): boolean {
  try {
    const last = Storage.get<number>(GUARD_KEY)
    Storage.set(GUARD_KEY, Date.now())
    return typeof last === "number" && Date.now() - last < GUARD_WINDOW_MS
  } catch {
    return false
  }
}

function urlsFromValue(raw: unknown, out: string[], depth = 0): void {
  if (raw == null || depth > 4) return

  if (typeof raw === "string") {
    const matches = raw.match(/https?:\/\/[A-Za-z0-9\-._~:/?#@!$&*+,;=%\[\]]+/gi)
    if (matches) {
      for (const match of matches) out.push(match.replace(/[.,;:]+$/, ""))
    }
    return
  }

  if (Array.isArray(raw)) {
    for (const item of raw) urlsFromValue(item, out, depth + 1)
    return
  }

  if (typeof raw === "object") {
    for (const value of Object.values(raw as Record<string, unknown>)) {
      urlsFromValue(value, out, depth + 1)
    }
  }
}

function sharedPaths(): string[] {
  const paths: string[] = []

  for (const item of Intent.fileURLsParameter ?? []) {
    if (typeof item === "string" && item) paths.push(item)
  }

  const shortcut = Intent.shortcutParameter as { type?: string; value?: unknown } | null | undefined
  if (shortcut?.type === "fileURL" && typeof shortcut.value === "string") {
    paths.push(shortcut.value)
  }

  return paths
}

function collectSharedFiles(logs: string[]): FileEntry[] {
  const seed: FileEntry[] = []
  const seen = new Set<string>()

  for (const raw of sharedPaths()) {
    const path = normalizeFilePath(raw)
    const name = basename(path)
    if (seen.has(path)) continue
    seen.add(path)

    if (!INSTALLABLE.test(name)) {
      logs.push(`略過不支援的檔案：${name}`)
      continue
    }

    if (!fileExists(path)) {
      logs.push(`讀取失敗（無權限或檔案不存在）：${name}`)
      continue
    }

    seed.push(toLocalEntry(path))
    logs.push(`加入分享檔案：${name}`)
  }

  return seed
}

function collectSeed(): { urlSeed: FileEntry[]; summary: string } {
  const urls: string[] = []

  urlsFromValue(Intent.urlsParameter ?? [], urls)
  urlsFromValue(Intent.textsParameter ?? [], urls)

  const shortcut = Intent.shortcutParameter as unknown as Record<string, unknown> | null | undefined
  if (shortcut) {
    const wrapped = "value" in shortcut && "type" in shortcut
    urlsFromValue(wrapped ? shortcut.value : shortcut, urls)
  }

  const unique = Array.from(new Set(urls))
  const urlSeed: FileEntry[] = unique.map(url => ({ kind: "url", name: nameFromUrl(url), url }))

  const parts: string[] = []
  if (Intent.fileURLsParameter?.length) parts.push(`files=${Intent.fileURLsParameter.length}`)
  if (shortcut) parts.push(`shortcutParameter=${String(shortcut.type ?? "object")}`)
  if (Intent.urlsParameter?.length) parts.push(`urls=${Intent.urlsParameter.length}`)
  if (Intent.textsParameter?.length) parts.push(`texts=${Intent.textsParameter.length}`)

  return { urlSeed, summary: parts.join(" ") }
}

async function main() {
  const logs: string[] = []
  try {
    if (isDuplicateLaunch()) {
      Script.exit()
      return
    }

    const { urlSeed, summary } = collectSeed()
    const fileSeed = collectSharedFiles(logs)
    const seed = [...fileSeed, ...urlSeed]

    if (summary) {
      logs.unshift(`分享輸入：${summary}（${seed.length} 個項目）`)
    }

    await presentUI(seed, logs)
  } catch (e) {
    logs.push(`Intent 錯誤：${String(e)}`)
    await presentUI([], logs)
  }
}

main()
