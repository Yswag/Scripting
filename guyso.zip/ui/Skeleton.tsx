// 載入骨架（U6）：用假字串撐出和真實列相同的版面，灰塊帶掃光。

import { HStack, Spacer, VStack } from "scripting"
import { space } from "../ui/theme"
import { ShimmerBox, ShimmerText } from "./Shimmer"

const RANK_WIDTH = 60
const COVER_OVERLAP = 10
const BLOCK_WIDTH = RANK_WIDTH - COVER_OVERLAP + 96

/** 3 個 Top3 骨架 + 10 個緊湊列骨架。 */
export function ChartSkeleton() {
  return (
    <VStack spacing={0} frame={{ maxWidth: "infinity" }}>
      <Top3Skeleton />
      <Top3Skeleton />
      <Top3Skeleton />
      {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(index => (
        <CompactSkeleton key={index} />
      ))}
    </VStack>
  )
}

/** 搜尋結果的骨架：沒有名次欄的緊湊列。 */
export function RowsSkeleton({ count = 8 }: { count?: number }) {
  return (
    <VStack spacing={0} frame={{ maxWidth: "infinity" }}>
      {Array.from({ length: count }).map((_, index) => (
        <CompactSkeleton key={`row-${index}`} showRank={false} />
      ))}
    </VStack>
  )
}

function CompactSkeleton({ showRank = true }: { showRank?: boolean }) {
  return (
    <HStack
      spacing={space.row}
      frame={{ maxWidth: "infinity", height: 64 }}
      padding={{ horizontal: space.page }}
    >
      {showRank ? (
        <ShimmerText font="title3" fontDesign="rounded" fontWeight="bold" width={36} alignment="center">
          00
        </ShimmerText>
      ) : null}
      <ShimmerBox width={44} height={44} corner={8} />
      <VStack alignment="leading" spacing={2}>
        <ShimmerText font="headline">歌名歌名歌名歌名</ShimmerText>
        <ShimmerText font="subheadline">歌手歌手歌手</ShimmerText>
      </VStack>
      <Spacer />
    </HStack>
  )
}

function Top3Skeleton() {
  return (
    <HStack
      spacing={0}
      frame={{ maxWidth: "infinity", height: 124 }}
      padding={{ horizontal: space.page }}
    >
      <HStack spacing={0} frame={{ width: BLOCK_WIDTH, height: 124 }}>
        <Spacer frame={{ width: RANK_WIDTH - COVER_OVERLAP }} />
        <ShimmerBox width={96} height={96} corner={12} />
      </HStack>

      <VStack alignment="leading" spacing={4} padding={{ leading: 16 }}>
        <ShimmerText font="title3" fontWeight="semibold">歌名歌名歌名</ShimmerText>
        <ShimmerText font="subheadline">歌手歌手歌手</ShimmerText>
        <VStack padding={{ top: 6 }}>
          <ShimmerText font="caption" fontWeight="bold" ratio={0.5}>↑0</ShimmerText>
        </VStack>
      </VStack>
      <Spacer minLength={0} />
    </HStack>
  )
}
