// 前三名列（U4）：大字名次壓在封面左緣，數字在上層。

import {
  Group,
  HStack,
  Rectangle,
  Spacer,
  Text,
  VStack,
  ZStack,
} from "scripting"
import type { ChartEntry } from "../model/types"
import { artistLine, formatCount } from "../model/song"
import { changeColor, space } from "../ui/theme"
import { Cover } from "../ui/Cover"
import { RankChangeView } from "../ui/RankChange"
import { useZoomNamespace } from "../ui/zoom"
import { SpotifyMenuItems } from "../ui/spotify"
import { PushRow } from "../ui/router"
import { SongScreen } from "../screens/SongScreen"

const RANK_WIDTH = 60
const COVER_OVERLAP = 10
const BLOCK_WIDTH = RANK_WIDTH - COVER_OVERLAP + 96

export function Top3Row({
  entry,
  zoomId,
  showValue = false,
  showDivider = true,
}: {
  entry: ChartEntry
  zoomId: string
  showValue?: boolean
  showDivider?: boolean
}) {
  const namespace = useZoomNamespace()

  return (
    <PushRow element={<SongScreen song={entry.song} transitionId={zoomId} />}>
      <VStack
        spacing={0}
        frame={{ maxWidth: "infinity" }}
        contentShape="rect"
        contextMenu={{
          menuItems: <SpotifyMenuItems song={entry.song} />,
        }}
      >
        <HStack
          spacing={0}
          frame={{ maxWidth: "infinity", height: 124 }}
          padding={{ horizontal: space.page }}
        >
          <ZStack frame={{ width: BLOCK_WIDTH, height: 124 }}>
            <HStack frame={{ width: BLOCK_WIDTH, height: 124 }}>
              <Text
                font={72}
                fontDesign="rounded"
                fontWeight="heavy"
                frame={{ width: RANK_WIDTH, alignment: "trailing" }}
                contentTransition="numericText"
              >
                {`${entry.rank}`}
              </Text>
              <Spacer />
            </HStack>
            <HStack spacing={0} frame={{ width: BLOCK_WIDTH, height: 124 }}>
              <Spacer frame={{ width: RANK_WIDTH - COVER_OVERLAP }} />
              <Cover
                image={entry.song.image}
                points={96}
                corner={12}
                zoom={namespace ? { id: zoomId, namespace } : undefined}
              />
            </HStack>
          </ZStack>

          <VStack alignment="leading" spacing={4} padding={{ leading: 16 }}>
            <Text font="title3" fontWeight="semibold" lineLimit={2}>
              {entry.song.name}
            </Text>
            <Text font="subheadline" foregroundStyle="secondaryLabel" lineLimit={1}>
              {artistLine(entry.song)}
            </Text>

            {showValue ? (
              <HStack spacing={6}>
                {entry.value == null ? (
                  <Text font="footnote">{" "}</Text>
                ) : (
                  <Group>
                    <Text font="footnote" monospacedDigit foregroundStyle="secondaryLabel">
                      {formatCount(entry.value)}
                    </Text>
                    {entry.valueDiff != null && entry.change.type !== "new" ? (
                      <Text
                        font="caption2"
                        monospacedDigit
                        foregroundStyle={entry.valueDiff >= 0 ? changeColor.up : changeColor.down}
                        contentTransition="numericText"
                      >
                        {`${entry.valueDiff >= 0 ? "+" : "−"}${formatCount(Math.abs(entry.valueDiff))}`}
                      </Text>
                    ) : null}
                  </Group>
                )}
              </HStack>
            ) : null}

            <HStack spacing={6} padding={{ top: 6 }}>
              <RankChangeView change={entry.change} align="leading" />
            </HStack>
          </VStack>

          <Spacer minLength={0} />
        </HStack>

        {showDivider ? (
          <Rectangle
            fill="separator"
            frame={{ maxWidth: "infinity", height: 0.5 }}
            padding={{ leading: space.page + BLOCK_WIDTH + 16 }}
          />
        ) : null}
      </VStack>
    </PushRow>
  )
}
