// 設計 token：間距、圓角、字級、色源。

import type { PlatformId } from "../model/types"
import type { Color } from "scripting"

export const space = {
  page: 20,
  section: 32,
  titleGap: 12,
  row: 12,
}

export const radius = {
  thumb: 8,
  cover: 12,
  large: 20,
  card: 24,
  cell: 16,
}

export type Hex = `#${string}`

export const changeColor = {
  up: "#f0780a",
  down: "#8cbefa",
  new: "#ff8a00",
  same: "#8c8c8c",
} as const

export const graphColor: Color[] = [
  "systemRed",
  "systemOrange",
  "systemYellow",
  "systemGreen",
  "systemTeal",
  "systemBlue",
  "systemIndigo",
  "systemPurple",
  "systemPink",
  "systemBrown",
]

export const platforms: { id: PlatformId; name: string }[] = [
  { id: "melon", name: "Melon" },
  { id: "genie", name: "Genie" },
  { id: "flo", name: "FLO" },
  { id: "bugs", name: "Bugs" },
  { id: "vibe", name: "VIBE" },
  { id: "circle", name: "Circle" },
  { id: "youtube", name: "YouTube" },
]

export function platformName(id: PlatformId): string {
  return platforms.find(p => p.id === id)?.name ?? id
}

export function logoUrl(id: PlatformId, size: number): string {
  return `https://cdn.guyso.me/image/logo/${id}.png?size=${size >= 80 ? 80 : size}`
}

/** 封面 URL 不帶 size，UI 依顯示尺寸補上。 */
export function coverAt(image: string, px: 80 | 400 | 800): string {
  if (image.startsWith("https://cdnimg.melon.co.kr/")) return `${image}/melon/resize/${px}`
  const separator = image.includes("?") ? "&" : "?"
  return `${image}${separator}size=${px}`
}

export function coverSizeFor(points: number): 80 | 400 | 800 {
  if (points <= 48) return 80
  if (points <= 160) return 400
  return 800
}
