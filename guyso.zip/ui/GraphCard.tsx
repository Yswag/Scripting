// graph 榜走勢卡：每首歌一條線（null 斷開），右側比例刻度，下方時間軸。

import {
  Chart,
  ChartOverlay,
  Device,
  Group,
  LineChart,
  Rectangle,
  Text,
  VStack,
  ZStack,
  type VirtualNode,
} from "scripting"
import type { Chart as ChartModel } from "../model/types"
import type { ShapeStyle } from "scripting"
import { axisLabels, axisStep, percentText, scaleMax, seriesRuns } from "../model/graph"
import { graphColor, space } from "../ui/theme"
import { AxisLabels } from "../ui/AxisLabels"

const CARD_HEIGHT = 300
const CARD_PADDING = 16
const AXIS_HEIGHT = 20
const Y_AXIS_WIDTH = 36

export function GraphCard({ chart }: { chart: ChartModel }) {
  const seriesList = chart.entries.map(entry => entry.series ?? [])
  const count = seriesList.reduce((longest, series) => Math.max(longest, series.length), 0)
  if (count < 2) return <VStack />

  const labels = axisLabels(chart.period, count)
  const step = axisStep(chart.period)
  const max = scaleMax(seriesList)
  const cardWidth = Device.screen.width - space.page * 2
  const plotWidth = cardWidth - CARD_PADDING * 2 - Y_AXIS_WIDTH
  const plotHeight = CARD_HEIGHT - CARD_PADDING * 2 - AXIS_HEIGHT

  const lines: VirtualNode[] = []
  const styleScale: Record<string, ShapeStyle> = {}
  chart.entries.forEach((entry, index) => {
    const color = graphColor[index % graphColor.length]
    seriesRuns(entry.series ?? []).forEach((run, runIndex) => {
      // 每一段各自一條線（風格名稱不同才不會被連起來），顏色還是同一首的顏色。
      const key = `s${index}-${runIndex}`
      styleScale[key] = color
      lines.push(
        <LineChart
          key={key}
          marks={run.map(point => ({
            label: labels[point.index],
            value: point.value,
            foregroundStyleBy: key,
            lineStyle: { lineWidth: 2.5 },
          }))}
        />
      )
    })
  })

  return (
    <VStack spacing={0} padding={{ horizontal: space.page }} frame={{ maxWidth: "infinity" }}>
      <VStack
        alignment="leading"
        spacing={0}
        padding={CARD_PADDING}
        frame={{ width: cardWidth, height: CARD_HEIGHT }}
        background="secondarySystemBackground"
        clipShape={{ type: "rect", cornerRadius: 24, style: "continuous" }}
      >
        <Chart
          frame={{ width: plotWidth, height: plotHeight }}
          chartLegend="hidden"
          chartXAxis="hidden"
          chartYAxis="hidden"
          chartXScale={labels}
          chartYScale={{ from: 0, to: max }}
          chartForegroundStyleScale={styleScale}
        >
          {lines}
          <ChartOverlay>
            {proxy => {
              const area = proxy.plotAreaFrame
              return (
                <ZStack frame={{ width: area.width, height: area.height }}>
                  {labels.map((label, index) => {
                    if ((((index - (labels.length - 1)) % step) + step) % step !== 0) return null
                    const position = proxy.position({ x: label })
                    if (!position) return null
                    return (
                      <Text
                        key={`x-${label}`}
                        font="caption2"
                        monospacedDigit
                        foregroundStyle="tertiaryLabel"
                        frame={{ width: 40, height: 14, alignment: "center" }}
                        offset={{
                          x: clampX(position.x, area.width, 40) - area.width / 2,
                          y: area.height / 2 + 10,
                        }}
                      >
                        {label}
                      </Text>
                    )
                  })}
                  {[max, max / 2, 0].map(value => {
                    const position = proxy.position({ y: value })
                    if (!position) return null
                    const y = position.y - area.height / 2
                    return (
                      <Group key={`tick-${value}`}>
                        <Rectangle
                          fill="separator"
                          opacity={0.5}
                          frame={{ width: area.width, height: 0.5 }}
                          offset={{ x: 0, y }}
                        />
                        <Text
                          font="caption2"
                          monospacedDigit
                          foregroundStyle="tertiaryLabel"
                          frame={{ width: Y_AXIS_WIDTH - 6, alignment: "leading" }}
                          offset={{ x: area.width / 2 + 2 + (Y_AXIS_WIDTH - 6) / 2, y }}
                        >
                          {percentText(value)}
                        </Text>
                      </Group>
                    )
                  })}
                </ZStack>
              )
            }}
          </ChartOverlay>
        </Chart>
      </VStack>
    </VStack>
  )
}

/** 邊緣的 X 標籤不超出畫布。 */
function clampX(center: number, width: number, labelWidth: number): number {
  const half = labelWidth / 2
  return Math.min(Math.max(center, half), width - half)
}
