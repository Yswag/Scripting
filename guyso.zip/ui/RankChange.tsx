// 名次變動（U1）：↑3 / ↓2 / NEW 膠囊 / 持平 -。

import { HStack, Text } from "scripting"
import type { RankChange } from "../model/types"
import { changeColor } from "./theme"

export function RankChangeView({
  change,
  minWidth = 44,
  align = "trailing",
}: {
  change: RankChange
  minWidth?: number
  align?: "leading" | "trailing"
}) {
  return (
    <HStack frame={{ minWidth, alignment: align }}>
      {content(change)}
    </HStack>
  )
}

function content(change: RankChange) {
  if (change.type === "new") {
    return (
      <Text
        font="caption2"
        fontWeight="heavy"
        foregroundStyle={changeColor.new}
        padding={{ horizontal: 6, vertical: 2 }}
        background={{ color: changeColor.new, opacity: 0.15 }}
        clipShape="capsule"
      >
        NEW
      </Text>
    )
  }

  if (change.type === "up") {
    return (
      <Text
        font="caption"
        fontWeight="bold"
        monospacedDigit
        foregroundStyle={changeColor.up}
        contentTransition="numericText"
      >
        {`↑${change.by}`}
      </Text>
    )
  }

  if (change.type === "down") {
    return (
      <Text
        font="caption"
        fontWeight="bold"
        monospacedDigit
        foregroundStyle={changeColor.down}
        contentTransition="numericText"
      >
        {`↓${change.by}`}
      </Text>
    )
  }

  return (
    <Text font="caption" fontWeight="bold" foregroundStyle={changeColor.same}>
      -
    </Text>
  )
}
