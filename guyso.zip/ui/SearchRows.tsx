// 搜尋結果的專輯列與歌手列。歌曲列直接用 CompactSongRow，不顯示名次。

import { HStack, Rectangle, Text, VStack } from "scripting"
import type { AlbumRef, Artist } from "../model/types"
import { albumSubtitle } from "../model/search"
import { space } from "../ui/theme"
import { Cover } from "../ui/Cover"
import { PushRow } from "../ui/router"
import { useZoomNamespace } from "../ui/zoom"
import { AlbumScreen } from "../screens/AlbumScreen"
import { ArtistScreen } from "../screens/ArtistScreen"

export function SearchAlbumRow({ album, showDivider }: { album: AlbumRef; showDivider: boolean }) {
  const namespace = useZoomNamespace()
  const zoomId = `search-album-${album.id}`
  const subtitle = albumSubtitle(album)

  const row = (
    <VStack spacing={0} frame={{ maxWidth: "infinity" }}>
      <HStack spacing={space.row} frame={{ maxWidth: "infinity", height: 64 }} padding={{ horizontal: space.page }}>
        <Cover
          image={album.image ?? ""}
          points={48}
          corner={8}
          zoom={namespace ? { id: zoomId, namespace } : undefined}
        />

        <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Text font="headline" lineLimit={1}>
            {album.name}
          </Text>
          {subtitle ? (
            <Text font="subheadline" foregroundStyle="secondaryLabel" lineLimit={1}>
              {subtitle}
            </Text>
          ) : null}
        </VStack>
      </HStack>

      {showDivider ? <Divider leading={space.page + 48 + space.row} /> : null}
    </VStack>
  )

  return <PushRow element={<AlbumScreen album={album} transitionId={zoomId} />}>{row}</PushRow>
}

export function SearchArtistRow({ artist, showDivider }: { artist: Artist; showDivider: boolean }) {
  const row = (
    <VStack spacing={0} frame={{ maxWidth: "infinity" }}>
      <HStack spacing={space.row} frame={{ maxWidth: "infinity", height: 60 }} padding={{ horizontal: space.page }}>
        <Cover image={artist.image ?? ""} points={44} circle emptyIcon="person.fill" />
        <Text font="headline" lineLimit={1} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          {artist.name}
        </Text>
      </HStack>

      {showDivider ? <Divider leading={space.page + 44 + space.row} /> : null}
    </VStack>
  )

  return <PushRow element={<ArtistScreen artist={artist} />}>{row}</PushRow>
}

/** 分隔線從文字區的左緣開始，不從螢幕邊緣開始。 */
function Divider({ leading }: { leading: number }) {
  return (
    <Rectangle fill="separator" frame={{ maxWidth: "infinity", height: 0.5 }} padding={{ leading }} />
  )
}
