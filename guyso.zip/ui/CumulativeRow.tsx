// 累計榜的列：數值當主角，名次退到左邊。

import {
  HStack,
  Rectangle,
  Spacer,
  Text,
  VStack,
} from "scripting"
import type { ChartEntry } from "../model/types"
import type { Color } from "scripting"
import { artistLine, formatCount, formatGrouped } from "../model/song"
import { changeColor, space } from "../ui/theme"
import { Cover } from "../ui/Cover"
import { useZoomNamespace } from "../ui/zoom"
import { SpotifyMenuItems } from "../ui/spotify"
import { PushRow } from "../ui/router"
import { SongScreen } from "../screens/SongScreen"

const RANK_WIDTH = 28

export function CumulativeRow({
  entry,
  zoomId,
  unit,
  showDivider = true,
}: {
  entry: ChartEntry
  zoomId: string
  /** 有單位時數字加千分位並在後面接單位，例如「2,873 天」。 */
  unit?: string
  showDivider?: boolean
}) {
  const namespace = useZoomNamespace()

  return (
    <PushRow element={<SongScreen song={entry.song} transitionId={zoomId} />}>
      <VStack
        spacing={0}
        frame={{ maxWidth: "infinity" }}
        contentShape="rect"
        contextMenu={{
          menuItems: <SpotifyMenuItems song={entry.song} />,
        }}
      >
        <HStack
          spacing={space.row}
          frame={{ maxWidth: "infinity", height: 64 }}
          padding={{ horizontal: space.page }}
        >
          <Text
            font={15}
            fontDesign="rounded"
            fontWeight="semibold"
            monospacedDigit
            foregroundStyle="secondaryLabel"
            frame={{ width: RANK_WIDTH, alignment: "center" }}
          >
            {`${entry.rank}`}
          </Text>

          <Cover
            image={entry.song.image}
            points={44}
            corner={8}
            zoom={namespace ? { id: zoomId, namespace } : undefined}
          />

          <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            <Text font="headline" lineLimit={1}>
              {entry.song.name}
            </Text>
            <Text font="subheadline" foregroundStyle="secondaryLabel" lineLimit={1}>
              {artistLine(entry.song)}
            </Text>
          </VStack>

          <Spacer />

          <VStack alignment="trailing" spacing={1}>
            {entry.value == null ? null : unit ? (
              <HStack spacing={2} alignment="firstTextBaseline">
                <Text font={17} fontDesign="rounded" fontWeight="bold" monospacedDigit>
                  {formatGrouped(entry.value)}
                </Text>
                <Text font={13}>{unit}</Text>
              </HStack>
            ) : (
              <Text font={17} fontDesign="rounded" fontWeight="bold" monospacedDigit>
                {formatCount(entry.value)}
              </Text>
            )}
            {entry.valueDiff == null ? null : <Diff value={entry.valueDiff} />}
          </VStack>
        </HStack>

        {showDivider ? (
          <Rectangle
            fill="separator"
            frame={{ maxWidth: "infinity", height: 0.5 }}
            padding={{ leading: space.page + RANK_WIDTH + space.row + 44 + space.row }}
          />
        ) : null}
      </VStack>
    </PushRow>
  )
}

function Diff({ value }: { value: number }) {
  if (value === 0) return <Text font="caption2" monospacedDigit foregroundStyle="secondaryLabel">-</Text>
  const color: Color = value > 0 ? changeColor.up : changeColor.down
  return (
    <Text font="caption2" monospacedDigit foregroundStyle={color} contentTransition="numericText">
      {`${value > 0 ? "+" : "−"}${formatCount(Math.abs(value))}`}
    </Text>
  )
}
