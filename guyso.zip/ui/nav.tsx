// 文字本身就是入口：一個人直接 push，多個人開選單選名字。

import { Button, Group, HStack, Menu } from "scripting"
import { PushRow, useRouter } from "./router"

export type NavTarget = { label: string; element: any }

export function NavLink({ targets, children }: { targets: NavTarget[]; children: any }) {
  const router = useRouter()
  const push = (target: NavTarget) => () => router.push(target.element)

  if (targets.length === 0) return <>{children}</>
  if (targets.length === 1) return <PushRow element={targets[0].element}>{children}</PushRow>

  return (
    <HStack frame={{ maxWidth: "infinity", alignment: "center" }}>
      <Menu label={<HStack spacing={0}>{children}</HStack>}>
        <Group>
          {targets.map((target, index) => (
            <Button key={`${index}-${target.label}`} title={target.label} action={push(target)} />
          ))}
        </Group>
      </Menu>
    </HStack>
  )
}
