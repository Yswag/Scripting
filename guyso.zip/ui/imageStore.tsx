// 圖片快取：記憶體 + App Group 檔案（guyso-cache/images），同一張圖只抓一次。

import { Image, Rectangle, useEffect, useState, type Shape } from "scripting"

const cacheFolder = `${FileManager.appGroupDocumentsDirectory}/guyso-cache/images`
const store = new Map<string, UIImage>()

function cachePath(url: string): string {
  let hash = 5381
  for (let i = 0; i < url.length; i++) {
    hash = (hash * 33 + url.charCodeAt(i)) % 2147483647
  }
  return `${cacheFolder}/${hash}.jpg`
}

export function localImage(url: string): UIImage | null {
  const hit = store.get(url)
  if (hit) return hit

  const path = cachePath(url)
  if (!FileManager.existsSync(path)) return null

  const image = UIImage.fromFile(path)
  if (image) store.set(url, image)
  return image
}

export function storedImage(url: string): UIImage | undefined {
  return localImage(url) ?? undefined
}

export async function loadImage(url: string): Promise<UIImage | null> {
  const hit = localImage(url)
  if (hit) return hit

  // CDN 沒有這張圖時 fromURL 會丟錯；當成沒有圖，讓呼叫端畫佔位。
  let image: UIImage | null = null
  try {
    image = await UIImage.fromURL(url)
  } catch {
    return null
  }
  if (!image) return null

  store.set(url, image)

  const data = image.toJPEGData(0.92)
  if (data) {
    void (async () => {
      try {
        if (!FileManager.existsSync(cacheFolder)) {
          await FileManager.createDirectory(cacheFolder, true)
        }
        await FileManager.writeAsData(cachePath(url), data)
      } catch (error) {
        console.log(`image cache write failed: ${String(error)}`)
      }
    })()
  }

  return image
}

export function ImageFill({ url, zoom }: { url: string; zoom?: { id: string; namespace: any } }) {
  const [image, setImage] = useState<UIImage | null>(() => localImage(url))

  useEffect(() => {
    let alive = true
    void loadImage(url).then(next => {
      if (alive && next) setImage(next)
    })
    return () => {
      alive = false
    }
  }, [url])

  if (!image) return <Rectangle fill="tertiarySystemFill" frame={{ maxWidth: "infinity", maxHeight: "infinity" }} />

  return (
    <Image
      image={image}
      resizable
      scaleToFill
      frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      {...(zoom ? { matchedTransitionSource: zoom } : {})}
    />
  )
}

export function CachedImage({
  url,
  width,
  height,
  shape,
  placeholder,
  zoom,
}: {
  url: string
  width: number
  height: number
  shape: Shape
  placeholder: any
  zoom?: { id: string; namespace: any }
}) {
  const [image, setImage] = useState<UIImage | null>(() => localImage(url))

  useEffect(() => {
    let alive = true
    const cached = localImage(url)
    if (cached) {
      setImage(cached)
      return
    }
    void loadImage(url).then(next => {
      if (alive && next) setImage(next)
    })
    return () => {
      alive = false
    }
  }, [url])

  if (!image) return placeholder

  return (
    <Image
      image={image}
      resizable
      scaleToFill
      frame={{ width, height }}
      clipShape={shape}
      {...(zoom ? { matchedTransitionSource: zoom } : {})}
    />
  )
}
