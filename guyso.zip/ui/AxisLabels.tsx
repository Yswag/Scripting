// 圖表 X 軸標籤：每 step 個點標一次，對齊分類軸的點位 (i + 0.5) / n。

import { Text, ZStack } from "scripting"

const labelWidth = 40

export function AxisLabels({ labels, step, width }: { labels: string[]; step: number; width: number }) {
  const band = width / labels.length

  return (
    <ZStack frame={{ width, height: 14, alignment: "topLeading" }} padding={{ top: 6 }}>
      {labels.map((label, index) => {
        if (index % step !== 0) return null
        const center = band * (index + 0.5)
        const left = center - labelWidth / 2
        const x = Math.min(Math.max(left, 0), width - labelWidth)
        const alignment = left < 0 ? "leading" : left > width - labelWidth ? "trailing" : "center"
        return (
          <Text
            key={`${label}-${index}`}
            font="caption2"
            monospacedDigit
            foregroundStyle="tertiaryLabel"
            frame={{ width: labelWidth, alignment }}
            offset={{ x, y: 0 }}
          >
            {label}
          </Text>
        )
      })}
    </ZStack>
  )
}
