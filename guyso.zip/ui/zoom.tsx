// zoom 轉場的 namespace：來源與目的頁共用同一個。

import { createContext, NamespaceReader, useContext } from "scripting"

export type ZoomNamespaceId = any

const ZoomContext = createContext<ZoomNamespaceId>()
let fallbackNamespace: ZoomNamespaceId | undefined

export function ZoomNamespace({ children }: { children: any }) {
  return (
    <NamespaceReader>
      {namespace => {
        fallbackNamespace = namespace
        return <ZoomContext.Provider value={namespace}>{children}</ZoomContext.Provider>
      }}
    </NamespaceReader>
  )
}

export function useZoomNamespace(): ZoomNamespaceId | undefined {
  try {
    return useContext(ZoomContext) ?? fallbackNamespace
  } catch {
    return fallbackNamespace
  }
}
