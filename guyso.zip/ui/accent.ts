// 歌曲 accent 取色（U7）：封面取色、對比保護、依封面 URL 快取。

import { coverAt } from "./theme"
import { loadImage, localImage } from "./imageStore"
import type { Hex } from "./theme"

export type Accent = {
  base: Hex
  light: Hex
  dark: Hex
}

const memory = new Map<string, Accent>()
export const neutralAccent: Accent = { base: "#8c8c8c", light: "#6b6b6b", dark: "#d0d0d0" }
const fallback = neutralAccent

type Hsb = { h: number; s: number; b: number }

function hexToRgb(hex: string): { r: number; g: number; b: number } {
  const clean = hex.replace("#", "").slice(0, 6)
  return {
    r: parseInt(clean.slice(0, 2), 16) / 255,
    g: parseInt(clean.slice(2, 4), 16) / 255,
    b: parseInt(clean.slice(4, 6), 16) / 255,
  }
}

function rgbToHsb({ r, g, b }: { r: number; g: number; b: number }): Hsb {
  const max = Math.max(r, g, b)
  const min = Math.min(r, g, b)
  const delta = max - min
  let h = 0
  if (delta > 0) {
    if (max === r) h = ((g - b) / delta) % 6
    else if (max === g) h = (b - r) / delta + 2
    else h = (r - g) / delta + 4
  }
  h = (h * 60 + 360) % 360
  return { h, s: max === 0 ? 0 : delta / max, b: max }
}

function hsbToHex({ h, s, b }: Hsb): Hex {
  const c = b * s
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1))
  const m = b - c
  let rgb: [number, number, number]
  if (h < 60) rgb = [c, x, 0]
  else if (h < 120) rgb = [x, c, 0]
  else if (h < 180) rgb = [0, c, x]
  else if (h < 240) rgb = [0, x, c]
  else if (h < 300) rgb = [x, 0, c]
  else rgb = [c, 0, x]
  const channel = (v: number) =>
    Math.round((v + m) * 255).toString(16).padStart(2, "0")
  return `#${channel(rgb[0])}${channel(rgb[1])}${channel(rgb[2])}` as Hex
}

function variant(hex: Hex, light: boolean): Hex {
  const hsb = rgbToHsb(hexToRgb(hex))
  const colored = hsb.s >= 0.08
  const s = colored ? Math.max(hsb.s, 0.45) : hsb.s

  if (light) {
    let b = Math.min(hsb.b, 0.55)
    let candidate = hsbToHex({ h: hsb.h, s, b })
    while (relativeLuminance(candidate) > 0.3 && b > 0.15) {
      b -= 0.05
      candidate = hsbToHex({ h: hsb.h, s, b })
    }
    return candidate
  }

  return hsbToHex({ h: hsb.h, s: Math.min(s, 0.85), b: Math.max(hsb.b, 0.75) })
}

/** Hero 漸層色：保留色相，亮度壓到 B ≤ 0.30、飽和度 ≥ 0.4。 */
export function deepAccent(hex: Hex): Hex {
  const hsb = rgbToHsb(hexToRgb(hex))
  return hsbToHex({ h: hsb.h, s: Math.max(hsb.s, 0.4), b: Math.min(hsb.b, 0.3) })
}

function relativeLuminance(hex: Hex): number {
  const { r, g, b } = hexToRgb(hex)
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}

function build(hex: Hex): Accent {
  return { base: hex, light: variant(hex, true), dark: variant(hex, false) }
}

export function textOnAccent(hex: Hex): "black" | "white" {
  const { r, g, b } = hexToRgb(hex)
  const luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b
  return luminance > 0.55 ? "black" : "white"
}

export function cachedAccent(image: string): Accent | undefined {
  if (memory.has(image)) return memory.get(image)
  const stored = Storage.get<Accent>(`accent:v4:${image}`)
  if (stored?.base) memory.set(image, stored)
  return stored ?? undefined
}

/** 同步版本：只用本地快取的 80px 封面算，沒快取就回 undefined。 */
export function accentFromCache(image: string): Accent | undefined {
  const cached = cachedAccent(image)
  if (cached) return cached

  const picture = localImage(coverAt(image, 80))
  if (!picture) return undefined

  const accent = pickAccent(picture)
  memory.set(image, accent)
  return accent
}

function pickAccent(picture: UIImage): Accent {
  const palette = picture.dominantColors(8) ?? []
  const scored = palette
    .filter(item => item.fraction >= 0.02)
    .map(item => {
      const hsb = rgbToHsb(hexToRgb(item.color.hex))
      return { hsb, score: hsb.s * Math.sqrt(item.fraction) }
    })
    .sort((a, b) => b.score - a.score)

  const pick = scored[0]
  if (pick && pick.hsb.s >= 0.08) return build(hsbToHex(pick.hsb))

  const average = picture.averageColor()
  return average ? build(average.hex.slice(0, 7) as Hex) : fallback
}

export async function accentOf(image: string): Promise<Accent> {
  const cached = cachedAccent(image)
  if (cached) return cached

  let accent = fallback
  const picture = (await loadImage(coverAt(image, 80))) ?? (await UIImage.fromURL(coverAt(image, 80)))
  if (picture) accent = pickAccent(picture)

  memory.set(image, accent)
  Storage.set(`accent:v4:${image}`, accent)
  return accent
}
