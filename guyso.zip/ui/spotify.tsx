// 長按選單的 Spotify 兩項。榜單 entry 沒有 group，所以點下去才去抓歌曲頁的真實 track id。

import { Button, Group } from "scripting"
import type { Song } from "../model/types"
import { artistLine, openInSpotify, searchInSpotify } from "../model/song"
import { guyso } from "../data/guyso"
import type { Guyso } from "../data/guyso"

export function SpotifyMenuItems({ song }: { song: Song }) {
  return (
    <Group>
      <Button
        title="在 Spotify 開啟"
        action={() => {
          void openSongInSpotify(song)
        }}
      />
      <Button
        title="在 Spotify 搜尋"
        action={() => {
          void searchInSpotify(song)
        }}
      />
    </Group>
  )
}

export async function openSongInSpotify(song: Song, source: Guyso = guyso): Promise<void> {
  if (song.spotifyTrackId) {
    await openInSpotify(song)
    return
  }
  const trackId = await trackIdOf(song, source)
  if (!trackId) {
    await Dialog.alert("這首歌沒有 Spotify 連結")
    return
  }
  await openInSpotify({ ...song, spotifyTrackId: trackId })
}

async function trackIdOf(song: Song, source: Guyso): Promise<string | undefined> {
  try {
    const { value } = await source.getSong(song.platform, song.id)
    return value.song.spotifyTrackId
  } catch {
    return undefined
  }
}
