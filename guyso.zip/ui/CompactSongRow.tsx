// 緊湊歌曲列（U3）：排行第 4 名以後、搜尋、新進榜、graph 圖例共用。

import {
  Circle,
  HStack,
  Rectangle,
  Spacer,
  Text,
  VStack,
  type VirtualNode,
} from "scripting"
import type { ChartEntry, PlatformId } from "../model/types"
import type { Color } from "scripting"
import { artistLine, formatCount } from "../model/song"
import { changeColor, space } from "../ui/theme"
import { Cover } from "../ui/Cover"
import { PlatformLogo } from "../ui/PlatformLogo"
import { RankChangeView } from "../ui/RankChange"
import { useZoomNamespace } from "../ui/zoom"
import { SpotifyMenuItems } from "../ui/spotify"
import { PushRow } from "../ui/router"
import { SongScreen } from "../screens/SongScreen"

export function CompactSongRow({
  entry,
  zoomId,
  rank,
  platform,
  dotColor,
  showRank = true,
  showValue = false,
  showChange = true,
  showDivider = true,
  valueText,
}: {
  entry: ChartEntry
  zoomId: string
  rank?: number
  /** 不需要名次時整欄省略，文字區往左補滿。 */
  showRank?: boolean
  platform?: PlatformId
  dotColor?: Color
  showValue?: boolean
  showChange?: boolean
  showDivider?: boolean
  /** 直接指定的數值文字（graph 榜的目前值），不顯示差值。 */
  valueText?: string
}) {
  const namespace = useZoomNamespace()
  const rankValue = showRank ? rank ?? entry.rank : null
  const leadingWidth = rankValue == null ? 0 : platform ? 56 : dotColor ? 52 : 36
  const dividerInset = space.page + leadingWidth + (leadingWidth > 0 ? space.row : 0) + 44 + space.row

  const row = (
    <VStack
      spacing={0}
      frame={{ maxWidth: "infinity" }}
      contentShape="rect"
      contextMenu={{
        menuItems: <SpotifyMenuItems song={entry.song} />,
      }}
    >
      <HStack
        spacing={space.row}
        frame={{ maxWidth: "infinity", height: 64 }}
        padding={{ horizontal: space.page }}
      >
        {rankValue == null ? null : leading(rankValue, platform, dotColor)}
        <Cover
          image={entry.song.image}
          points={44}
          corner={8}
          zoom={namespace ? { id: zoomId, namespace } : undefined}
        />

        <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Text font="headline" lineLimit={1}>
            {entry.song.name}
          </Text>
          <Text font="subheadline" foregroundStyle="secondaryLabel" lineLimit={1}>
            {artistLine(entry.song)}
          </Text>
        </VStack>

        {valueText != null ? (
          <Text
            font="footnote"
            monospacedDigit
            foregroundStyle="secondaryLabel"
            frame={{ width: 72, alignment: "trailing" }}
          >
            {valueText}
          </Text>
        ) : showValue ? (
          <ValueColumn entry={entry} />
        ) : null}

        {showChange ? <RankChangeView change={entry.change} /> : null}
      </HStack>

      {showDivider ? (
        <Rectangle
          fill="separator"
          frame={{ maxWidth: "infinity", height: 0.5 }}
          padding={{ leading: dividerInset }}
        />
      ) : null}
    </VStack>
  )

  return (
    <PushRow element={<SongScreen song={entry.song} transitionId={zoomId} />}>
      {row}
    </PushRow>
  )
}

function leading(rank: number, platform?: PlatformId, dotColor?: Color): VirtualNode {
  if (platform) {
    return (
      <HStack spacing={4} frame={{ width: 56, alignment: "leading" }}>
        <PlatformLogo id={platform} size={16} />
        <Text
          font={17}
          fontDesign="rounded"
          fontWeight="bold"
          monospacedDigit
          contentTransition="numericText"
        >
          {`${rank}`}
        </Text>
      </HStack>
    )
  }

  const rankText = (
    <Text
      font={20}
      fontDesign="rounded"
      fontWeight="bold"
      monospacedDigit
      frame={{ width: 36, alignment: "center" }}
      contentTransition="numericText"
    >
      {`${rank}`}
    </Text>
  )

  if (dotColor) {
    return (
      <HStack spacing={6}>
        <Circle fill={dotColor} frame={{ width: 8, height: 8 }} />
        {rankText}
      </HStack>
    )
  }

  return rankText
}

function ValueColumn({ entry }: { entry: ChartEntry }) {
  // 數值為 null 也保留欄位寬，列的版面不隨資料跳動。
  if (entry.value == null) return <VStack spacing={1} frame={{ width: 72, alignment: "trailing" }} />

  const diff = entry.valueDiff
  const color: Color =
    diff == null || diff === 0 ? "secondaryLabel" : diff > 0 ? changeColor.up : changeColor.down
  const sign = diff == null || diff === 0 ? "" : diff > 0 ? "+" : "−"

  return (
    <VStack alignment="trailing" spacing={1} frame={{ width: 72, alignment: "trailing" }}>
      <Text font="footnote" monospacedDigit foregroundStyle="secondaryLabel">
        {formatCount(entry.value ?? 0)}
      </Text>
      {diff == null || entry.change.type === "new" ? null : (
        <Text
          font="caption2"
          monospacedDigit
          foregroundStyle={color}
          contentTransition="numericText"
        >
          {`${sign}${formatCount(Math.abs(diff))}`}
        </Text>
      )}
    </VStack>
  )
}
