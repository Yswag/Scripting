// 以 path 綁定做程式化導覽：List 內的列改用 Button，避免 List 自動加箭頭。
// navigationDestination 必須掛在 stack 內的 view 上，掛在 NavigationStack 本身會找不到目的地。

import {
  Button,
  Group,
  NavigationDestination,
  NavigationStack,
  VStack,
  createContext,
  useContext,
  useObservable,
} from "scripting"

const routes = new Map<string, any>()
let counter = 0

type Router = {
  push: (element: any) => void
  /** 一次推入多層，路徑只更新一次（預覽示範整條導覽鏈用）。 */
  pushAll: (elements: any[]) => void
  pop: () => void
}

const RouterContext = createContext<Router>()

export function RouterStack({ children }: { children: any }) {
  const path = useObservable<string[]>([])

  const router: Router = {
    push: element => {
      const key = `route-${++counter}`
      routes.set(key, element)
      path.setValue([...path.value, key])
    },
    pushAll: elements => {
      if (elements.length === 0) return
      const keys = elements.map(element => {
        const key = `route-${++counter}`
        routes.set(key, element)
        return key
      })
      path.setValue([...path.value, ...keys])
    },
    pop: () => {
      path.setValue(path.value.slice(0, -1))
    },
  }

  return (
    <RouterContext.Provider value={router}>
      <NavigationStack path={path}>
        <Group
          navigationDestination={
            <NavigationDestination>
              {page => routes.get(page) ?? <VStack />}
            </NavigationDestination>
          }
        >
          {children}
        </Group>
      </NavigationStack>
    </RouterContext.Provider>
  )
}

export function useRouter(): Router {
  return useContext(RouterContext)
}

export function PushRow({ element, children }: { element: any; children: any }) {
  const router = useRouter()
  return (
    <Button buttonStyle="plain" action={() => router.push(element)}>
      {children}
    </Button>
  )
}
