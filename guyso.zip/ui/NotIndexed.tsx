// 가이섬 沒有收錄這筆資料：一行說明加一顆去 Melon 的按鈕，取代「重試」。

import { Button, Text, VStack } from "scripting"
import type { SearchKind } from "../model/types"
import { melonUrl } from "../model/platforms"

export function NotIndexed({ kind, id, width }: { kind: SearchKind; id: string; width: number }) {
  return (
    <VStack spacing={16} frame={{ width, alignment: "center" }}>
      <Text font="body" foregroundStyle="secondaryLabel" multilineTextAlignment="center">
        가이섬 沒有收錄
      </Text>
      <Button
        title="在 Melon 開啟"
        buttonStyle="bordered"
        buttonBorderShape="capsule"
        action={() => {
          void Safari.openURL(melonUrl(kind, id))
        }}
      />
    </VStack>
  )
}
