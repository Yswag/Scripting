// 出處列（U5）：全 App 唯一的說明性文字。搜尋結果來自 Melon 時標 Melon。

import { Text, VStack } from "scripting"
import { space } from "./theme"

const SOURCES = {
  guyso: { label: "資料來源 가이섬", url: "https://guyso.me" },
  melon: { label: "資料來源 Melon", url: "https://www.melon.com" },
}

export function Attribution({ source = "guyso" }: { source?: keyof typeof SOURCES }) {
  const { label, url } = SOURCES[source]
  return (
    <VStack
      padding={{ top: space.section, bottom: 24, horizontal: space.page }}
      frame={{ maxWidth: "infinity", alignment: "leading" }}
    >
      <Text
        font="footnote"
        foregroundStyle="tertiaryLabel"
        onTapGesture={() => {
          void Safari.openURL(url)
        }}
      >
        {label}
      </Text>
    </VStack>
  )
}
