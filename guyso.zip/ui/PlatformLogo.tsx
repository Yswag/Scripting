// 平台 logo（U2）：圓形，載入前用 tertiarySystemFill 佔位。

import { Circle, ZStack } from "scripting"
import type { PlatformId } from "../model/types"
import { logoUrl } from "./theme"
import { CachedImage } from "./imageStore"

export function PlatformLogo({
  id,
  size,
  ringed = false,
}: {
  id: PlatformId
  size: number
  ringed?: boolean
}) {
  const logo = (
    <CachedImage
      url={logoUrl(id, size)}
      width={size}
      height={size}
      shape="circle"
      placeholder={<Circle fill="tertiarySystemFill" frame={{ width: size, height: size }} />}
    />
  )

  if (!ringed) return logo

  return (
    <ZStack frame={{ width: size, height: size }}>
      {logo}
      <Circle
        frame={{ width: size, height: size }}
        stroke={{
          shapeStyle: "rgba(255,255,255,0.6)",
          strokeStyle: { lineWidth: 1.5 },
        }}
      />
    </ZStack>
  )
}
