// 專輯卡：今日的「最新專輯」與歌手頁共用，點擊用封面做 zoom 進專輯頁。

import { Text, VStack } from "scripting"
import type { AlbumRef } from "../model/types"
import { Cover } from "./Cover"
import { PushRow } from "./router"
import { useZoomNamespace } from "./zoom"
import { AlbumScreen } from "../screens/AlbumScreen"

export function AlbumCard({ album, subtitle = true }: { album: AlbumRef; subtitle?: boolean }) {
  const namespace = useZoomNamespace()
  const zoomId = `album-${album.platform}-${album.id}`

  return (
    <PushRow element={<AlbumScreen album={album} transitionId={zoomId} />}>
      <VStack alignment="leading" spacing={4} frame={{ width: 120 }}>
        <Cover
          image={album.image ?? ""}
          points={120}
          corner={12}
          zoom={namespace ? { id: zoomId, namespace } : undefined}
        />
        <Text font="subheadline" fontWeight="semibold" lineLimit={1}>
          {album.name}
        </Text>
        {subtitle ? (
          <Text font="footnote" foregroundStyle="secondaryLabel" lineLimit={1}>
            {album.artist ?? ""}
          </Text>
        ) : null}
      </VStack>
    </PushRow>
  )
}
