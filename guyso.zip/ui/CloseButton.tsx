// 關閉按鈕：全螢幕頁面左上角，推入的子頁面不放。

import { Button, Image, Script } from "scripting"

export function CloseButton() {
  return (
    <Button accessibilityLabel="關閉" action={() => Script.exit()}>
      <Image systemName="xmark" />
    </Button>
  )
}
