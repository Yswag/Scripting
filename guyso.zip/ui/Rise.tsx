// 骨架換成真內容時的區塊進場：淡入＋上移，依 order 錯開。
// List 的插入轉場只吃 opacity，位移要靠 state 驅動 offset＋animation 修飾器。

import { VStack, useEffect, useRef, useState } from "scripting"

const RISE = 12
const STAGGER = 0.05
const MAX_ORDER = 2
// 掛上後超過這段時間才出現（捲進畫面），直接放在終點不播。
const WINDOW_MS = 600

/** 這一輪是不是「骨架換成內容」：placeholder 傳畫面目前是否顯示骨架。 */
export function useEntering(placeholder: boolean): boolean {
  const entering = useRef(false)
  if (placeholder) entering.current = true
  useEffect(() => {
    if (!placeholder) entering.current = false
  }, [placeholder])
  return entering.current
}

export function Rise({ order, active, children }: { order: number; active: boolean; children: any }) {
  const [risen, setRisen] = useState<boolean>(() => !active)
  const [animated, setAnimated] = useState<boolean>(true)
  const mountedAt = useRef<number>(Date.now())

  function appear(): void {
    if (risen) return
    if (Date.now() - mountedAt.current > WINDOW_MS) setAnimated(false)
    setRisen(true)
  }

  const step = Math.min(Math.max(order, 0), MAX_ORDER)

  return (
    <VStack
      spacing={0}
      frame={{ maxWidth: "infinity" }}
      opacity={risen ? 1 : 0}
      offset={{ x: 0, y: risen ? 0 : RISE }}
      animation={animated ? { animation: Animation.spring().delay(step * STAGGER), value: risen } : undefined}
      onAppear={appear}
    >
      {children}
    </VStack>
  )
}
