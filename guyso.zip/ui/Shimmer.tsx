// 骨架的掃光：每個灰塊各自畫自己那一段，位置依螢幕座標算，整頁看起來是同一道光掃過。

import {
  GeometryReader,
  Rectangle,
  Text,
  VStack,
  ZStack,
  useColorScheme,
  useEffect,
  useState,
  type Color,
  type Font,
  type FontWeight,
  type Shape,
} from "scripting"

/** 亮帶寬（pt）、傾斜角、速度（pt/秒）、掃完後多走的距離（＝停頓）、掛上後多久開始動。 */
const BAND = 140
const ANGLE = 20
const SPEED = 420
const REST = 320
const DELAY_MS = 100

/** 中間最亮、兩側淡出；深色用白光，淺色用灰光（白光在淺灰底上看不到）。 */
const GLOW: Record<"light" | "dark", { peak: Color; soft: Color; clear: Color }> = {
  light: { peak: "rgba(150,158,168,0.16)", soft: "rgba(150,158,168,0.06)", clear: "rgba(150,158,168,0)" },
  dark: { peak: "rgba(255,255,255,0.14)", soft: "rgba(255,255,255,0.05)", clear: "rgba(255,255,255,0)" },
}

/** 這塊的螢幕中心：掛上那一刻量到，之後不跟著變（中途改起訖點會打亂重播）。 */
type Anchor = { x: number; y: number }

function Light({ width, height, anchor }: { width: number; height: number; anchor: Anchor }) {
  const scheme = useColorScheme()
  const [origin] = useState(anchor)
  const [moving, setMoving] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setMoving(true), DELAY_MS)
    return () => clearTimeout(timer)
  }, [])

  // 光的中線在螢幕上是 x = X − y·tanθ，X 從整條光都在左邊外走到右邊外再多走一段停頓。
  const radians = (ANGLE * Math.PI) / 180
  const tan = Math.tan(radians)
  const halfBand = BAND / 2 / Math.cos(radians)
  const start = -halfBand
  const end = Device.screen.width + Device.screen.height * tan + halfBand + REST
  const shift = origin.x + origin.y * tan
  const glow = GLOW[scheme === "dark" ? "dark" : "light"]

  return (
    <ZStack frame={{ width, height }}>
      <Rectangle
        fill={{
          stops: [
            { color: glow.clear, location: 0 },
            { color: glow.soft, location: 0.3 },
            { color: glow.peak, location: 0.5 },
            { color: glow.soft, location: 0.7 },
            { color: glow.clear, location: 1 },
          ],
          startPoint: "leading",
          endPoint: "trailing",
        }}
        frame={{ width: BAND, height: (height + BAND) / Math.cos(radians) }}
        rotationEffect={ANGLE}
        offset={{ x: (moving ? end : start) - shift, y: 0 }}
        animation={{ animation: Animation.linear((end - start) / SPEED).repeatForever(false), value: moving }}
      />
    </ZStack>
  )
}

/** 疊在灰塊上的掃光，用同一個形狀裁切。尺寸變了就重建。 */
function Overlay({ shape }: { shape: Shape }) {
  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }} clipShape={shape} clipped={true}>
      <GeometryReader coordinateSpaces={["global"]}>
        {geometry => {
          const frame = geometry.frame("global")
          return (
            <Light
              key={`${geometry.size.width}x${geometry.size.height}`}
              width={geometry.size.width}
              height={geometry.size.height}
              anchor={{ x: frame.x + frame.width / 2, y: frame.y + frame.height / 2 }}
            />
          )
        }}
      </GeometryReader>
    </ZStack>
  )
}

/** 一塊灰底：封面、卡片、條狀字都用它，尺寸給多少就畫多少。 */
export function ShimmerBox({
  width,
  height,
  corner = 8,
  capsule = false,
  fill = "tertiarySystemFill",
}: {
  width?: number
  height: number
  corner?: number
  capsule?: boolean
  fill?: Color
}) {
  const shape: Shape = capsule ? "capsule" : { type: "rect", cornerRadius: corner, style: "continuous" }
  return (
    <VStack
      spacing={0}
      frame={width == null ? { maxWidth: "infinity", height } : { width, height }}
      background={fill}
      clipShape={shape}
      overlay={<Overlay shape={shape} />}
    />
  )
}

/** 一行字的位置放灰條：字本身透明但撐住寬高，灰條依量到的寬高畫。 */
export function ShimmerText({
  children,
  font,
  fontWeight,
  fontDesign,
  lineLimit = 1,
  ratio = 1,
  width,
  alignment = "leading",
}: {
  children: string
  font: Font
  fontWeight?: FontWeight
  fontDesign?: "default" | "rounded" | "monospaced" | "serif"
  lineLimit?: number
  /** 灰條佔這行字寬的比例。 */
  ratio?: number
  width?: number
  alignment?: "leading" | "center" | "trailing"
}) {
  return (
    <Text
      font={font}
      fontWeight={fontWeight}
      fontDesign={fontDesign}
      lineLimit={lineLimit}
      foregroundStyle="clear"
      frame={width == null ? undefined : { width, alignment }}
      overlay={
        <GeometryReader>
          {geometry => (
            <ZStack
              alignment={alignment}
              frame={{ width: geometry.size.width, height: geometry.size.height, alignment }}
            >
              <ShimmerBox
                width={Math.round(geometry.size.width * ratio)}
                height={Math.round(geometry.size.height * 0.62)}
                corner={3}
              />
            </ZStack>
          )}
        </GeometryReader>
      }
    >
      {children}
    </Text>
  )
}
