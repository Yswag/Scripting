// 封面圖：依顯示尺寸補 size 參數，圓角一律連續曲率。

import { Image, Rectangle, ZStack, type Shape } from "scripting"
import { coverAt, coverSizeFor } from "./theme"
import { CachedImage } from "./imageStore"
import type { ZoomNamespaceId } from "./zoom"

export function Cover({
  image,
  points,
  corner,
  circle = false,
  emptyIcon,
  zoom,
}: {
  image: string
  points: number
  corner?: number
  circle?: boolean
  /** 沒有圖時用什麼圖示佔位（歌手用 person.fill）。 */
  emptyIcon?: string
  zoom?: { id: string; namespace: ZoomNamespaceId }
}) {
  const shape: Shape = circle
    ? "circle"
    : { type: "rect", cornerRadius: corner ?? 12, style: "continuous" }

  const placeholder = emptyIcon ? (
    <ZStack frame={{ width: points, height: points }} background="tertiarySystemFill" clipShape={shape}>
      <Image systemName={emptyIcon} font={points * 0.36} foregroundStyle="tertiaryLabel" />
    </ZStack>
  ) : (
    <Rectangle fill="tertiarySystemFill" frame={{ width: points, height: points }} clipShape={shape} />
  )

  if (!image) return placeholder

  return (
    <CachedImage
      url={coverAt(image, coverSizeFor(points))}
      width={points}
      height={points}
      shape={shape}
      zoom={zoom}
      placeholder={placeholder}
    />
  )
}
