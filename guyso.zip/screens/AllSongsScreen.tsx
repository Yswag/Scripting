// 歌手的全部歌曲：List 當根，列不顯示名次；資料由歌手頁整份傳進來。

import { List, Rectangle, VStack } from "scripting"
import type { Artist, Song } from "../model/types"
import { entryOf } from "../model/song"
import { Attribution } from "../ui/Attribution"
import { CompactSongRow } from "../ui/CompactSongRow"

export function AllSongsScreen({ artist, songs }: { artist: Artist; songs: Song[] }) {
  return (
    <List
      listStyle="plain"
      listRowSpacing={0}
      listSectionSpacing={0}
      scrollContentBackground="hidden"
      scrollEdgeEffectStyle="soft"
      navigationTitle={artist.name}
      navigationBarTitleDisplayMode="inline"
    >
      {songs.map((song, index) => (
        <Row key={song.fullId}>
          <CompactSongRow
            entry={entryOf(song)}
            zoomId={`all-${artist.id}-${song.fullId}`}
            showRank={false}
            showChange={false}
            showDivider={index < songs.length - 1}
          />
        </Row>
      ))}

      <Row>
        <Attribution />
      </Row>
    </List>
  )
}

function Row({ children }: { children: any }) {
  return (
    <VStack
      spacing={0}
      listRowInsets={0}
      listRowSeparator="hidden"
      listRowBackground={<Rectangle fill="clear" />}
      frame={{ maxWidth: "infinity" }}
    >
      {children}
    </VStack>
  )
}
