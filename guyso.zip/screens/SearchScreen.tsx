// 搜尋：沒輸入時是熱門搜尋榜；有輸入時先問 Melon 搜尋建議，該分段 0 筆才退回 가이섬 搜尋。

import {
  Button,
  Device,
  HStack,
  Image,
  List,
  Picker,
  ProgressView,
  Rectangle,
  ScrollViewReader,
  ScrollViewProxy,
  Spacer,
  Text,
  Toolbar,
  ToolbarItem,
  VStack,
  useEffect,
  useRef,
  useState,
  type VirtualNode,
} from "scripting"
import type {
  AlbumRef,
  Artist,
  Home,
  Loaded,
  SearchKind,
  SearchSuggestions,
  Song,
} from "../model/types"
import { entryOf } from "../model/song"
import { acceptsResult, hotSearchLabel, nextTicket, searchKinds } from "../model/search"
import type { SearchTicket } from "../model/search"
import { guyso } from "../data/guyso"
import type { Guyso } from "../data/guyso"
import { space } from "../ui/theme"
import { CompactSongRow } from "../ui/CompactSongRow"
import { SearchAlbumRow, SearchArtistRow } from "../ui/SearchRows"
import { Attribution } from "../ui/Attribution"
import { CloseButton } from "../ui/CloseButton"
import { RowsSkeleton } from "../ui/Skeleton"
import { Rise, useEntering } from "../ui/Rise"

const TOP_HOT_ID = "hot-title"
const TOP_RESULT_ID = "segments"
const DEBOUNCE_MS = 350
/** 가이섬 搜尋一頁 20 筆，回傳比這少就是最後一頁。 */
const PAGE_SIZE = 20
const SKELETON_ROWS = 8
/** 熱門的進場動畫只播前幾列（第一屏）。 */
const ENTER_ROWS = 8

type Status = "loading" | "ready" | "error"

/** 畫面上的結果屬於哪一次搜尋；關鍵字一換，舊的就整組作廢。 */
type View = { query: string; status: Status }

type Fallback = {
  query: string
  kind: SearchKind
  items: Song[] | AlbumRef[] | Artist[]
  page: number
  hasMore: boolean
  loading: boolean
  failed: boolean
}

export function SearchScreen({
  source = guyso,
  initial,
}: {
  source?: Guyso
  /** 預覽用：直接給關鍵字與結果，不發請求。 */
  initial?: {
    query: string
    suggestions: SearchSuggestions
    segment?: SearchKind
    /** 該分段 Melon 0 筆時要顯示的後備結果；空陣列就是無結果。 */
    fallback?: Song[] | AlbumRef[] | Artist[]
  }
}) {
  const [input, setInput] = useState(initial?.query ?? "")
  const [segment, setSegment] = useState<SearchKind>(initial?.segment ?? "song")
  const [view, setView] = useState<View>(() =>
    initial ? { query: initial.query, status: "ready" } : { query: "", status: "loading" }
  )
  const [suggestions, setSuggestions] = useState<SearchSuggestions | null>(initial?.suggestions ?? null)
  const [fallback, setFallback] = useState<Fallback | null>(() =>
    initial?.fallback
      ? {
          query: initial.query,
          kind: initial.segment ?? "song",
          items: initial.fallback,
          page: 1,
          hasMore: false,
          loading: false,
          failed: false,
        }
      : null
  )
  const [home, setHome] = useState<Loaded<Home> | null>(() => (initial ? null : source.peekHome()))
  const [homeFailed, setHomeFailed] = useState(false)
  const enteringHot = useEntering(home == null)

  const ticketRef = useRef<SearchTicket>({ seq: 0, query: "" })
  const segmentRef = useRef<SearchKind>(segment)
  segmentRef.current = segment
  const loadingFallbackRef = useRef<string | null>(null)
  /** 同一個關鍵字、同一個分段只有一份後備結果；切回去不重打網路。 */
  const fallbackCacheRef = useRef<
    Map<string, { items: Song[] | AlbumRef[] | Artist[]; page: number; hasMore: boolean }>
  >(new Map())
  const proxyRef = useRef<ScrollViewProxy>()

  const query = input.trim()
  const current = view.query === query ? view : null
  const status: Status | "idle" = query.length === 0 ? "idle" : current?.status ?? "loading"

  // 首頁的熱門搜尋：快取一小時，進畫面就抓。
  useEffect(() => {
    if (initial) return
    let alive = true
    source.getHome().then(
      next => {
        if (alive) {
          withAnimation(() => setHome(next))
          setHomeFailed(false)
        }
      },
      () => {
        if (alive && !source.peekHome()) setHomeFailed(true)
      }
    )
    return () => {
      alive = false
    }
  }, [source])

  // 停頓 350ms 才送；關鍵字一變就先回到骨架，不讓舊結果留在新關鍵字底下。
  useEffect(() => {
    if (query.length === 0) {
      ticketRef.current = nextTicket(ticketRef.current, "")
      setFallback(null)
      return
    }
    if (initial && query === initial.query) return

    const timer = setTimeout(() => {
      void submit(query)
    }, DEBOUNCE_MS)
    return () => clearTimeout(timer)
  }, [query])

  async function submit(next: string): Promise<void> {
    const ticket = nextTicket(ticketRef.current, next)
    ticketRef.current = ticket
    loadingFallbackRef.current = null
    fallbackCacheRef.current.clear()
    withAnimation(() => {
      setView({ query: next, status: "loading" })
      setFallback(null)
    })

    try {
      const result = await source.searchSuggestions(next)
      if (!acceptsResult(ticketRef.current, ticket)) return
      withAnimation(() => {
        setSuggestions(result)
        setView({ query: next, status: "ready" })
      })
    } catch {
      if (!acceptsResult(ticketRef.current, ticket)) return
      setView({ query: next, status: "error" })
    }
  }

  const melonItems = suggestions && status === "ready" ? itemsOf(suggestions, segment) : []
  const needsFallback = status === "ready" && suggestions != null && melonItems.length === 0

  // Melon 在這個分段 0 筆才用 가이섬 搜尋；換分段時對新分段重新判斷。
  useEffect(() => {
    if (!needsFallback) return
    if (initial && query === initial.query) return
    if (fallbackCacheRef.current.has(`${query}|${segment}`)) return
    void loadFallback(query, segment, 1)
  }, [needsFallback, query, segment])

  async function loadFallback(forQuery: string, kind: SearchKind, page: number): Promise<void> {
    const key = `${forQuery}|${kind}|${page}`
    if (loadingFallbackRef.current === key) return
    loadingFallbackRef.current = key
    if (page === 1) fallbackCacheRef.current.delete(`${forQuery}|${kind}`)

    setFallback(previous =>
      page === 1
        ? { query: forQuery, kind, items: [], page: 0, hasMore: true, loading: true, failed: false }
        : previous
          ? { ...previous, loading: true, failed: false }
          : previous
    )

    try {
      const items = await fetchPage(source, kind, forQuery, page)
      // 換了關鍵字或分段，這一批就不要了。
      if (ticketRef.current.query !== forQuery || segmentRef.current !== kind) return
      withAnimation(() => {
        setFallback(previous => {
          const next =
            page === 1 || !previous
              ? {
                  query: forQuery,
                  kind,
                  items,
                  page,
                  hasMore: items.length >= PAGE_SIZE,
                  loading: false,
                  failed: false,
                }
              : {
                  ...previous,
                  items: [...previous.items, ...items],
                  page,
                  hasMore: items.length >= PAGE_SIZE,
                  loading: false,
                  failed: false,
                }
          fallbackCacheRef.current.set(`${forQuery}|${kind}`, {
            items: next.items,
            page: next.page,
            hasMore: next.hasMore,
          })
          return next
        })
      })
    } catch {
      setFallback(previous => (previous ? { ...previous, loading: false, failed: true } : previous))
    } finally {
      if (loadingFallbackRef.current === key) loadingFallbackRef.current = null
    }
  }

  function loadMore(): void {
    if (!fallback || fallback.loading || fallback.failed || !fallback.hasMore) return
    void loadFallback(fallback.query, fallback.kind, fallback.page + 1)
  }

  function loadHome(): void {
    setHomeFailed(false)
    source.getHome({ force: true }).then(
      next => withAnimation(() => setHome(next)),
      () => setHomeFailed(true)
    )
  }

  function retry(): void {
    if (query.length === 0) {
      loadHome()
      return
    }
    void submit(query)
  }

  function scrollToTop(): void {
    const id = query.length === 0 ? TOP_HOT_ID : TOP_RESULT_ID
    proxyRef.current?.scrollTo(id, "top")
    setTimeout(() => proxyRef.current?.scrollTo(id, "top"), 0)
  }

  function selectSegment(next: SearchKind): void {
    if (next === segment) return
    const cached = fallbackCacheRef.current.get(`${query}|${next}`)
    withAnimation(() => {
      setSegment(next)
      setFallback(
        cached
          ? {
              query,
              kind: next,
              items: cached.items,
              page: cached.page,
              hasMore: cached.hasMore,
              loading: false,
              failed: false,
            }
          : null
      )
    })
    scrollToTop()
  }

  const rows: VirtualNode[] = []

  if (query.length > 0) {
    rows.push(
      <Row key={TOP_RESULT_ID}>
        <VStack frame={{ maxWidth: "infinity" }} padding={{ horizontal: space.page, vertical: 8 }}>
          <Picker
            title="結果種類"
            value={segment}
            onChanged={(value: string | number) => selectSegment(value as SearchKind)}
            pickerStyle="segmented"
            labelsHidden
          >
            {searchKinds.map(kind => (
              <Text key={kind.id} tag={kind.id}>
                {kind.name}
              </Text>
            ))}
          </Picker>
        </VStack>
      </Row>
    )
  }

  if (query.length === 0) {
    rows.push(...hotRows())
  } else if (status === "error") {
    rows.push(
      <Row key="retry">
        <Center>
          <Button title="重試" buttonStyle="bordered" action={retry} />
        </Center>
      </Row>
    )
  } else if (status === "loading" || suggestions == null) {
    rows.push(
      <Row key="skeleton">
        <RowsSkeleton count={SKELETON_ROWS} />
      </Row>
    )
  } else {
    rows.push(...resultRows())
  }

  rows.push(
    <Row key="attribution">
      <Attribution source={status === "ready" && !needsFallback ? "melon" : "guyso"} />
    </Row>
  )

  function resultRows(): VirtualNode[] {
    if (needsFallback) return fallbackRows()

    if (segment === "song") {
      const songs = suggestions?.songs ?? []
      return songs.map((song, index) => (
        <Row key={`song-${song.id}`}>
          <CompactSongRow
            entry={entryOf(song)}
            zoomId={`search-song-${song.id}`}
            showRank={false}
            showChange={false}
            showDivider={index < songs.length - 1}
          />
        </Row>
      ))
    }

    if (segment === "album") {
      const albums = suggestions?.albums ?? []
      return albums.map((album, index) => (
        <Row key={`album-${album.id}`}>
          <SearchAlbumRow album={album} showDivider={index < albums.length - 1} />
        </Row>
      ))
    }

    const artists = suggestions?.artists ?? []
    return artists.map((artist, index) => (
      <Row key={`artist-${artist.id}`}>
        <SearchArtistRow artist={artist} showDivider={index < artists.length - 1} />
      </Row>
    ))
  }

  function fallbackRows(): VirtualNode[] {
    const items = fallback?.items ?? []

    if (fallback == null || (fallback.page === 0 && fallback.loading)) {
      return [
        <Row key="fallback-loading">
          <RowsSkeleton count={SKELETON_ROWS} />
        </Row>,
      ]
    }

    if (items.length === 0) {
      if (fallback.failed) {
        return [
          <Row key="fallback-retry">
            <Center>
              <Button title="重試" buttonStyle="bordered" action={() => void loadFallback(query, segment, 1)} />
            </Center>
          </Row>,
        ]
      }
      return [<Row key="empty">{emptyState()}</Row>]
    }

    const list: VirtualNode[] = []
    if (segment === "song") {
      (items as Song[]).forEach(song => {
        list.push(
          <Row key={`f-song-${song.id}`}>
            <CompactSongRow
              entry={entryOf(song)}
              zoomId={`search-song-${song.id}`}
              showRank={false}
              showChange={false}
              showDivider
            />
          </Row>
        )
      })
    } else if (segment === "album") {
      (items as AlbumRef[]).forEach(album => {
        list.push(
          <Row key={`f-album-${album.id}`}>
            <SearchAlbumRow album={album} showDivider />
          </Row>
        )
      })
    } else {
      (items as Artist[]).forEach(artist => {
        list.push(
          <Row key={`f-artist-${artist.id}`}>
            <SearchArtistRow artist={artist} showDivider />
          </Row>
        )
      })
    }

    if (fallback.loading) {
      list.push(
        <Row key="fallback-next">
          <HStack frame={{ maxWidth: "infinity", height: 56, alignment: "center" }}>
            <ProgressView />
          </HStack>
        </Row>
      )
    } else if (fallback.hasMore) {
      list.push(
        <Row key="fallback-more">
          <VStack frame={{ height: 1 }} onAppear={loadMore} />
        </Row>
      )
    }

    return list
  }

  function hotRows(): VirtualNode[] {
    if (homeFailed) {
      return [
        <Row key="home-retry">
          <Center>
            <Button title="重試" buttonStyle="bordered" action={loadHome} />
          </Center>
        </Row>,
      ]
    }

    if (home == null) {
      return [
        <Row key="home-skeleton">
          <RowsSkeleton count={SKELETON_ROWS} />
        </Row>,
      ]
    }

    const songs = home.value.hotSearches
    const list: VirtualNode[] = [
      <Row key={TOP_HOT_ID}>
        <Rise order={0} active={enteringHot}>
          <HStack
            spacing={space.row}
            frame={{ maxWidth: "infinity" }}
            padding={{ horizontal: space.page, top: 24, bottom: 8 }}
          >
            <Text font="title3" fontWeight="bold">
              熱門搜尋
            </Text>
            <Spacer />
            <Text font="footnote" foregroundStyle="secondaryLabel">
              {hotSearchLabel(home.value.hotSearchDate)}
            </Text>
          </HStack>
        </Rise>
      </Row>,
    ]

    songs.forEach((song, index) => {
      list.push(
        <Row key={`hot-${song.id}`}>
          <Rise order={0} active={enteringHot && index < ENTER_ROWS}>
            <CompactSongRow
              entry={entryOf(song, index + 1)}
              zoomId={`search-hot-${song.id}`}
              showChange={false}
              showDivider={index < songs.length - 1}
            />
          </Rise>
        </Row>
      )
    })

    return list
  }

  return (
    <ScrollViewReader>
      {proxy => {
        proxyRef.current = proxy
        return (
          <List
            listStyle="plain"
            listRowSpacing={0}
            listSectionSpacing={0}
            contentMargins={0}
            scrollContentBackground="hidden"
            scrollEdgeEffectStyle="soft"
            navigationTitle="搜尋"
            navigationBarTitleDisplayMode="large"
            searchable={{
              value: input,
              onChanged: setInput,
              placement: "navigationBarDrawer",
              prompt: "歌曲、專輯、歌手",
            }}
            toolbar={
              <Toolbar>
                <ToolbarItem placement="topBarLeading">
                  <CloseButton />
                </ToolbarItem>
              </Toolbar>
            }
          >
            {rows}
          </List>
        )
      }}
    </ScrollViewReader>
  )
}

function itemsOf(suggestions: SearchSuggestions, kind: SearchKind): (Song | AlbumRef | Artist)[] {
  return kind === "song" ? suggestions.songs : kind === "album" ? suggestions.albums : suggestions.artists
}

function fetchPage(
  source: Guyso,
  kind: SearchKind,
  query: string,
  page: number
): Promise<Song[] | AlbumRef[] | Artist[]> {
  if (kind === "song") return source.searchSongs(query, page)
  if (kind === "album") return source.searchAlbums(query, page)
  return source.searchArtists(query, page)
}

function emptyState(): VirtualNode {
  return (
    <VStack spacing={12} frame={{ maxWidth: "infinity", height: Device.screen.height * 0.5 }} alignment="center">
      <Image systemName="magnifyingglass" font={40} foregroundStyle="tertiaryLabel" />
      <Text font="body" foregroundStyle="secondaryLabel">
        無結果
      </Text>
    </VStack>
  )
}

function Center({ children }: { children: any }) {
  return (
    <HStack frame={{ maxWidth: "infinity", height: Device.screen.height * 0.5, alignment: "center" }}>
      {children}
    </HStack>
  )
}

function Row({ children }: { children: any }) {
  return (
    <VStack
      spacing={0}
      listRowInsets={0}
      listRowSeparator="hidden"
      listRowBackground={<Rectangle fill="clear" />}
      frame={{ maxWidth: "infinity" }}
    >
      {children}
    </VStack>
  )
}
