// 時間選擇 sheet：依榜單 unit 顯示日期、時、週、月或年，上限是最新一期。

import {
  Button,
  DatePicker,
  HStack,
  List,
  Menu,
  NavigationStack,
  Picker,
  Section,
  Spacer,
  Text,
  Toolbar,
  ToolbarItem,
  useState,
} from "scripting"
import type { PresentationDetent } from "scripting"
import type { ChartWeek, Period } from "../model/types"

/** 網站沒有標示資料起點，日期選擇器就從 2010 年開始。 */
const YEAR_FLOOR = 2010

type Props = {
  unit: Period["unit"]
  /** 目前最新一期：選擇範圍的上限。 */
  latest: Period
  /** 開啟時預選的那一期。 */
  selected: Period
  /** 週榜的週清單；其他 unit 沒有。 */
  weeks?: ChartWeek[]
  onGo: (period: Period) => void
  onClose: () => void
}

export function TimePickerSheet({ unit, latest, selected, weeks, onGo, onClose }: Props) {
  const latestParts = dayOf(latest) ?? { year: YEAR_FLOOR, month: 1, day: 1 }
  const latestMs = startOfDay(latestParts)
  const latestYear = yearOf(latest) ?? latestParts.year
  const latestWeek = latest.unit === "week" ? latest.week : 1
  const latestMonth = latest.unit === "month" ? latest.month : 12

  const selectedParts = dayOf(selected) ?? latestParts
  const [dateMs, setDateMs] = useState(() => Math.min(startOfDay(selectedParts), latestMs))
  const [hour, setHour] = useState(() =>
    Math.min(selected.unit === "hour" ? selected.hour : 0, maxHourOf(startOfDay(selectedParts), latest))
  )
  const [year, setYear] = useState(() => Math.min(yearOf(selected) ?? latestYear, latestYear))
  const [week, setWeek] = useState(() => (selected.unit === "week" ? selected.week : latestWeek))
  const [month, setMonth] = useState(() => (selected.unit === "month" ? selected.month : latestMonth))

  const years =
    unit === "week" ? weekYears(weeks, latestYear, latestWeek) : range(YEAR_FLOOR, latestYear)
  const shownYear = years.includes(year) ? year : years[years.length - 1]

  const hours = range(0, maxHourOf(dateMs, latest))
  const shownHour = hours.includes(hour) ? hour : hours[hours.length - 1]

  const weekList = weekOptions(weeks, shownYear, latestYear, latestWeek)
  const shownWeek = weekList.includes(week) ? week : weekList[weekList.length - 1]

  const months = range(1, shownYear === latestYear ? latestMonth : 12)
  const shownMonth = months.includes(month) ? month : months[months.length - 1]

  function go(): void {
    if (unit === "hour") return onGo({ unit: "hour", date: dateString(dateMs), hour: shownHour })
    if (unit === "day") return onGo({ unit: "day", date: dateString(dateMs) })
    if (unit === "week") return onGo({ unit: "week", year: shownYear, week: shownWeek })
    if (unit === "month") return onGo({ unit: "month", year: shownYear, month: shownMonth })
    onGo({ unit: "year", year: shownYear })
  }

  return (
    <NavigationStack presentationDetents={[detentOf(unit)]}>
      <List
        listStyle="insetGroup"
        scrollDisabled
        navigationTitle="選擇時間"
        navigationBarTitleDisplayMode="inline"
        toolbar={
          <Toolbar>
            <ToolbarItem placement="cancellationAction">
              <Button action={onClose}>
                <Text font="body" foregroundStyle="tintColor">
                  取消
                </Text>
              </Button>
            </ToolbarItem>
            <ToolbarItem placement="confirmationAction">
              <Button action={go}>
                <Text font="body" fontWeight="semibold" foregroundStyle="tintColor">
                  前往
                </Text>
              </Button>
            </ToolbarItem>
          </Toolbar>
        }
      >
        {unit === "day" || unit === "hour" ? (
          <Section>
            <DatePicker
              title="日期"
              value={dateMs}
              onChanged={next => {
                const clamped = Math.min(next, latestMs)
                setDateMs(clamped)
                const max = maxHourOf(clamped, latest)
                if (hour > max) setHour(max)
              }}
              startDate={startOfDay({ year: YEAR_FLOOR, month: 1, day: 1 })}
              endDate={latestMs}
              displayedComponents={["date"]}
              datePickerStyle="graphical"
              labelsHidden
              frame={{ maxWidth: "infinity", alignment: "center" }}
            />
            {unit === "hour" ? (
              <HStack>
                <Text font="body">時間</Text>
                <Spacer />
                <Menu
                  label={
                    <Text
                      font="body"
                      monospacedDigit
                      foregroundStyle="label"
                      padding={{ horizontal: 12, vertical: 6 }}
                      background="tertiarySystemFill"
                      clipShape="capsule"
                    >
                      {`${shownHour} 時`}
                    </Text>
                  }
                >
                  <Picker
                    title="時"
                    labelsHidden
                    value={shownHour}
                    onChanged={(next: number) => setHour(next)}
                  >
                    {hours.map(item => (
                      <Text key={item} tag={item}>
                        {`${item} 時`}
                      </Text>
                    ))}
                  </Picker>
                </Menu>
              </HStack>
            ) : null}
          </Section>
        ) : null}

        {unit === "week" ? (
          <Section>
            <HStack spacing={0}>
              <Picker
                title="年"
                labelsHidden
                value={shownYear}
                onChanged={(next: number) => {
                  setYear(next)
                  const list = weekOptions(weeks, next, latestYear, latestWeek)
                  if (!list.includes(week)) setWeek(list[list.length - 1])
                }}
                pickerStyle="wheel"
                frame={{ maxWidth: "infinity" }}
              >
                {years.map(item => (
                  <Text key={item} tag={item}>
                    {`${item} 年`}
                  </Text>
                ))}
              </Picker>
              <Picker
                title="週"
                labelsHidden
                value={shownWeek}
                onChanged={(next: number) => setWeek(next)}
                pickerStyle="wheel"
                frame={{ maxWidth: "infinity" }}
              >
                {weekList.map(item => (
                  <Text key={item} tag={item}>
                    {`第 ${item} 週`}
                  </Text>
                ))}
              </Picker>
            </HStack>
          </Section>
        ) : null}

        {unit === "month" ? (
          <Section>
            <HStack spacing={0}>
              <Picker
                title="年"
                labelsHidden
                value={shownYear}
                onChanged={(next: number) => {
                  setYear(next)
                  const max = next === latestYear ? latestMonth : 12
                  if (month > max) setMonth(max)
                }}
                pickerStyle="wheel"
                frame={{ maxWidth: "infinity" }}
              >
                {years.map(item => (
                  <Text key={item} tag={item}>
                    {`${item} 年`}
                  </Text>
                ))}
              </Picker>
              <Picker
                title="月"
                labelsHidden
                value={shownMonth}
                onChanged={(next: number) => setMonth(next)}
                pickerStyle="wheel"
                frame={{ maxWidth: "infinity" }}
              >
                {months.map(item => (
                  <Text key={item} tag={item}>
                    {`${item} 月`}
                  </Text>
                ))}
              </Picker>
            </HStack>
          </Section>
        ) : null}

        {unit === "year" ? (
          <Section>
            <Picker
              title="年"
              labelsHidden
              value={shownYear}
              onChanged={(next: number) => setYear(next)}
              pickerStyle="wheel"
              frame={{ maxWidth: "infinity" }}
            >
              {years.map(item => (
                <Text key={item} tag={item}>
                  {`${item} 年`}
                </Text>
              ))}
            </Picker>
          </Section>
        ) : null}
      </List>
    </NavigationStack>
  )
}

/** 日曆版面用固定高度貼合內容。 */
function detentOf(unit: Period["unit"]): PresentationDetent {
  if (unit === "hour") return 520
  if (unit === "day") return 470
  return "medium"
}

type DateParts = { year: number; month: number; day: number }

function parseDate(date: string): DateParts {
  return {
    year: Number(date.slice(0, 4)),
    month: Number(date.slice(4, 6)),
    day: Number(date.slice(6, 8)),
  }
}

function dayOf(period: Period): DateParts | null {
  return period.unit === "hour" || period.unit === "day" ? parseDate(period.date) : null
}

function yearOf(period: Period): number | null {
  return period.unit === "hour" || period.unit === "day" ? null : period.year
}

/** 用裝置時區的當地午夜，日期選擇器才會顯示成榜單上的那一天。 */
function startOfDay(parts: DateParts): number {
  return new Date(parts.year, parts.month - 1, parts.day).getTime()
}

function dateString(ms: number): string {
  const date = new Date(ms)
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}`
}

/** 最新那一天的「時」只到最新一期；其他日子是整個 0–23。 */
function maxHourOf(ms: number, latest: Period): number {
  if (latest.unit !== "hour") return 23
  return dateString(ms) === latest.date ? latest.hour : 23
}

function weekYears(weeks: ChartWeek[] | undefined, latestYear: number, latestWeek: number): number[] {
  if (!weeks || weeks.length === 0) return range(YEAR_FLOOR, latestYear)
  const years: number[] = []
  for (const item of weeks) {
    if (item.year > latestYear) continue
    if (item.year === latestYear && item.week > latestWeek) continue
    if (!years.includes(item.year)) years.push(item.year)
  }
  years.sort((a, b) => a - b)
  return years.length > 0 ? years : range(YEAR_FLOOR, latestYear)
}

function weekOptions(
  weeks: ChartWeek[] | undefined,
  year: number,
  latestYear: number,
  latestWeek: number
): number[] {
  const max = year === latestYear ? latestWeek : 53
  if (weeks && weeks.length > 0) {
    const list = weeks.filter(item => item.year === year && item.week <= max).map(item => item.week)
    if (list.length > 0) return list.sort((a, b) => a - b)
  }
  return range(1, max)
}

function range(from: number, to: number): number[] {
  const list: number[] = []
  for (let value = from; value <= to; value++) list.push(value)
  return list
}

function pad(value: number): string {
  return `${value}`.padStart(2, "0")
}
