// 今日：Hero、急升、新進榜、最新加入。先用快取畫一幀，7 個榜與首頁全部 settle 後才換內容。

import {
  Button,
  Device,
  HStack,
  Image,
  List,
  Rectangle,
  ScrollView,
  Spacer,
  Text,
  Toolbar,
  ToolbarItem,
  VStack,
  ZStack,
  gradient,
  useEffect,
  useRef,
  useState,
} from "scripting"
import type { Artist, ChartEntry, PlatformId, Song, Today, TodayEntry } from "../model/types"
import { artistLine } from "../model/song"
import { guyso } from "../data/guyso"
import type { Guyso } from "../data/guyso"
import { accentOf, cachedAccent, deepAccent, type Accent } from "../ui/accent"
import { coverAt, space } from "../ui/theme"
import { Cover } from "../ui/Cover"
import { ImageFill } from "../ui/imageStore"
import { PlatformLogo } from "../ui/PlatformLogo"
import { CompactSongRow } from "../ui/CompactSongRow"
import { Attribution } from "../ui/Attribution"
import { CloseButton } from "../ui/CloseButton"
import { PushRow } from "../ui/router"
import { useZoomNamespace } from "../ui/zoom"
import { SpotifyMenuItems } from "../ui/spotify"
import { AlbumCard } from "../ui/AlbumCard"
import { ShimmerBox } from "../ui/Shimmer"
import { Rise, useEntering } from "../ui/Rise"
import { SongScreen } from "./SongScreen"
import { ArtistScreen } from "./ArtistScreen"

const pageWidth = Device.screen.width - space.page * 2
const risingHeight = 236
const heroHeight = pageWidth * 1.25
const cardWidth = 148

const fallbackAccent: Accent = { base: "#222222", light: "#222222", dark: "#dddddd" }

type State = { data: Today | null; failed: boolean }

export function TodayScreen({ source = guyso }: { source?: Guyso }) {
  const [state, setState] = useState<State>(() => ({ data: source.peekToday(), failed: false }))
  const heroImage = state.data?.hero?.entry.song.image
  const [accent, setAccent] = useState<Accent>(() =>
    heroImage ? cachedAccent(heroImage) ?? fallbackAccent : fallbackAccent
  )
  const alive = useRef(true)
  const showing = useRef(state.data != null)
  showing.current = state.data != null

  useEffect(() => {
    alive.current = true
    void load(false)
    return () => {
      alive.current = false
    }
  }, [source])

  useEffect(() => {
    if (!heroImage) return
    let live = true
    const cached = cachedAccent(heroImage)
    if (cached) setAccent(cached)
    void accentOf(heroImage).then(next => {
      if (live) setAccent(next)
    })
    return () => {
      live = false
    }
  }, [heroImage])

  async function load(force: boolean): Promise<void> {
    try {
      const next = await source.getToday(force ? { force: true } : {})
      if (!alive.current) return
      showing.current = true
      withAnimation(() => setState({ data: next, failed: false }))
    } catch {
      // 已經有內容就照舊顯示；完全沒有資料才換成重試。
      if (!alive.current || showing.current) return
      setState({ data: null, failed: true })
    }
  }

  function refresh(): Promise<void> {
    return load(true)
  }

  function retry(): void {
    showing.current = false
    setState({ data: null, failed: false })
    void load(true)
  }

  const data = state.data
  const entering = useEntering(data == null)

  return (
    <List
      listStyle="plain"
      listRowSpacing={0}
      listSectionSpacing={0}
      scrollContentBackground="hidden"
      scrollEdgeEffectStyle="soft"
      navigationTitle="今日"
      navigationBarTitleDisplayMode="large"
      refreshable={refresh}
      toolbar={
        <Toolbar>
          <ToolbarItem placement="topBarLeading">
            <CloseButton />
          </ToolbarItem>
        </Toolbar>
      }
    >
      {state.failed ? (
        <Row>
          <HStack
            frame={{ maxWidth: "infinity", height: Device.screen.height * 0.5, alignment: "center" }}
          >
            <Button title="重試" buttonStyle="bordered" action={retry} />
          </HStack>
        </Row>
      ) : data == null ? (
        <Row>
          <TodaySkeleton />
        </Row>
      ) : (
        <TodayContent data={data} accent={accent} entering={entering} />
      )}
    </List>
  )
}

function TodayContent({ data, accent, entering }: { data: Today; accent: Accent; entering: boolean }) {
  const hero = data.hero

  return (
    <VStack
      spacing={0}
      listRowInsets={0}
      listRowSeparator="hidden"
      listRowBackground={<Rectangle fill="clear" />}
      frame={{ maxWidth: "infinity" }}
    >
      {data.time ? (
        <Row>
          <Rise order={0} active={entering}>
            <HStack
              spacing={4}
              frame={{ maxWidth: "infinity", alignment: "leading" }}
              padding={{ horizontal: space.page, top: 8 }}
            >
              {data.stale ? (
                <Image systemName="wifi.slash" font="footnote" foregroundStyle="secondaryLabel" />
              ) : null}
              <Text font="footnote" foregroundStyle="secondaryLabel">
                {data.time}
              </Text>
            </HStack>
          </Rise>
        </Row>
      ) : null}

      {hero ? (
        <Row>
          <Rise order={0} active={entering}>
            <HeroCard
              hero={hero.entry}
              ranks={hero.ranks}
              winners={hero.platforms}
              accent={accent}
            />
          </Rise>
        </Row>
      ) : null}

      {data.rising.length > 0 ? (
        <Row>
          <Rise order={1} active={entering}>
            <Section title="急升">
              <ScrollView axes="horizontal" scrollIndicator="hidden">
                <HStack spacing={12} padding={{ horizontal: space.page }} alignment="top">
                  {data.rising.map(item => (
                    <RisingCard key={`${item.platform}-${item.entry.song.fullId}`} item={item} />
                  ))}
                </HStack>
              </ScrollView>
            </Section>
          </Rise>
        </Row>
      ) : null}

      {data.newcomers.length > 0 ? (
        <Row>
          <Rise order={2} active={entering}>
            <Section title="新進榜">
              <VStack spacing={0}>
                {data.newcomers.map((item, index) => (
                  <CompactSongRow
                    key={`${item.platform}-${item.entry.song.fullId}`}
                    entry={item.entry}
                    platform={item.platform}
                    zoomId={`new-${item.platform}-${item.entry.song.fullId}`}
                    showDivider={index < data.newcomers.length - 1}
                  />
                ))}
              </VStack>
            </Section>
          </Rise>
        </Row>
      ) : null}

      {data.latest.albums.length > 0 ? (
        <Row>
          <Section title="最新專輯">
            <CardStrip>
              {data.latest.albums.map(album => (
                <AlbumCard key={`${album.platform}-${album.id}`} album={album} />
              ))}
            </CardStrip>
          </Section>
        </Row>
      ) : null}

      {data.latest.songs.length > 0 ? (
        <Row>
          <Section title="最新歌曲">
            <CardStrip>
              {data.latest.songs.map(song => (
                <SongCard key={song.fullId} song={song} />
              ))}
            </CardStrip>
          </Section>
        </Row>
      ) : null}

      {data.latest.artists.length > 0 ? (
        <Row>
          <Section title="最新歌手">
            <CardStrip>
              {data.latest.artists.map(person => (
                <ArtistCard key={`${person.platform}-${person.id}`} artist={person} />
              ))}
            </CardStrip>
          </Section>
        </Row>
      ) : null}

      <Row>
        <Attribution />
      </Row>
    </VStack>
  )
}

function Row({ children }: { children: any }) {
  return (
    <VStack
      spacing={0}
      listRowInsets={0}
      listRowSeparator="hidden"
      listRowBackground={<Rectangle fill="clear" />}
      frame={{ maxWidth: "infinity" }}
    >
      {children}
    </VStack>
  )
}

export function Section({ title, children }: { title: string; children: any }) {
  return (
    <VStack
      alignment="leading"
      spacing={space.titleGap}
      padding={{ top: space.section }}
      frame={{ maxWidth: "infinity" }}
    >
      <Text font="title3" fontWeight="bold" padding={{ horizontal: space.page }}>
        {title}
      </Text>
      {children}
    </VStack>
  )
}

export function CardStrip({ children }: { children: any }) {
  return (
    <ScrollView axes="horizontal" scrollIndicator="hidden">
      <HStack spacing={12} padding={{ horizontal: space.page }} alignment="top">
        {children}
      </HStack>
    </ScrollView>
  )
}

/** 沒有任何快取時的骨架：Hero 同尺寸、急升 4 張卡、新進榜 5 列。 */
export function TodaySkeleton() {
  return (
    <VStack spacing={0} frame={{ maxWidth: "infinity" }}>
      <VStack padding={{ horizontal: space.page, top: 12 }}>
        {/* Scripting 在 List 裡會把 secondarySystemBackground 畫成深色，骨架一律用 tertiarySystemFill。 */}
        <ShimmerBox width={pageWidth} height={heroHeight} corner={24} />
      </VStack>
      <TodaySkeletonSections />
    </VStack>
  )
}

/** 骨架的兩個區塊，預覽時可以單獨拍。 */
export function TodaySkeletonSections() {
  return (
    <VStack spacing={0} frame={{ maxWidth: "infinity" }}>
      <Section title="急升">
        <ScrollView axes="horizontal" scrollIndicator="hidden">
          <HStack spacing={12} padding={{ horizontal: space.page }} alignment="top">
            {[0, 1, 2, 3].map(index => (
              <RisingSkeleton key={index} />
            ))}
          </HStack>
        </ScrollView>
      </Section>

      <Section title="新進榜">
        <VStack spacing={0}>
          {[0, 1, 2, 3, 4].map(index => (
            <HStack
              key={index}
              spacing={space.row}
              frame={{ maxWidth: "infinity", height: 64 }}
              padding={{ horizontal: space.page }}
            >
              <ShimmerBox width={44} height={44} corner={8} />
              <VStack alignment="leading" spacing={6}>
                <ShimmerBox width={140} height={12} corner={4} />
                <ShimmerBox width={84} height={10} corner={4} />
              </VStack>
              <Spacer />
            </HStack>
          ))}
        </VStack>
      </Section>
    </VStack>
  )
}

function RisingSkeleton() {
  return (
    <VStack
      alignment="leading"
      spacing={0}
      frame={{ width: cardWidth, height: risingHeight, alignment: "topLeading" }}
    >
      <ShimmerBox width={cardWidth} height={cardWidth} corner={12} />
      <VStack padding={{ top: 10 }}>
        <ShimmerBox width={64} height={22} corner={4} />
      </VStack>
      <VStack padding={{ top: 10 }}>
        <ShimmerBox width={120} height={12} corner={4} />
      </VStack>
      <VStack padding={{ top: 6 }}>
        <ShimmerBox width={80} height={10} corner={4} />
      </VStack>
    </VStack>
  )
}

function HeroCard({
  hero,
  ranks,
  winners,
  accent,
}: {
  hero: ChartEntry
  ranks: Partial<Record<PlatformId, number | null>>
  /** 拿第 1 名的平台，照 platformIds 的順序。 */
  winners: PlatformId[]
  accent: Accent
}) {
  const namespace = useZoomNamespace()
  const width = pageWidth
  const height = heroHeight
  const zoomId = `hero-${hero.song.fullId}`

  const card = (
    <ZStack
      frame={{ width, height }}
      clipShape={{ type: "rect", cornerRadius: 24, style: "continuous" }}
      shadow={{ color: "rgba(0,0,0,0.25)", radius: 24, y: 12 }}
      contentShape="rect"
      contextMenu={{
        menuItems: <SpotifyMenuItems song={hero.song} />,
      }}
      {...(namespace ? { matchedTransitionSource: { id: zoomId, namespace } } : {})}
    >
      <ImageFill url={coverAt(hero.song.image, 800)} />

      <Rectangle
        frame={{ width, height }}
        opacity={0.95}
        fill={gradient("linear", {
          colors: ["clear", deepAccent(accent.base)],
          startPoint: { x: 0.5, y: 0.35 },
          endPoint: { x: 0.5, y: 1 },
        })}
      />

      <VStack frame={{ width, height, alignment: "bottomLeading" }}>
        <VStack alignment="leading" spacing={10} padding={20}>
          <HStack spacing={6}>
            {winners.map(platform => (
              <PlatformLogo key={platform} id={platform} size={22} ringed />
            ))}
          </HStack>

          <Text font="largeTitle" fontWeight="heavy" foregroundStyle="white" lineLimit={2}>
            {hero.song.name}
          </Text>

          <Text
            font="title3"
            fontWeight="semibold"
            foregroundStyle="rgba(255,255,255,0.85)"
            lineLimit={1}
          >
            {artistLine(hero.song)}
          </Text>
        </VStack>
      </VStack>
    </ZStack>
  )

  return (
    <VStack padding={{ horizontal: space.page, top: 12 }}>
      <PushRow element={<SongScreen song={hero.song} transitionId={zoomId} />}>{card}</PushRow>
    </VStack>
  )
}

export function RisingCard({ item }: { item: TodayEntry }) {
  const namespace = useZoomNamespace()
  const song = item.entry.song
  const zoomId = `rising-${song.fullId}`

  return (
    <PushRow element={<SongScreen song={song} transitionId={zoomId} />}>
      <VStack
        alignment="leading"
        spacing={0}
        frame={{ width: cardWidth, height: risingHeight, alignment: "topLeading" }}
        contentShape="rect"
        contextMenu={{
          menuItems: <SpotifyMenuItems song={song} />,
        }}
      >
        <Cover
          image={song.image}
          points={cardWidth}
          corner={12}
          zoom={namespace ? { id: zoomId, namespace } : undefined}
        />

        <HStack padding={{ top: 8 }} frame={{ width: cardWidth }}>
          <Text
            font={28}
            fontDesign="rounded"
            fontWeight="heavy"
            monospacedDigit
            foregroundStyle="systemOrange"
            lineLimit={1}
            fixedSize
            layoutPriority={1}
          >
            {`↑${item.entry.change.type === "up" ? item.entry.change.by : ""}`}
          </Text>
          <Spacer minLength={0} />
          <PlatformLogo id={item.platform} size={16} />
        </HStack>

        <Text font="headline" lineLimit={1} padding={{ top: 4 }}>
          {song.name}
        </Text>
        <Text font="subheadline" foregroundStyle="secondaryLabel" lineLimit={1}>
          {artistLine(song)}
        </Text>
      </VStack>
    </PushRow>
  )
}

export function SongCard({ song }: { song: Song }) {
  const namespace = useZoomNamespace()
  const zoomId = `latest-song-${song.fullId}`

  return (
    <PushRow element={<SongScreen song={song} transitionId={zoomId} />}>
      <VStack alignment="leading" spacing={4} frame={{ width: 120 }}>
        <Cover
          image={song.image}
          points={120}
          corner={12}
          zoom={namespace ? { id: zoomId, namespace } : undefined}
        />
        <Text font="subheadline" fontWeight="semibold" lineLimit={1}>
          {song.name}
        </Text>
        <Text font="footnote" foregroundStyle="secondaryLabel" lineLimit={1}>
          {artistLine(song)}
        </Text>
      </VStack>
    </PushRow>
  )
}

export function ArtistCard({ artist }: { artist: Artist }) {
  return (
    <PushRow element={<ArtistScreen artist={artist} />}>
      <VStack alignment="center" spacing={6} frame={{ width: 88 }}>
        <Cover image={artist.image ?? ""} points={88} circle emptyIcon="person.fill" />
        <Text font="footnote" fontWeight="semibold" lineLimit={1} multilineTextAlignment="center">
          {artist.name}
        </Text>
      </VStack>
    </PushRow>
  )
}
