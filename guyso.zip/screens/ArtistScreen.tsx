// 歌手頁：模糊照片背景、圓形照片、最新歌曲、專輯、全部歌曲入口。

import {
  Button,
  GeometryReader,
  HStack,
  Image,
  Rectangle,
  ScrollView,
  Spacer,
  Text,
  VStack,
  ZStack,
  useColorScheme,
  useEffect,
  useState,
} from "scripting"
import type { Artist, ArtistDetail, Loaded, Song } from "../model/types"
import { entryOf } from "../model/song"
import { guyso } from "../data/guyso"
import type { Guyso } from "../data/guyso"
import { isNotIndexed } from "../data/http"
import {
  accentFromCache,
  accentOf,
  cachedAccent,
  neutralAccent,
  type Accent,
} from "../ui/accent"
import { coverAt, space } from "../ui/theme"
import { Cover } from "../ui/Cover"
import { ShimmerBox, ShimmerText } from "../ui/Shimmer"
import { AlbumCard } from "../ui/AlbumCard"
import { Attribution } from "../ui/Attribution"
import { CompactSongRow } from "../ui/CompactSongRow"
import { NotIndexed } from "../ui/NotIndexed"
import { PushRow } from "../ui/router"
import { AllSongsScreen } from "./AllSongsScreen"

type Phase = "loading" | "ready" | "error" | "missing"

export function ArtistScreen({
  artist,
  forceScheme,
  source = guyso,
  part = "full",
}: {
  artist: Artist
  forceScheme?: "light" | "dark"
  /** 預覽與測試用：換掉 facade。 */
  source?: Guyso
  /** 預覽用：lower 只畫照片以下的區塊。 */
  part?: "full" | "lower"
}) {
  const envScheme = useColorScheme()
  const scheme = forceScheme ?? envScheme

  const [initial] = useState<Loaded<ArtistDetail> | null>(() =>
    source.peekArtist(artist.platform, artist.id)
  )
  const [loaded, setLoaded] = useState<Loaded<ArtistDetail> | null>(initial)
  const [failed, setFailed] = useState(false)
  const [missing, setMissing] = useState(false)
  const [accent, setAccent] = useState<Accent>(
    () => accentFromCache(artist.image ?? "") ?? cachedAccent(artist.image ?? "") ?? neutralAccent
  )

  const image = loaded?.value.artist.image ?? artist.image ?? ""

  useEffect(() => {
    if (!image) return
    let alive = true
    void accentOf(image).then(next => {
      if (alive) setAccent(next)
    })
    return () => {
      alive = false
    }
  }, [image])

  useEffect(() => {
    let alive = true
    source.getArtist(artist.platform, artist.id).then(
      next => {
        if (alive) {
          withAnimation(() => setLoaded(next))
          setFailed(false)
          setMissing(false)
        }
      },
      error => {
        if (!alive || initial) return
        if (isNotIndexed(error)) setMissing(true)
        else setFailed(true)
      }
    )
    return () => {
      alive = false
    }
  }, [artist.platform, artist.id, source])

  const detail = loaded?.value ?? null
  const name = detail?.artist.name ?? artist.name
  const person = detail?.artist ?? artist
  const songs = detail?.songs ?? []
  const albums = detail?.albums ?? []
  const phase: Phase = failed ? "error" : missing ? "missing" : detail ? "ready" : "loading"

  function retry(): void {
    setFailed(false)
    setMissing(false)
    source.getArtist(artist.platform, artist.id, { force: true }).then(
      next => withAnimation(() => setLoaded(next)),
      () => setFailed(true)
    )
  }

  return (
    <GeometryReader>
      {proxy => {
        const contentWidth = proxy.size.width - space.page * 2

        return (
          <ScrollView
            tint={accent.base}
            navigationBarTitleDisplayMode="inline"
            frame={{ width: proxy.size.width, height: proxy.size.height }}
            background={
              image
                ? {
                    alignment: "center",
                    content: (
                      <ZStack ignoresSafeArea>
                        <Image
                          imageUrl={coverAt(image, 400)}
                          resizable
                          scaleToFill
                          blur={40}
                          frame={{ width: proxy.size.width * 1.4, height: proxy.size.height * 1.4 }}
                        />
                        <Rectangle
                          fill={
                            scheme === "dark"
                              ? { color: "black", opacity: 0.65 }
                              : { color: "white", opacity: 0.7 }
                          }
                          frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
                        />
                      </ZStack>
                    ),
                  }
                : undefined
            }
          >
            <VStack spacing={space.section} padding={{ top: 60 }} frame={{ width: proxy.size.width }}>
              {part === "full" ? (
                <VStack spacing={16} frame={{ width: contentWidth }}>
                  {image ? (
                    <Cover image={image} points={140} circle />
                  ) : (
                    <ZStack
                      frame={{ width: 140, height: 140 }}
                      background="tertiarySystemFill"
                      clipShape="circle"
                    >
                      <Image systemName="person.fill" font={56} foregroundStyle="tertiaryLabel" />
                    </ZStack>
                  )}
                  <Text font="title" fontWeight="bold" multilineTextAlignment="center" lineLimit={1}>
                    {name}
                  </Text>
                </VStack>
              ) : null}

              <VStack
                key={phase}
                spacing={space.section}
                frame={{ width: proxy.size.width }}
                transition={Transition.opacity()}
              >
                {phase === "error" ? (
                  <VStack frame={{ width: contentWidth, alignment: "center" }}>
                    <Button title="重試" buttonStyle="bordered" action={retry} />
                  </VStack>
                ) : phase === "missing" ? (
                  <NotIndexed kind="artist" id={artist.id} width={contentWidth} />
                ) : phase === "loading" ? (
                  <LoadingBlocks width={proxy.size.width} />
                ) : (
                  <>
                    {songs.length > 0 ? <LatestSongs songs={songs} artistId={artist.id} /> : null}
                    {albums.length > 0 ? <Albums albums={albums} /> : null}
                    {songs.length > 0 ? (
                      <AllSongsRow artist={person} songs={songs} width={contentWidth} />
                    ) : null}
                  </>
                )}
              </VStack>

              <Attribution />
            </VStack>
          </ScrollView>
        )
      }}
    </GeometryReader>
  )
}

const LATEST = 5

function LatestSongs({ songs, artistId }: { songs: Song[]; artistId: string }) {
  const shown = songs.slice(0, LATEST)
  return (
    <VStack
      alignment="leading"
      spacing={space.titleGap}
      frame={{ maxWidth: "infinity", alignment: "leading" }}
    >
      <Text font="title3" fontWeight="bold" padding={{ horizontal: space.page }}>
        最新歌曲
      </Text>
      <VStack spacing={0} frame={{ maxWidth: "infinity" }}>
        {shown.map((song, index) => (
          <CompactSongRow
            key={song.fullId}
            entry={entryOf(song)}
            zoomId={`artist-${artistId}-${song.fullId}`}
            showRank={false}
            showChange={false}
            showDivider={index < shown.length - 1}
          />
        ))}
      </VStack>
    </VStack>
  )
}

function Albums({ albums }: { albums: ArtistDetail["albums"] }) {
  return (
    <VStack
      alignment="leading"
      spacing={space.titleGap}
      frame={{ maxWidth: "infinity", alignment: "leading" }}
    >
      <Text font="title3" fontWeight="bold" padding={{ horizontal: space.page }}>
        專輯
      </Text>
      <ScrollView axes="horizontal" scrollIndicator="hidden">
        <HStack spacing={12} padding={{ horizontal: space.page }} alignment="top">
          {albums.map(album => (
            <AlbumCard key={`${album.platform}-${album.id}`} album={album} subtitle={false} />
          ))}
        </HStack>
      </ScrollView>
    </VStack>
  )
}

function AllSongsRow({ artist, songs, width }: { artist: Artist; songs: Song[]; width: number }) {
  return (
    <PushRow element={<AllSongsScreen artist={artist} songs={songs} />}>
      <HStack spacing={12} frame={{ width, height: 44 }} contentShape="rect">
        <Text font="body">全部歌曲</Text>
        <Spacer minLength={0} />
        <Text font="footnote" monospacedDigit foregroundStyle="secondaryLabel">
          {`${songs.length}`}
        </Text>
        <Image systemName="chevron.right" font="footnote" foregroundStyle="tertiaryLabel" />
      </HStack>
    </PushRow>
  )
}

/** 載入中：和真實區塊同尺寸的骨架。 */
function LoadingBlocks({ width }: { width: number }) {
  return (
    <>
      <VStack
        alignment="leading"
        spacing={space.titleGap}
        frame={{ width, alignment: "leading" }}
      >
        <Text font="title3" fontWeight="bold" padding={{ horizontal: space.page }}>
          最新歌曲
        </Text>
        <VStack spacing={0} frame={{ width }}>
          {[0, 1, 2, 3, 4].map(index => (
            <HStack
              key={index}
              spacing={space.row}
              frame={{ width, height: 64 }}
              padding={{ horizontal: space.page }}
            >
              <ShimmerBox width={44} height={44} corner={8} />
              <VStack alignment="leading" spacing={2}>
                <ShimmerText font="headline">歌名歌名歌名</ShimmerText>
                <ShimmerText font="subheadline">歌手歌手</ShimmerText>
              </VStack>
              <Spacer />
            </HStack>
          ))}
        </VStack>
      </VStack>

      <VStack
        alignment="leading"
        spacing={space.titleGap}
        frame={{ width, alignment: "leading" }}
      >
        <Text font="title3" fontWeight="bold" padding={{ horizontal: space.page }}>
          專輯
        </Text>
        <HStack spacing={12} padding={{ horizontal: space.page }} alignment="top">
          {[0, 1, 2].map(index => (
            <VStack key={index} alignment="leading" spacing={4} frame={{ width: 120 }}>
              <ShimmerBox width={120} height={120} corner={12} />
              <ShimmerText font="subheadline" width={100}>
                專輯名稱
              </ShimmerText>
            </VStack>
          ))}
        </HStack>
      </VStack>
    </>
  )
}
