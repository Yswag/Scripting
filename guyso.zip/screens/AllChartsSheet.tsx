// 全部榜單 sheet：7 個平台的全部榜單、網站連結、清除快取。

import {
  Button,
  Group,
  HStack,
  Image,
  List,
  NavigationStack,
  Section,
  Spacer,
  Text,
  Toolbar,
  ToolbarItem,
  useEffect,
  useObservable,
  useState,
} from "scripting"
import type { PlatformId } from "../model/types"
import { chartsOf } from "../data/catalog"
import { HOST } from "../data/http"
import type { Guyso } from "../data/guyso"
import { platforms, space } from "../ui/theme"
import { PlatformLogo } from "../ui/PlatformLogo"

export function AllChartsSheet({
  platform,
  slug,
  source,
  onSelect,
  onClose,
}: {
  platform: PlatformId
  slug: string
  source: Guyso
  onSelect: (platform: PlatformId, slug: string) => void
  onClose: () => void
}) {
  const [size, setSize] = useState<number | null>(null)
  const confirm = useObservable<boolean>(false)

  useEffect(() => {
    let alive = true
    void source.cacheSize().then(next => {
      if (alive) setSize(next)
    })
    return () => {
      alive = false
    }
  }, [source])

  function clear() {
    void source.clearCache().then(async () => {
      const next = await source.cacheSize()
      withAnimation(() => setSize(next))
    })
  }

  return (
    <NavigationStack presentationDetents={["large"]}>
      <List
        listStyle="insetGroup"
        navigationTitle="全部榜單"
        navigationBarTitleDisplayMode="inline"
        toolbar={
          <Toolbar>
            <ToolbarItem placement="confirmationAction">
              <Button action={onClose}>
                <Text font="body" fontWeight="semibold" foregroundStyle="tintColor">
                  完成
                </Text>
              </Button>
            </ToolbarItem>
          </Toolbar>
        }
        alert={{
          title: "清除快取？",
          isPresented: confirm,
          actions: (
            <Group>
              <Button title="清除" role="destructive" action={clear} />
              <Button title="取消" role="cancel" action={() => confirm.setValue(false)} />
            </Group>
          ),
        }}
      >
        {platforms.map(item => (
          <Section
            key={item.id}
            header={
              <HStack spacing={8} textCase={null}>
                <PlatformLogo id={item.id} size={20} />
                <Text font="headline" foregroundStyle="label">
                  {item.name}
                </Text>
              </HStack>
            }
          >
            {chartsOf(item.id).map(def => (
              <PlainRow
                key={def.slug}
                action={() => {
                  onSelect(item.id, def.slug)
                  onClose()
                }}
              >
                <Text font="body" foregroundStyle="label">
                  {def.name}
                </Text>
                <Spacer />
                {item.id === platform && def.slug === slug ? (
                  <Image systemName="checkmark" font="body" foregroundStyle="tintColor" />
                ) : null}
              </PlainRow>
            ))}
          </Section>
        ))}

        <Section
          header={
            <Text font="headline" foregroundStyle="label" textCase={null}>
              網站
            </Text>
          }
        >
          <PlainRow action={() => void Safari.openURL(`${HOST}/song/add`)}>
            <Text font="body" foregroundStyle="label">
              補充歌曲
            </Text>
            <Spacer />
            <Image systemName="arrow.up.right" font="footnote" foregroundStyle="tertiaryLabel" />
          </PlainRow>
          <PlainRow action={() => void Safari.openURL(`${HOST}/suggestion`)}>
            <Text font="body" foregroundStyle="label">
              資訊更正
            </Text>
            <Spacer />
            <Image systemName="arrow.up.right" font="footnote" foregroundStyle="tertiaryLabel" />
          </PlainRow>
        </Section>

        <Section>
          <PlainRow destructive action={() => confirm.setValue(true)}>
            <Text font="body" foregroundStyle="systemRed">
              清除快取
            </Text>
            <Spacer />
            <Text
              font="body"
              monospacedDigit
              foregroundStyle="secondaryLabel"
              contentTransition="numericText"
            >
              {size == null ? "" : formatBytes(size)}
            </Text>
          </PlainRow>
        </Section>
      </List>
    </NavigationStack>
  )
}

function PlainRow({
  children,
  action,
  destructive = false,
}: {
  children: any
  action: () => void
  destructive?: boolean
}) {
  return (
    <Button
      buttonStyle="plain"
      action={action}
      {...(destructive ? { role: "destructive" as const } : {})}
    >
      <HStack spacing={space.row} frame={{ maxWidth: "infinity" }} contentShape="rect">
        {children}
      </HStack>
    </Button>
  )
}

/** < 1 MB 用 KB，其餘用 MB 一位小數。 */
function formatBytes(bytes: number): string {
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
  return `${Math.round(bytes / 1024)} KB`
}
