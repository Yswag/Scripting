// 歌曲詳細：模糊封面背景、accent 跟著封面、跨平台名次、紀錄、走勢、聽眾、製作。
// 上半部用列表傳進來的 Song 立刻畫；下半部靠 facade 的歌曲頁，缺資料的區塊整個隱藏。

import {
  Button,
  Chart,
  ChartOverlay,
  Circle,
  GeometryReader,
  HStack,
  Image,
  LineChart,
  Picker,
  Rectangle,
  ScrollView,
  Text,
  VStack,
  ZStack,
  useColorScheme,
  useEffect,
  useState,
} from "scripting"
import type { Loaded, PlatformId, Song, SongDetail } from "../model/types"
import { artistLine, splitCount } from "../model/song"
import { seriesRuns } from "../model/graph"
import { guyso } from "../data/guyso"
import type { Guyso, PlatformRanks } from "../data/guyso"
import { isNotIndexed } from "../data/http"
import {
  accentFromCache,
  accentOf,
  cachedAccent,
  neutralAccent,
  textOnAccent,
  type Accent,
} from "../ui/accent"
import { coverAt, platforms, space, type Hex } from "../ui/theme"
import { Cover } from "../ui/Cover"
import { ShimmerBox, ShimmerText } from "../ui/Shimmer"
import { PlatformLogo } from "../ui/PlatformLogo"
import { Attribution } from "../ui/Attribution"
import { AxisLabels } from "../ui/AxisLabels"
import { useZoomNamespace } from "../ui/zoom"
import { NavLink } from "../ui/nav"
import { NotIndexed } from "../ui/NotIndexed"
import { openSongInSpotify } from "../ui/spotify"
import { creatorRoleOf } from "../model/creator"
import { ArtistScreen } from "./ArtistScreen"
import { AlbumScreen } from "./AlbumScreen"
import { CreatorScreen } from "./CreatorScreen"

type Phase = "loading" | "ready" | "error" | "missing"

export function SongScreen({
  song,
  transitionId,
  forceScheme,
  source = guyso,
  initialPhase,
}: {
  song: Song
  transitionId: string
  forceScheme?: "light" | "dark"
  /** 預覽與測試用：換掉 facade。 */
  source?: Guyso
  /** 預覽用：第一幀就是這個狀態，截圖才拍得到。 */
  initialPhase?: "missing"
}) {
  const namespace = useZoomNamespace()
  const envScheme = useColorScheme()
  const scheme = forceScheme ?? envScheme

  const [initial] = useState<Loaded<SongDetail> | null>(() =>
    source.peekSong(song.platform, song.id)
  )
  const [loaded, setLoaded] = useState<Loaded<SongDetail> | null>(initial)
  const [ranks, setRanks] = useState<PlatformRanks | null>(() =>
    initial ? source.peekRanks(initial.value) : null
  )
  const [failed, setFailed] = useState(false)
  const [missing, setMissing] = useState(initialPhase === "missing")
  const [accent, setAccent] = useState<Accent>(
    () => accentFromCache(song.image) ?? cachedAccent(song.image) ?? neutralAccent
  )
  const [range, setRange] = useState<"24h" | "30d">("24h")

  useEffect(() => {
    let alive = true
    void accentOf(song.image).then(next => {
      if (alive) setAccent(next)
    })
    return () => {
      alive = false
    }
  }, [song.image])

  useEffect(() => {
    let alive = true

    function apply(next: Loaded<SongDetail>): void {
      withAnimation(() => {
        setLoaded(next)
        setFailed(false)
        setMissing(false)
      })
      void source.crossPlatformRanks(next.value).then(nextRanks => {
        if (alive) withAnimation(() => setRanks(nextRanks))
      })
    }

    source.getSong(song.platform, song.id).then(
      next => {
        if (alive) apply(next)
      },
      error => {
        if (!alive || initial) return
        if (isNotIndexed(error)) setMissing(true)
        else setFailed(true)
      }
    )

    return () => {
      alive = false
    }
  }, [song.platform, song.id, source])

  const detail = loaded?.value ?? null
  const tint: Hex = scheme === "dark" ? accent.dark : accent.light
  const zoom = namespace ? { type: "zoom" as const, namespace, sourceID: transitionId } : undefined
  const zoomSource = namespace ? { id: transitionId, namespace } : undefined
  const spotifyTrackId = detail?.song.spotifyTrackId ?? song.spotifyTrackId
  const albumRef = detail?.song.album ?? song.album
  const phase: Phase = failed ? "error" : missing ? "missing" : detail ? "ready" : "loading"

  function retry(): void {
    setFailed(false)
    source.getSong(song.platform, song.id, { force: true }).then(
      next => {
        withAnimation(() => setLoaded(next))
        void source.crossPlatformRanks(next.value).then(nextRanks => withAnimation(() => setRanks(nextRanks)))
      },
      () => setFailed(true)
    )
  }

  return (
    <GeometryReader>
      {proxy => {
        const contentWidth = proxy.size.width - space.page * 2
        const coverSize = contentWidth * 0.72
        const fill = cellFill(scheme)

        return (
          <ScrollView
            tint={accent.base}
            navigationTransition={zoom}
            navigationBarTitleDisplayMode="inline"
            frame={{ width: proxy.size.width, height: proxy.size.height }}
            background={{
              alignment: "center",
              content: (
                <ZStack ignoresSafeArea>
                  <Image
                    imageUrl={coverAt(song.image, 400)}
                    resizable
                    scaleToFill
                    blur={40}
                    frame={{
                      width: proxy.size.width * 1.4,
                      height: proxy.size.height * 1.4,
                    }}
                  />
                  <Rectangle
                    fill={
                      scheme === "dark"
                        ? { color: "black", opacity: 0.65 }
                        : { color: "white", opacity: 0.7 }
                    }
                    frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
                  />
                </ZStack>
              ),
            }}
          >
            <VStack spacing={space.section} padding={{ top: 60 }} frame={{ width: proxy.size.width }}>
              <VStack spacing={20} frame={{ width: contentWidth }}>
                <ZStack
                  frame={{ width: contentWidth }}
                  shadow={{ color: "rgba(0,0,0,0.35)", radius: 32, y: 16 }}
                >
                  <Cover image={song.image} points={coverSize} corner={20} zoom={zoomSource} />
                </ZStack>

                <VStack spacing={6} frame={{ width: contentWidth }}>
                  <Text font="title2" fontWeight="bold" multilineTextAlignment="center" lineLimit={2}>
                    {song.name}
                  </Text>

                  <NavLink
                    targets={song.artists.map(artist => ({
                      label: artist.name,
                      element: <ArtistScreen artist={artist} />,
                    }))}
                  >
                    <Text
                      font="body"
                      fontWeight="semibold"
                      foregroundStyle={tint}
                      multilineTextAlignment="center"
                      lineLimit={1}
                    >
                      {artistLine(song)}
                    </Text>
                  </NavLink>

                  {albumRef ? (
                    <NavLink
                      targets={[
                        { label: albumRef.name, element: <AlbumScreen album={albumRef} transitionId={`song-album-${albumRef.id}`} /> },
                      ]}
                    >
                      <Text
                        font="footnote"
                        foregroundStyle="secondaryLabel"
                        multilineTextAlignment="center"
                        lineLimit={1}
                      >
                        {albumRef.name}
                      </Text>
                    </NavLink>
                  ) : null}
                </VStack>

                {phase === "missing" ? null : (
                  <Button
                    disabled={spotifyTrackId == null}
                    action={() => {
                      void openSongInSpotify(spotifyTrackId ? { ...song, spotifyTrackId } : song, source)
                    }}
                  >
                    <HStack
                      spacing={8}
                      frame={{ width: contentWidth, height: 50 }}
                      background={tint}
                      clipShape="capsule"
                    >
                      <Image systemName="play.fill" foregroundStyle={textOnAccent(tint)} />
                      <Text font="headline" foregroundStyle={textOnAccent(tint)}>
                        在 Spotify 開啟
                      </Text>
                    </HStack>
                  </Button>
                )}
              </VStack>

              <VStack
                key={phase}
                spacing={space.section}
                frame={{ width: contentWidth }}
                transition={Transition.opacity()}
              >
                {phase === "error" ? (
                  <VStack frame={{ width: contentWidth, alignment: "center" }}>
                    <Button title="重試" buttonStyle="bordered" action={retry} />
                  </VStack>
                ) : phase === "missing" ? (
                  <NotIndexed kind="song" id={song.id} width={contentWidth} />
                ) : (
                  <>
                    <Section title="各平台" width={contentWidth}>
                      {ranks ? (
                        <PlatformGrid ranks={ranks} width={contentWidth} fill={fill} />
                      ) : (
                        <PlatformGridSkeleton width={contentWidth} fill={fill} />
                      )}
                    </Section>

                    {detail == null ? (
                      <DetailSkeleton width={contentWidth} fill={fill} />
                    ) : (
                      <DetailSections
                        detail={detail}
                        tint={tint}
                        width={contentWidth}
                        fill={fill}
                        range={range}
                        onRange={setRange}
                      />
                    )}
                  </>
                )}
              </VStack>

              <Attribution />
            </VStack>
          </ScrollView>
        )
      }}
    </GeometryReader>
  )
}

/** 紀錄、走勢、聽眾、製作：有沒有資料決定區塊出不出現。 */
function DetailSections({
  detail,
  tint,
  width,
  fill,
  range,
  onRange,
}: {
  detail: SongDetail
  tint: Hex
  width: number
  fill: { color: "white" | "black"; opacity: number }
  range: "24h" | "30d"
  onRange: (value: "24h" | "30d") => void
}) {
  const hourly = detail.hourly ?? []
  const daily = detail.daily ?? []
  const hasHourly = hasTrend(hourly)
  const hasDaily = hasTrend(daily)
  const shown: "24h" | "30d" = hasHourly ? (range === "30d" && hasDaily ? "30d" : "24h") : "30d"

  return (
    <>
      {detail.records.length > 0 ? (
        <Section title="紀錄" width={width}>
          <RecordGrid records={detail.records} width={width} fill={fill} />
        </Section>
      ) : null}

      {hasHourly || hasDaily ? (
        <Section title="走勢" width={width}>
          <VStack spacing={12} frame={{ width }}>
            {hasHourly && hasDaily ? (
              <Picker
                title="走勢"
                value={shown}
                onChanged={(value: string | number) => onRange(value === "30d" ? "30d" : "24h")}
                pickerStyle="segmented"
                labelsHidden
              >
                <Text tag="24h">24 小時</Text>
                <Text tag="30d">30 天</Text>
              </Picker>
            ) : null}

            <TrendChart
              ranks={shown === "24h" ? hourly : daily}
              labels={shown === "24h" ? detail.hourlyLabels ?? hourLabels(hourly.length) : detail.dailyLabels}
              tint={tint}
              width={width}
            />
          </VStack>
        </Section>
      ) : null}

      {detail.listeners ? (
        <Section title="聽眾" width={width}>
          <ListenerBlock
            male={detail.listeners.male}
            female={detail.listeners.female}
            ages={detail.listeners.ages}
            tint={tint}
            width={width}
          />
        </Section>
      ) : null}

      {detail.credits.length > 0 ? (
        <Section title="製作" width={width}>
          <CreditList credits={detail.credits} width={width} />
        </Section>
      ) : null}
    </>
  )
}

export function Section({ title, width, children }: { title: string; width: number; children: any }) {
  return (
    <VStack alignment="leading" spacing={space.titleGap} frame={{ width, alignment: "leading" }}>
      <Text font="title3" fontWeight="bold">
        {title}
      </Text>
      {children}
    </VStack>
  )
}

export function RecordGrid({
  records,
  width,
  fill,
}: {
  records: SongDetail["records"]
  width: number
  fill: { color: "white" | "black"; opacity: number }
}) {
  const gap = 10
  const cellWidth = (width - gap * (records.length - 1)) / records.length

  return (
    <HStack spacing={gap} frame={{ width }}>
      {records.map(record => {
        const parts = splitCount(record.value)
        return (
          <VStack
            key={record.label}
            spacing={2}
            padding={{ horizontal: 12 }}
            frame={{ width: cellWidth, height: 96 }}
            background={fill}
            clipShape={{ type: "rect", cornerRadius: 16, style: "continuous" }}
          >
            <HStack spacing={2} alignment="firstTextBaseline" minScaleFactor={0.6} lineLimit={1}>
              {record.prefix ? (
                <Text font={17} fontDesign="rounded" fontWeight="bold">
                  {record.prefix}
                </Text>
              ) : null}
              <Text font={34} fontDesign="rounded" fontWeight="heavy" monospacedDigit>
                {parts.value}
              </Text>
              {parts.unit ? (
                <Text font={17} fontDesign="rounded" fontWeight="bold">
                  {parts.unit}
                </Text>
              ) : null}
            </HStack>
            <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1}>
              {record.label}
            </Text>
          </VStack>
        )
      })}
    </HStack>
  )
}

export function CreditList({ credits, width }: { credits: SongDetail["credits"]; width: number }) {
  return (
    <VStack spacing={0} frame={{ width }}>
      {credits.map(credit => (
        <NavLink
          key={credit.role}
          targets={credit.people.map(person => ({
            label: person.name,
            element: <CreatorScreen creator={person} role={creatorRoleOf(credit.role)} />,
          }))}
        >
          <HStack spacing={12} frame={{ width, height: 44 }}>
            <Text font="subheadline" foregroundStyle="secondaryLabel" frame={{ width: 48, alignment: "leading" }}>
              {credit.role}
            </Text>
            <Text font="body" lineLimit={1} frame={{ maxWidth: "infinity", alignment: "leading" }}>
              {credit.people.map(p => p.name).join(", ")}
            </Text>
            <Image systemName="chevron.right" font="footnote" foregroundStyle="tertiaryLabel" />
          </HStack>
        </NavLink>
      ))}
    </VStack>
  )
}

export function cellFill(scheme: "light" | "dark") {
  return scheme === "dark"
    ? { color: "white" as const, opacity: 0.09 }
    : { color: "black" as const, opacity: 0.045 }
}

export function PlatformGrid({
  ranks,
  width,
  fill,
}: {
  ranks: Record<PlatformId, number | null>
  width: number
  fill: { color: "white" | "black"; opacity: number }
}) {
  const cells: ({ id: PlatformId; name: string } | null)[] = [...platforms, null]
  const rows = [cells.slice(0, 4), cells.slice(4)]
  const cellWidth = (width - 30) / 4

  return (
    <VStack spacing={10} frame={{ width, alignment: "leading" }}>
      {rows.map((row, rowIndex) => (
        <HStack key={rowIndex} spacing={10} frame={{ width, alignment: "leading" }}>
          {row.map((cell, index) => {
            if (!cell) return <VStack key={`empty-${index}`} frame={{ width: cellWidth }} />
            const rank = ranks[cell.id]
            return (
              <VStack
                key={cell.id}
                spacing={6}
                frame={{ width: cellWidth, height: 76 }}
                background={fill}
                clipShape={{ type: "rect", cornerRadius: 16, style: "continuous" }}
              >
                <PlatformLogo id={cell.id} size={22} />
                <Text
                  font={28}
                  fontDesign="rounded"
                  fontWeight="heavy"
                  monospacedDigit
                  foregroundStyle={rank == null ? "tertiaryLabel" : "label"}
                  contentTransition="numericText"
                >
                  {rank == null ? "—" : `${rank}`}
                </Text>
              </VStack>
            )
          })}
        </HStack>
      ))}
    </VStack>
  )
}

export function TrendChart({
  ranks,
  labels,
  tint,
  width,
}: {
  ranks: (number | null)[]
  labels: string[]
  tint: Hex
  width: number
}) {
  const known = ranks.filter((rank): rank is number => rank != null)
  if (known.length < 2) return <VStack />

  const best = Math.min(...known)
  // 至少留 10 名的範圍，名次幾乎沒變時線才會貼在上方、不會放大抖動。
  const worst = Math.max(...known, best + 9)
  const bestIndex = ranks.indexOf(best)
  const bestValue = worst + 1 - best
  const height = 200

  // 名次反過來畫（第 1 名在上）；null 的點靠拆成多段線斷開。
  const values = ranks.map(rank => (rank == null ? null : worst + 1 - rank))
  const styleScale: Record<string, Hex> = {}
  const lines = seriesRuns(values).map((run, index) => {
    const key = `s${index}`
    styleScale[key] = tint
    return (
      <LineChart
        key={key}
        marks={run.map(point => ({
          label: labels[point.index],
          value: point.value,
          foregroundStyleBy: key,
          lineStyle: { lineWidth: 2.5 },
        }))}
      />
    )
  })

  return (
    <VStack spacing={0}>
      <Chart
        frame={{ width, height }}
        chartLegend="hidden"
        chartYAxis="hidden"
        chartXAxis="hidden"
        chartXScale={labels}
        chartYScale={{ from: 0, to: bestValue + 2 }}
        chartForegroundStyleScale={styleScale}
      >
        {lines}
        <ChartOverlay>
          {proxy => {
            const area = proxy.plotAreaFrame
            const px = proxy.position({ x: labels[bestIndex] })
            const py = proxy.position({ y: bestValue })
            if (!px || !py) return <VStack />

            const labelWidth = 44
            const labelOffset = Math.min(
              Math.max(px.x - area.width / 2 - labelWidth / 2, -area.width / 2 + 2),
              area.width / 2 - labelWidth - 2
            )

            return (
              <ZStack frame={{ width: area.width, height: area.height }}>
                <HStack
                  spacing={4}
                  frame={{ width: area.width, height: 1, alignment: "leading" }}
                  offset={{ x: 0, y: py.y - area.height / 2 }}
                >
                  {Array.from({ length: Math.max(0, Math.floor((px.x - 6) / 8)) }, (_, index) => (
                    <Rectangle key={index} fill="separator" frame={{ width: 4, height: 1 }} />
                  ))}
                </HStack>
                <Circle
                  fill={tint}
                  frame={{ width: 6, height: 6 }}
                  offset={{ x: px.x - area.width / 2, y: py.y - area.height / 2 }}
                />
                <Text
                  font="caption"
                  fontWeight="bold"
                  foregroundStyle={tint}
                  frame={{ width: labelWidth, height: 16, alignment: "center" }}
                  offset={{ x: labelOffset, y: py.y - area.height / 2 - 16 }}
                >
                  {`#${best}`}
                </Text>
              </ZStack>
            )
          }}
        </ChartOverlay>
      </Chart>
      <AxisLabels labels={labels} step={labels.length > 26 ? 7 : 6} width={width} />
    </VStack>
  )
}

export function ListenerBlock({
  male,
  female,
  ages,
  tint,
  width,
}: {
  male: number
  female: number
  ages: { label: string; ratio: number }[]
  tint: Hex
  width: number
}) {
  const top = Math.max(...ages.map(age => age.ratio))
  const maleLeads = male >= female
  const barWidth = width - 44 - 12 - 40 - 12

  return (
    <VStack spacing={16} frame={{ width, alignment: "leading" }}>
      <VStack spacing={6} frame={{ width }}>
        <HStack spacing={2} frame={{ width, height: 12 }}>
          <Rectangle
            fill={maleLeads ? tint : { color: tint, opacity: 0.35 }}
            frame={{ width: (width - 2) * (male / 100), height: 12 }}
            clipShape="capsule"
          />
          <Rectangle
            fill={maleLeads ? { color: tint, opacity: 0.35 } : tint}
            frame={{ width: (width - 2) * (female / 100), height: 12 }}
            clipShape="capsule"
          />
        </HStack>
        <HStack frame={{ width }}>
          <Text font="footnote" monospacedDigit foregroundStyle="secondaryLabel">
            {`男 ${male}%`}
          </Text>
          <VStack frame={{ maxWidth: "infinity" }} />
          <Text font="footnote" monospacedDigit foregroundStyle="secondaryLabel">
            {`女 ${female}%`}
          </Text>
        </HStack>
      </VStack>

      <VStack spacing={8} frame={{ width }}>
        {ages.map(age => (
          <HStack key={age.label} spacing={12} frame={{ width }}>
            <Text
              font="caption"
              foregroundStyle="secondaryLabel"
              frame={{ width: 44, alignment: "leading" }}
            >
              {age.label}
            </Text>
            <HStack frame={{ width: barWidth, height: 8, alignment: "leading" }}>
              <Rectangle
                fill={age.ratio === top ? tint : "systemFill"}
                frame={{ width: (barWidth * age.ratio) / 100, height: 8 }}
                clipShape="capsule"
              />
            </HStack>
            <Text
              font="caption"
              monospacedDigit
              foregroundStyle="secondaryLabel"
              frame={{ width: 40, alignment: "trailing" }}
            >
              {`${age.ratio}%`}
            </Text>
          </HStack>
        ))}
      </VStack>
    </VStack>
  )
}

/** 載入中的下半部：和真實區塊同尺寸的骨架，資料回來再淡入。 */
export function DetailSkeleton({
  width,
  fill,
}: {
  width: number
  fill: { color: "white" | "black"; opacity: number }
}) {
  return (
    <>
      <Section title="紀錄" width={width}>
        <HStack spacing={10} frame={{ width }}>
          {[0, 1, 2].map(index => (
            <VStack
              key={index}
              spacing={2}
              padding={{ horizontal: 12 }}
              frame={{ width: (width - 20) / 3, height: 96 }}
              background={fill}
              clipShape={{ type: "rect", cornerRadius: 16, style: "continuous" }}
            >
              <ShimmerText font="largeTitle" fontDesign="rounded" fontWeight="heavy" width={44} alignment="center">
                00
              </ShimmerText>
              <ShimmerText font="caption" width={52} alignment="center">
                最高名次
              </ShimmerText>
            </VStack>
          ))}
        </HStack>
      </Section>

      <Section title="走勢" width={width}>
        <VStack spacing={12} frame={{ width }}>
          <ShimmerBox width={width} height={32} capsule />
          <ShimmerBox width={width} height={220} corner={16} />
        </VStack>
      </Section>

      <Section title="聽眾" width={width}>
        <VStack spacing={16} frame={{ width, alignment: "leading" }}>
          <HStack spacing={8} frame={{ width, alignment: "leading" }}>
            <ShimmerBox width={width / 2 - 4} height={12} capsule />
            <ShimmerBox width={width / 2 - 4} height={12} capsule />
          </HStack>
          <VStack spacing={8} frame={{ width }}>
            {[0, 1, 2, 3, 4, 5].map(index => (
              <HStack key={index} spacing={12} frame={{ width }}>
                <ShimmerText font="caption" width={44}>
                  00–00
                </ShimmerText>
                <ShimmerBox width={width - 108} height={8} capsule />
                <ShimmerText font="caption" width={40} alignment="trailing">
                  00%
                </ShimmerText>
              </HStack>
            ))}
          </VStack>
        </VStack>
      </Section>

      <Section title="製作" width={width}>
        <VStack spacing={0} frame={{ width }}>
          {["作詞", "作曲", "編曲"].map(role => (
            <HStack key={role} spacing={12} frame={{ width, height: 44 }}>
              <ShimmerText font="subheadline" width={48}>
                {role}
              </ShimmerText>
              <ShimmerText font="body" width={120}>
                名字名字名字
              </ShimmerText>
            </HStack>
          ))}
        </VStack>
      </Section>
    </>
  )
}

export function PlatformGridSkeleton({
  width,
  fill,
}: {
  width: number
  fill: { color: "white" | "black"; opacity: number }
}) {
  const cells = [0, 1, 2, 3, 4, 5, 6]
  const rows = [cells.slice(0, 4), cells.slice(4)]
  const cellWidth = (width - 30) / 4

  return (
    <VStack spacing={10} frame={{ width, alignment: "leading" }}>
      {rows.map((row, rowIndex) => (
        <HStack key={rowIndex} spacing={10} frame={{ width, alignment: "leading" }}>
          {row.map((_, index) => (
            <VStack
              key={index}
              spacing={6}
              frame={{ width: cellWidth, height: 76 }}
              background={fill}
              clipShape={{ type: "rect", cornerRadius: 16, style: "continuous" }}
            >
              <ShimmerBox width={22} height={22} capsule />
              <ShimmerText font="title" fontDesign="rounded" fontWeight="heavy" width={34} alignment="center">
                00
              </ShimmerText>
            </VStack>
          ))}
          {row.length < 4 ? <VStack frame={{ width: cellWidth }} /> : null}
        </HStack>
      ))}
    </VStack>
  )
}

function countRanks(ranks: (number | null)[]): number {
  return ranks.filter(rank => rank != null).length
}

/** 少於兩個點畫不成線，那個時間範圍就當作沒有。 */
export function hasTrend(ranks: (number | null)[]): boolean {
  return countRanks(ranks) >= 2
}

function hourLabels(count: number): string[] {
  const labels: string[] = []
  for (let i = 0; i < count; i++) labels.push(`${(i + 3) % 24}時`)
  return labels
}
