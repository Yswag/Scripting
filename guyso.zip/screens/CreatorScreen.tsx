// 創作者頁：List 當根、inline 標題；第一列就是角色與歌曲數。

import {
  Button,
  HStack,
  List,
  Rectangle,
  Spacer,
  Text,
  VStack,
  useEffect,
  useState,
} from "scripting"
import type { Artist, CreatorDetail, CreatorRole, Loaded } from "../model/types"
import { entryOf } from "../model/song"
import { creatorRoleLabel } from "../model/creator"
import { guyso } from "../data/guyso"
import type { Guyso } from "../data/guyso"
import { space } from "../ui/theme"
import { ShimmerBox, ShimmerText } from "../ui/Shimmer"
import { Attribution } from "../ui/Attribution"
import { CompactSongRow } from "../ui/CompactSongRow"

export function CreatorScreen({
  creator,
  role,
  source = guyso,
}: {
  creator: Artist
  role: CreatorRole
  /** 預覽與測試用：換掉 facade。 */
  source?: Guyso
}) {
  const [initial] = useState<Loaded<CreatorDetail> | null>(() =>
    source.peekCreator(role, creator.platform, creator.id)
  )
  const [loaded, setLoaded] = useState<Loaded<CreatorDetail> | null>(initial)
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    let alive = true
    source.getCreator(role, creator.platform, creator.id).then(
      next => {
        if (alive) {
          withAnimation(() => setLoaded(next))
          setFailed(false)
        }
      },
      () => {
        if (alive && !initial) setFailed(true)
      }
    )
    return () => {
      alive = false
    }
  }, [role, creator.platform, creator.id, source])

  const detail = loaded?.value ?? null
  const songs = detail?.songs ?? []
  const name = detail?.artist.name ?? creator.name

  if (failed && !detail) {
    return (
      <VStack
        navigationTitle={name}
        navigationBarTitleDisplayMode="inline"
        background="systemBackground"
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
      >
        <Button title="重試" buttonStyle="bordered" action={retry} />
      </VStack>
    )
  }

  function retry(): void {
    setFailed(false)
    source.getCreator(role, creator.platform, creator.id, { force: true }).then(
      next => withAnimation(() => setLoaded(next)),
      () => setFailed(true)
    )
  }

  return (
    <List
      listStyle="plain"
      listRowSpacing={0}
      listSectionSpacing={0}
      scrollContentBackground="hidden"
      scrollEdgeEffectStyle="soft"
      navigationTitle={name}
      navigationBarTitleDisplayMode="inline"
    >
      {detail ? (
        <>
          <Row>
            <Text
              font="footnote"
              foregroundStyle="secondaryLabel"
              padding={{ horizontal: space.page, top: 4, bottom: 8 }}
            >
              {`${creatorRoleLabel(role)} · ${songs.length} 首`}
            </Text>
          </Row>

          {songs.map((song, index) => (
            <Row key={song.fullId}>
              <CompactSongRow
                entry={entryOf(song)}
                zoomId={`creator-${creator.id}-${song.fullId}`}
                showRank={false}
                showChange={false}
                showDivider={index < songs.length - 1}
              />
            </Row>
          ))}
        </>
      ) : (
        [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(index => (
          <Row key={index}>
            <SkeletonRow />
          </Row>
        ))
      )}

      <Row>
        <Attribution />
      </Row>
    </List>
  )
}

function SkeletonRow() {
  return (
    <HStack
      spacing={space.row}
      frame={{ maxWidth: "infinity", height: 64 }}
      padding={{ horizontal: space.page }}
    >
      <ShimmerBox width={44} height={44} corner={8} />
      <VStack alignment="leading" spacing={2}>
        <ShimmerText font="headline">歌名歌名歌名</ShimmerText>
        <ShimmerText font="subheadline">歌手歌手</ShimmerText>
      </VStack>
      <Spacer />
    </HStack>
  )
}

function Row({ children }: { children: any }) {
  return (
    <VStack
      spacing={0}
      listRowInsets={0}
      listRowSeparator="hidden"
      listRowBackground={<Rectangle fill="clear" />}
      frame={{ maxWidth: "infinity" }}
    >
      {children}
    </VStack>
  )
}
