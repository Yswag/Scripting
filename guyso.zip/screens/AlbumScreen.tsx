// 專輯頁：模糊封面背景、大封面、曲目列表。網站沒有分頁，一次就是全部。

import {
  Button,
  GeometryReader,
  HStack,
  Image,
  Rectangle,
  ScrollView,
  Spacer,
  Text,
  VStack,
  ZStack,
  useColorScheme,
  useEffect,
  useState,
} from "scripting"
import type { AlbumDetail, AlbumRef, Loaded } from "../model/types"
import { formatDuration } from "../model/song"
import { guyso } from "../data/guyso"
import type { Guyso } from "../data/guyso"
import { isNotIndexed } from "../data/http"
import {
  accentFromCache,
  accentOf,
  cachedAccent,
  neutralAccent,
  type Accent,
} from "../ui/accent"
import { coverAt, space, type Hex } from "../ui/theme"
import { Cover } from "../ui/Cover"
import { ShimmerBox, ShimmerText } from "../ui/Shimmer"
import { Attribution } from "../ui/Attribution"
import { useZoomNamespace } from "../ui/zoom"
import { PushRow } from "../ui/router"
import { NavLink } from "../ui/nav"
import { NotIndexed } from "../ui/NotIndexed"
import { SpotifyMenuItems } from "../ui/spotify"
import { SongScreen } from "./SongScreen"
import { ArtistScreen } from "./ArtistScreen"

type Phase = "loading" | "ready" | "error" | "missing"

export function AlbumScreen({
  album,
  transitionId,
  forceScheme,
  source = guyso,
}: {
  album: AlbumRef
  transitionId: string
  forceScheme?: "light" | "dark"
  /** 預覽與測試用：換掉 facade。 */
  source?: Guyso
}) {
  const namespace = useZoomNamespace()
  const envScheme = useColorScheme()
  const scheme = forceScheme ?? envScheme

  const [initial] = useState<Loaded<AlbumDetail> | null>(() => source.peekAlbum(album.platform, album.id))
  const [loaded, setLoaded] = useState<Loaded<AlbumDetail> | null>(initial)
  const [failed, setFailed] = useState(false)
  const [missing, setMissing] = useState(false)
  const [accent, setAccent] = useState<Accent>(
    () => accentFromCache(album.image ?? "") ?? cachedAccent(album.image ?? "") ?? neutralAccent
  )

  useEffect(() => {
    if (!album.image) return
    let alive = true
    void accentOf(album.image).then(next => {
      if (alive) setAccent(next)
    })
    return () => {
      alive = false
    }
  }, [album.image])

  useEffect(() => {
    let alive = true
    source.getAlbum(album.platform, album.id).then(
      next => {
        if (alive) {
          withAnimation(() => setLoaded(next))
          setFailed(false)
          setMissing(false)
        }
      },
      error => {
        if (!alive || initial) return
        if (isNotIndexed(error)) setMissing(true)
        else setFailed(true)
      }
    )
    return () => {
      alive = false
    }
  }, [album.platform, album.id, source])

  const detail = loaded?.value ?? null
  const tint: Hex = scheme === "dark" ? accent.dark : accent.light
  const image = detail?.image ?? album.image ?? ""
  const name = detail?.name ?? album.name
  const songs = detail?.songs ?? []
  const artists = detail?.artists ?? []
  const year = detail?.releasedAt?.slice(0, 4)
  const phase: Phase = failed ? "error" : missing ? "missing" : detail ? "ready" : "loading"
  const zoom = namespace ? { type: "zoom" as const, namespace, sourceID: transitionId } : undefined
  const zoomSource = namespace ? { id: transitionId, namespace } : undefined

  function retry(): void {
    setFailed(false)
    setMissing(false)
    source.getAlbum(album.platform, album.id, { force: true }).then(
      next => withAnimation(() => setLoaded(next)),
      () => setFailed(true)
    )
  }

  return (
    <GeometryReader>
      {proxy => {
        const contentWidth = proxy.size.width - space.page * 2

        return (
          <ScrollView
            tint={accent.base}
            navigationTransition={zoom}
            navigationBarTitleDisplayMode="inline"
            frame={{ width: proxy.size.width, height: proxy.size.height }}
            background={
              image
                ? {
                    alignment: "center",
                    content: (
                      <ZStack ignoresSafeArea>
                        <Image
                          imageUrl={coverAt(image, 400)}
                          resizable
                          scaleToFill
                          blur={40}
                          frame={{ width: proxy.size.width * 1.4, height: proxy.size.height * 1.4 }}
                        />
                        <Rectangle
                          fill={
                            scheme === "dark"
                              ? { color: "black", opacity: 0.65 }
                              : { color: "white", opacity: 0.7 }
                          }
                          frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
                        />
                      </ZStack>
                    ),
                  }
                : undefined
            }
          >
            <VStack spacing={space.section} padding={{ top: 60 }} frame={{ width: proxy.size.width }}>
              <VStack spacing={20} frame={{ width: contentWidth }}>
                <ZStack
                  frame={{ width: contentWidth }}
                  shadow={{ color: "rgba(0,0,0,0.35)", radius: 32, y: 16 }}
                >
                  <Cover image={image} points={220} corner={20} zoom={zoomSource} />
                </ZStack>

                <VStack spacing={6} frame={{ width: contentWidth }}>
                  <Text font="title2" fontWeight="bold" multilineTextAlignment="center" lineLimit={2}>
                    {name}
                  </Text>

                  {artists.length > 0 ? (
                    <NavLink
                      targets={artists.map(artist => ({
                        label: artist.name,
                        element: <ArtistScreen artist={artist} />,
                      }))}
                    >
                      <Text
                        font="body"
                        fontWeight="semibold"
                        foregroundStyle={tint}
                        multilineTextAlignment="center"
                        lineLimit={1}
                      >
                        {artists.map(artist => artist.name).join(", ")}
                      </Text>
                    </NavLink>
                  ) : phase === "loading" ? (
                    <Text font="body" foregroundStyle="clear" multilineTextAlignment="center" overlay={<ShimmerBox width={64} height={14} corner={3} />}>
                      歌手歌手
                    </Text>
                  ) : null}

                  {phase === "ready" ? (
                    <Text
                      font="footnote"
                      foregroundStyle="secondaryLabel"
                      multilineTextAlignment="center"
                    >
                      {metaLine(year, songs.length)}
                    </Text>
                  ) : phase === "loading" ? (
                    <Text font="footnote" foregroundStyle="clear" multilineTextAlignment="center" overlay={<ShimmerBox width={80} height={11} corner={3} />}>
                      0000 · 00 首
                    </Text>
                  ) : null}
                </VStack>
              </VStack>

              <VStack
                key={phase}
                spacing={space.section}
                frame={{ width: contentWidth }}
                transition={Transition.opacity()}
              >
                {phase === "error" ? (
                  <VStack frame={{ width: contentWidth, alignment: "center" }}>
                    <Button title="重試" buttonStyle="bordered" action={retry} />
                  </VStack>
                ) : phase === "missing" ? (
                  <NotIndexed kind="album" id={album.id} width={contentWidth} />
                ) : phase === "loading" ? (
                  <TrackSkeleton width={contentWidth} />
                ) : (
                  <VStack spacing={0} frame={{ width: contentWidth }}>
                    {songs.map((song, index) => (
                      <TrackRow
                        key={song.fullId}
                        song={song}
                        tint={tint}
                        width={contentWidth}
                        showDivider={index < songs.length - 1}
                        transitionId={`album-${album.id}-${song.fullId}`}
                      />
                    ))}
                  </VStack>
                )}
              </VStack>

              <Attribution />
            </VStack>
          </ScrollView>
        )
      }}
    </GeometryReader>
  )
}

function metaLine(year: string | undefined, count: number): string {
  return year ? `${year} · ${count} 首` : `${count} 首`
}

function TrackRow({
  song,
  tint,
  width,
  showDivider,
  transitionId,
}: {
  song: AlbumDetail["songs"][number]
  tint: Hex
  width: number
  showDivider: boolean
  transitionId: string
}) {
  const row = (
    <VStack
      spacing={0}
      frame={{ width }}
      contentShape="rect"
      contextMenu={{ menuItems: <SpotifyMenuItems song={song} /> }}
    >
      <HStack spacing={space.row} frame={{ width, height: 56 }}>
        <Text
          font={15}
          fontDesign="rounded"
          fontWeight="semibold"
          monospacedDigit
          foregroundStyle="secondaryLabel"
          frame={{ width: 28, alignment: "leading" }}
        >
          {song.trackNo == null ? "" : `${song.trackNo}`}
        </Text>

        <Text font="headline" lineLimit={1} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          {song.name}
        </Text>

        {song.isTitle ? (
          <Text
            font="caption2"
            fontWeight="bold"
            foregroundStyle={tint}
            padding={{ horizontal: 6, vertical: 2 }}
            background={{ color: tint, opacity: 0.15 }}
            clipShape="capsule"
            fixedSize
          >
            主打
          </Text>
        ) : null}

        <Spacer minLength={8} />

        <Text font="footnote" monospacedDigit foregroundStyle="secondaryLabel" fixedSize>
          {formatDuration(song.durationSec)}
        </Text>
      </HStack>

      {showDivider ? (
        <Rectangle
          fill="separator"
          frame={{ maxWidth: "infinity", height: 0.5 }}
          padding={{ leading: 40 }}
        />
      ) : null}
    </VStack>
  )

  return <PushRow element={<SongScreen song={song} transitionId={transitionId} />}>{row}</PushRow>
}

function TrackSkeleton({ width }: { width: number }) {
  return (
    <VStack spacing={0} frame={{ width }}>
      {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(index => (
        <HStack key={index} spacing={space.row} frame={{ width, height: 56 }}>
          <ShimmerText font="footnote" fontDesign="rounded" fontWeight="semibold" width={28}>
            0
          </ShimmerText>
          <ShimmerText font="headline" width={width - 100}>
            歌名歌名歌名
          </ShimmerText>
          <Spacer />
          <ShimmerText font="footnote" width={32}>
            0:00
          </ShimmerText>
        </HStack>
      ))}
    </VStack>
  )
}
