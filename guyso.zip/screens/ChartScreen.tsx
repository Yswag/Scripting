// 排行：平台選單、榜單膠囊列、全部榜單與時間選擇 sheet。切換時內容淡入淡出並捲回最上方。

import {
  Button,
  Device,
  Group,
  HStack,
  Image,
  List,
  Rectangle,
  ScrollView,
  ScrollViewReader,
  ScrollViewProxy,
  Spacer,
  Text,
  Toolbar,
  ToolbarItem,
  VStack,
  useEffect,
  useObservable,
  useRef,
  useState,
  type VirtualNode,
} from "scripting"
import type { Chart as ChartModel, ChartDef, ChartWeek, Loaded, PlatformId, Period } from "../model/types"
import { latestValue, percentText } from "../model/graph"
import { periodKey, timeLabel } from "../model/period"
import { chartsOf, defaultChartOf, findChart } from "../data/catalog"
import { guyso } from "../data/guyso"
import type { Guyso } from "../data/guyso"
import { graphColor, platforms, space } from "../ui/theme"
import { CompactSongRow } from "../ui/CompactSongRow"
import { CumulativeRow } from "../ui/CumulativeRow"
import { GraphCard } from "../ui/GraphCard"
import { Top3Row } from "../ui/Top3Row"
import { Attribution } from "../ui/Attribution"
import { CloseButton } from "../ui/CloseButton"
import { ChartSkeleton } from "../ui/Skeleton"
import { Rise, useEntering } from "../ui/Rise"
import { ShimmerText } from "../ui/Shimmer"
import { AllChartsSheet } from "./AllChartsSheet"
import { TimePickerSheet } from "./TimePickerSheet"

const TOP_ROW_ID = "chart-top"
const SELECTION_KEY = "guyso.chartSelection"
const BOARD_LIMIT = 100
/** 進場動畫只播前幾列（第一屏）。 */
const ENTER_ROWS = 8

type Selection = { platform: PlatformId; slugByPlatform: Partial<Record<PlatformId, string>> }

/** 畫面上那一框資料。key 是 platform/slug/期別，還沒換過來之前不顯示舊內容。 */
type View = { key: string; chart: Loaded<ChartModel> | null; failed: boolean }

type TimeSheet = { unit: Period["unit"]; latest: Period; selected: Period }

export function ChartScreen({
  source = guyso,
  initial,
}: {
  source?: Guyso
  /** 預覽用：指定要開的榜單與期別，不讀也不寫 Storage。 */
  initial?: { platform: PlatformId; slug: string; period?: Period }
}) {
  const start = useRef<Selection>(
    initial ? { platform: initial.platform, slugByPlatform: { [initial.platform]: initial.slug } } : readSelection()
  )
  const persist = initial == null
  const [platform, setPlatform] = useState<PlatformId>(start.current.platform)
  const [slugByPlatform, setSlugByPlatform] = useState<Partial<Record<PlatformId, string>>>(
    start.current.slugByPlatform
  )
  const slug = slugOf(platform, slugByPlatform)
  const charts = chartsOf(platform)

  // 期別不進 Storage：重開 App 一律最新一期。
  const [period, setPeriod] = useState<Period | null>(initial?.period ?? null)
  const key = periodKey(period)
  const viewKey = `${platform}/${slug}/${key}`

  const [view, setView] = useState<View>(() => ({
    key: viewKey,
    chart: source.peekChart(platform, slug, period ?? undefined),
    failed: false,
  }))
  const viewRef = useRef<View>(view)
  viewRef.current = view
  const periodRef = useRef<Period | null>(period)
  periodRef.current = period

  // 時間選擇的上限是最新一期；週榜的週清單也只列網站真的有資料的週。
  const latestRef = useRef<Partial<Record<string, Period>>>({})
  const weeksRef = useRef<ChartWeek[] | undefined>(undefined)

  const proxyRef = useRef<ScrollViewProxy>()
  const sheetOpen = useObservable<boolean>(false)
  const sheetKind = useObservable<"charts" | "time">("charts")
  const [timeSheet, setTimeSheet] = useState<TimeSheet | null>(null)

  function remember(chart: ChartModel, isLatest: boolean): void {
    if (chart.availableWeeks?.length) weeksRef.current = chart.availableWeeks
    if (isLatest) latestRef.current[`${chart.def.platform}/${chart.def.slug}`] = chart.period
  }

  useEffect(() => {
    let cancelled = false
    const requested = periodRef.current
    const cached = source.peekChart(platform, slug, requested ?? undefined)
    if (cached) remember(cached.value, requested == null)
    setView({ key: viewKey, chart: cached, failed: false })

    source
      .getChart(platform, slug, requested ?? undefined)
      .then(next => {
        if (cancelled) return
        remember(next.value, requested == null)
        withAnimation(() => {
          setView({ key: viewKey, chart: next, failed: false })
        })
      })
      .catch(() => {
        if (cancelled || cached) return
        setView({ key: viewKey, chart: null, failed: true })
      })

    return () => {
      cancelled = true
    }
  }, [viewKey, source])

  function select(nextPlatform: PlatformId, nextSlug: string) {
    if (nextPlatform === platform && nextSlug === slug) return
    const nextMap = { ...slugByPlatform, [nextPlatform]: nextSlug }
    if (persist) writeSelection({ platform: nextPlatform, slugByPlatform: nextMap })
    withAnimation(() => {
      setPeriod(null)
      setPlatform(nextPlatform)
      setSlugByPlatform(nextMap)
    })
    scrollToTop()
  }

  function scrollToTop() {
    proxyRef.current?.scrollTo(TOP_ROW_ID, "top")
    setTimeout(() => proxyRef.current?.scrollTo(TOP_ROW_ID, "top"), 0)
  }

  async function refresh() {
    // 歷史期別永久快取：下拉重新整理直接結束，不發請求。
    if (periodRef.current != null) return
    try {
      const next = await source.getChart(platform, slug, undefined, { force: true })
      remember(next.value, true)
      withAnimation(() => {
        setView({ key: viewKey, chart: next, failed: false })
      })
    } catch {
      if (!viewRef.current.chart) setView({ key: viewKey, chart: null, failed: true })
    }
  }

  function retry() {
    const requested = periodRef.current ?? undefined
    setView({ key: viewKey, chart: null, failed: false })
    source
      .getChart(platform, slug, requested, { force: true })
      .then(next => {
        remember(next.value, periodRef.current == null)
        withAnimation(() => setView({ key: viewKey, chart: next, failed: false }))
      })
      .catch(() => setView({ key: viewKey, chart: null, failed: true }))
  }

  const titleMenu = (
    <Group>
      {platforms.map(item => (
        <Button
          key={item.id}
          title={item.name}
          {...(item.id === platform ? { systemImage: "checkmark" } : {})}
          action={() => select(item.id, slugOf(item.id, slugByPlatform))}
        />
      ))}
    </Group>
  )

  // 畫面上只顯示已經換過來的那一期，不閃舊內容。
  const current = view.key === viewKey ? view : null
  const shown = current?.chart ?? null
  const failed = current?.failed === true
  const loading = shown == null && !failed
  const history = period != null
  const contentKey = viewKey
  const valueLabel = shown ? valueLabelOf(shown.value) : undefined
  // 只有第一次從骨架換成內容才進場；切平台／期別沿用淡入淡出。
  const shownOnce = useRef(false)
  const entering = useEntering(loading && !shownOnce.current)
  if (shown) shownOnce.current = true

  const rows: VirtualNode[] = []

  // 期間列：歷史顯示選擇的期間（label 色）＋「回到最新」。
  const periodLine: VirtualNode | null = shown ? (
    <PeriodLine
      period={shown.value.period}
      stale={shown.stale}
      valueLabel={valueLabel}
      history={history}
      onLatest={backToLatest}
    />
  ) : period ? (
    <PeriodLine period={period} stale={false} history onLatest={backToLatest} />
  ) : failed ? null : (
    <PeriodSkeleton />
  )

  if (periodLine != null) {
    rows.push(
      <Row key={TOP_ROW_ID}>
        <VStack
          key={contentKey}
          spacing={0}
          frame={{ maxWidth: "infinity" }}
          transition={Transition.opacity()}
        >
          {shown ? (
            <Rise order={0} active={entering}>
              {periodLine}
            </Rise>
          ) : (
            periodLine
          )}
        </VStack>
      </Row>
    )
  }

  if (failed) {
    rows.push(
      <Row key="retry">
        <HStack
          frame={{ maxWidth: "infinity", height: Device.screen.height * 0.5, alignment: "center" }}
        >
          <Button title="重試" buttonStyle="bordered" action={retry} />
        </HStack>
      </Row>
    )
  } else if (loading) {
    rows.push(
      <Row key="skeleton">
        <VStack
          key={contentKey}
          spacing={0}
          frame={{ maxWidth: "infinity" }}
          transition={Transition.opacity()}
        >
          <ChartSkeleton />
        </VStack>
      </Row>
    )
  } else if (shown!.value.def.kind === "graph") {
    rows.push(...graphRows(shown!.value, contentKey, entering))
  } else if (shown!.value.def.kind === "cumulative") {
    rows.push(...cumulativeRows(shown!.value, entering))
  } else {
    rows.push(...rankingRows(shown!.value, entering))
  }

  rows.push(
    <Row key="attribution">
      <Attribution />
    </Row>
  )

  function backToLatest(): void {
    withAnimation(() => setPeriod(null))
    scrollToTop()
  }

  function openTimeSheet(): void {
    const def = findChart(platform, slug)
    const latest = latestRef.current[`${platform}/${slug}`] ?? source.peekChart(platform, slug)?.value.period
    if (!def || !latest) return
    setTimeSheet({ unit: def.unit, latest, selected: periodRef.current ?? shown?.value.period ?? latest })
    sheetKind.setValue("time")
    sheetOpen.setValue(true)
  }

  function goToPeriod(next: Period): void {
    const target = timeSheet && periodKey(next) === periodKey(timeSheet.latest) ? null : next
    sheetOpen.setValue(false)
    if (periodKey(target) === key) return
    withAnimation(() => setPeriod(target))
    scrollToTop()
  }

  return (
    <ScrollViewReader>
      {proxy => {
        proxyRef.current = proxy
        return (
          <List
            listStyle="plain"
            listRowSpacing={0}
            listSectionSpacing={0}
            contentMargins={0}
            scrollContentBackground="hidden"
            scrollEdgeEffectStyle="soft"
            refreshable={refresh}
            safeAreaBar={{
              edge: "top",
              content: (
                <CapsuleStrip
                  charts={charts}
                  platform={platform}
                  slug={slug}
                  onSelect={next => select(platform, next)}
                />
              ),
            }}
            navigationTitle={platformName(platform)}
            navigationBarTitleDisplayMode="inline"
            toolbarTitleMenu={titleMenu}
            sheet={{
              isPresented: sheetOpen,
              content:
                sheetKind.value === "time" && timeSheet ? (
                  <TimePickerSheet
                    unit={timeSheet.unit}
                    latest={timeSheet.latest}
                    selected={timeSheet.selected}
                    {...(weeksRef.current ? { weeks: weeksRef.current } : {})}
                    onGo={goToPeriod}
                    onClose={() => sheetOpen.setValue(false)}
                  />
                ) : (
                  <AllChartsSheet
                    platform={platform}
                    slug={slug}
                    source={source}
                    onSelect={(nextPlatform, nextSlug) => select(nextPlatform, nextSlug)}
                    onClose={() => sheetOpen.setValue(false)}
                  />
                ),
            }}
            toolbar={
              <Toolbar>
                <ToolbarItem placement="topBarLeading">
                  <CloseButton />
                </ToolbarItem>
                <ToolbarItem placement="topBarTrailing">
                  <Button title="日曆" systemImage="calendar" action={openTimeSheet} />
                </ToolbarItem>
                <ToolbarItem placement="topBarTrailing">
                  <Button
                    title="全部榜單"
                    systemImage="square.grid.2x2"
                    action={() => {
                      sheetKind.setValue("charts")
                      sheetOpen.setValue(true)
                    }}
                  />
                </ToolbarItem>
              </Toolbar>
            }
          >
            {rows}
          </List>
        )
      }}
    </ScrollViewReader>
  )
}

function Row({ children }: { children: any }) {
  return (
    <VStack
      spacing={0}
      listRowInsets={0}
      listRowSeparator="hidden"
      listRowBackground={<Rectangle fill="clear" />}
      frame={{ maxWidth: "infinity" }}
    >
      {children}
    </VStack>
  )
}

function PeriodLine({
  period,
  stale,
  valueLabel,
  history,
  onLatest,
}: {
  period: Period
  stale: boolean
  valueLabel?: string
  /** 歷史期別：時段用 label 色，右邊改成「回到最新」。 */
  history: boolean
  onLatest: () => void
}) {
  return (
    <HStack
      spacing={4}
      frame={{ maxWidth: "infinity", alignment: "leading" }}
      padding={{ horizontal: space.page, bottom: 4 }}
    >
      {stale && !history ? (
        <Image systemName="wifi.slash" font="caption" foregroundStyle="secondaryLabel" />
      ) : null}
      <Text font="footnote" foregroundStyle={history ? "label" : "secondaryLabel"}>
        {timeLabel(period)}
      </Text>
      <Spacer />
      {history ? (
        <Button action={onLatest}>
          <Text
            font="footnote"
            fontWeight="semibold"
            foregroundStyle="label"
            padding={{ horizontal: 12 }}
            frame={{ height: 28 }}
            background="tertiarySystemFill"
            clipShape="capsule"
          >
            回到最新
          </Text>
        </Button>
      ) : valueLabel ? (
        <Text font="footnote" foregroundStyle="tertiaryLabel">
          {valueLabel}
        </Text>
      ) : null}
    </HStack>
  )
}

function PeriodSkeleton() {
  return (
    <HStack
      spacing={0}
      frame={{ maxWidth: "infinity", alignment: "leading" }}
      padding={{ horizontal: space.page, bottom: 4 }}
    >
      <ShimmerText font="footnote">10月31日 00:00</ShimmerText>
    </HStack>
  )
}

function CapsuleStrip({
  charts,
  platform,
  slug,
  onSelect,
}: {
  charts: ChartDef[]
  platform: PlatformId
  slug: string
  onSelect: (next: string) => void
}) {
  const proxyRef = useRef<ScrollViewProxy>()
  const lastPlatform = useRef<PlatformId>(platform)

  useEffect(() => {
    if (lastPlatform.current !== platform) {
      lastPlatform.current = platform
      proxyRef.current?.scrollTo(charts[0]?.slug ?? slug, "leading")
      return
    }
    proxyRef.current?.scrollTo(slug, "center")
  }, [platform, slug])

  return (
    <ScrollViewReader>
      {proxy => {
        proxyRef.current = proxy
        return (
          <ScrollView
            axes="horizontal"
            scrollIndicator="hidden"
            contentMargins={0}
            frame={{ height: 32 }}
            padding={{ bottom: 8 }}
          >
            <HStack spacing={8} padding={{ horizontal: space.page }}>
              {charts.map(item => (
                <Button
                  key={item.slug}
                  action={() => {
                    if (item.slug !== slug) onSelect(item.slug)
                  }}
                >
                  <Text
                    font="subheadline"
                    fontWeight="semibold"
                    foregroundStyle={item.slug === slug ? "systemBackground" : "label"}
                    padding={{ horizontal: 14 }}
                    frame={{ height: 32 }}
                    {...(item.slug === slug
                      ? { background: "label" as const, clipShape: "capsule" as const }
                      : { glassEffect: "capsule" as const })}
                  >
                    {item.name}
                  </Text>
                </Button>
              ))}
            </HStack>
          </ScrollView>
        )
      }}
    </ScrollViewReader>
  )
}

/** 一般榜：每筆一列，只畫前 100 名（資料層保留整份）。 */
function rankingRows(chart: ChartModel, entering: boolean): VirtualNode[] {
  const valued = showsValues(chart)
  const entries = chart.entries.slice(0, BOARD_LIMIT)
  return entries.map((entry, index) =>
    index < 3 ? (
      <Row key={entry.song.fullId}>
        <Rise order={0} active={entering}>
          <Top3Row entry={entry} zoomId={`top3-${entry.song.fullId}`} showValue={valued} />
        </Rise>
      </Row>
    ) : (
      <Row key={entry.song.fullId}>
        <Rise order={1} active={entering && index < ENTER_ROWS}>
          <CompactSongRow
            entry={entry}
            zoomId={`chart-${entry.song.fullId}`}
            showValue={valued}
            showDivider={index < entries.length - 1}
          />
        </Rise>
      </Row>
    )
  )
}

/** graph 榜：走勢卡一列，圖例一列（圖例 32pt 之後）。 */
function graphRows(chart: ChartModel, contentKey: string, entering: boolean): VirtualNode[] {
  return [
    <Row key={`${contentKey}-card`}>
      <VStack
        key={contentKey}
        spacing={0}
        frame={{ maxWidth: "infinity" }}
        transition={Transition.opacity()}
      >
        <Rise order={0} active={entering}>
          <GraphCard chart={chart} />
        </Rise>
      </VStack>
    </Row>,
    <Row key={`${contentKey}-legend`}>
      <VStack
        key={`${contentKey}-legend`}
        spacing={0}
        padding={{ top: space.section }}
        frame={{ maxWidth: "infinity" }}
        transition={Transition.opacity()}
      >
        <Rise order={1} active={entering}>
          {chart.entries.map((entry, index) => {
            const current = entry.series ? latestValue(entry.series) : undefined
            return (
              <CompactSongRow
                key={entry.song.fullId}
                entry={entry}
                zoomId={`graph-${entry.song.fullId}`}
                dotColor={graphColor[index % graphColor.length]}
                showChange={false}
                {...(current != null ? { valueText: percentText(current) } : {})}
                showDivider={index < chart.entries.length - 1}
              />
            )
          })}
        </Rise>
      </VStack>
    </Row>,
  ]
}

/** 累計榜：每筆一列，只畫前 100 名（資料層保留整份）。 */
function cumulativeRows(chart: ChartModel, entering: boolean): VirtualNode[] {
  const entries = chart.entries.slice(0, BOARD_LIMIT)
  return entries.map((entry, index) => (
    <Row key={entry.song.fullId}>
      <Rise order={index < 3 ? 0 : 1} active={entering && index < ENTER_ROWS}>
        <CumulativeRow
          entry={entry}
          zoomId={`cumulative-${entry.song.fullId}`}
          {...(chart.def.valueUnit ? { unit: chart.def.valueUnit } : {})}
          showDivider={index < entries.length - 1}
        />
      </Rise>
    </Row>
  ))
}

/** valued 榜且有數值才有數值欄；整份榜都沒數值時不留欄位、也不顯示意義標籤。 */
function showsValues(chart: ChartModel): boolean {
  return chart.def.kind === "valued" && chart.entries.some(entry => entry.value != null)
}

function valueLabelOf(chart: ChartModel): string | undefined {
  if (chart.def.kind === "valued") return showsValues(chart) ? chart.valueLabel : undefined
  return chart.valueLabel
}

function platformName(id: PlatformId): string {
  return platforms.find(item => item.id === id)?.name ?? id
}

function slugOf(platform: PlatformId, map: Partial<Record<PlatformId, string>>): string {
  const stored = map[platform]
  if (stored && findChart(platform, stored)) return stored
  return defaultChartOf(platform).slug
}

function readSelection(): Selection {
  const stored = Storage.get<Selection>(SELECTION_KEY)
  const platform = platforms.some(item => item.id === stored?.platform)
    ? (stored!.platform as PlatformId)
    : "melon"
  return { platform, slugByPlatform: stored?.slugByPlatform ?? {} }
}

function writeSelection(selection: Selection): void {
  Storage.set(SELECTION_KEY, selection)
}
