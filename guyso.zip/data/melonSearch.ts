// Melon 搜尋建議：JSONP 一次回歌曲、專輯、歌手各 10 筆，沒有分頁。
// 名稱可能帶 HTML entity，要用 SONGNAME／ALBUMNAME 這些原文欄位，不是帶 <b> 的 DP 欄位。

import type { AlbumRef, Artist, SearchSuggestions, Song } from "../model/types"
import { MELON_HOST } from "./http"

const CDN = "https://cdn.guyso.me/image"

export function melonKeywordUrl(query: string): string {
  return `${MELON_HOST}/search/keyword/index.json?jscallback=cb&query=${encodeURIComponent(query)}`
}

export function parseSuggestions(body: string): SearchSuggestions {
  const data = jsonp(body)
  return {
    songs: listOf(data.SONGCONTENTS).map(songOf).filter((song): song is Song => song != null),
    albums: listOf(data.ALBUMCONTENTS).map(albumOf).filter((album): album is AlbumRef => album != null),
    artists: listOf(data.ARTISTCONTENTS)
      .map(artistOf)
      .filter((artist): artist is Artist => artist != null),
  }
}

/** 回應是 `cb({...});`；沒有結果時是 `{"STATUS":"3001","ERROR":"결과없음"}`。 */
function jsonp(body: string): Record<string, any> {
  const open = body.indexOf("(")
  const close = body.lastIndexOf(")")
  if (open < 0 || close <= open) return {}
  try {
    return JSON.parse(body.slice(open + 1, close))
  } catch {
    return {}
  }
}

function listOf(value: unknown): Record<string, any>[] {
  return Array.isArray(value) ? value : []
}

function text(value: unknown): string {
  return typeof value === "string" ? value.trim() : ""
}

function split(value: unknown): string[] {
  return text(value)
    .split(",")
    .map(part => part.trim())
    .filter(part => part.length > 0)
}

export function decodeEntities(value: string): string {
  return value
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCharCode(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_, code: string) => String.fromCharCode(parseInt(code, 16)))
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
}

/** 優先用 Melon 的圖（去掉尾巴的 query 與 resize，尺寸由 coverAt 補）；沒有才用 guyso CDN。 */
function cover(kind: "song" | "album" | "artist", id: string, melonImage?: unknown): string {
  const url = text(melonImage)
  const base = url.match(/^https:\/\/cdnimg\.melon\.co\.kr\/[^?]+?\.(jpg|jpeg|png)/i)?.[0]
  return base ?? `${CDN}/${kind}/melon/${id}.jpg`
}

function name(value: unknown): string {
  return decodeEntities(text(value))
}

function songOf(raw: Record<string, any>): Song | null {
  const id = text(raw.SONGID)
  if (!id) return null

  const names = split(raw.ARTISTNAME)
  const ids = split(raw.ARTISTID)
  const artists: Artist[] = names
    .map((artistName, index) => ({
      platform: "melon" as const,
      id: ids[index] ?? "",
      name: decodeEntities(artistName),
    }))
    .filter(artist => artist.id.length > 0)

  const albumId = text(raw.ALBUMID)
  const album: AlbumRef | undefined = albumId
    ? {
        platform: "melon",
        id: albumId,
        name: name(raw.ALBUMNAME) || name(raw.SONGNAME),
        image: cover("album", albumId, raw.ALBUMIMG),
      }
    : undefined

  return {
    platform: "melon",
    id,
    fullId: `melon_${id}`,
    name: name(raw.SONGNAME),
    artists,
    image: cover("song", id, raw.ALBUMIMG),
    ...(album ? { album } : {}),
  }
}

function albumOf(raw: Record<string, any>): AlbumRef | null {
  const id = text(raw.ALBUMID)
  if (!id) return null
  const issued = text(raw.ISSUEDATE)
  const artist = name(raw.ARTISTNAME)
  // 沒有發行日的專輯會回 00000000，不要當成年份。
  const dated = issued.length === 8 && Number(issued.slice(0, 4)) > 1900

  return {
    platform: "melon",
    id,
    name: name(raw.ALBUMNAME),
    image: cover("album", id, raw.ALBUMIMG),
    ...(dated ? { releasedAt: `${issued.slice(0, 4)}-${issued.slice(4, 6)}-${issued.slice(6, 8)}` } : {}),
    ...(artist ? { artist } : {}),
  }
}

function artistOf(raw: Record<string, any>): Artist | null {
  const id = text(raw.ARTISTID)
  if (!id) return null
  return {
    platform: "melon",
    id,
    name: name(raw.ARTISTNAME),
    // Melon 的欄位拼成 ARITSTIMG。
    image: cover("artist", id, raw.ARITSTIMG ?? raw.ARTISTIMG),
  }
}
