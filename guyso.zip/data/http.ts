// 傳輸：集中 UA、抓 HTML、取出 __NEXT_DATA__。

import { fetch } from "scripting"

export const HOST = "https://xn--o39an51b2re.com"

export const MELON_HOST = "https://www.melon.com"

const USER_AGENT =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1"

/** Melon 的 www 對手機 UA 會 302 到 m.melon.com；它的搜尋建議只認桌面 UA。 */
export const MELON_HEADERS = {
  "User-Agent":
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15",
}

export type TransportResponse = { url: string; status: number; body: string }
export type Transport = (url: string, headers?: Record<string, string>) => Promise<TransportResponse>

/** 回應 4xx／5xx：狀態碼留在錯誤上，資料層才分得出「沒有收錄」。 */
export class HttpError extends Error {
  readonly status: number

  constructor(status: number, url: string) {
    super(`HTTP ${status}: ${url}`)
    this.status = status
  }
}

/** 가이섬 沒有收錄這筆資料（回應 404 或 500）。 */
export class NotIndexedError extends Error {
  /** 子類別的 instanceof 在轉譯後不一定成立，用標記判斷。 */
  readonly notIndexed = true

  constructor(url: string) {
    super(`沒有收錄: ${url}`)
  }
}

export function isNotIndexed(error: unknown): boolean {
  return (error as { notIndexed?: boolean } | null)?.notIndexed === true
}

export function statusOf(error: unknown): number | null {
  const status = (error as { status?: unknown } | null)?.status
  return typeof status === "number" ? status : null
}

export const fetchTransport: Transport = async (url, headers) => {
  const response = await fetch(url, { headers: { "User-Agent": USER_AGENT, ...headers } })
  const body = await response.text()
  if (response.status >= 400) throw new HttpError(response.status, url)
  return { url: response.url || url, status: response.status, body }
}

const MARKER = '<script id="__NEXT_DATA__" type="application/json">'

export function nextData(html: string): any {
  const start = html.indexOf(MARKER)
  if (start < 0) throw new Error("找不到 __NEXT_DATA__")
  const from = start + MARKER.length
  const end = html.indexOf("</script>", from)
  if (end < 0) throw new Error("__NEXT_DATA__ 沒有結尾")
  return JSON.parse(html.slice(from, end))
}

export function pageProps(html: string): any {
  return nextData(html)?.props?.pageProps
}
