// 歌曲頁解析：__NEXT_DATA__ → SongPage；再組成 SongDetail（走勢用 Melon 版本）。
// 網站的頁面是「一個平台一首歌」：records 與 trends 都是這個平台自己的榜單。

import type {
  AlbumRef,
  Artist,
  Credit,
  ListenerProfile,
  Period,
  PlatformId,
  RecordStat,
  Song,
  SongDetail,
} from "../model/types"
import { isPlatformId } from "../model/platforms"
import { decodeSpotifyHex } from "../model/song"
import { chartCodeOf, defaultChartOf } from "./catalog"
import { pageProps } from "./http"

const HOUR_CODE = "MELON_TOP100_CHART"
const DAY_CODE = "MELON_DAILY_CHART"

export type RawPerson = { platform?: string; id: string; name: string; image?: string | null }
export type RawAlbum = {
  platform?: string
  id: string
  name: string
  image?: string | null
  releasedAt?: string | null
  artists?: RawPerson[] | null
}
type RawGroup = { id?: number | null; [key: string]: string | number | null | undefined }
export type RawSong = {
  fullId?: string
  platform?: string
  id: string
  name: string
  image?: string | null
  duration?: number | null
  isTitle?: boolean | null
  trackNo?: number | null
  releasedAt?: string | null
  album?: RawAlbum | null
  artists?: RawPerson[] | null
  lyricists?: RawPerson[] | null
  composers?: RawPerson[] | null
  arrangers?: RawPerson[] | null
  group?: RawGroup | null
  sameSongs?: { platform?: string; id?: string }[] | null
}
type RawRecord = {
  chart: string
  type: string
  score?: number | null
  columnUnit?: Record<string, string> | null
}
type RawPoint = {
  ranking?: number | null
  time?: string
  ratio?: Record<string, number | null> | null
}
type RawTrend = { chart: string; timeUnit?: string; data?: RawPoint[] | null }

/** 一條走勢：名次序列、時間軸標籤，日榜另有聽眾組成。 */
export type TrendSeries = {
  chart: string
  unit: Period["unit"]
  rankings: (number | null)[]
  labels: string[]
  listeners: (ListenerProfile | null)[]
}

export type SongPage = {
  song: Song
  records: RecordStat[]
  credits: Credit[]
  trends: TrendSeries[]
  group?: Partial<Record<PlatformId, string>>
  sameSongs: { platform: PlatformId; id: string }[]
}

export function parseSongPage(html: string): SongPage {
  const props = pageProps(html)
  const raw = props?.song as RawSong | undefined
  if (!raw || !raw.id) throw new Error("歌曲回應格式不符")
  const platform = isPlatformId(raw.platform) ? raw.platform : "melon"
  const trends = ((props?.trends ?? []) as RawTrend[])
    .map(trendOf)
    .filter((item): item is TrendSeries => item != null)

  return {
    song: songFromRaw(raw, platform),
    records: recordsOf((props?.records ?? []) as RawRecord[], platform),
    credits: creditsOf(raw, platform),
    trends,
    ...(groupOf(raw.group) ? { group: groupOf(raw.group) } : {}),
    sameSongs: sameSongsOf(raw.sameSongs),
  }
}

/**
 * 走勢一律用 Melon 版本：24 小時看 TOP100、30 天看日榜。
 * 不是 Melon 的歌才退回自己平台的 HOURS／DAYS（欄位對得上就照用，週榜不畫）。
 */
export function assembleDetail(page: SongPage, melonPage: SongPage | null): SongDetail {
  const melon = page.song.platform === "melon" ? page : melonPage
  const hourly = usable(byCode(melon?.trends, HOUR_CODE)) ?? ownTrend(page, "hour")
  const dailySource = byCode(melon?.trends, DAY_CODE)
  const daily = usable(dailySource) ?? ownTrend(page, "day")
  // 聽眾看的是日榜的 ratio，就算點數太少畫不成線，最新一筆還是真的。
  const listeners = latestListeners(dailySource) ?? latestListeners(daily)

  return {
    song: page.song,
    records: page.records,
    hourly: hourly?.rankings ?? [],
    hourlyLabels: hourly?.labels ?? [],
    daily: daily?.rankings ?? [],
    dailyLabels: daily?.labels ?? [],
    ...(listeners ? { listeners } : {}),
    credits: page.credits,
    ...(page.group ? { group: page.group } : {}),
    sameSongs: page.sameSongs,
  }
}

function byCode(trends: TrendSeries[] | undefined, code: string): TrendSeries | null {
  return trends?.find(trend => trend.chart === code) ?? null
}

/** 不到兩個點就畫不成線，當作這個時間範圍沒有資料。 */
function usable(trend: TrendSeries | null): TrendSeries | null {
  return trend && countOf(trend.rankings) >= 2 ? trend : null
}

/** Melon 版本沒有這個時間範圍時，才用歌曲自己平台的序列。 */
function ownTrend(page: SongPage, unit: "hour" | "day"): TrendSeries | null {
  if (page.song.platform === "melon") return null
  return page.trends.find(trend => trend.unit === unit && countOf(trend.rankings) >= 2) ?? null
}

function latestListeners(daily: TrendSeries | null): ListenerProfile | undefined {
  if (!daily) return undefined
  for (let index = daily.listeners.length - 1; index >= 0; index--) {
    const profile = daily.listeners[index]
    if (profile) return profile
  }
  return undefined
}

function countOf(rankings: (number | null)[]): number {
  return rankings.filter(rank => rank != null).length
}

export function songFromRaw(raw: RawSong, platform: PlatformId): Song {
  const spotifyTrackId = decodeSpotifyHex(
    typeof raw.group?.spotify === "string" ? raw.group.spotify : undefined
  )
  return {
    platform,
    id: raw.id,
    fullId: raw.fullId ?? `${platform}_${raw.id}`,
    name: raw.name,
    image: raw.image ?? "",
    artists: artistsFromRaw(raw.artists, platform),
    ...(raw.album ? { album: albumFromRaw(raw.album, platform) } : {}),
    ...(raw.duration != null ? { durationSec: raw.duration } : {}),
    ...(raw.isTitle != null ? { isTitle: raw.isTitle } : {}),
    ...(raw.trackNo != null ? { trackNo: raw.trackNo } : {}),
    ...(typeof raw.group?.id === "number" ? { groupId: raw.group.id } : {}),
    ...(spotifyTrackId ? { spotifyTrackId } : {}),
  }
}

export function albumFromRaw(raw: RawAlbum, platform: PlatformId): AlbumRef {
  const artist = raw.artists?.find(person => person?.name)?.name
  return {
    platform: isPlatformId(raw.platform) ? raw.platform : platform,
    id: raw.id,
    name: raw.name,
    image: raw.image ?? "",
    ...(raw.releasedAt ? { releasedAt: raw.releasedAt } : {}),
    ...(artist ? { artist } : {}),
  }
}

export function artistsFromRaw(
  list: RawPerson[] | null | undefined,
  platform: PlatformId
): Artist[] {
  if (!Array.isArray(list)) return []
  return list
    .filter(person => person?.id && person?.name)
    .map(person => ({
      platform: isPlatformId(person.platform) ? person.platform : platform,
      id: person.id,
      name: person.name,
      ...(person.image ? { image: person.image } : {}),
    }))
}

function creditsOf(raw: RawSong, platform: PlatformId): Credit[] {
  const roles: { role: Credit["role"]; list: RawPerson[] | null | undefined }[] = [
    { role: "作詞", list: raw.lyricists },
    { role: "作曲", list: raw.composers },
    { role: "編曲", list: raw.arrangers },
  ]
  return roles
    .map(item => ({ role: item.role, people: artistsFromRaw(item.list, platform) }))
    .filter(item => item.people.length > 0)
}

function groupOf(raw: RawGroup | null | undefined): Partial<Record<PlatformId, string>> | undefined {
  if (!raw) return undefined
  const group: Partial<Record<PlatformId, string>> = {}
  for (const [key, value] of Object.entries(raw)) {
    if (key === "id" || key === "spotify") continue
    if (isPlatformId(key) && typeof value === "string") group[key] = value
  }
  return Object.keys(group).length > 0 ? group : undefined
}

function sameSongsOf(
  raw: { platform?: string; id?: string }[] | null | undefined
): { platform: PlatformId; id: string }[] {
  if (!Array.isArray(raw)) return []
  return raw
    .filter(item => isPlatformId(item?.platform) && typeof item?.id === "string")
    .map(item => ({ platform: item.platform as PlatformId, id: item.id as string }))
}

/** 三張卡：最高名次、冠軍次數、最高聽眾。score 為 0 一律當作沒有。 */
function recordsOf(raw: RawRecord[], platform: PlatformId): RecordStat[] {
  const defaultCode = chartCodeOf(platform, defaultChartOf(platform).slug)
  const stats: RecordStat[] = []

  const peak = scoreOf(raw, defaultCode, "PEAK_RANKING") ?? minScoreOf(raw, "PEAK_RANKING")
  if (peak != null) stats.push({ label: "最高名次", value: peak, prefix: "#" })

  const wins = scoreOf(raw, defaultCode, "TOP1")
  if (wins != null) stats.push({ label: "冠軍次數", value: wins })

  const listeners = listenersOf(raw, platform)
  if (listeners != null) stats.push({ label: "最高聽眾", value: listeners })

  return stats
}

function scoreOf(raw: RawRecord[], chart: string | undefined, type: string): number | null {
  if (!chart) return null
  const hit = raw.find(item => item.chart === chart && item.type === type)
  return hit && typeof hit.score === "number" && hit.score > 0 ? hit.score : null
}

function minScoreOf(raw: RawRecord[], type: string): number | null {
  let min: number | null = null
  for (const item of raw) {
    if (item.type !== type) continue
    if (typeof item.score !== "number" || item.score <= 0) continue
    if (min == null || item.score < min) min = item.score
  }
  return min
}

/** 最高聽眾：PEAK_COUNT 且單位是「명」，優先同平台日榜。 */
function listenersOf(raw: RawRecord[], platform: PlatformId): number | null {
  const dailyCode = chartCodeOf(platform, "daily")
  const eligible = raw.filter(
    item =>
      item.type === "PEAK_COUNT" &&
      typeof item.score === "number" &&
      item.score > 0 &&
      hasPeopleUnit(item.columnUnit)
  )
  const hit = eligible.find(item => item.chart === dailyCode) ?? eligible[0]
  return hit ? (hit.score as number) : null
}

function hasPeopleUnit(unit: Record<string, string> | null | undefined): boolean {
  return unit != null && Object.values(unit).some(value => value === "명")
}

function trendOf(raw: RawTrend): TrendSeries | null {
  const points = raw?.data
  if (!raw?.chart || !Array.isArray(points) || points.length === 0) return null
  const unit = unitOf(raw.timeUnit)
  if (!unit) return null
  return {
    chart: raw.chart,
    unit,
    rankings: points.map(point =>
      typeof point.ranking === "number" && point.ranking > 0 ? point.ranking : null
    ),
    labels: points.map(point => labelOf(unit, point.time)),
    listeners: points.map(point => listenersOfPoint(point.ratio)),
  }
}

function unitOf(timeUnit: string | undefined): Period["unit"] | null {
  switch (timeUnit) {
    case "HOURS":
      return "hour"
    case "DAYS":
    case "NONE":
      return "day"
    case "WEEKS":
      return "week"
    case "MONTHS":
      return "month"
    case "YEARS":
      return "year"
    default:
      return null
  }
}

const AGE_LABELS: { key: string; label: string }[] = [
  { key: "age10", label: "10–19" },
  { key: "age20", label: "20–29" },
  { key: "age30", label: "30–39" },
  { key: "age40", label: "40–49" },
  { key: "age50", label: "50–59" },
  { key: "age60", label: "60+" },
]

function listenersOfPoint(raw: Record<string, number | null> | null | undefined): ListenerProfile | null {
  if (!raw || typeof raw.male !== "number" || typeof raw.female !== "number") return null
  const ages = AGE_LABELS.map(age => ({ label: age.label, ratio: raw[age.key] }))
    .filter(age => typeof age.ratio === "number")
    .map(age => ({ label: age.label, ratio: round1(age.ratio as number) }))
  return { male: round1(raw.male), female: round1(raw.female), ages }
}

function round1(value: number): number {
  return Math.round(value * 10) / 10
}

/** 時間軸標籤照網站的時間字串：小時「15時」、日期「10/29」。 */
function labelOf(unit: Period["unit"], time: string | undefined): string {
  if (!time) return ""
  if (unit === "hour") return `${Number(time.slice(11, 13))}時`
  if (unit === "day") return `${Number(time.slice(5, 7))}/${Number(time.slice(8, 10))}`
  return time.slice(0, 10)
}
