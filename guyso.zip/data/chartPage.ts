// 榜單頁解析：__NEXT_DATA__ → Chart。欄位依 columnType 取主數值。

import type { Chart, ChartDef, ChartEntry, ChartWeek, Period, Song } from "../model/types"
import { changeOf, decodeSpotifyHex } from "../model/song"
import { pageProps } from "./http"

type RawArtist = { id: string; name: string; image?: string | null }
type RawSong = {
  fullId: string
  platform: string
  id: string
  name: string
  image: string
  duration?: number
  isTitle?: boolean
  album?: { id: string; name: string; image: string }
  artists?: RawArtist[]
  group?: { id?: number; spotify?: string }
}
type RawRow = {
  ranking: number
  previous: number | null
  song: RawSong
  values?: (number | null)[] | null
  count?: number | null
  countDiff?: number | null
  count1?: number | null
  count2?: number | null
  count1Diff?: number | null
  count2Diff?: number | null
  like?: number | null
}
type RawPage = {
  date?: number
  hour?: number
  minute?: number
  year?: number
  month?: number
  week?: number
  timeUnit?: string
  columnType?: string
  data?: RawRow[]
}
type RawWeek = { year?: number; week?: number; time?: string }

/** 網站這一期還沒有資料（最新一期常見：網址已轉到下一期、資料還沒更新）。 */
export class EmptyChartError extends Error {
  constructor() {
    super("榜單沒有資料")
    this.name = "EmptyChartError"
  }
}

export function parseChart(html: string, def: ChartDef): Chart {
  const props = pageProps(html)
  return parseChartPage(props?.data as RawPage | undefined, def, props?.weeks as RawWeek[] | undefined)
}

/** 空陣列是「網站這段時間沒有資料」，不是可用的榜單，所以直接丟錯、不進快取。 */
export function parseChartPage(raw: RawPage | undefined, def: ChartDef, weeks?: RawWeek[]): Chart {
  if (!raw || !Array.isArray(raw.data)) throw new Error("榜單回應格式不符")
  if (raw.data.length === 0) throw new EmptyChartError()
  const availableWeeks = weeksOf(weeks)
  return {
    def,
    period: periodOf(raw),
    entries: raw.data.map(row => entryOf(row, def.platform, raw.columnType ?? "")),
    ...(def.valueLabel ? { valueLabel: def.valueLabel } : {}),
    ...(availableWeeks ? { availableWeeks } : {}),
  }
}

/** 週榜的 pageProps.weeks；其他 unit 是 null。 */
function weeksOf(raw: RawWeek[] | null | undefined): ChartWeek[] | undefined {
  if (!Array.isArray(raw)) return undefined
  const list = raw
    .filter(item => typeof item?.year === "number" && typeof item?.week === "number")
    .map(item => ({
      year: item.year as number,
      week: item.week as number,
      ...(item.time ? { time: item.time } : {}),
    }))
  return list.length > 0 ? list : undefined
}

function periodOf(raw: RawPage): Period {
  const date = `${raw.date ?? 0}`
  switch (raw.timeUnit) {
    case "HOURS":
      return { unit: "hour", date, hour: raw.hour ?? 0 }
    case "MINUTES":
      return { unit: "hour", date, hour: raw.hour ?? 0, ...(raw.minute != null ? { minute: raw.minute } : {}) }
    case "DAYS":
    case "NONE":
      return { unit: "day", date }
    case "WEEKS":
      return { unit: "week", year: raw.year ?? 0, week: raw.week ?? 0 }
    case "MONTHS":
      return { unit: "month", year: raw.year ?? 0, month: raw.month ?? 0 }
    case "YEARS":
      return { unit: "year", year: raw.year ?? 0 }
    default:
      throw new Error(`未支援的 timeUnit: ${raw.timeUnit}`)
  }
}

/** 主數值依 columnType 取：雙欄榜取 count1、單欄榜取 count；讚數是歌曲累計值，不當成榜單數值。 */
function entryOf(row: RawRow, platform: ChartDef["platform"], columnType: string): ChartEntry {
  // 網站用 0 表示上一期不在榜上（countDiff 也是 null），和 null 同樣是新進榜。
  const previous = row.previous != null && row.previous > 0 ? row.previous : null
  const { value, valueDiff } = valueOf(row, columnType)
  const series = seriesOf(row, columnType)
  return {
    rank: row.ranking,
    previous,
    change: changeOf(previous, row.ranking),
    song: songOf(row.song, platform),
    ...(value != null ? { value } : {}),
    ...(valueDiff != null ? { valueDiff } : {}),
    ...(series ? { series } : {}),
  }
}

/** graph 榜的走勢：原樣保留 null，畫線時靠它斷點。 */
function seriesOf(row: RawRow, columnType: string): (number | null)[] | undefined {
  if (!columnType.includes("VALUES") || !Array.isArray(row.values)) return undefined
  return row.values.map(value => (typeof value === "number" ? value : null))
}

function valueOf(row: RawRow, columnType: string): { value?: number; valueDiff?: number } {
  if (columnType.includes("COUNT1")) {
    return {
      ...(row.count1 != null ? { value: row.count1 } : {}),
      ...(row.count1Diff != null ? { valueDiff: row.count1Diff } : {}),
    }
  }
  if (columnType.includes("COUNT")) {
    return {
      ...(row.count != null ? { value: row.count } : {}),
      ...(row.countDiff != null ? { valueDiff: row.countDiff } : {}),
    }
  }
  return {}
}

function songOf(raw: RawSong, platform: ChartDef["platform"]): Song {
  const song: Song = {
    platform,
    id: raw.id,
    fullId: raw.fullId,
    name: raw.name,
    image: raw.image ?? "",
    artists: (raw.artists ?? []).map(artist => ({
      platform,
      id: artist.id,
      name: artist.name,
      ...(artist.image ? { image: artist.image } : {}),
    })),
    ...(raw.album
      ? { album: { platform, id: raw.album.id, name: raw.album.name, image: raw.album.image } }
      : {}),
    ...(raw.duration != null ? { durationSec: raw.duration } : {}),
    ...(raw.isTitle != null ? { isTitle: raw.isTitle } : {}),
    ...(raw.group?.id != null ? { groupId: raw.group.id } : {}),
  }
  const spotifyTrackId = decodeSpotifyHex(raw.group?.spotify)
  return spotifyTrackId ? { ...song, spotifyTrackId } : song
}
