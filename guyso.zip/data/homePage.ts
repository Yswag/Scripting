// 首頁：熱門搜尋榜（songSearchChart）與最新加入的歌曲、專輯、歌手。

import type { AlbumRef, Artist, Home, Song } from "../model/types"
import { pageProps } from "./http"
import { albumFromRaw, artistsFromRaw, songFromRaw } from "./songPage"
import type { RawAlbum, RawPerson, RawSong } from "./songPage"

export function parseHome(html: string): Home {
  const props = pageProps(html)
  const chart = props?.songSearchChart
  const rows: { song?: RawSong }[] = Array.isArray(chart?.data) ? chart.data : []

  return {
    hotSearches: rows
      .map(row => row?.song)
      .filter((song): song is RawSong => song?.id != null)
      .map(song => songFromRaw(song, "melon")),
    hotSearchDate: dateOf(chart?.date ?? chart?.time),
    newSongs: listOf<RawSong>(props?.newSongs).map(song => songFromRaw(song, "melon")),
    newAlbums: listOf<RawAlbum>(props?.newAlbums).map(album => albumFromRaw(album, "melon")),
    newArtists: listOf<RawPerson>(props?.newArtists).flatMap(person => artistsFromRaw([person], "melon")),
  }
}

/** 榜單日期是數字 20261018，也可能是 2026-10-18T00:00:00。 */
function dateOf(value: unknown): string {
  if (typeof value === "number") return `${value}`.slice(0, 8)
  if (typeof value !== "string" || value.length === 0) return ""
  return value.slice(0, 10).replace(/-/g, "")
}

function listOf<T>(value: unknown): T[] {
  return Array.isArray(value) ? (value as T[]) : []
}
