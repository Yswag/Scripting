// 榜單目錄：slug 與側欄順序取自網站，unit / kind / valueLabel 依各頁的
// timeUnit 與 columnType 判定。陣列順序即膠囊列的順序（同 group 內）。

import type { ChartDef, PlatformId } from "../model/types"

const def = (
  platform: PlatformId,
  slug: string,
  name: string,
  unit: ChartDef["unit"],
  kind: ChartDef["kind"],
  group: ChartDef["group"],
  valueLabel?: string,
  valueUnit?: string
): ChartDef => ({
  platform,
  slug,
  name,
  unit,
  kind,
  group,
  isDefault: false,
  ...(valueLabel ? { valueLabel } : {}),
  ...(valueUnit ? { valueUnit } : {}),
})

export const chartCatalog: ChartDef[] = [
  def("melon", "top100", "TOP100", "hour", "valued", "realtime", "聽眾"),
  def("melon", "hot100-five", "HOT100 5 分鐘", "hour", "graph", "realtime", "使用比例"),
  def("melon", "hot100-graph", "HOT100 走勢", "hour", "graph", "realtime", "使用比例"),
  def("melon", "hot100-d100", "HOT100 100 天", "hour", "ranking", "realtime"),
  def("melon", "hot100-d30", "HOT100 30 天", "hour", "ranking", "realtime"),
  def("melon", "newest-w1", "新歌 1 週", "hour", "ranking", "realtime"),
  def("melon", "newest-w4", "新歌 4 週", "hour", "ranking", "realtime"),
  def("melon", "realtime-five", "5 分鐘", "hour", "graph", "realtime", "使用比例"),
  def("melon", "realtime-graph", "即時走勢", "hour", "graph", "realtime", "使用比例"),
  def("melon", "realtime", "即時", "hour", "ranking", "realtime"),
  def("melon", "24hour-count", "24 小時聽眾", "hour", "valued", "realtime", "聽眾"),
  def("melon", "24hits", "24Hits", "hour", "ranking", "realtime"),
  def("melon", "24hits-newest-w1", "新歌 24Hits 1 週", "hour", "ranking", "realtime"),
  def("melon", "24hits-newest-w4", "新歌 24Hits 4 週", "hour", "ranking", "realtime"),
  def("melon", "daily", "日榜", "day", "valued", "daily", "聽眾"),
  def("melon", "weekly", "週榜", "week", "ranking", "weekly"),
  def("melon", "monthly", "月榜", "month", "ranking", "monthly"),
  def("melon", "yearly", "年榜", "year", "ranking", "yearly"),
  def("melon", "daily-long-run", "日榜連續在榜", "day", "cumulative", "cumulative", "連續在榜", "天"),
  def("melon", "weekly-count", "聽眾累計 週", "week", "cumulative", "cumulative", "累計聽眾"),
  def("melon", "monthly-count", "聽眾累計 月", "month", "cumulative", "cumulative", "累計聽眾"),
  def("melon", "yearly-count", "聽眾累計 年", "year", "cumulative", "cumulative", "累計聽眾"),
  def("melon", "365days-count", "聽眾累計 365 天", "year", "cumulative", "cumulative", "累計聽眾"),

  def("genie", "realtime", "即時", "hour", "valued", "realtime", "聽眾"),
  def("genie", "realtime-graph", "即時走勢", "hour", "graph", "realtime", "使用比例"),
  def("genie", "daily", "日榜", "day", "ranking", "daily"),

  def("flo", "24hour", "24 小時", "hour", "ranking", "realtime"),

  def("bugs", "realtime", "即時", "hour", "ranking", "realtime"),
  def("bugs", "daily", "日榜", "day", "ranking", "daily"),

  def("vibe", "daily", "日榜", "day", "ranking", "daily"),

  def("circle", "digital-weekly", "數位週榜", "week", "valued", "weekly", "分數"),

  def("youtube", "track-weekly", "週人氣歌曲", "week", "valued", "weekly", "觀看"),
  def("youtube", "video-weekly", "週人氣 MV", "week", "valued", "weekly", "觀看"),
].map(item => ({
  ...item,
  isDefault:
    (item.platform === "melon" && item.slug === "top100") ||
    (item.platform === "genie" && item.slug === "realtime") ||
    (item.platform === "flo" && item.slug === "24hour") ||
    (item.platform === "bugs" && item.slug === "realtime") ||
    (item.platform === "vibe" && item.slug === "daily") ||
    (item.platform === "circle" && item.slug === "digital-weekly") ||
    (item.platform === "youtube" && item.slug === "track-weekly"),
}))

/** 這個平台的全部榜單，照 group 的順序（同 group 維持目錄順序）。 */
export function chartsOf(platform: PlatformId): ChartDef[] {
  return chartCatalog.filter(item => item.platform === platform)
}

export function findChart(platform: PlatformId, slug: string): ChartDef | undefined {
  return chartCatalog.find(item => item.platform === platform && item.slug === slug)
}

/**
 * 歌曲頁的 records／trends 用網站自己的榜單代碼，這裡對回目錄。
 * 只列歌曲頁真的會出現的代碼；MELON_STREAMING_CARD 之類沒有對應榜單的略過。
 */
const chartCodeMap: Record<string, { platform: PlatformId; slug: string }> = {
  MELON_TOP100_CHART: { platform: "melon", slug: "top100" },
  MELON_HOT100_D100_CHART: { platform: "melon", slug: "hot100-d100" },
  MELON_HOT100_D30_CHART: { platform: "melon", slug: "hot100-d30" },
  MELON_NEWEST_W1_CHART: { platform: "melon", slug: "newest-w1" },
  MELON_NEWEST_W4_CHART: { platform: "melon", slug: "newest-w4" },
  MELON_REALTIME_CHART: { platform: "melon", slug: "realtime" },
  MELON_DAILY_CHART: { platform: "melon", slug: "daily" },
  MELON_WEEKLY_CHART: { platform: "melon", slug: "weekly" },
  MELON_MONTHLY_CHART: { platform: "melon", slug: "monthly" },
  MELON_YEARLY_CHART: { platform: "melon", slug: "yearly" },
  MELON_24HOUR_COUNT: { platform: "melon", slug: "24hour-count" },
  MELON_WEEKLY_COUNT: { platform: "melon", slug: "weekly-count" },
  MELON_MONTHLY_COUNT: { platform: "melon", slug: "monthly-count" },
  MELON_YEARLY_COUNT: { platform: "melon", slug: "yearly-count" },
  GENIE_REALTIME_CHART: { platform: "genie", slug: "realtime" },
  GENIE_DAILY_CHART: { platform: "genie", slug: "daily" },
  FLO_24HOUR_CHART: { platform: "flo", slug: "24hour" },
  BUGS_REALTIME_CHART: { platform: "bugs", slug: "realtime" },
  BUGS_DAILY_CHART: { platform: "bugs", slug: "daily" },
  VIBE_DAILY_CHART: { platform: "vibe", slug: "daily" },
  CIRCLE_DIGITAL_WEEKLY_CHART: { platform: "circle", slug: "digital-weekly" },
  YOUTUBE_TRACK_WEEKLY_CHART: { platform: "youtube", slug: "track-weekly" },
  YOUTUBE_VIDEO_WEEKLY_CHART: { platform: "youtube", slug: "video-weekly" },
}

/** 目錄榜單對應的網站代碼；沒有對應就 undefined。 */
export function chartCodeOf(platform: PlatformId, slug: string): string | undefined {
  return Object.keys(chartCodeMap).find(
    code => chartCodeMap[code].platform === platform && chartCodeMap[code].slug === slug
  )
}

/** 網站代碼對應的目錄榜單。 */
export function findChartByCode(code: string): ChartDef | undefined {
  const hit = chartCodeMap[code]
  return hit ? findChart(hit.platform, hit.slug) : undefined
}

export function defaultChartOf(platform: PlatformId): ChartDef {
  const list = chartsOf(platform)
  return list.find(item => item.isDefault) ?? list[0]
}
