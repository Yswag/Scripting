// 檔案快取：一個 URL 一個 JSON 檔，寫入先暫存再改名。

export type CacheEntry<T> = { url: string; fetchedAt: number; value: T }

/** 圖片快取（guyso-cache/images）由 UI 的圖片層寫入，清除與計量一起處理。 */
const IMAGES_DIR = "images"

function folderSize(path: string): number {
  if (!FileManager.existsSync(path)) return 0
  let total = 0
  for (const item of FileManager.readDirectorySync(path)) {
    const child = `${path}/${item}`
    try {
      total += FileManager.statSync(child).size
    } catch {}
  }
  return total
}

export type FileCache = {
  read<T>(url: string): CacheEntry<T> | null
  write<T>(url: string, entry: CacheEntry<T>): void
  clear(): Promise<void>
  size(): Promise<number>
}

export function createFileCache(dir: string): FileCache {
  function ensureDir(): void {
    if (!FileManager.existsSync(dir)) FileManager.createDirectorySync(dir, true)
  }

  function pathOf(url: string): string {
    return `${dir}/${fnv1a(url)}.json`
  }

  return {
    read<T>(url: string): CacheEntry<T> | null {
      const path = pathOf(url)
      if (!FileManager.existsSync(path)) return null
      try {
        const entry = JSON.parse(FileManager.readAsStringSync(path)) as CacheEntry<T>
        return entry && typeof entry.fetchedAt === "number" ? entry : null
      } catch {
        return null
      }
    },

    write<T>(url: string, entry: CacheEntry<T>): void {
      ensureDir()
      const path = pathOf(url)
      const temp = `${path}.${Math.floor(Math.random() * 1e9)}.tmp`
      FileManager.writeAsStringSync(temp, JSON.stringify(entry))
      if (FileManager.existsSync(path)) FileManager.removeSync(path)
      FileManager.renameSync(temp, path)
    },

    async clear(): Promise<void> {
      if (!FileManager.existsSync(dir)) return
      for (const item of FileManager.readDirectorySync(dir)) {
        if (item === IMAGES_DIR) {
          if (FileManager.existsSync(`${dir}/${item}`)) FileManager.removeSync(`${dir}/${item}`)
          continue
        }
        if (!item.endsWith(".json") && !item.endsWith(".tmp")) continue
        try {
          FileManager.removeSync(`${dir}/${item}`)
        } catch {}
      }
    },

    async size(): Promise<number> {
      if (!FileManager.existsSync(dir)) return 0
      let total = 0
      for (const item of FileManager.readDirectorySync(dir)) {
        if (item === IMAGES_DIR) {
          total += folderSize(`${dir}/${item}`)
          continue
        }
        if (!item.endsWith(".json")) continue
        try {
          total += FileManager.statSync(`${dir}/${item}`).size
        } catch {}
      }
      return total
    },
  }
}

function fnv1a(text: string): string {
  let hash = 0x811c9dc5
  for (let i = 0; i < text.length; i++) {
    hash ^= text.charCodeAt(i)
    hash = Math.imul(hash, 0x01000193) >>> 0
  }
  return hash.toString(16).padStart(8, "0")
}
