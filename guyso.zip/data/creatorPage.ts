// 創作者頁解析：三種角色共用同一個 artist 物件，只有對應的那份歌曲清單有值。

import type { CreatorDetail, CreatorRole } from "../model/types"
import { isPlatformId } from "../model/platforms"
import { pageProps } from "./http"
import { songFromRaw } from "./songPage"
import type { RawPerson, RawSong } from "./songPage"

type RawCreator = RawPerson & {
  songsByLyricist?: RawSong[] | null
  songsByComposer?: RawSong[] | null
  songsByArranger?: RawSong[] | null
}

const KEY: Record<CreatorRole, "songsByLyricist" | "songsByComposer" | "songsByArranger"> = {
  lyricist: "songsByLyricist",
  composer: "songsByComposer",
  arranger: "songsByArranger",
}

export function parseCreatorPage(html: string, role: CreatorRole): CreatorDetail {
  const raw = pageProps(html)?.artist as RawCreator | undefined
  if (!raw?.id || !raw.name) throw new Error("創作者回應格式不符")
  const platform = isPlatformId(raw.platform) ? raw.platform : "melon"

  return {
    artist: {
      platform,
      id: raw.id,
      name: raw.name,
      ...(raw.image ? { image: raw.image } : {}),
    },
    role,
    // 網站給舊到新，改成和歌手頁一樣新到舊。
    songs: [...(raw[KEY[role]] ?? [])]
      .sort((a, b) => (b.releasedAt ?? "").localeCompare(a.releasedAt ?? ""))
      .map(song => songFromRaw(song, platform)),
  }
}
