// 資料層 facade：UI 只透過這裡取資料。

import type {
  AlbumDetail,
  AlbumRef,
  Artist,
  ArtistDetail,
  Chart,
  ChartDef,
  CreatorDetail,
  CreatorRole,
  Home,
  Loaded,
  Period,
  PlatformId,
  SearchSuggestions,
  Song,
  SongDetail,
  Today,
} from "../model/types"
import { platformIds } from "../model/platforms"
import { aggregateToday, hasCharts } from "../model/today"
import { createFileCache } from "./cache"
import { chartCatalog, defaultChartOf, findChart } from "./catalog"
import { EmptyChartError, parseChart } from "./chartPage"
import { fetchTransport, HOST, MELON_HEADERS, NotIndexedError, statusOf } from "./http"
import type { Transport, TransportResponse } from "./http"
import { dayExpiry, expiresAt, hourExpiry } from "./kst"
import { assembleDetail, parseSongPage } from "./songPage"
import type { SongPage } from "./songPage"
import { parseAlbumPage } from "./albumPage"
import { parseArtistPage } from "./artistPage"
import { parseCreatorPage } from "./creatorPage"
import { melonKeywordUrl, parseSuggestions } from "./melonSearch"
import { parseHome } from "./homePage"
import { parseSearchAlbums, parseSearchArtists, parseSearchSongs } from "./searchPage"

export type GuysoDeps = {
  transport?: Transport
  now?: () => number
  cacheDir?: string
}

export type FetchOptions = { force?: boolean }

export type PlatformRanks = Record<PlatformId, number | null>

export type Guyso = {
  catalog(): ChartDef[]
  getChart(platform: PlatformId, slug: string, period?: Period, opts?: FetchOptions): Promise<Loaded<Chart>>
  peekChart(platform: PlatformId, slug: string, period?: Period): Loaded<Chart> | null
  getSong(platform: PlatformId, id: string, opts?: FetchOptions): Promise<Loaded<SongDetail>>
  peekSong(platform: PlatformId, id: string): Loaded<SongDetail> | null
  getAlbum(platform: PlatformId, id: string, opts?: FetchOptions): Promise<Loaded<AlbumDetail>>
  peekAlbum(platform: PlatformId, id: string): Loaded<AlbumDetail> | null
  getArtist(platform: PlatformId, id: string, opts?: FetchOptions): Promise<Loaded<ArtistDetail>>
  peekArtist(platform: PlatformId, id: string): Loaded<ArtistDetail> | null
  getCreator(
    role: CreatorRole,
    platform: PlatformId,
    id: string,
    opts?: FetchOptions
  ): Promise<Loaded<CreatorDetail>>
  peekCreator(role: CreatorRole, platform: PlatformId, id: string): Loaded<CreatorDetail> | null
  /** Melon 搜尋建議：一次拿三種、沒有分頁、不快取。 */
  searchSuggestions(query: string): Promise<SearchSuggestions>
  /** 가이섬 搜尋後備：只有 Melon 在該分段回 0 筆時才用，每頁 20 筆。 */
  searchSongs(query: string, page: number): Promise<Song[]>
  searchAlbums(query: string, page: number): Promise<AlbumRef[]>
  searchArtists(query: string, page: number): Promise<Artist[]>
  getHome(opts?: FetchOptions): Promise<Loaded<Home>>
  peekHome(): Loaded<Home> | null
  /** 今日：7 個預設榜單與首頁全部 settle 後才聚合一次。 */
  getToday(opts?: FetchOptions): Promise<Today>
  /** 快取同步聚合，畫面第一幀直接畫；完全沒有快取時回 null。 */
  peekToday(): Today | null
  crossPlatformRanks(detail: SongDetail): Promise<PlatformRanks>
  peekRanks(detail: SongDetail): PlatformRanks | null
  clearCache(): Promise<void>
  cacheSize(): Promise<number>
}

export function createGuyso(deps: GuysoDeps = {}): Guyso {
  const transport = deps.transport ?? fetchTransport
  const now = deps.now ?? (() => Date.now())
  const cache = createFileCache(deps.cacheDir ?? `${FileManager.appGroupDocumentsDirectory}/guyso-cache`)
  const inflight = new Map<string, Promise<TransportResponse>>()

  function request(url: string, headers?: Record<string, string>): Promise<TransportResponse> {
    const pending = inflight.get(url)
    if (pending) return pending
    const task = transport(url, headers).then(
      response => {
        inflight.delete(url)
        return response
      },
      error => {
        inflight.delete(url)
        throw error
      }
    )
    inflight.set(url, task)
    return task
  }

  function getChart(
    platform: PlatformId,
    slug: string,
    period?: Period,
    opts: FetchOptions = {}
  ): Promise<Loaded<Chart>> {
    const def = chartCatalog.find(item => item.platform === platform && item.slug === slug)
    if (!def) return Promise.reject(new Error(`未知榜單: ${platform}/${slug}`))

    const url = chartUrl(platform, slug, period)
    const cached = cache.read<Chart>(url)
    // 指定歷史 period 的榜單永久有效，force 也不重抓（下拉重新整理直接結束）。
    const fresh = cached != null && (period != null || (!opts.force && now() < expiresAt(cached.value.period, false)))
    if (cached && fresh) {
      return Promise.resolve({ value: withDef(cached.value, def), fetchedAt: cached.fetchedAt, stale: false })
    }

    return request(url)
      .then(response => parseChart(response.body, def))
      .then(
        value => {
          const fetchedAt = now()
          cache.write(url, { url, fetchedAt, value })
          return { value, fetchedAt, stale: false }
        },
        error => {
          if (!cached) throw error
          // 最新一期還沒更新：快取就是目前最新的資料，不算過期。
          const stale = !(error instanceof EmptyChartError && period == null)
          return { value: withDef(cached.value, def), fetchedAt: cached.fetchedAt, stale }
        }
      )
  }

  function peekChart(platform: PlatformId, slug: string, period?: Period): Loaded<Chart> | null {
    const cached = cache.read<Chart>(chartUrl(platform, slug, period))
    if (!cached) return null
    const def = findChart(platform, slug)
    return { value: def ? withDef(cached.value, def) : cached.value, fetchedAt: cached.fetchedAt, stale: false }
  }

  /** 歌曲頁的快取跟時榜一起換：到下一個 KST 整點再 10 分鐘。 */
  function peekSong(platform: PlatformId, id: string): Loaded<SongDetail> | null {
    const cached = cache.read<SongDetail>(songUrl(platform, id))
    if (!cached || now() >= hourExpiry(cached.fetchedAt)) return null
    return { value: cached.value, fetchedAt: cached.fetchedAt, stale: false }
  }

  function fetchPage(platform: PlatformId, id: string): Promise<SongPage> {
    return request(songUrl(platform, id)).then(response => parseSongPage(response.body))
  }

  /** Melon 版本的歌曲頁；非 Melon 的歌用它取走勢與聽眾。 */
  function melonTwin(page: SongPage): Promise<SongPage | null> {
    if (page.song.platform === "melon") return Promise.resolve(null)
    const melonId = page.group?.melon ?? page.sameSongs.find(item => item.platform === "melon")?.id
    if (!melonId) return Promise.resolve(null)
    return fetchPage("melon", melonId).catch(() => null)
  }

  function getSong(platform: PlatformId, id: string, opts: FetchOptions = {}): Promise<Loaded<SongDetail>> {
    const url = songUrl(platform, id)
    const cached = cache.read<SongDetail>(url)
    const fresh = cached != null && !opts.force && now() < hourExpiry(cached.fetchedAt)
    if (cached && fresh) {
      return Promise.resolve({ value: cached.value, fetchedAt: cached.fetchedAt, stale: false })
    }

    return fetchPage(platform, id).then(
      async page => {
        const melon = await melonTwin(page)
        const value = assembleDetail(page, melon)
        const fetchedAt = now()
        cache.write(url, { url, fetchedAt, value })
        return { value, fetchedAt, stale: false }
      },
      error => {
        if (cached) return { value: cached.value, fetchedAt: cached.fetchedAt, stale: true }
        rethrow(error, url)
      }
    )
  }

  /** 專輯、歌手、創作者頁共用：一天一次，失敗有舊快取就回 stale。 */
  function loadPage<T>(url: string, parse: (html: string) => T, opts: FetchOptions): Promise<Loaded<T>> {
    const cached = cache.read<T>(url)
    const fresh = cached != null && !opts.force && now() < dayExpiry(cached.fetchedAt)
    if (cached && fresh) {
      return Promise.resolve({ value: cached.value, fetchedAt: cached.fetchedAt, stale: false })
    }

    return request(url).then(
      response => {
        const value = parse(response.body)
        const fetchedAt = now()
        cache.write(url, { url, fetchedAt, value })
        return { value, fetchedAt, stale: false }
      },
      error => {
        if (cached) return { value: cached.value, fetchedAt: cached.fetchedAt, stale: true }
        rethrow(error, url)
      }
    )
  }

  function peekPage<T>(url: string): Loaded<T> | null {
    const cached = cache.read<T>(url)
    if (!cached || now() >= dayExpiry(cached.fetchedAt)) return null
    return { value: cached.value, fetchedAt: cached.fetchedAt, stale: false }
  }

  function getAlbum(
    platform: PlatformId,
    id: string,
    opts: FetchOptions = {}
  ): Promise<Loaded<AlbumDetail>> {
    return loadPage(albumUrl(platform, id), parseAlbumPage, opts)
  }

  function peekAlbum(platform: PlatformId, id: string): Loaded<AlbumDetail> | null {
    return peekPage<AlbumDetail>(albumUrl(platform, id))
  }

  function getArtist(
    platform: PlatformId,
    id: string,
    opts: FetchOptions = {}
  ): Promise<Loaded<ArtistDetail>> {
    return loadPage(artistUrl(platform, id), parseArtistPage, opts)
  }

  function peekArtist(platform: PlatformId, id: string): Loaded<ArtistDetail> | null {
    return peekPage<ArtistDetail>(artistUrl(platform, id))
  }

  function getCreator(
    role: CreatorRole,
    platform: PlatformId,
    id: string,
    opts: FetchOptions = {}
  ): Promise<Loaded<CreatorDetail>> {
    return loadPage(creatorUrl(role, platform, id), html => parseCreatorPage(html, role), opts)
  }

  function peekCreator(
    role: CreatorRole,
    platform: PlatformId,
    id: string
  ): Loaded<CreatorDetail> | null {
    return peekPage<CreatorDetail>(creatorUrl(role, platform, id))
  }

  /** 가이섬 回 404／500 就是沒有收錄這筆資料，和網路失敗分開。 */
  function rethrow(error: unknown, url: string): never {
    const status = statusOf(error)
    if (status === 404 || status === 500) throw new NotIndexedError(url)
    throw error
  }

  function searchSuggestions(query: string): Promise<SearchSuggestions> {
    return request(melonKeywordUrl(query), MELON_HEADERS).then(response => parseSuggestions(response.body))
  }

  function searchSongs(query: string, page: number): Promise<Song[]> {
    return request(searchUrl("song", query, page)).then(response =>
      parseSearchSongs(response.body, "melon")
    )
  }

  function searchAlbums(query: string, page: number): Promise<AlbumRef[]> {
    return request(searchUrl("album", query, page)).then(response =>
      parseSearchAlbums(response.body, "melon")
    )
  }

  function searchArtists(query: string, page: number): Promise<Artist[]> {
    return request(searchUrl("artist", query, page)).then(response =>
      parseSearchArtists(response.body, "melon")
    )
  }

  /** 首頁快取 1 小時；熱門搜尋榜本身是日榜，但頁面資料會跟著新加入更新。 */
  function getHome(opts: FetchOptions = {}): Promise<Loaded<Home>> {
    const url = homeUrl()
    const cached = cache.read<Home>(url)
    const fresh = cached != null && !opts.force && now() - cached.fetchedAt < HOME_TTL
    if (cached && fresh) {
      return Promise.resolve({ value: cached.value, fetchedAt: cached.fetchedAt, stale: false })
    }

    return request(url).then(
      response => {
        const value = parseHome(response.body)
        const fetchedAt = now()
        cache.write(url, { url, fetchedAt, value })
        return { value, fetchedAt, stale: false }
      },
      error => {
        if (cached) return { value: cached.value, fetchedAt: cached.fetchedAt, stale: true }
        throw error
      }
    )
  }

  function peekHome(): Loaded<Home> | null {
    const cached = cache.read<Home>(homeUrl())
    if (!cached || now() - cached.fetchedAt >= HOME_TTL) return null
    return { value: cached.value, fetchedAt: cached.fetchedAt, stale: false }
  }

  function peekToday(): Today | null {
    const charts: Partial<Record<PlatformId, Loaded<Chart> | null>> = {}
    for (const platform of platformIds) {
      charts[platform] = peekChart(platform, defaultChartOf(platform).slug)
    }
    if (!hasCharts(charts)) return null
    return aggregateToday({ charts, home: peekHome(), at: now() })
  }

  /** 7 個榜與首頁一起抓；全部有結果才聚合，中途不更新畫面。 */
  async function getToday(opts: FetchOptions = {}): Promise<Today> {
    const tasks: Promise<Loaded<Chart> | Loaded<Home>>[] = platformIds.map(platform =>
      getChart(platform, defaultChartOf(platform).slug, undefined, opts)
    )
    tasks.push(getHome(opts))
    const settled = await Promise.allSettled(tasks)

    const charts: Partial<Record<PlatformId, Loaded<Chart> | null>> = {}
    let failed = false
    platformIds.forEach((platform, index) => {
      const result = settled[index] as PromiseSettledResult<Loaded<Chart>>
      charts[platform] = result.status === "fulfilled" ? result.value : null
      if (result.status !== "fulfilled") failed = true
    })

    const homeResult = settled[settled.length - 1] as PromiseSettledResult<Loaded<Home>>
    if (homeResult.status !== "fulfilled") failed = true
    if (!hasCharts(charts)) throw new Error("榜單全部抓取失敗")

    return aggregateToday({
      charts,
      home: homeResult.status === "fulfilled" ? homeResult.value : null,
      stale: failed,
      at: now(),
    })
  }

  /** 各平台的歌曲 id：歌曲頁的 group 為主，缺的平台用 sameSongs 補。 */
  function idsOf(detail: SongDetail): Partial<Record<PlatformId, string>> {
    const ids: Partial<Record<PlatformId, string>> = { ...(detail.group ?? {}) }
    for (const same of detail.sameSongs ?? []) {
      if (!ids[same.platform]) ids[same.platform] = same.id
    }
    return ids
  }

  /** 榜單 entry 沒有 group，所以用歌曲頁的 id 反查各平台預設榜單的名次。 */
  async function crossPlatformRanks(detail: SongDetail): Promise<PlatformRanks> {
    const ids = idsOf(detail)
    const ranks = emptyRanks()
    await Promise.all(
      platformIds.map(async platform => {
        const id = ids[platform]
        if (!id) return
        try {
          const chart = await getChart(platform, defaultChartOf(platform).slug)
          const hit = chart.value.entries.find(entry => entry.song.id === id)
          ranks[platform] = hit ? hit.rank : null
        } catch {
          ranks[platform] = null
        }
      })
    )
    return ranks
  }

  /** 7 個預設榜單都在快取裡才回傳，否則讓 UI 先畫骨架。 */
  function peekRanks(detail: SongDetail): PlatformRanks | null {
    const ids = idsOf(detail)
    const ranks = emptyRanks()
    for (const platform of platformIds) {
      const def = defaultChartOf(platform)
      const cached = cache.read<Chart>(chartUrl(platform, def.slug))
      // 週月年榜的 period 會落後現在；日榜也可能午前就抓到新版，兩種鮮度取其一。
      if (!cached) return null
      const fresh = now() < expiresAt(cached.value.period, false) || now() < hourExpiry(cached.fetchedAt)
      if (!fresh) return null
      const id = ids[platform]
      const hit = id ? cached.value.entries.find(entry => entry.song.id === id) : undefined
      ranks[platform] = hit ? hit.rank : null
    }
    return ranks
  }

  return {
    catalog: () => chartCatalog.slice(),
    getChart,
    peekChart,
    getSong,
    peekSong,
    getAlbum,
    peekAlbum,
    getArtist,
    peekArtist,
    getCreator,
    peekCreator,
    searchSuggestions,
    searchSongs,
    searchAlbums,
    searchArtists,
    getHome,
    peekHome,
    getToday,
    peekToday,
    crossPlatformRanks,
    peekRanks,
    clearCache: () => cache.clear(),
    cacheSize: () => cache.size(),
  }
}

export function emptyRanks(): PlatformRanks {
  const ranks = {} as PlatformRanks
  for (const platform of platformIds) ranks[platform] = null
  return ranks
}

export function chartUrl(platform: PlatformId, slug: string, period?: Period): string {
  const base = `${HOST}/chart/${platform}/${slug}`
  if (!period) return base
  if (period.unit === "hour") return `${base}/${period.date}/${period.hour}`
  if (period.unit === "day") return `${base}/${period.date}`
  if (period.unit === "week") return `${base}/${period.year}/${period.week}`
  if (period.unit === "month") return `${base}/${period.year}/${period.month}`
  return `${base}/${period.year}`
}

export function songUrl(platform: PlatformId, id: string): string {
  return `${HOST}/song/${platform}/${id}`
}

export function albumUrl(platform: PlatformId, id: string): string {
  return `${HOST}/album/${platform}/${id}`
}

export function artistUrl(platform: PlatformId, id: string): string {
  return `${HOST}/artist/${platform}/${id}`
}

export function homeUrl(): string {
  return `${HOST}/`
}

/** 搜尋後備：platform 不能留空，留空會 504。 */
export function searchUrl(kind: "song" | "album" | "artist", query: string, page: number): string {
  return `${HOST}/api/v3/${kind}/search?platform=melon&query=${encodeURIComponent(query)}&page=${page}`
}

/** 創作者頁的路徑分段就是角色本身。 */
export function creatorUrl(role: CreatorRole, platform: PlatformId, id: string): string {
  return `${HOST}/${role}/${platform}/${id}/songs`
}

export const guyso = createGuyso()

/** 首頁的快取時間。 */
const HOME_TTL = 60 * 60 * 1000

/** 快取裡存的是當時的目錄，回傳前換成現在這一版。 */
function withDef(chart: Chart, def: ChartDef): Chart {
  return {
    ...chart,
    def,
    ...(def.valueLabel ? { valueLabel: def.valueLabel } : { valueLabel: undefined }),
  }
}
