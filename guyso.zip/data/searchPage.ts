// 가이섬 搜尋後備：純陣列、每頁 20 筆，platform 不能留空（會 504）。

import type { AlbumRef, Artist, PlatformId, Song } from "../model/types"
import { albumFromRaw, artistsFromRaw, songFromRaw } from "./songPage"
import type { RawAlbum, RawSong } from "./songPage"

export function parseSearchSongs(body: string, platform: PlatformId): Song[] {
  return rowsOf<RawSong>(body)
    .filter(raw => raw?.id && raw?.name)
    .map(raw => songFromRaw(raw, platform))
}

export function parseSearchAlbums(body: string, platform: PlatformId): AlbumRef[] {
  return rowsOf<RawAlbum>(body)
    .filter(raw => raw?.id && raw?.name)
    .map(raw => albumFromRaw(raw, platform))
}

export function parseSearchArtists(body: string, platform: PlatformId): Artist[] {
  return rowsOf<Artist & { fullId?: string }>(body)
    .map(raw => artistsFromRaw([raw], platform)[0])
    .filter((artist): artist is Artist => artist != null)
}

function rowsOf<T>(body: string): T[] {
  try {
    const value = JSON.parse(body)
    return Array.isArray(value) ? value : []
  } catch {
    return []
  }
}
