// 歌手頁解析：songs 與 albums 都由網站排好（發行日新到舊），一次全給。

import type { ArtistDetail } from "../model/types"
import { isPlatformId } from "../model/platforms"
import { pageProps } from "./http"
import { albumFromRaw, songFromRaw } from "./songPage"
import type { RawAlbum, RawPerson, RawSong } from "./songPage"

type RawArtist = RawPerson & {
  songs?: RawSong[] | null
  albums?: RawAlbum[] | null
}

export function parseArtistPage(html: string): ArtistDetail {
  const raw = pageProps(html)?.artist as RawArtist | undefined
  if (!raw?.id || !raw.name) throw new Error("歌手回應格式不符")
  const platform = isPlatformId(raw.platform) ? raw.platform : "melon"

  return {
    artist: {
      platform,
      id: raw.id,
      name: raw.name,
      ...(raw.image ? { image: raw.image } : {}),
    },
    songs: (raw.songs ?? []).map(song => songFromRaw(song, platform)),
    albums: (raw.albums ?? []).map(album => {
      const ref = albumFromRaw(album, platform)
      const artists = (album.artists ?? []).map(person => person.name).filter(Boolean)
      return artists.length > 0 ? { ...ref, artist: artists.join(", ") } : ref
    }),
  }
}
