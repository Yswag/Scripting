// 專輯頁解析：__NEXT_DATA__ → AlbumDetail。網站一次給整張專輯，沒有分頁。

import type { AlbumDetail } from "../model/types"
import { isPlatformId } from "../model/platforms"
import { pageProps } from "./http"
import { artistsFromRaw, songFromRaw } from "./songPage"
import type { RawAlbum, RawSong } from "./songPage"

type RawAlbumPage = RawAlbum & {
  releasedAt?: string | null
  songs?: RawSong[] | null
}

export function parseAlbumPage(html: string): AlbumDetail {
  const raw = pageProps(html)?.album as RawAlbumPage | undefined
  if (!raw?.id || !raw.name) throw new Error("專輯回應格式不符")
  const platform = isPlatformId(raw.platform) ? raw.platform : "melon"

  return {
    platform,
    id: raw.id,
    name: raw.name,
    image: raw.image ?? "",
    ...(typeof raw.releasedAt === "string" ? { releasedAt: raw.releasedAt } : {}),
    artists: artistsFromRaw(raw.artists, platform),
    songs: (raw.songs ?? []).map(song => songFromRaw(song, platform)),
  }
}
