// KST 時間計算與快取 TTL。

import type { Period } from "../model/types"

const MINUTE = 60_000
const HOUR = 60 * MINUTE
const DAY = 24 * HOUR
const KST_OFFSET = 9 * HOUR

/** 把 KST 的牆上時間換成 epoch 毫秒。 */
export function kstMs(year: number, month: number, day: number, hour = 0, minute = 0): number {
  return Date.UTC(year, month - 1, day, hour, minute) - KST_OFFSET
}

/** 指定 period 的起點。 */
export function periodStart(period: Period): number {
  if (period.unit === "hour") {
    return kstMs(
      Number(period.date.slice(0, 4)),
      Number(period.date.slice(4, 6)),
      Number(period.date.slice(6, 8)),
      period.hour
    )
  }
  if (period.unit === "day") {
    return kstMs(
      Number(period.date.slice(0, 4)),
      Number(period.date.slice(4, 6)),
      Number(period.date.slice(6, 8))
    )
  }
  if (period.unit === "week") return weekStart(period.year, period.week)
  if (period.unit === "month") return kstMs(period.year, period.month, 1)
  return kstMs(period.year, 1, 1)
}

/** ISO 週的第一天（週一）。 */
function weekStart(year: number, week: number): number {
  const jan4 = kstMs(year, 1, 4)
  const weekday = new Date(jan4 + KST_OFFSET).getUTCDay()
  const mondayOffset = (weekday + 6) % 7
  return jan4 - mondayOffset * DAY + (week - 1) * 7 * DAY
}

/** 下一期的起點。 */
function nextStart(period: Period): number {
  if (period.unit === "hour") return periodStart(period) + HOUR
  if (period.unit === "day") return periodStart(period) + DAY
  if (period.unit === "week") return periodStart(period) + 7 * DAY
  if (period.unit === "month") {
    const year = period.month === 12 ? period.year + 1 : period.year
    const month = period.month === 12 ? 1 : period.month + 1
    return kstMs(year, month, 1)
  }
  return kstMs(period.year + 1, 1, 1)
}

/**
 * 快取到期時間。小時榜到下一個整點後 10 分鐘、日榜到隔天 00:10，
 * 週月年榜到下一期；指定歷史 period 的榜單永久有效。
 */
/** 歌曲頁這類跟時榜一起換的資料：到寫入後的下一個 KST 整點再 10 分鐘。 */
export function hourExpiry(at: number): number {
  return Math.floor((at + KST_OFFSET) / HOUR) * HOUR + HOUR - KST_OFFSET + 10 * MINUTE
}

/** 專輯、歌手、創作者頁：到下一個 KST 00:00 為止。 */
export function dayExpiry(at: number): number {
  return Math.floor((at + KST_OFFSET) / DAY) * DAY + DAY - KST_OFFSET
}

export function expiresAt(period: Period, explicit: boolean): number {
  if (explicit) return Infinity
  if (period.unit === "hour" || period.unit === "day") {
    return nextStart(period) + 10 * MINUTE
  }
  return nextStart(period)
}
