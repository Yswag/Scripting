// App 入口：三個 Tab，各自一個 NavigationStack。

import {
  Navigation,
  Script,
  Tab,
  TabView,
  useObservable,
} from "scripting"
import { RouterStack } from "./ui/router"
import { ZoomNamespace } from "./ui/zoom"
import { TodayScreen } from "./screens/TodayScreen"
import { ChartScreen } from "./screens/ChartScreen"
import { SearchScreen } from "./screens/SearchScreen"

function Root() {
  const selection = useObservable<number>(0)

  return (
    <ZoomNamespace>
      <TabView selection={selection} scrollEdgeEffectStyle="soft">
        <Tab title="今日" systemImage="sparkles" value={0}>
          <ZoomNamespace>
            <RouterStack>
              <TodayScreen />
            </RouterStack>
          </ZoomNamespace>
        </Tab>

        <Tab title="排行" systemImage="list.number" value={1}>
          <ZoomNamespace>
            <RouterStack>
              <ChartScreen />
            </RouterStack>
          </ZoomNamespace>
        </Tab>

        <Tab title="搜尋" systemImage="magnifyingglass" value={2}>
          <ZoomNamespace>
            <RouterStack>
              <SearchScreen />
            </RouterStack>
          </ZoomNamespace>
        </Tab>
      </TabView>
    </ZoomNamespace>
  )
}

async function run() {
  await Navigation.present({
    element: <Root />,
    modalPresentationStyle: "overFullScreen",
    swipeBackBehavior: "minimize",
  })
  Script.exit()
}

run()
