// 創作者角色：歌曲頁的製作名單與網站的 Creator 路由互相對應。

import type { CreatorRole, Credit } from "./types"

const ROUTE: Record<Credit["role"], CreatorRole> = {
  作詞: "lyricist",
  作曲: "composer",
  編曲: "arranger",
}

const LABEL: Record<CreatorRole, string> = {
  lyricist: "作詞",
  composer: "作曲",
  arranger: "編曲",
}

export function creatorRoleOf(role: Credit["role"]): CreatorRole {
  return ROUTE[role]
}

export function creatorRoleLabel(role: CreatorRole): string {
  return LABEL[role]
}
