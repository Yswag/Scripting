// 領域模型的型別形狀：資料層與 UI 共用的契約。

export type PlatformId = "melon" | "genie" | "flo" | "bugs" | "vibe" | "circle" | "youtube"

export type Period =
  /** minute 只有 5 分鐘榜有：該小時最後一筆樣本的分鐘。 */
  | { unit: "hour"; date: string /* YYYYMMDD */; hour: number; minute?: number }
  | { unit: "day"; date: string }
  | { unit: "week"; year: number; week: number }
  | { unit: "month"; year: number; month: number }
  | { unit: "year"; year: number }

export type ChartKind = "ranking" | "valued" | "graph" | "cumulative"

export type ChartDef = {
  platform: PlatformId
  slug: string
  name: string
  unit: Period["unit"]
  kind: ChartKind
  group: "realtime" | "daily" | "weekly" | "monthly" | "yearly" | "cumulative"
  isDefault: boolean
  /** 數值欄的意義，例如「聽眾」「分數」「累計聽眾」「使用比例」。 */
  valueLabel?: string
  /** 數值單位，數字另加千分位顯示，例如連續在榜的「天」。 */
  valueUnit?: string
}

export type Artist = {
  platform: PlatformId
  id: string
  name: string
  image?: string
}

export type AlbumRef = {
  platform: PlatformId
  id: string
  name: string
  image?: string
  /** 卡片副標用的歌手名，原網站專輯物件另帶 artists。 */
  artist?: string
  /** 發行日，UI 只取年份。 */
  releasedAt?: string
}

export type Song = {
  platform: PlatformId
  id: string
  fullId: string
  name: string
  artists: Artist[]
  album?: AlbumRef
  image: string
  durationSec?: number
  isTitle?: boolean
  trackNo?: number
  groupId?: number
  spotifyTrackId?: string
}

export type RankChange =
  | { type: "up"; by: number }
  | { type: "down"; by: number }
  | { type: "new" }
  | { type: "same" }

export type ChartEntry = {
  rank: number
  previous: number | null
  change: RankChange
  song: Song
  value?: number
  valueDiff?: number
  /** graph 榜的走勢：每點一個使用量占比（%）。null 是該時刻沒有樣本，畫線時要斷開。 */
  series?: (number | null)[]
}

/** 週榜回傳的週清單：只列網站真的有資料的週。 */
export type ChartWeek = {
  year: number
  week: number
  time?: string
}

export type Chart = {
  def: ChartDef
  period: Period
  entries: ChartEntry[]
  valueLabel?: string
  /** 週榜才有：時間選擇器的年與週選項。 */
  availableWeeks?: ChartWeek[]
}

export type Loaded<T> = {
  value: T
  fetchedAt: number
  stale: boolean
}

export type SearchKind = "song" | "album" | "artist"

/** Melon 搜尋建議：一次回三種、各最多 10 筆、沒有分頁。 */
export type SearchSuggestions = {
  songs: Song[]
  albums: AlbumRef[]
  artists: Artist[]
}

/** 首頁：熱門搜尋榜與最新加入。 */
export type Home = {
  /** 熱門搜尋榜，順序就是名次。 */
  hotSearches: Song[]
  /** 熱門搜尋榜的日期 YYYYMMDD，畫面直接顯示這天。 */
  hotSearchDate: string
  newSongs: Song[]
  newAlbums: AlbumRef[]
  newArtists: Artist[]
}

export type RecordStat = {
  label: string
  value: number
  /** 數字前的符號，例如最高名次的「#」。 */
  prefix?: string
}

export type ListenerProfile = {
  male: number
  female: number
  ages: { label: string; ratio: number }[]
}

export type Credit = {
  role: "作詞" | "作曲" | "編曲"
  people: Artist[]
}

export type AlbumDetail = AlbumRef & {
  releasedAt?: string
  artists: Artist[]
  songs: Song[]
}

export type ArtistDetail = {
  artist: Artist
  /** 網站一次給全部，發行日新到舊。 */
  songs: Song[]
  albums: AlbumRef[]
}

export type CreatorRole = "lyricist" | "composer" | "arranger"

export type CreatorDetail = {
  artist: Artist
  role: CreatorRole
  songs: Song[]
}

export type SongDetail = {
  song: Song
  /** 跨平台名次：歌曲頁本身沒有，由 facade 的 crossPlatformRanks 補上。 */
  ranks?: Record<PlatformId, number | null>
  records: RecordStat[]
  /** 名次序列，null 是那個時間點不在榜上，畫線要斷開。 */
  hourly: (number | null)[]
  hourlyLabels?: string[]
  daily: (number | null)[]
  dailyLabels: string[]
  listeners?: ListenerProfile
  credits: Credit[]
  /** 各平台的歌曲 id；youtube 是 hex 編碼的影片 id。 */
  group?: Partial<Record<PlatformId, string>>
  sameSongs?: { platform: PlatformId; id: string }[]
}

export type TodayHero = {
  entry: ChartEntry
  /** 這首歌有進榜的平台名次；沒進榜的平台不出現。 */
  ranks: Partial<Record<PlatformId, number | null>>
  /** 拿第 1 名的平台，照 platformIds 的順序。 */
  platforms: PlatformId[]
}

/** 今日頁的跨平台條目：entry 的名次是該平台的名次。 */
export type TodayEntry = {
  entry: ChartEntry
  platform: PlatformId
}

export type Today = {
  hero: TodayHero | null
  /** 急升：幅度是各平台裡最大的一個，platform 就是那個平台。 */
  rising: TodayEntry[]
  /** 新進榜：跨平台去重，entry.rank 是各平台裡最好的名次。 */
  newcomers: TodayEntry[]
  latest: { songs: Song[]; albums: AlbumRef[]; artists: Artist[] }
  /** 有榜單抓不到（含快取過期）。 */
  stale: boolean
  /** 時間標籤，例如「14:00」；沒有任何榜單時是 null。 */
  time: string | null
  at: number
}
