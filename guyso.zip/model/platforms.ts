// 平台順序：各平台名次、今日聚合都照這個順序。

import type { PlatformId, SearchKind } from "./types"

export const platformIds: PlatformId[] = ["melon", "genie", "flo", "bugs", "vibe", "circle", "youtube"]

export function isPlatformId(value: unknown): value is PlatformId {
  return typeof value === "string" && (platformIds as string[]).includes(value)
}

/** Melon 的詳細頁；가이섬 沒收錄時從這裡開。 */
export function melonUrl(kind: SearchKind, id: string): string {
  const path = kind === "song" ? "song" : kind === "album" ? "album" : "artist"
  const param = kind === "song" ? "songId" : kind === "album" ? "albumId" : "artistId"
  return `https://www.melon.com/${path}/detail.htm?${param}=${id}`
}
