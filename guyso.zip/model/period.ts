// 期別的純函式：識別與顯示。

import type { Period } from "./types"

/** 期別的識別字串，用來比對「是不是同一期」；null 代表最新一期。 */
export function periodKey(period: Period | null | undefined): string {
  if (!period) return "latest"
  if (period.unit === "hour") return `h:${period.date}:${period.hour}`
  if (period.unit === "day") return `d:${period.date}`
  if (period.unit === "week") return `w:${period.year}:${period.week}`
  if (period.unit === "month") return `m:${period.year}:${period.month}`
  return `y:${period.year}`
}

export function timeLabel(period: Period): string {
  if (period.unit === "hour") {
    const month = Number(period.date.slice(4, 6))
    const day = Number(period.date.slice(6, 8))
    const total = period.hour * 60 + (period.minute ?? 0)
    return `${month}月${day}日 ${pad(Math.floor(total / 60) % 24)}:${pad(total % 60)}`
  }
  if (period.unit === "day") {
    const month = Number(period.date.slice(4, 6))
    const day = Number(period.date.slice(6, 8))
    return `${month}月${day}日`
  }
  if (period.unit === "week") return `${period.year}年 第${period.week}週`
  if (period.unit === "month") return `${period.year}年 ${period.month}月`
  return `${period.year}年`
}

function pad(value: number): string {
  return `${value}`.padStart(2, "0")
}
