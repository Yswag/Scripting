// 今日聚合：7 個預設榜單跨平台對歌，算出 Hero、急升、新進榜，接上首頁的最新加入。

import type {
  Chart,
  ChartEntry,
  Home,
  Loaded,
  PlatformId,
  Song,
  Today,
  TodayEntry,
  TodayHero,
} from "./types"
import { platformIds } from "./platforms"
import { timeLabel } from "./period"

type Charts = Partial<Record<PlatformId, Loaded<Chart> | null>>

const RISING_LIMIT = 10
const NEWCOMER_LIMIT = 10
const NOT_RANKED = Number.POSITIVE_INFINITY
const WEEKLY = new Set<PlatformId>(["circle", "youtube"])

/** 榜單 entry 沒有跨平台 id，只能用歌名＋歌手對歌。 */
type Cluster = {
  /** 最先看到的那一筆，平台順序在前面的優先，所以是 Melon 的版本。 */
  song: Song
  entries: Partial<Record<PlatformId, ChartEntry>>
}

export function aggregateToday(input: {
  charts: Charts
  home: Loaded<Home> | null
  /** 這次載入有沒有請求失敗；快取本身過期也算。 */
  stale?: boolean
  at: number
}): Today {
  const clusters = clusterSongs(input.charts)
  const loaded = platformIds.map(platform => input.charts[platform] ?? null)
  return {
    hero: pickHero(clusters),
    rising: pickRising(clusters),
    newcomers: pickNewcomers(clusters),
    latest: {
      songs: input.home?.value.newSongs ?? [],
      albums: input.home?.value.newAlbums ?? [],
      artists: input.home?.value.newArtists ?? [],
    },
    stale: input.stale === true || loaded.some(chart => chart?.stale === true) || input.home?.stale === true,
    time: timeOf(input.charts),
    at: input.at,
  }
}

/** 這個榜單在這個平台上算不算有資料（全部失敗時 UI 要顯示重試）。 */
export function hasCharts(charts: Charts): boolean {
  return platformIds.some(platform => (charts[platform]?.value.entries.length ?? 0) > 0)
}

/** 歌名正規化：NFKC、小寫、去掉括號段，只留字母數字。 */
export function songNameKey(name: string): string {
  const text = stripBrackets(name.normalize("NFKC").toLowerCase())
  let key = ""
  for (const char of text) {
    if (/[\p{L}\p{N}]/u.test(char)) key += char
  }
  return key
}

/** 歌手名正規化：只留字母數字，YouTube 的「A2O 및 A2O MAY」靠比對時的包含關係對上。 */
export function artistKey(name: string): string {
  const text = stripBrackets(name.normalize("NFKC").toLowerCase())
  let key = ""
  for (const char of text) {
    if (/[\p{L}\p{N}]/u.test(char)) key += char
  }
  return key
}

/** 同名又同歌手才算同一首歌；歌手字串一個包含另一個（YouTube 會串多組）放寬。 */
export function sameSong(a: Song, b: Song): boolean {
  if (songNameKey(a.name) !== songNameKey(b.name)) return false
  const left = a.artists.map(artist => artistKey(artist.name)).filter(key => key.length > 0)
  const right = b.artists.map(artist => artistKey(artist.name)).filter(key => key.length > 0)
  if (left.length === 0 || right.length === 0) return left.length === right.length
  return left.some(one => right.some(other => one.includes(other) || other.includes(one)))
}

/** 括號段的內容通常是韓文別名或多版本說明，去掉才對得上。 */
function stripBrackets(text: string): string {
  let out = ""
  let depth = 0
  for (const char of text) {
    if (char === "(" || char === "[" || char === "{") depth++
    else if (char === ")" || char === "]" || char === "}") {
      if (depth > 0) depth--
    } else if (depth === 0) out += char
  }
  return out
}

function clusterSongs(charts: Charts): Cluster[] {
  const clusters: Cluster[] = []
  for (const platform of platformIds) {
    const entries = charts[platform]?.value.entries
    if (!entries) continue
    for (const entry of entries) {
      const hit = clusters.find(cluster => sameSong(cluster.song, entry.song))
      if (hit) hit.entries[platform] = entry
      else clusters.push({ song: entry.song, entries: { [platform]: entry } })
    }
  }
  return clusters
}

/** 拿第 1 名平台數最多 → 名次總和最小 → Melon 名次最小；後兩者只在有榜的平台之間比。 */
function pickHero(clusters: Cluster[]): TodayHero | null {
  let best: { hero: TodayHero; wins: number; total: number; melon: number } | null = null

  for (const cluster of clusters) {
    const platforms = platformIds.filter(platform => cluster.entries[platform]?.rank === 1)
    if (platforms.length === 0) continue

    const ranked = platformIds.filter(platform => cluster.entries[platform] != null)
    const total = ranked.reduce((sum, platform) => sum + (cluster.entries[platform]?.rank ?? 0), 0)
    const melon = cluster.entries.melon?.rank ?? NOT_RANKED
    const first = platforms[0]
    const hero: TodayHero = {
      entry: cluster.entries[first] as ChartEntry,
      ranks: ranksOf(cluster),
      platforms,
    }

    if (
      best == null ||
      platforms.length > best.wins ||
      (platforms.length === best.wins && total < best.total) ||
      (platforms.length === best.wins && total === best.total && melon < best.melon)
    ) {
      best = { hero, wins: platforms.length, total, melon }
    }
  }

  return best?.hero ?? null
}

function ranksOf(cluster: Cluster): Partial<Record<PlatformId, number | null>> {
  const ranks: Partial<Record<PlatformId, number | null>> = {}
  for (const platform of platformIds) {
    const entry = cluster.entries[platform]
    if (entry) ranks[platform] = entry.rank
  }
  return ranks
}

/** 每首歌取各平台最大的上升幅度，幅度一樣時名次前面、平台順序前面的優先。 */
function pickRising(clusters: Cluster[]): TodayEntry[] {
  const picked: { item: TodayEntry; by: number }[] = []

  for (const cluster of clusters) {
    let best: { item: TodayEntry; by: number } | null = null
    for (const platform of platformIds) {
      const entry = cluster.entries[platform]
      if (!entry || entry.previous == null) continue
      const by = entry.previous - entry.rank
      if (by <= 0) continue
      if (best == null || by > best.by) best = { item: { entry, platform }, by }
    }
    if (best) picked.push(best)
  }

  return picked
    .sort(
      (a, b) =>
        b.by - a.by ||
        a.item.entry.rank - b.item.entry.rank ||
        platformIds.indexOf(a.item.platform) - platformIds.indexOf(b.item.platform)
    )
    .slice(0, RISING_LIMIT)
    .map(item => item.item)
}

/**
 * 任一平台是 NEW、且沒有任何平台有上期名次才算（週榜的 NEW 常是別的榜早就在榜上的歌）；
 * 只出現在週榜的不算（YouTube 歌名是影片標題、Circle 常缺封面與歌手）。最佳名次取所有平台裡最小的。
 */
function pickNewcomers(clusters: Cluster[]): TodayEntry[] {
  const picked: { item: TodayEntry; best: number }[] = []

  for (const cluster of clusters) {
    const ranked = platformIds
      .map(platform => ({ platform, entry: cluster.entries[platform] }))
      .filter((row): row is { platform: PlatformId; entry: ChartEntry } => row.entry != null)
    if (!ranked.some(row => row.entry.change.type === "new")) continue
    if (ranked.some(row => row.entry.previous != null)) continue
    if (ranked.every(row => WEEKLY.has(row.platform))) continue

    const best = Math.min(...ranked.map(row => row.entry.rank))
    const lead = ranked.find(row => row.entry.rank === best) as { platform: PlatformId; entry: ChartEntry }
    // 徽章一律是 NEW：這首歌在某個平台是新進榜的。
    picked.push({ item: { entry: { ...lead.entry, change: { type: "new" } }, platform: lead.platform }, best })
  }

  return picked
    .sort((a, b) => a.best - b.best || platformIds.indexOf(a.item.platform) - platformIds.indexOf(b.item.platform))
    .slice(0, NEWCOMER_LIMIT)
    .map(item => item.item)
}

/** 時間標籤取 Melon TOP100 的時刻；沒有 Melon 就用抓取時間最新的那個榜。 */
function timeOf(charts: Charts): string | null {
  const melon = charts.melon?.value
  if (melon) return clockOf(melon)
  const loaded = platformIds
    .map(platform => charts[platform])
    .filter((chart): chart is Loaded<Chart> => chart != null)
    .sort((a, b) => b.fetchedAt - a.fetchedAt)
  return loaded.length > 0 ? clockOf(loaded[0].value) : null
}

function clockOf(chart: Chart): string {
  const period = chart.period
  if (period.unit !== "hour") return timeLabel(period)
  return `${`${period.hour}`.padStart(2, "0")}:${`${period.minute ?? 0}`.padStart(2, "0")}`
}
