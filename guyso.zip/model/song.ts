// 歌曲純函式：顯示字串、名次變動、Spotify 連結。

import type { ChartEntry, RankChange, Song } from "./types"

export function artistLine(song: Song): string {
  return song.artists.map(a => a.name).join(", ")
}

/** 曲目長度 m:ss。 */
export function formatDuration(seconds?: number): string {
  if (seconds == null || seconds <= 0) return ""
  const minute = Math.floor(seconds / 60)
  const second = Math.floor(seconds % 60)
  return `${minute}:${`${second}`.padStart(2, "0")}`
}

/** 只有歌曲、沒有榜單資料時的列：名次與變動都不顯示。 */
export function entryOf(song: Song, rank = 1): ChartEntry {
  return { rank, previous: null, change: { type: "same" }, song }
}

export function changeOf(previous: number | null, rank: number): RankChange {
  if (previous == null) return { type: "new" }
  if (previous > rank) return { type: "up", by: previous - rank }
  if (previous < rank) return { type: "down", by: rank - previous }
  return { type: "same" }
}

export function decodeSpotifyHex(hex?: string): string | undefined {
  if (!hex || hex.length % 2 !== 0) return undefined
  let out = ""
  for (let i = 0; i < hex.length; i += 2) {
    out += String.fromCharCode(parseInt(hex.slice(i, i + 2), 16))
  }
  return out.length === 22 ? out : undefined
}

export function formatCount(value: number): string {
  const parts = splitCount(value)
  return `${parts.value}${parts.unit}`
}

export function splitCount(value: number): { value: string; unit: string } {
  if (Math.abs(value) >= 100000000) {
    return { value: trim(value / 100000000), unit: "億" }
  }
  if (Math.abs(value) >= 10000) {
    return { value: trim(value / 10000), unit: "萬" }
  }
  return { value: `${value}`, unit: "" }
}

function trim(value: number): string {
  return (Math.round(value * 10) / 10).toString()
}

/** 千分位分組，用在不足萬的小數字（例如連續在榜天數）。 */
export function formatGrouped(value: number): string {
  return `${Math.round(value)}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
}

export function searchQuery(song: Song): string {
  return `${song.name} ${artistLine(song)}`
}

export async function openInSpotify(song: Song): Promise<void> {
  if (song.spotifyTrackId) {
    await Safari.openURL(`https://open.spotify.com/track/${song.spotifyTrackId}`)
    return
  }
  await searchInSpotify(song)
}

export async function searchInSpotify(song: Song): Promise<void> {
  const query = encodeURIComponent(searchQuery(song))
  const opened = await Safari.openURL(`spotify:search:${query}`)
  if (!opened) {
    await Safari.openURL(`https://open.spotify.com/search/${query}`)
  }
}

export function subtitleOf(entry: ChartEntry): string {
  return artistLine(entry.song)
}
