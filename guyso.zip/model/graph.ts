// graph 榜純函式：series 斷點、時間軸標籤、比例刻度。

import type { Period } from "./types"

export type SeriesPoint = { index: number; value: number }

/** 把 series 切成連續的非 null 段；每段是一條獨立的線。 */
export function seriesRuns(series: (number | null)[]): SeriesPoint[][] {
  const runs: SeriesPoint[][] = []
  let run: SeriesPoint[] = []
  series.forEach((value, index) => {
    if (value == null) {
      if (run.length > 0) runs.push(run)
      run = []
      return
    }
    run.push({ index, value })
  })
  if (run.length > 0) runs.push(run)
  return runs
}

/** 目前值：最後一個非 null 的點。 */
export function latestValue(series: (number | null)[]): number | undefined {
  for (let index = series.length - 1; index >= 0; index--) {
    const value = series[index]
    if (value != null) return value
  }
  return undefined
}

/** 5 分鐘榜（period 帶 minute）一格 15 分鐘，小時榜一格 6 小時。 */
export function axisStep(period: Period): number {
  return isFineGrained(period) ? 3 : 6
}

/** X 軸標籤：最後一點是榜單時刻，往前回溯；5 分鐘榜用整點的 5 分鐘刻度。 */
export function axisLabels(period: Period, count: number): string[] {
  const labels: string[] = []
  const hour = period.unit === "hour" ? period.hour : 0
  for (let index = 0; index < count; index++) {
    if (isFineGrained(period)) {
      const total = hour * 60 + index * 5
      labels.push(`${pad(Math.floor(total / 60) % 24)}:${pad(total % 60)}`)
    } else {
      labels.push(`${(hour + index - count + 25) % 24}時`)
    }
  }
  return labels
}

/** 比例刻度：從 0 到資料最大值往上取整到 5 的倍數。 */
export function scaleMax(seriesList: ((number | null)[] | undefined)[]): number {
  let max = 0
  for (const series of seriesList) {
    for (const value of series ?? []) {
      if (value != null && value > max) max = value
    }
  }
  return Math.max(5, Math.ceil(max / 5) * 5)
}

/** 比例數字的顯示：一位小數，整數不帶小數點。 */
export function percentText(value: number): string {
  return `${Math.round(value * 10) / 10}%`
}

function isFineGrained(period: Period): boolean {
  return period.unit === "hour" && period.minute != null
}

function pad(value: number): string {
  return `${value}`.padStart(2, "0")
}
