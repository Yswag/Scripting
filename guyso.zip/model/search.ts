// 搜尋的純邏輯：送出序號、列表副標、熱門搜尋的日期標籤。

import type { AlbumRef, SearchKind } from "./types"

export const searchKinds: { id: SearchKind; name: string }[] = [
  { id: "song", name: "歌曲" },
  { id: "album", name: "專輯" },
  { id: "artist", name: "歌手" },
]

/** 一次搜尋的身分：序號遞增，關鍵字一起記，舊的回應一率作廢。 */
export type SearchTicket = { seq: number; query: string }

export function nextTicket(current: SearchTicket, query: string): SearchTicket {
  return { seq: current.seq + 1, query }
}

export function acceptsResult(current: SearchTicket, response: SearchTicket): boolean {
  return response.seq === current.seq && response.query === current.query
}

/** 專輯列副標：「歌手 · 年份」，缺哪一個就不留分隔點。 */
export function albumSubtitle(album: AlbumRef): string {
  const year = album.releasedAt?.slice(0, 4) ?? ""
  const usableYear = /^\d{4}$/.test(year) && year !== "0000" ? year : ""
  return [album.artist ?? "", usableYear].filter(part => part.length > 0).join(" · ")
}

/** 熱門搜尋榜的日期：20261018 → 10月18日。 */
export function hotSearchLabel(date: string): string {
  const digits = date.replace(/-/g, "")
  const month = Number(digits.slice(4, 6))
  const day = Number(digits.slice(6, 8))
  if (!month || !day) return ""
  return `${month}月${day}日`
}
