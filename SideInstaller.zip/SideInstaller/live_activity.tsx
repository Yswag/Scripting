// The pairing code, drawn where a person who is in Settings can still read it.
//
// Pairing this iPhone means typing a code this app shows into a prompt in Settings, with the app
// behind it — so a card inside the app arrives at exactly the wrong moment. A Live Activity is drawn
// by the system from the registration below and survives this app being suspended, which is the same
// reason the original app shows its code this way.
//
// The name and place are not a choice: `live_activity.tsx` at the project root is the capability file
// the Scripting App loads to render one, so this file is also evaluated by the extension — where
// there is no catalogue and no `t`. Every string in the state below is therefore already translated
// by the app (see `createPairingSurface`), and this file only lays it out.
import {
  AppEvents, LiveActivity, LiveActivityUI, LiveActivityUIExpandedCenter, Text, VStack,
  type LiveActivityUIBuilder, type ScenePhase,
} from "scripting"
import { t, type TranslationKey } from "./lib/i18n"
import type { PairingCardProblem, PairingCodeSurface } from "./lib/engine"

/** The card's content. JSON-serialisable: it crosses into the extension as data. */
export interface PairingCodeState {
  /** The six digits. Empty before the host has made one. */
  pin: string
  /** The line above the code, already translated. */
  title: string
  /** The line below it: where to type the code, or how pairing ended. */
  hint: string
  /** Which card this is, for the tint: the extension cannot translate, but it can colour. */
  tone: "waiting" | "ok" | "failed"
}

const TINT = { waiting: "#0A84FF", ok: "#30D158", failed: "#FF453A" } as const

/** The code at a readable size, between the lines that say what to do with it. */
function CodeView({ state, size }: { state: PairingCodeState, size: number }) {
  return (
    <VStack spacing={2} frame={{ maxWidth: "infinity" }}>
      <Text font="caption2" foregroundStyle="secondaryLabel">{state.title}</Text>
      <Text font={{ name: "Menlo", size }} foregroundStyle={TINT[state.tone]}>{state.pin}</Text>
      <Text font="caption2" foregroundStyle="secondaryLabel">{state.hint}</Text>
    </VStack>
  )
}

/**
 * The island's compact form has room for a few characters either side of the cutout, so the code goes
 * in as two halves and reads across it. That is what keeps the code visible while the person is in
 * Settings, without asking them to expand anything.
 */
const builder: LiveActivityUIBuilder<PairingCodeState> = state => (
  <LiveActivityUI
    content={<CodeView state={state} size={34} />}
    compactLeading={<Text font={{ name: "Menlo", size: 15 }}>{state.pin.slice(0, 3)}</Text>}
    compactTrailing={<Text font={{ name: "Menlo", size: 15 }}>{state.pin.slice(3)}</Text>}
    minimal={<Text font={{ name: "Menlo", size: 13 }}>{state.pin.slice(0, 3)}</Text>}>
    <LiveActivityUIExpandedCenter>
      <CodeView state={state} size={26} />
    </LiveActivityUIExpandedCenter>
  </LiveActivityUI>
)

/** Registering is what lets the app start it and the extension draw it. */
export const PairingActivity = LiveActivity.register("SideInstallerPairing", builder)

// MARK: - the app side

/**
 * How long the card offers the way back when nobody takes it. The original app holds its own card for
 * this long after pairing, which is the time someone still reading the prompt in Settings has to
 * notice it and tap it.
 */
const PAIRED_HOLD_MS = 15_000

/**
 * The surface `pairStep` draws on. It lives here because the registration above does, and because the
 * engine deliberately has no opinion about how a code is shown.
 *
 * Every call is best-effort: a device with Live Activities turned off still has to be able to pair,
 * and the step's log carries the code in any case.
 */
export function createPairingSurface(): PairingCodeSurface {
  let activity: ReturnType<typeof PairingActivity> | null = null
  let pin = ""
  // Away until the app says otherwise. The listener only reports changes, so an app that never
  // changed phase says nothing — and holding the card is the harmless way to be wrong about it.
  let inFront = false
  AppEvents.scenePhase.addListener(phase => { inFront = phase === "active" })

  /** Resolves once the app is back in front, or after `ms` — whichever comes first. */
  const backInFront = (ms: number): Promise<void> =>
    new Promise(resolve => {
      // Not `if (timer)`: the first handle this runtime hands out is 0.
      let timer: number | null = null
      const stop = () => {
        if (timer !== null) clearTimeout(timer)
        AppEvents.scenePhase.removeListener(listener)
        resolve()
      }
      const listener = (phase: ScenePhase) => { if (phase === "active") stop() }
      timer = setTimeout(stop, ms)
      AppEvents.scenePhase.addListener(listener)
    })

  const card = (
    title: TranslationKey, hint: TranslationKey, tone: PairingCodeState["tone"], params?: Record<string, string>,
  ): PairingCodeState => ({
    pin,
    title: t(title),
    hint: params === undefined ? t(hint) : t(hint, params),
    tone,
  })

  /**
   * Draws the card. `alert` is what opens the Dynamic Island on iPhone — the only way to draw
   * attention to a card the person is not looking at (elsewhere it drops it down as a banner).
   */
  const draw = async (state: PairingCodeState, alert?: { title: string, body: string }) => {
    if (activity === null) return
    try {
      await activity.update(state, alert === undefined ? undefined : { alert })
    } catch {
      // A card that will not update is never a reason to fail a pairing.
    }
  }

  return {
    async start(code): Promise<PairingCardProblem | null> {
      pin = code
      try {
        if (!await LiveActivity.areActivitiesEnabled()) return { key: "activity.pair.disabled" }
        const instance = PairingActivity()
        if (await instance.start(card("activity.pair.title", "activity.pair.where", "waiting"))) {
          activity = instance
          return null
        }
        return { key: "activity.pair.refused" }
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error)
        // ActivityKit will not start one from a backgrounded app, and this step runs while the app is
        // still in front — so that message means the person left before the card was up, and there is
        // no second chance at it.
        return {
          key: /foreground/i.test(message) ? "activity.pair.notForeground" : "activity.pair.refused",
          message,
        }
      }
    },

    async prompt(code) {
      if (code.length > 0) pin = code
      await draw(
        card("activity.pair.enter", "activity.pair.where", "waiting"),
        { title: t("activity.pair.alert.title"), body: t("activity.pair.alert.body") },
      )
    },

    async finish(paired, device) {
      if (activity === null) return
      const state = paired
        ? card("activity.pair.paired", "activity.pair.return", "ok")
        : card("activity.pair.failed", "activity.pair.retry", "failed")
      await draw(state, { title: state.title, body: state.hint })
      try {
        if (paired && !inFront) {
          // The person is still in Settings, so the tap is how they get back: the card stays up until
          // they take it, and is gone the moment they are here. Awaited rather than scheduled: the
          // pairing's keep-alive is released right after this returns, and an end that never ran would
          // leave the card up for good.
          await backInFront(PAIRED_HOLD_MS)
          await activity.end(state, { dismissTimeInterval: 0 })
        } else {
          // Already back in the app, which is what explains the run: a minute on the Lock Screen is
          // long enough to read and gone before it is clutter.
          await activity.end(state, { dismissTimeInterval: 60 })
        }
      } catch {
        // Nothing left to clean up.
      }
      activity = null
    },
  }
}
