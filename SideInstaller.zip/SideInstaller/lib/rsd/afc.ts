// AFC: the file service, in its RSD form.
//
// Every request and reply is a 40-byte little-endian header followed by a header payload and
// then a body. The two length fields are easy to get wrong and the mistake is silent: get
// `header_payload_len` wrong and the streams desynchronise a packet later, not here.
import type { Bytes } from "../util"
import { concat, fromUtf8, readU32le, readU64le, toHex, u32le, u64le, utf8 } from "../util"
import { StreamReader, rsdCheckin, type ByteStream } from "./stream"

/** "CFA6LPAA" read as a little-endian u64. */
export const AFC_MAGIC = 0x4141504c36414643n

export const AFC_HEADER_LEN = 40

/**
 * The reference caps a single transfer at this, "what libimobiledevice uses in afcclient".
 *
 * The transport underneath caps a single *call* much lower (`TUNNEL_MAX_TRANSFER`), and `TunnelStream`
 * splits a packet at that — so this stays the protocol's notion of a transfer even though one of them
 * now leaves here as several writes.
 */
export const AFC_MAX_TRANSFER = 1024 * 1024

export const AFC_OPCODE = {
  Status: 0x01,
  ReadDir: 0x03,
  RemovePath: 0x08,
  MakeDir: 0x09,
  GetFileInfo: 0x0a,
  FileOpen: 0x0d,
  Read: 0x0f,
  Write: 0x10,
  FileSeek: 0x11,
  FileTell: 0x12,
  FileClose: 0x14,
  RenamePath: 0x18,
  RemovePathAndContents: 0x22,
} as const

export type AfcOpcode = typeof AFC_OPCODE[keyof typeof AFC_OPCODE]

/** AFC's own status codes, as the device numbers them (the reference's `AfcError`). */
export const AFC_ERROR = {
  InvalidArg: 7n,
  ObjectNotFound: 8n,
  ObjectIsDir: 9n,
  PermDenied: 10n,
  ObjectExists: 16n,
} as const

export const AFC_MODE = {
  RdOnly: 0x01n,
  Rw: 0x02n,
  WrOnly: 0x03n,
  Wr: 0x04n,
  Append: 0x05n,
  RdAppend: 0x06n,
} as const

export interface AfcPacket {
  /** `header_payload_len + payload.length`, as the reference computes it. */
  entireLength: number
  /** `40 + header_payload.length` — it INCLUDES the fixed header. */
  headerPayloadLength: number
  packetNumber: number
  operation: number
  headerPayload: Bytes
  payload: Bytes
}

/** Encodes one request. `packetNumber` is the sender's own counter, starting at 0. */
export function encodeAfcPacket(
  operation: number,
  packetNumber: number,
  headerPayload: Bytes,
  payload: Bytes = new Uint8Array(0),
): Bytes {
  const headerPayloadLength = AFC_HEADER_LEN + headerPayload.length
  const entireLength = headerPayloadLength + payload.length
  const header = concat(
    u64le(AFC_MAGIC),
    u64le(BigInt(entireLength)),
    u64le(BigInt(headerPayloadLength)),
    u64le(BigInt(packetNumber)),
    u64le(BigInt(operation)),
  )
  if (header.length !== AFC_HEADER_LEN) {
    throw new Error(`afc: header is ${header.length} bytes, expected ${AFC_HEADER_LEN}`)
  }
  return concat(header, headerPayload, payload)
}

/**
 * Decodes a packet from a reader, or null when a whole one has not arrived.
 *
 * Only the fields the caller needs are returned as numbers; `magic` and `packetNumber` are
 * validated because a desynchronised stream is otherwise indistinguishable from a valid reply.
 */
export function readAfcPacket(reader: StreamReader): AfcPacket | null {
  const head = reader.peek(AFC_HEADER_LEN)
  if (head === null) return null

  const magic = readU64le(head, 0)
  if (magic !== AFC_MAGIC) {
    throw new Error(`afc: bad magic ${toHex(head.subarray(0, 8))} (expected CFA6LPAA)`)
  }
  const entireLength = Number(readU64le(head, 8))
  const headerPayloadLength = Number(readU64le(head, 16))
  const packetNumber = Number(readU64le(head, 24))
  const operation = Number(readU64le(head, 32))

  if (headerPayloadLength < AFC_HEADER_LEN || entireLength < headerPayloadLength) {
    throw new Error(
      `afc: implausible lengths (entire ${entireLength}, header payload ${headerPayloadLength})`,
    )
  }

  const total = AFC_HEADER_LEN + (entireLength - AFC_HEADER_LEN)
  if (reader.buffered < total) return null

  reader.take(AFC_HEADER_LEN)
  const payloadArea = reader.take(entireLength - AFC_HEADER_LEN)
  const headerPayload = payloadArea.subarray(0, headerPayloadLength - AFC_HEADER_LEN)
  const payload = payloadArea.subarray(headerPayloadLength - AFC_HEADER_LEN)

  return { entireLength, headerPayloadLength, packetNumber, operation, headerPayload, payload }
}

/** An error reply: `operation == Status` with an 8-byte little-endian code. */
export class AfcError extends Error {
  constructor(readonly code: bigint, operation: number) {
    super(`afc: operation 0x${operation.toString(16)} failed with status ${code}`)
    this.name = "AfcError"
  }
}

export interface AfcFileInfo {
  /** `st_size`, in bytes. */
  size: number
  /** `st_blocks`. */
  blocks: number
  /** `st_ifmt`, e.g. `S_IFREG` or `S_IFDIR`. */
  kind: string
  /** `st_link_target`, present only for a symlink. */
  linkTarget: string | null
  /** `st_nlink`, as the device sends it (a string). */
  nlink: string | null
}

/** An opened file's identity, as it arrives from `FileOpen`. */
export type AfcHandle = bigint

/**
 * One AFC session. Every request consumes exactly one reply, and the packet counter is shared
 * across all of them, so requests cannot be interleaved on one client.
 */
export class AfcClient {
  private readonly reader: StreamReader
  private nextPacket = 0

  private constructor(private readonly stream: ByteStream) {
    this.reader = new StreamReader(stream)
  }

  /** Connects, checks in, and returns a client ready to speak AFC. */
  static async connect(stream: ByteStream, label: string): Promise<AfcClient> {
    await rsdCheckin(stream, label)
    return new AfcClient(stream)
  }

  /** Wraps an already-open AFC connection (house_arrest hands one back after a vend). */
  static fromStream(stream: ByteStream): AfcClient {
    return new AfcClient(stream)
  }

  /** Closes the connection this client reads and writes on, when the transport has one. */
  async disconnect(): Promise<void> {
    if (this.stream.close !== undefined) await this.stream.close()
  }

  private async request(operation: number, headerPayload: Bytes, payload?: Bytes): Promise<AfcPacket> {
    await this.stream.write(encodeAfcPacket(operation, this.nextPacket, headerPayload, payload))
    this.nextPacket++

    return this.reader.until<AfcPacket>(reader => {
      const packet = readAfcPacket(reader)
      if (packet === null) return null
      if (packet.operation === AFC_OPCODE.Status) {
        const code = packet.headerPayload.length >= 8 ? readU64le(packet.headerPayload, 0) : -1n
        if (code !== 0n) throw new AfcError(code, operation)
      }
      return packet
    })
  }

  // MARK: directory operations

  async makeDir(path: string): Promise<void> {
    await this.request(AFC_OPCODE.MakeDir, utf8(path))
  }

  /** True when the path exists. A failing `GetFileInfo` is the only way to ask. */
  async exists(path: string): Promise<boolean> {
    try {
      await this.info(path)
      return true
    } catch (error) {
      if (error instanceof AfcError) return false
      throw error
    }
  }

  async info(path: string): Promise<AfcFileInfo> {
    const packet = await this.request(AFC_OPCODE.GetFileInfo, utf8(path))
    // The device puts the key/value block in the packet's PAYLOAD, not the header payload.
    // Reading the wrong one yields an empty map rather than an error, so this matters.
    return parseFileInfo(packet.payload.length > 0 ? packet.payload : packet.headerPayload)
  }

  /** Entry names in a directory. `.` and `..` are filtered out. */
  async listDir(path: string): Promise<string[]> {
    const packet = await this.request(AFC_OPCODE.ReadDir, utf8(path))
    return fromUtf8(packet.payload)
      .split("\0")
      .filter(name => name.length > 0 && name !== "." && name !== "..")
  }

  async removePath(path: string): Promise<void> {
    await this.request(AFC_OPCODE.RemovePath, utf8(path))
  }

  async removePathAndContents(path: string): Promise<void> {
    await this.request(AFC_OPCODE.RemovePathAndContents, utf8(path))
  }

  async rename(from: string, to: string): Promise<void> {
    await this.request(AFC_OPCODE.RenamePath, concat(utf8(from), new Uint8Array([0]), utf8(to), new Uint8Array([0])))
  }

  // MARK: files

  async open(path: string, mode: bigint = AFC_MODE.WrOnly): Promise<AfcHandle> {
    const packet = await this.request(AFC_OPCODE.FileOpen, concat(u64le(mode), utf8(path)))
    return readU64le(packet.headerPayload, 0)
  }

  async write(handle: AfcHandle, bytes: Bytes): Promise<void> {
    // One packet per chunk: a single write larger than the cap is not exercised anywhere in the
    // reference, and the reference's own chunking is at exactly this size.
    let offset = 0
    while (offset < bytes.length) {
      const chunk = bytes.subarray(offset, offset + AFC_MAX_TRANSFER)
      await this.request(AFC_OPCODE.Write, u64le(handle), chunk)
      offset += chunk.length
    }
  }

  /** Closes the handle. This is also what commits the write. */
  async close(handle: AfcHandle): Promise<void> {
    await this.request(AFC_OPCODE.FileClose, u64le(handle))
  }

  async readFile(handle: AfcHandle, count: number): Promise<Bytes> {
    const packet = await this.request(AFC_OPCODE.Read, concat(u64le(handle), u64le(BigInt(count))))
    return packet.payload
  }

  /** Opens, reads to the end, closes. For verification reads, not for bulk work. */
  async readWholeFile(path: string, maxBytes = 64 * 1024 * 1024): Promise<Bytes> {
    const handle = await this.open(path, AFC_MODE.RdOnly)
    try {
      const parts: Bytes[] = []
      let total = 0
      for (;;) {
        const packet = await this.request(
          AFC_OPCODE.Read,
          concat(u64le(handle), u64le(BigInt(AFC_MAX_TRANSFER))),
        )
        if (packet.payload.length === 0) break
        parts.push(packet.payload)
        total += packet.payload.length
        if (total > maxBytes) throw new Error(`afc: ${path} is larger than ${maxBytes} bytes`)
      }
      return concat(...parts)
    } finally {
      await this.close(handle)
    }
  }
}

/**
 * Parses a `GetFileInfo` reply: NUL-separated strings forming key/value pairs.
 *
 * The reference parses these as plain pairs from the first string. Some AFC implementations
 * prepend the file name instead, which would shift every pair by one, so a leading entry is
 * detected and skipped rather than silently producing an empty map — that failure mode is
 * invisible otherwise, and it is cheap to guard against.
 */
export function parseFileInfo(headerPayload: Bytes): AfcFileInfo {
  const parts = fromUtf8(headerPayload).split("\0").filter(part => part.length > 0)

  const pairsFrom = (at: number): Map<string, string> => {
    const map = new Map<string, string>()
    for (let i = at; i + 1 < parts.length; i += 2) map.set(parts[i], parts[i + 1])
    return map
  }

  let map = pairsFrom(0)
  if (!map.has("st_ifmt") && !map.has("st_size") && parts.length > 1) {
    const shifted = pairsFrom(1)
    if (shifted.has("st_ifmt") || shifted.has("st_size")) map = shifted
  }

  const size = map.get("st_size")
  const blocks = map.get("st_blocks")
  if (size === undefined || map.get("st_ifmt") === undefined) {
    throw new Error(`afc: a GetFileInfo reply had no st_size/st_ifmt (keys: ${Array.from(map.keys()).join(", ")})`)
  }

  return {
    size: Number.parseInt(size, 10),
    blocks: blocks === undefined ? 0 : Number.parseInt(blocks, 10),
    kind: map.get("st_ifmt")!,
    linkTarget: map.get("st_link_target") ?? null,
    nlink: map.get("st_nlink") ?? null,
  }
}

// MARK: - upload

export interface UploadProgress {
  path: string
  bytes: number
  totalBytes: number
}

export interface UploadOptions {
  /** Called after each file finishes. */
  onProgress?: (progress: UploadProgress) => void
  /** Read the file back and compare lengths once written. Cheap insurance. */
  verify?: boolean
}

/**
 * Uploads a local file tree into an AFC root, depth-first with directories created before their
 * children.
 *
 * `files` is a flat list rather than a live directory walk so the caller decides how the tree is
 * read — the local file API and the remote one have different shapes, and mixing them here would
 * make this untestable.
 */
export async function uploadTree(
  client: AfcClient,
  remoteRoot: string,
  files: Array<{ path: string, bytes: number, read: () => Promise<Bytes> }>,
  directories: string[],
  options: UploadOptions = {},
): Promise<{ files: number, bytes: number }> {
  // Parents first: any order that satisfies that works, so sort by path depth.
  const ordered = directories.slice().sort((a, b) => depth(a) - depth(b) || a.localeCompare(b))
  for (const directory of ordered) {
    const remote = joinRemote(remoteRoot, directory)
    if (!await client.exists(remote)) await client.makeDir(remote)
  }

  const totalBytes = files.reduce((sum, file) => sum + file.bytes, 0)
  let uploadedBytes = 0
  let uploadedFiles = 0

  for (const file of files) {
    const remote = joinRemote(remoteRoot, file.path)
    const handle = await client.open(remote, AFC_MODE.WrOnly)
    try {
      const bytes = await file.read()
      try {
        await client.write(handle, bytes)
      } catch (error) {
        // The size is the first thing to suspect when a write fails on a real device: the transport
        // caps a single write, and a file under that cap did get through where the next one did not.
        const message = error instanceof Error ? error.message : String(error)
        throw new Error(`afc: writing ${remote} (${bytes.length} bytes) failed: ${message}`)
      }
    } finally {
      // The close is what commits, so it happens even if the write threw — a half-written file
      // that was never closed simply does not appear.
      await client.close(handle)
    }
    uploadedBytes += file.bytes
    uploadedFiles++

    if (options.verify === true && file.bytes > 0) {
      const back = await client.readWholeFile(remote)
      if (back.length !== file.bytes) {
        throw new Error(`afc: ${remote} is ${back.length} bytes after upload, expected ${file.bytes}`)
      }
    }
    options.onProgress?.({ path: file.path, bytes: uploadedBytes, totalBytes })
  }

  return { files: uploadedFiles, bytes: uploadedBytes }
}

function depth(path: string): number {
  return path.split("/").filter(part => part.length > 0).length
}

/** Joins with a single slash, never doubling it, always absolute. */
export function joinRemote(root: string, path: string): string {
  const cleaned = path.replace(/^\/+/, "")
  const base = `/${root.replace(/^\/+|\/+$/g, "")}`
  return cleaned.length === 0 ? base : `${base}/${cleaned}`
}

export { u32le, readU32le, readU64le }
