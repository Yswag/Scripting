// Seeding another app with this device's pairing file, over house_arrest.
//
// Two shapes go in, because the builds in circulation read different ones: `ALTPairingFile.
// mobiledevicepairing` (what AltStore-family apps hand straight to minimuxer) and, for builds that
// read one file per protocol, `PairingFile_Lockdown.plist` / `PairingFile_RemoteRP.plist` plus the
// two settings their own import writes. The first is required; the second only logs when it fails.
import { parsePlist, str, utf8, writeXml, type PlistDict } from "../util"
import { updateContainerPlist, writeIntoDocuments } from "./container"
import type { ServiceOpener } from "./housearrest"

/** Where SideStore's own folder sits inside the app that received the pairing file. */
export type SideStoreHome = "standalone" | "liveContainer"

/** One app that can receive the pairing file, as in the original's `PairingTargetApp.all`. */
export interface PairingTarget {
  /** The display name the installed app reports, matched on. */
  name: string
  /** Where the pairing file must land, relative to the app's Documents directory. */
  relativePath: string
  /** The app carries SideStore, in this place. */
  sideStoreHome: SideStoreHome | null
  /** Restricts the entry to bundle ids containing this, which splits StikDebug's two builds. */
  bundleIdContains?: string
}

export const PAIRING_TARGETS: PairingTarget[] = [
  { name: "SideStore", relativePath: "ALTPairingFile.mobiledevicepairing", sideStoreHome: "standalone" },
  {
    name: "LiveContainer",
    relativePath: "SideStore/Documents/ALTPairingFile.mobiledevicepairing",
    sideStoreHome: "liveContainer",
  },
  { name: "Feather", relativePath: "pairingFile.plist", sideStoreHome: null },
  { name: "StikDebug", relativePath: "pairingFile.plist", sideStoreHome: null },
  {
    name: "StikDebug (Sideloaded)",
    relativePath: "rp_pairing_file.plist",
    sideStoreHome: null,
    bundleIdContains: "com.stik.stikdebug",
  },
  { name: "StikTest", relativePath: "stiktest_pairing.plist", sideStoreHome: null },
  { name: "Protokolle", relativePath: "pairingFile.plist", sideStoreHome: null },
  { name: "Antrag", relativePath: "pairingFile.plist", sideStoreHome: null },
  { name: "SparseBox", relativePath: "pairingFile.plist", sideStoreHome: null },
  { name: "StikStore", relativePath: "pairingFile.plist", sideStoreHome: null },
  { name: "ByeTunes", relativePath: "pairing file/pairingFile.plist", sideStoreHome: null },
  { name: "Reynard", relativePath: "pairingFile.plist", sideStoreHome: null },
  { name: "PanicAnalyzer", relativePath: "pairingFile.plist", sideStoreHome: null },
]

/**
 * The table entry for an installed app, matched on its display name.
 *
 * A display name of `StikDebug` picks the sideloaded entry when the bundle id is its, and plain
 * entries only are considered otherwise — the bundle-id-gated variant is reached that way alone.
 */
export function pairingTargetFor(
  displayName: string,
  bundleId: string,
): PairingTarget | null {
  if (displayName === "StikDebug") {
    const sideloaded = bundleId.includes("com.stik.stikdebug")
    return PAIRING_TARGETS.find(target =>
      target.name === (sideloaded ? "StikDebug (Sideloaded)" : "StikDebug")) ?? null
  }
  return PAIRING_TARGETS.find(target =>
    target.name === displayName && target.bundleIdContains === undefined) ?? null
}

// MARK: the per-protocol hand-off

export const LOCKDOWN_FILE_NAME = "PairingFile_Lockdown.plist"
export const REMOTE_FILE_NAME = "PairingFile_RemoteRP.plist"

/** The keys minimuxer requires for each protocol (`MinimuxerCommon`'s `PairingFile.swift`). */
const REQUIRED_LOCKDOWN_KEYS = [
  "WiFiMACAddress", "SystemBUID", "RootPrivateKey", "HostPrivateKey", "HostID",
  "RootCertificate", "UDID", "EscrowBag", "HostCertificate", "DeviceCertificate",
]
const REQUIRED_REMOTE_KEYS = ["private_key", "public_key", "identifier"]
/** Every RPPairing key, including the optional `alt_irk`. */
const REMOTE_KEYS = new Set(["private_key", "public_key", "identifier", "alt_irk"])

export type PairingProtocol = "lockdown" | "rppairing"

export interface SplitRecords {
  /** The lockdown record alone, or null when the file holds no complete one. */
  lockdown: string | null
  /** The RPPairing record alone, or null when the file holds none. */
  remote: string | null
  /** Keys missing from a partial lockdown record, for the log. */
  missingLockdownKeys: string[]
  /**
   * The protocol the app should load. Lockdown goes first: it reaches lockdownd over the loopback
   * VPN, where the RPPairing listener can refuse a tunnel the device itself opens.
   */
  activeProtocol: PairingProtocol | null
}

/** Splits a pairing file into one record per protocol, filling in the UDID the lockdown half needs. */
export function splitPairingRecords(xml: string, udid: string | null): SplitRecords {
  const parsed = parsePlist(xml)
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed) || parsed instanceof Uint8Array) {
    throw new Error("pairing file: not a plist dictionary")
  }
  const dict = parsed as PlistDict

  const lockdown: PlistDict = {}
  for (const [key, value] of Object.entries(dict)) {
    if (!REMOTE_KEYS.has(key)) lockdown[key] = value
  }
  if (udid !== null && udid.length > 0 && str(lockdown, "UDID") === undefined) lockdown.UDID = udid

  const missingLockdownKeys = REQUIRED_LOCKDOWN_KEYS.filter(key => lockdown[key] === undefined)
  // A file with no lockdown keys at all is not missing anything worth reporting.
  const hasAnyLockdown = REQUIRED_LOCKDOWN_KEYS.some(key => key !== "UDID" && lockdown[key] !== undefined)

  const remote: PlistDict = {}
  for (const [key, value] of Object.entries(dict)) {
    if (REMOTE_KEYS.has(key)) remote[key] = value
  }
  const hasRemote = REQUIRED_REMOTE_KEYS.every(key => remote[key] !== undefined)

  const lockdownRecord = missingLockdownKeys.length === 0 ? writeXml(lockdown) : null
  const remoteRecord = hasRemote ? writeXml(remote) : null

  return {
    lockdown: lockdownRecord,
    remote: remoteRecord,
    missingLockdownKeys: hasAnyLockdown ? missingLockdownKeys : [],
    activeProtocol: lockdownRecord !== null ? "lockdown" : remoteRecord !== null ? "rppairing" : null,
  }
}

/**
 * Sets what the app's own import sets: pairing no longer reset, and the protocol whose file to load.
 * A protocol chosen in the app's settings lives under another key and is left alone.
 */
export function applyPairingSettings(plist: PlistDict, activeProtocol: PairingProtocol): void {
  plist.isPairingReset = false
  plist.activePairingProtocol = activeProtocol
}

/** SideStore's Documents folder, relative to the host app's Documents. */
const DOCUMENTS_PREFIX: Record<SideStoreHome, string> = {
  standalone: "",
  liveContainer: "SideStore/Documents/",
}

/** Where SideStore's own files go, relative to the app's Documents: another file joins them here. */
export function documentsPrefix(home: SideStoreHome): string {
  return DOCUMENTS_PREFIX[home]
}

/** SideStore's settings plist, relative to the host app's container root. */
export function preferencesPath(home: SideStoreHome, hostBundleId: string): string {
  return home === "standalone"
    ? `Library/Preferences/${hostBundleId}.plist`
    : "Documents/SideStore/Library/Preferences/com.SideStore.SideStore.plist"
}

export interface SplitOutcome {
  /** The files that landed, relative to the app's Documents. */
  files: string[]
  activeProtocol: PairingProtocol | null
  missingLockdownKeys: string[]
  settingsWritten: boolean
  /** Why the newer format was not handed over, when it was not. */
  error: string | null
}

export interface SeedOptions {
  link: ServiceOpener
  /** The bundle id installation_proxy knows the app by. */
  bundleId: string
  target: PairingTarget
  /** The RPPairing record, as XML. */
  xml: string
  udid: string | null
}

export interface SeedOutcome extends SplitOutcome {
  /** The legacy file's byte count, read back and verified by the device. */
  bytes: number
}

/**
 * Writes the pairing file into `target`'s app, then hands over the newer shape as well.
 *
 * The first write throws when it fails — an app with no pairing file cannot talk to the device. The
 * second is best-effort: older builds have the file they read by then, and only a newer build loses
 * anything, which the returned `error` names.
 */
export async function seedPairingFile(options: SeedOptions): Promise<SeedOutcome> {
  const bytes = await writeIntoDocuments(
    options.link, options.bundleId, options.target.relativePath, utf8(options.xml))

  if (options.target.sideStoreHome === null) {
    return { bytes, files: [], activeProtocol: null, missingLockdownKeys: [], settingsWritten: false, error: null }
  }

  const home = options.target.sideStoreHome
  try {
    const records = splitPairingRecords(options.xml, options.udid)
    if (records.activeProtocol === null) {
      return {
        bytes,
        files: [],
        activeProtocol: null,
        missingLockdownKeys: records.missingLockdownKeys,
        settingsWritten: false,
        error: null,
      }
    }

    const prefix = DOCUMENTS_PREFIX[home]
    const files: string[] = []
    for (const [name, record] of [
      [LOCKDOWN_FILE_NAME, records.lockdown],
      [REMOTE_FILE_NAME, records.remote],
    ] as Array<[string, string | null]>) {
      if (record === null) continue
      const relative = prefix + name
      await writeIntoDocuments(options.link, options.bundleId, relative, utf8(record))
      files.push(relative)
    }

    const preferences = preferencesPath(home, options.bundleId)
    await updateContainerPlist(options.link, options.bundleId, preferences, plist => {
      applyPairingSettings(plist, records.activeProtocol as PairingProtocol)
    })

    return {
      bytes,
      files,
      activeProtocol: records.activeProtocol,
      missingLockdownKeys: records.missingLockdownKeys,
      settingsWritten: true,
      error: null,
    }
  } catch (error) {
    return {
      bytes,
      files: [],
      activeProtocol: null,
      missingLockdownKeys: [],
      settingsWritten: false,
      error: error instanceof Error ? error.message : String(error),
    }
  }
}
