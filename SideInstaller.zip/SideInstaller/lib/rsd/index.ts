// RSD services: connect to the device control plane (check-in), transfer files (AFC), and
// install apps (installation_proxy). Internal framing (length-prefixed plist) is hidden.

// Stream layer
export { rsdCheckin, SERVICES, type ByteStream } from "./stream"

// Reaching the device: the tunnel and the service table on it
export { openDeviceLink, REMOTED_PORT, type DeviceLink, type RsdTunnel } from "./device"
export { probeTcp, type TcpProbe } from "./probe"
export { RsdClient, requireService, type RsdHandshake, type RsdService } from "./rsd"

// AFC — file transfer
export { AfcClient, AFC_ERROR, uploadTree, parseFileInfo } from "./afc"

// misagent — the device's provisioning profiles, which a refresh replaces
export { MisagentClient } from "./misagent"

// house_arrest — another app's container, as an AFC volume
export { HouseArrestClient, withAppContainer, type ContainerScope, type ServiceOpener } from "./housearrest"
export { listContainer, readFromDocuments, updateContainerPlist, writeIntoDocuments } from "./container"

// Seeding another app with the pairing file
export {
  LOCKDOWN_FILE_NAME,
  PAIRING_TARGETS,
  REMOTE_FILE_NAME,
  documentsPrefix,
  pairingTargetFor,
  preferencesPath,
  seedPairingFile,
  splitPairingRecords,
  type PairingTarget,
  type SeedOutcome,
  type SideStoreHome,
  type SplitOutcome,
  type SplitRecords,
} from "./pairing"

// Deploy & install
export { deployBundle, describeBundle } from "./deploy"
export { InstallationProxy, installCommand, readInstallStatus, stagingPath } from "./installation"
