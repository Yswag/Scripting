// An installed app's files, reached over house_arrest.
//
// Paths are the container's own: `/Documents/<name>` is what the app reads, and anything else —
// `Library/Preferences`, say — needs the whole container vended. A write is read back and its
// length checked, because AFC commits on close and a close that failed commits nothing.
import { parsePlist, writeBinaryPlist, type Bytes, type PlistDict } from "../util"
import { AFC_ERROR, AFC_MODE, AfcError, type AfcClient } from "./afc"
import { withAppContainer, type ContainerScope, type ServiceOpener } from "./housearrest"

/** Writes `data` into the app's Documents at `relativePath`. Returns the verified byte count. */
export async function writeIntoDocuments(
  link: ServiceOpener,
  bundleId: string,
  relativePath: string,
  data: Bytes,
): Promise<number> {
  return withAppContainer(link, bundleId, "documents", afc =>
    writeVerified(afc, `/Documents/${relativePath}`, data))
}

/** The file at `relativePath` in the app's Documents, or null when there is none. */
export async function readFromDocuments(
  link: ServiceOpener,
  bundleId: string,
  relativePath: string,
): Promise<Bytes | null> {
  return withAppContainer(link, bundleId, "documents", afc =>
    readIfPresent(afc, `/Documents/${relativePath}`))
}

/** Entry names in a folder of the container, `.` and `..` left out. */
export async function listContainer(
  link: ServiceOpener,
  bundleId: string,
  containerPath: string,
  scope: ContainerScope,
): Promise<string[]> {
  return withAppContainer(link, bundleId, scope, afc => afc.listDir(`/${containerPath}`))
}

/**
 * Edits the plist dictionary at `containerPath` in the app's container, starting from an empty
 * one when the file is missing, and returns the byte count written.
 *
 * The result is written beside the file and renamed over it: rewriting it in place keeps the inode,
 * and cfprefsd then keeps serving the copy it cached. A file that exists but cannot be read, or is
 * not a dictionary, throws before anything is written, so the app's other settings survive.
 */
export async function updateContainerPlist(
  link: ServiceOpener,
  bundleId: string,
  containerPath: string,
  edit: (plist: PlistDict) => void,
): Promise<number> {
  const remotePath = `/${containerPath}`
  const scope: ContainerScope = containerPath.startsWith("Documents/") ? "documents" : "container"
  return withAppContainer(link, bundleId, scope, async afc => {
    const existing = await readIfPresent(afc, remotePath)
    let plist: PlistDict = {}
    if (existing !== null && existing.length > 0) {
      const parsed = parsePlist(existing)
      if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed) || parsed instanceof Uint8Array) {
        throw new Error(`house_arrest: ${containerPath} in ${bundleId} is not a plist dictionary`)
      }
      plist = parsed as PlistDict
    }

    edit(plist)
    const staging = `${remotePath}.sideinstaller`
    const written = await writeVerified(afc, staging, writeBinaryPlist(plist))
    await afc.rename(staging, remotePath)
    return written
  })
}

/**
 * Writes `data` to `remotePath` (absolute, as the vended volume sees it), creating its parent
 * directories, then reads it back and compares lengths.
 */
async function writeVerified(afc: AfcClient, remotePath: string, data: Bytes): Promise<number> {
  if (data.length === 0) throw new Error("house_arrest: refusing to write an empty file")
  await makeDirectories(afc, remotePath)

  const handle = await afc.open(remotePath, AFC_MODE.Wr)
  try {
    await afc.write(handle, data)
  } catch (error) {
    // The handle is consumed either way; only the write's own failure is reported.
    await afc.close(handle).catch(() => {})
    throw error
  }
  // Closing is what commits the write, so its error is the write's error.
  await afc.close(handle)

  const back = await afc.readWholeFile(remotePath)
  if (back.length !== data.length) {
    throw new Error(
      `house_arrest: ${remotePath} is ${back.length} bytes after the write, expected ${data.length}`,
    )
  }
  return back.length
}

/** The file at `remotePath`, or null when there is none. Any other failure is thrown. */
async function readIfPresent(afc: AfcClient, remotePath: string): Promise<Bytes | null> {
  try {
    await afc.info(remotePath)
  } catch (error) {
    if (error instanceof AfcError && error.code === AFC_ERROR.ObjectNotFound) return null
    throw error
  }
  return afc.readWholeFile(remotePath)
}

/** Creates every parent directory of `remotePath`; one that already exists fails and is ignored. */
async function makeDirectories(afc: AfcClient, remotePath: string): Promise<void> {
  const parts = remotePath.split("/").filter(part => part.length > 0).slice(0, -1)
  let path = ""
  for (const part of parts) {
    path += `/${part}`
    try {
      await afc.makeDir(path)
    } catch {
      // Already there.
    }
  }
}
