// installation_proxy: the service that actually installs the app.
//
// Two details decide whether an install works:
//   - `PackageType: "Developer"`, without which installd never reads the embedded profile and
//     rejects the upload at VerifyingApplication;
//   - `PackagePath` is the path *AFC* sees, i.e. `/PublicStaging/<name>.app`, not a local path.
import { plistNumber, type PlistDict, type PlistValue } from "../util"
import { PlistStream, rsdCheckin, type ByteStream } from "./stream"

export interface InstallProgress {
  /** 0..100 when the device reports it. */
  percent: number | null
  status: string
}

export interface InstallOptions {
  /** Called for every progress plist the device streams. */
  onProgress?: (progress: InstallProgress) => void
}

/** What installd streams back while it works. */
export interface InstallStatus {
  done: boolean
  error: string | null
  percent: number | null
  status: string
}

/**
 * Reads one status plist.
 *
 * `ErrorDescription` is checked **first**, before `Status`: a failure arrives with a status too,
 * and trusting the status would report a broken install as progress.
 */
export function readInstallStatus(dict: PlistDict): InstallStatus {
  const percent = dict.PercentComplete
  const status = dict.Status
  return {
    done: false,
    error: failureFrom(dict),
    // installation_proxy reports the percent as a plist real, so `typeof === "number"` would
    // have dropped every progress update.
    percent: plistNumber(percent),
    status: typeof status === "string" ? status : "",
  }
}

/**
 * The device's own words for a reply it refused, read the way the reference reader reads them: any
 * `Error` at all — a string or a code — makes the reply a failure, and `ErrorString`
 * names it when the code alone would not.
 *
 * Waiting for `ErrorDescription` alone means a refusal that carries only a code is read as another
 * progress line, and the install loop spins until the link drops instead of stopping with the
 * device's reason.
 */
function failureFrom(dict: PlistDict): string | null {
  const error = dict.Error
  const description = dict.ErrorDescription
  const named: string | null =
    typeof error === "string" && error.length > 0 ? error
      : typeof error === "number" ? String(error)
        : null

  if (named === null) {
    // No `Error` key: a bare description is still a failure, and nothing else is.
    return typeof description === "string" && description.length > 0 ? description : null
  }
  const detail = dict.ErrorString
  const message = typeof detail === "string" && detail.length > 0 ? detail : named
  return typeof description === "string" && description.length > 0 ? `${message} (${description})` : message
}

/** The install command, with the one option this project passes. */
export function installCommand(packagePath: string): PlistDict {
  return {
    Command: "Install",
    ClientOptions: { PackageType: "Developer" },
    PackagePath: packagePath,
  }
}

/** Reading the installed apps, which needs no options at all. */
export function lookupCommand(bundleIds?: string[]): PlistDict {
  const options: PlistDict = { ApplicationType: "Any" }
  if (bundleIds !== undefined && bundleIds.length > 0) options.BundleIDs = bundleIds
  return { Command: "Lookup", ClientOptions: options }
}

/**
 * The `/PublicStaging/<name>.app` path for a bundle directory.
 *
 * The name is the bundle's own filename, which is what installd expects to find; it is not
 * derived from the bundle identifier.
 */
export function stagingPath(bundleName: string): string {
  const trimmed = bundleName.replace(/^\/+|\/+$/g, "")
  if (trimmed.length === 0) throw new Error("installation_proxy: empty bundle name")
  return `/PublicStaging/${trimmed}`
}

export class InstallationProxy {
  private readonly plists: PlistStream

  private constructor(private readonly stream: ByteStream) {
    this.plists = new PlistStream(stream)
  }

  static async connect(stream: ByteStream, label: string): Promise<InstallationProxy> {
    await rsdCheckin(stream, label)
    return new InstallationProxy(stream)
  }

  /** Closes the connection, when the transport has one. */
  async disconnect(): Promise<void> {
    if (this.stream.close !== undefined) await this.stream.close()
  }

  /**
   * Installs a bundle already uploaded to `/PublicStaging`, streaming progress until the device
   * says it is done or reports an error.
   */
  async install(packagePath: string, options: InstallOptions = {}): Promise<void> {
    await this.plists.send(installCommand(packagePath))

    for (;;) {
      const dict = await this.plists.receive()
      if (dict === null) throw new Error("installation_proxy: the device closed before reporting a result")

      const status = readInstallStatus(dict)
      options.onProgress?.({ percent: status.percent, status: status.status })

      if (status.error !== null) {
        throw new Error(`installation_proxy: ${status.error}`)
      }
      if (status.status === "Complete") return
      // Any other status ("CreatingStagingDirectory", "InstallingPackage", …) means keep going.
    }
  }

  /** The installed apps, keyed by bundle identifier. */
  async lookup(bundleIds?: string[]): Promise<Record<string, PlistDict>> {
    await this.plists.send(lookupCommand(bundleIds))
    const dict = await this.plists.receive()
    if (dict === null) throw new Error("installation_proxy: no reply to Lookup")
    const result = dict.LookupResult
    if (result === null || typeof result !== "object" || Array.isArray(result) || result instanceof Uint8Array) {
      throw new Error("installation_proxy: Lookup reply carried no LookupResult dictionary")
    }
    return result as Record<string, PlistDict>
  }

  /** True when the bundle identifier is installed. */
  async isInstalled(bundleId: string): Promise<boolean> {
    const apps = await this.lookup([bundleId])
    return Object.prototype.hasOwnProperty.call(apps, bundleId)
  }
}

export type { PlistValue }
