// Getting a signed bundle onto the device: enumerate it, stream it into `/PublicStaging`, then ask
// `installation_proxy` to install it.
//
// The upload is deliberately file-at-a-time rather than "read the whole tree into memory and send
// it": a signed app is tens of megabytes, and the runtime's own byte reader returns an ArrayBuffer
// per call, so holding them all would be the one place this project could exhaust memory.
import type { Bytes } from "../util"
import type { AfcClient, UploadOptions } from "./afc"
import { uploadTree } from "./afc"
import type { InstallationProxy } from "./installation"
import { stagingPath } from "./installation"

function fs(): any {
  const manager: any = (globalThis as any).FileManager
  if (manager === undefined) throw new Error("deploy: this build has no FileManager")
  return manager
}

export interface BundleContents {
  /** Files, relative paths, each read lazily. */
  files: Array<{ path: string, bytes: number, read: () => Promise<Bytes> }>
  /** Directories, relative paths. */
  directories: string[]
  totalBytes: number
}

/**
 * Walks a bundle and describes it without reading it.
 *
 * Sizes come from `statSync` so the progress total is known before anything is read.
 */
export function describeBundle(root: string): BundleContents {
  const manager = fs()
  const files: BundleContents["files"] = []
  const directories: string[] = []
  let totalBytes = 0

  const walk = (relative: string) => {
    const absolute = relative === "" ? root : `${root}/${relative}`
    const names = (manager.readDirectorySync(absolute) as string[]).slice().sort()
    for (const name of names) {
      if (name === "." || name === "..") continue
      const child = relative === "" ? name : `${relative}/${name}`
      const childAbsolute = `${root}/${child}`
      if (manager.isDirectorySync(childAbsolute)) {
        directories.push(child)
        walk(child)
        continue
      }
      const size = Number(manager.statSync(childAbsolute).size ?? 0)
      totalBytes += size
      files.push({
        path: child,
        bytes: size,
        read: async () => {
          const raw = manager.readAsBytesSync(childAbsolute)
          return raw instanceof Uint8Array ? raw : new Uint8Array(raw as ArrayBuffer)
        },
      })
    }
  }
  walk("")

  return { files, directories, totalBytes }
}

export interface DeployOptions {
  /**
   * The bundle's FILE NAME under `/PublicStaging`, extension included: `"SideStore.app"` stages to
   * `/PublicStaging/SideStore.app`. The extension is not added for you, because a nested bundle
   * can be a `.appex` or a `.framework` and guessing which would be wrong half the time.
   */
  bundleName: string
  onProgress?: (file: string, done: number, total: number) => void
}

export interface DeployResult {
  stagingPath: string
  files: number
  bytes: number
}

/**
 * Uploads a signed bundle and installs it.
 *
 * `install` is only called after every byte has landed, because `installation_proxy` copies from
 * `/PublicStaging` itself: a partial tree would install a truncated app, and the device reports
 * that as an unhelpful "package could not be found".
 */
export async function deployBundle(
  appPath: string,
  client: AfcClient,
  installer: InstallationProxy,
  options: DeployOptions,
): Promise<DeployResult> {
  const contents = describeBundle(appPath)
  const remote = stagingPath(options.bundleName)

  // The staging directory itself, before anything goes into it. `describeBundle` lists only what is
  // *inside* the bundle, and a nested `mkdir` does not create its parents, so without this line every
  // file is opened in a directory that does not exist. Upstream creates exactly this one, and nothing
  // else (isideload's `install.rs`, `ensure_public_staging` in idevice).
  //
  // An earlier run's tree is removed first rather than overwritten file by file: a half-uploaded
  // bundle left behind would be installed as a truncated app.
  if (await client.exists(remote)) await client.removePathAndContents(remote)
  await client.makeDir(remote)

  const uploadOptions: UploadOptions = {}
  if (options.onProgress !== undefined) {
    uploadOptions.onProgress = progress => {
      options.onProgress?.(progress.path, progress.bytes, progress.totalBytes)
    }
  }

  const uploaded = await uploadTree(
    client, remote, contents.files, contents.directories, uploadOptions,
  )

  await installer.install(remote, {
    onProgress: progress => {
      options.onProgress?.(progress.status, progress.percent ?? 0, 100)
    },
  })

  return { stagingPath: remote, files: uploaded.files, bytes: uploaded.bytes }
}
