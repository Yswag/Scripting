// house_arrest: an installed app's container, handed over as an AFC volume.
//
// One command plist in, one reply out, and the connection the reply arrives on is an AFC client
// rooted at that container. `VendDocuments` roots it at the container too — Documents is the one
// writable folder under that root — so a path into it carries the `/Documents/` prefix, and the
// container root itself is read-only. The vend consumes the service: there is no second check-in.
import { AfcClient } from "./afc"
import { PlistStream, SERVICES, rsdCheckin, type ByteStream } from "./stream"

/** Which of the app's folders the device hands over. */
export type ContainerScope = "documents" | "container"

/** What reaching a container needs of the device link: one fresh connection per service. */
export interface ServiceOpener {
  open: (serviceName: string) => Promise<ByteStream>
}

const VEND_COMMAND: Record<ContainerScope, string> = {
  documents: "VendDocuments",
  container: "VendContainer",
}

export class HouseArrestClient {
  private readonly plists: PlistStream

  private constructor(private readonly stream: ByteStream) {
    this.plists = new PlistStream(stream)
  }

  static async connect(stream: ByteStream, label: string): Promise<HouseArrestClient> {
    await rsdCheckin(stream, label)
    return new HouseArrestClient(stream)
  }

  /**
   * Vends the app's container and returns the AFC client on the same connection.
   *
   * The reply is read here because a refusal arrives in it — `ApplicationLookupFailed` when no app
   * on the device carries that bundle id.
   */
  async vend(bundleId: string, scope: ContainerScope = "documents"): Promise<AfcClient> {
    const command = VEND_COMMAND[scope]
    await this.plists.send({ Command: command, Identifier: bundleId })

    const reply = await this.plists.receive()
    if (reply === null) {
      throw new Error(`house_arrest: the device closed without answering ${command} for ${bundleId}`)
    }
    const refusal = reply.Error
    if (typeof refusal === "string" && refusal.length > 0) {
      throw new Error(`house_arrest: ${command} for ${bundleId} was refused: ${refusal}`)
    }
    return AfcClient.fromStream(this.stream)
  }
}

/**
 * Runs `body` against `bundleId`'s container on a connection of its own, then closes it.
 *
 * `container` reaches everything under the container root, which the device allows for an app
 * signed for development; `documents` is the one writable folder that works regardless.
 */
export async function withAppContainer<T>(
  link: ServiceOpener,
  bundleId: string,
  scope: ContainerScope,
  body: (afc: AfcClient) => Promise<T>,
): Promise<T> {
  const stream = await link.open(SERVICES.houseArrest)
  try {
    const houseArrest = await HouseArrestClient.connect(stream, `house_arrest: ${bundleId}`)
    return await body(await houseArrest.vend(bundleId, scope))
  } finally {
    if (stream.close !== undefined) await stream.close()
  }
}
