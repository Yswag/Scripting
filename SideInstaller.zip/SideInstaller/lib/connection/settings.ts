// The device link's settings: which VPN provides the reflection, and where the device answers.
//
// The address is only written down because a proxy tool's reflection cannot be read the way
// Scripting's own can: `localDevVPN` reports its own alias, and a proxy tool's is not ours to ask
// for. 10.7.0.1 is the convention the other sideloading tools address the device at.

export type TunnelSource = "builtIn" | "proxyApp"

export interface ConnectionSettings {
  /** builtIn: Scripting's own VPN reflects. proxyApp: a proxy tool (Surge, Loon) reflects. */
  source: TunnelSource
  /** The device's address under the reflection, used when the proxy tool provides it. */
  host: string
}

const KEY = "connection.v1"

export const DEFAULT_DEVICE_HOST = "10.7.0.1"

/** Trims, and falls back unless it is a dotted-quad IPv4 — a stray space must not break the link. */
export function normalizeHost(text: string): string {
  const host = text.trim()
  const parts = host.split(".")
  const valid = parts.length === 4 && parts.every(part => /^\d{1,3}$/.test(part) && Number(part) <= 255)
  return valid ? host : DEFAULT_DEVICE_HOST
}

export function loadConnectionSettings(): ConnectionSettings {
  const stored = Storage.get<Partial<ConnectionSettings>>(KEY)
  return {
    source: stored?.source === "proxyApp" ? "proxyApp" : "builtIn",
    host: normalizeHost(stored?.host ?? DEFAULT_DEVICE_HOST),
  }
}

export function saveConnectionSettings(settings: ConnectionSettings): void {
  Storage.set(KEY, {
    source: settings.source === "proxyApp" ? "proxyApp" : "builtIn",
    host: normalizeHost(settings.host),
  })
}
