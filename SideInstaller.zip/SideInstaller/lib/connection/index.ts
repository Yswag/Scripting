// The device link's settings: which VPN provides the reflection, and the device's address.
export {
  DEFAULT_DEVICE_HOST, loadConnectionSettings, normalizeHost, saveConnectionSettings,
  type ConnectionSettings, type TunnelSource,
} from "./settings"
