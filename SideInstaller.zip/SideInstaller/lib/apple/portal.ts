// The developer portal: developerservices2 — the legacy Xcode "REST" API, plist in and out.
import { Bytes, randomBytes, toHex } from "../util"
import { PlistDict, str } from "../util"
import { AnisetteServer } from "./anisette"
import {
  AppleHttpError, AppleRequest, AppleResponse, HeaderMap, HeaderSource, PortalError, bytesField,
  checkPortalResult, dateField, dictField, intField, listField, parseBarePlist, requireStr, send, xmlBytes,
} from "./http"

export const DEV_HOST = "developerservices2.apple.com"
export const DEV_BASE = `https://${DEV_HOST}`
/** What identifies us to the portal as Xcode. Not decorative: `.action` 404s without it. */
export const DEV_CLIENT_ID = "XABBG36SBA"
export const DEV_PROTOCOL = "QH65B2"

export const XCODE_VERSION = "14.2 (14C18)"
export const APP_INFO = "com.apple.gs.xcode.auth"

/**
 * `device_type` is a path segment, not decoration: `listTeams` is the one endpoint with an
 * empty segment, everything else 404s without its platform.
 */
export function portalUrl(endpoint: string, deviceType = "ios/"): string {
  return `${DEV_BASE}/services/${DEV_PROTOCOL}/${deviceType}${endpoint}.action?clientId=${DEV_CLIENT_ID}`
}

/**
 * Apple's `resultCode` vocabulary for this chain.
 *
 * One code means two things: 35 is "already registered" from `addDevice` and "invalid value" from
 * `addAppId`, so the callers that can see either pass their own gloss instead of relying on this.
 */
export const PORTAL_ERRORS: Record<number, string> = {
  1100: "Your session has expired. Please log in.",
  1102: "This account's owner is under age.",
  2160: "This email address has not been verified.",
  35: "This device is already registered with the team.",
  7252: "There is no 'ios' certificate with that serial number.",
  7460: "The maximum number of development certificates has been reached.",
  8220: "This team has no registered devices.",
}

export function describePortalError(code: number, message: string): string {
  const known = PORTAL_ERRORS[code]
  // Apple's own userString already says 1100 and 1102; the point of the table is the codes
  // whose text is opaque (7252, 7460, 8220), so only add a gloss that is new information.
  if (known === undefined || message.includes(known) || known.includes(message)) return message
  return `${message} — ${known}`
}

/**
 * `addAppId`'s own vocabulary, which shares a code with `addDevice` and means the opposite thing.
 *
 * 35 from `addDevice` is "this device is already on the team"; from `addAppId` it is "this name is
 * not acceptable", which is why the table's wording would be actively misleading here.
 */
export function describeAppIdError(code: number, message: string): string {
  if (code === 35) {
    return `${message} — an App ID name may only contain ASCII letters and digits.`
  }
  return describePortalError(code, message)
}

/**
 * A UUIDv4, uppercased, fresh per request. Unlike the anisette device id, this one *does*
 * stamp the version and variant bits — the portal expects a real v4 and the bytes are ours
 * to choose, whereas the device id has to echo Apple's identifier verbatim.
 */
export function requestId(bytes: Bytes = randomBytes(16)): string {
  const b = new Uint8Array(bytes)
  b[6] = (b[6] & 0x0f) | 0x40
  b[8] = (b[8] & 0x3f) | 0x80
  const hex = toHex(b)
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20, 32)}`.toUpperCase()
}

/** Every legacy call has this prepended to its own fields. */
export function envelope(fields: PlistDict = {}): PlistDict {
  return {
    clientId: DEV_CLIENT_ID,
    protocolVersion: DEV_PROTOCOL,
    requestId: requestId(),
    userLocale: ["en_US"],
    ...fields,
  }
}

export interface Team {
  name: string
  teamId: string
  type: string
  status: string
}

/**
 * A development certificate as the portal lists it.
 *
 * `content` is the DER of the certificate itself, and it is only sent for certificates the account
 * owns — which is what makes "is this one mine?" a question about the public key inside it rather
 * than about the listing.
 */
export interface DeveloperCertificate {
  name: string
  certificateId: string | null
  serialNumber: string | null
  machineId: string | null
  machineName: string | null
  content: Bytes | null
  /** `ios`, `mac`, … — the platform segment the endpoint was called under filters nothing. */
  platform: string
  /** When Apple stops honouring it, or null when the listing left it out. */
  expirationDate: Date | null
}

export interface RegisteredDevice {
  name: string
  deviceId: string | null
  deviceNumber: string
  status: string | null
}

export interface AppId {
  appIdId: string
  identifier: string
  name: string
  /**
   * The App ID's capabilities as the portal states them: feature keys to booleans, e.g.
   * `APG3427HIY` for App Groups. Absent keys mean off.
   */
  features: PlistDict
}

export interface AppIdListing {
  appIds: AppId[]
  /** How many App IDs the account may hold in total, and how many are left. */
  maxQuantity: number | null
  availableQuantity: number | null
}

/**
 * The portal's capability key for App Groups on an App ID (`app_ids.rs`: `ensure_group_feature`).
 *
 * Without it the App ID may not hold a group at all, and the profile cut from it grants no
 * `com.apple.security.application-groups` whatever was assigned.
 */
export const APP_GROUP_FEATURE = "APG3427HIY"

/** A team's App Group, as the portal lists it. */
export interface AppGroup {
  name: string | null
  /** The identifier that was asked for. */
  identifier: string
  /** The portal's own name for it, which is what an assignment and a profile carry. */
  applicationGroup: string
}

/** A `.mobileprovision` straight from the portal. */
export interface ProvisioningProfileReply {
  /** The CMS envelope, byte for byte as Apple signed it. `lib/sign/provisioning.ts` reads it. */
  encodedProfile: Bytes
  filename: string
  uuid: string
  name: string
}

/** What a request is carried by. Injected so a test can answer in memory instead of over the wire. */
export type PortalTransport = (req: AppleRequest, anisette?: HeaderSource) => Promise<AppleResponse>

/**
 * The name to register an App ID under.
 *
 * Apple refuses anything but ASCII letters and digits ("invalid value for the parameter
 * 'appIdName'") and the name is the bundle's `CFBundleName`, so an IPA called "YouTube Music+" or
 * "微信" cannot be registered as it stands. Both reference implementations strip it down the same
 * way, and an empty result still needs a name.
 */
export function normalizeAppIdName(name: string): string {
  const normalized = name.replace(/[^A-Za-z0-9]/g, "")
  return normalized === "" ? "App" : normalized
}

/** Reads one entry of a list field, or null for anything that is not a dictionary. */
function dictEntry(entry: unknown): PlistDict | null {
  if (entry === null || typeof entry !== "object" || Array.isArray(entry)
    || entry instanceof Uint8Array) return null
  return entry as PlistDict
}

/** An App ID out of any reply that carries one (`listAppIds`'s entries, `addAppId`, `updateAppId`). */
function parseAppId(dict: PlistDict, fallbackIdentifier: string, fallbackName: string): AppId {
  const id = str(dict, "appIdId")
  if (id === undefined) throw new Error("the portal replied with an App ID that has no id")
  return {
    appIdId: id,
    identifier: str(dict, "identifier") ?? fallbackIdentifier,
    name: str(dict, "name") ?? fallbackName,
    features: dictField(dict, "features") ?? {},
  }
}

/** An App Group out of a reply that carries one. */
function parseAppGroup(dict: PlistDict, fallbackIdentifier: string): AppGroup {
  const identifier = str(dict, "identifier") ?? fallbackIdentifier
  return {
    name: str(dict, "name") ?? null,
    identifier,
    applicationGroup: str(dict, "applicationGroup") ?? identifier,
  }
}

export class PortalClient {
  constructor(
    readonly anisette: AnisetteServer,
    readonly token: string,
    readonly adsid: string,
    readonly transport: PortalTransport = send,
  ) {}

  /**
   * The portal credential is the pair (token, adsid), sent under `X-Apple-GS-Token` and
   * `X-Apple-I-Identity-Id` — not the `X-Apple-Identity-Token` the 2FA pages use. The three
   * anisette headers come fresh from the server for every request.
   */
  headers(plist = true): HeaderMap {
    const headers: HeaderMap = {}
    if (plist) {
      headers["Content-Type"] = "text/x-xml-plist"
      headers["Accept"] = "text/x-xml-plist"
    }
    headers["X-Mme-Client-Info"] = this.anisette.clientInfo.clientInfo
    headers["User-Agent"] = this.anisette.clientInfo.userAgent
    headers["X-Xcode-Version"] = XCODE_VERSION
    headers["X-Apple-App-Info"] = APP_INFO
    headers["X-Apple-GS-Token"] = this.token
    headers["X-Apple-I-Identity-Id"] = this.adsid
    return headers
  }

  async call(
    endpoint: string, fields: PlistDict = {}, deviceType = "ios/",
    gloss: (code: number, message: string) => string = describePortalError,
  ): Promise<PlistDict> {
    const url = portalUrl(endpoint, deviceType)
    const res = await this.transport({
      method: "POST",
      url,
      headers: this.headers(),
      body: xmlBytes(envelope(fields)),
      timeoutSeconds: 60,
      label: `portal ${endpoint}`,
    }, this.anisette)
    if (res.status !== 200) throw new AppleHttpError(res.status, url)
    return checkPortalResult(parseBarePlist(res.body), gloss)
  }

  /** One endpoint's reply, already unwrapped from the key it hides under. */
  private async action(
    endpoint: string, fields: PlistDict, key: string,
    gloss?: (code: number, message: string) => string,
  ): Promise<any> {
    const response = await this.call(endpoint, fields, "ios/", gloss)
    const value = response[key]
    if (value === undefined || value === null) {
      // A 200 with the key missing is not a success: it is Apple answering a different question,
      // and the caller would otherwise act on an empty list.
      throw new Error(`the portal's ${endpoint} reply had no '${key}'`)
    }
    return value
  }

  /**
   * The cheapest authenticated call, and the one that distinguishes "the token works" from
   * "the token has expired" cleanly: with a bad token Apple answers `resultCode` 1100
   * rather than a 404 or an unparseable body. An empty list means the account has never
   * accepted the free developer agreement.
   */
  async listTeams(): Promise<Team[]> {
    const response = await this.call("listTeams", {}, "")
    const teams = listField(response, "teams") ?? []
    const out: Team[] = []
    for (const entry of teams) {
      if (entry === null || typeof entry !== "object" || Array.isArray(entry) || entry instanceof Uint8Array) continue
      const team = entry as PlistDict
      out.push({
        name: str(team, "name") ?? "",
        teamId: requireStr(team, "teamId", "a team"),
        type: str(team, "type") ?? "",
        status: str(team, "status") ?? "",
      })
    }
    return out
  }

  // MARK: - certificates

  /**
   * Every development certificate on the team, cross-platform ones included.
   *
   * Only some of these can sign an iOS bundle, so a caller that wants to sign takes
   * `listCertificates` instead. Revoking needs this unfiltered view: a certificate Apple refuses to
   * revoke by serial is usually one of the cross-platform ones.
   */
  async listAllDevelopmentCertificates(teamId: string): Promise<DeveloperCertificate[]> {
    const entries = await this.action("listAllDevelopmentCerts", { teamId }, "certificates")
    const out: DeveloperCertificate[] = []
    for (const entry of Array.isArray(entries) ? entries : []) {
      const cert = dictEntry(entry)
      if (cert === null) continue
      const type = dictField(cert, "certificateType")
      const platform = str(cert, "certificatePlatform")
        ?? (type === undefined ? undefined : str(type, "platform")) ?? "ios"
      out.push({
        name: str(cert, "name") ?? "",
        certificateId: str(cert, "certificateId") ?? null,
        serialNumber: str(cert, "serialNumber") ?? null,
        machineId: str(cert, "machineId") ?? null,
        machineName: str(cert, "machineName") ?? null,
        content: bytesField(cert, "certContent") ?? null,
        platform,
        expirationDate: dateField(cert, "expirationDate") ?? null,
      })
    }
    return out
  }

  /**
   * The ones that can sign an iOS bundle: the cross-platform "Apple Development" certificates
   * Xcode makes are not all usable here.
   *
   * The filter matches the reference implementations': the platform field, else the type's
   * platform, else assume iOS.
   */
  async listCertificates(teamId: string): Promise<DeveloperCertificate[]> {
    const all = await this.listAllDevelopmentCertificates(teamId)
    return all.filter(certificate => certificate.platform.toLowerCase() === "ios")
  }

  /**
   * Submits a CSR and returns the `certRequestId`, which is the only way to find the certificate
   * afterwards: the reply carries an id and nothing else.
   *
   * `machineName` and `machineId` are how a client recognises its own certificates later, so a
   * caller that intends to reuse one has to send the same name every time. The id is a fresh v4
   * UUID per request in both reference implementations, and only its presence is ever checked.
   */
  async submitDevelopmentCSR(teamId: string, csrPem: string, machineName: string): Promise<string> {
    const request: PlistDict = await this.action("submitDevelopmentCSR", {
      teamId, csrContent: csrPem, machineName, machineId: requestId(),
    }, "certRequest")
    const id = str(request, "certRequestId")
    if (id === undefined) throw new Error("the portal issued no certRequestId")
    return id
  }

  /**
   * Revokes a certificate by serial number.
   *
   * Irreversible, and every app already signed with that certificate stops launching — including
   * apps this project never touched. The caller is expected to have asked a person first.
   */
  async revokeCertificate(teamId: string, serialNumber: string): Promise<void> {
    try {
      await this.call("revokeDevelopmentCert", { teamId, serialNumber })
      return
    } catch (error) {
      // 7252 …: the per-platform endpoint only revokes its own kind of certificate, and the
      // cross-platform "Apple Development" ones Xcode makes are not it. Those are deleted by id
      // instead. A serial the team does not hold at all is a real refusal, and Apple's stands.
      if (!(error instanceof PortalError) || error.code !== 7252) throw error
      const wanted = serialNumber.toLowerCase()
      const listed = await this.listAllDevelopmentCertificates(teamId)
      const match = listed.find(certificate => (certificate.serialNumber ?? "").toLowerCase() === wanted)
      if (match === undefined || match.certificateId === null) throw error
      await this.deleteCertificate(teamId, match.certificateId)
    }
  }

  /**
   * Deletes one certificate by id, whatever kind it is.
   *
   * Xcode's `services/v1` is a different API from the `.action` endpoints: it is always POSTed,
   * the real method rides in `X-HTTP-Method-Override`, the query goes in the body, and both sides
   * speak JSON.
   */
  async deleteCertificate(teamId: string, certificateId: string): Promise<void> {
    const url = `${DEV_BASE}/services/v1/certificates/${certificateId}`
    const headers = this.headers(false)
    headers["Content-Type"] = "application/vnd.api+json"
    headers["Accept"] = "application/vnd.api+json"
    headers["X-HTTP-Method-Override"] = "DELETE"
    const response = await this.transport({
      method: "POST",
      url,
      headers,
      json: { urlEncodedQueryParams: `teamId=${teamId}` },
      timeoutSeconds: 60,
      label: `portal certificates/${certificateId}`,
    }, this.anisette)
    // A delete answers 204 with no content; anything else is Apple refusing it.
    if (response.status !== 200 && response.status !== 204) throw new AppleHttpError(response.status, url)
  }

  // MARK: - devices

  async listDevices(teamId: string): Promise<RegisteredDevice[]> {
    const entries = await this.action("listDevices", { teamId }, "devices")
    const out: RegisteredDevice[] = []
    for (const entry of Array.isArray(entries) ? entries : []) {
      const device = dictEntry(entry)
      if (device === null) continue
      const number = str(device, "deviceNumber")
      if (number === undefined) continue
      out.push({
        name: str(device, "name") ?? "",
        deviceId: str(device, "deviceId") ?? null,
        deviceNumber: number,
        status: str(device, "status") ?? null,
      })
    }
    return out
  }

  /**
   * Registers this device under the team, unless it is already there.
   *
   * 35 from `addDevice` means "already registered", which is not a failure; the caller is still
   * told which of the two happened, because "registered your iPhone" and "your iPhone was already
   * registered" are different sentences to put in front of a person.
   */
  async ensureDeviceRegistered(
    teamId: string, name: string, udid: string,
  ): Promise<"added" | "already-registered"> {
    const devices = await this.listDevices(teamId)
    if (devices.some(device => device.deviceNumber === udid)) return "already-registered"
    try {
      await this.action("addDevice", { teamId, name, deviceNumber: udid }, "device")
    } catch (error) {
      if (error instanceof PortalError && error.code === 35) return "already-registered"
      throw error
    }
    return "added"
  }

  // MARK: - App IDs and the profile built from them

  /**
   * The team's App IDs and what is left of its quota.
   *
   * `availableQuantity` is the number worth showing: on a free account the slots expire after
   * seven days, so an account that has been used before can be full with nothing to show for it.
   */
  async listAppIds(teamId: string): Promise<AppIdListing> {
    const response = await this.call("listAppIds", { teamId })
    const appIds: AppId[] = []
    for (const entry of listField(response, "appIds") ?? []) {
      const appId = dictEntry(entry)
      if (appId === null) continue
      if (str(appId, "identifier") === undefined) continue
      appIds.push(parseAppId(appId, "", ""))
    }
    return {
      appIds,
      maxQuantity: intField(response, "maxQuantity") ?? null,
      availableQuantity: intField(response, "availableQuantity") ?? null,
    }
  }

  /**
   * Adds an App ID, which is what a profile is cut for.
   *
   * The name goes through `normalizeAppIdName` first: this endpoint's 35 means the value was
   * invalid, which is the opposite of what 35 means from `addDevice`.
   */
  async addAppId(teamId: string, identifier: string, name: string): Promise<AppId> {
    const created = dictEntry(await this.action("addAppId", {
      teamId, identifier, name: normalizeAppIdName(name),
    }, "appId", describeAppIdError))
    if (created === null) throw new Error("the portal created an App ID and replied with something else")
    return parseAppId(created, identifier, normalizeAppIdName(name))
  }

  // MARK: - App Groups

  /**
   * The team's App Groups.
   *
   * A profile only grants `com.apple.security.application-groups` when the group exists **and** is
   * assigned to the App ID the profile is cut for, so an app that keeps its data in one needs this
   * to have happened before its profile is downloaded.
   */
  async listAppGroups(teamId: string): Promise<AppGroup[]> {
    const entries = await this.action("listApplicationGroups", { teamId }, "applicationGroupList")
    const out: AppGroup[] = []
    for (const entry of Array.isArray(entries) ? entries : []) {
      const group = dictEntry(entry)
      if (group === null) continue
      if (str(group, "identifier") === undefined) continue
      out.push(parseAppGroup(group, ""))
    }
    return out
  }

  async addAppGroup(teamId: string, identifier: string, name: string): Promise<AppGroup> {
    const created = dictEntry(await this.action("addApplicationGroup", {
      teamId, name: normalizeAppIdName(name), identifier,
    }, "applicationGroup"))
    if (created === null) throw new Error("the portal created an App Group and replied with something else")
    return parseAppGroup(created, identifier)
  }

  /** The team's group with this identifier, created when the team has none. */
  async ensureAppGroup(teamId: string, name: string, identifier: string): Promise<AppGroup> {
    const groups = await this.listAppGroups(teamId)
    const existing = groups.find(group => group.identifier === identifier)
    return existing ?? await this.addAppGroup(teamId, identifier, name)
  }

  /**
   * Turns the App Groups capability on for one App ID and returns it as it now stands.
   *
   * The portal states an App ID's capabilities as feature keys, and assigning a group to an App ID
   * that may not hold one leaves the profile without it.
   */
  async ensureAppGroupCapability(teamId: string, appId: AppId): Promise<AppId> {
    if (appId.features[APP_GROUP_FEATURE] === true) return appId
    const updated = dictEntry(await this.action("updateAppId", {
      teamId, appIdId: appId.appIdId, [APP_GROUP_FEATURE]: true,
    }, "appId"))
    if (updated === null) throw new Error("the portal updated an App ID and replied with something else")
    return parseAppId(updated, appId.identifier, appId.name)
  }

  /** Puts the group on the App ID. The next profile cut for it grants the group. */
  async assignAppGroup(teamId: string, group: AppGroup, appIdId: string): Promise<void> {
    await this.call("assignApplicationGroupToAppId", {
      teamId, applicationGroups: group.applicationGroup, appIdId,
    })
  }

  /**
   * The profile for one App ID: a CMS envelope over a plist, which `parseProvisioningProfile`
   * reads. Its expiry comes from that plist rather than from this reply, which is the same truth
   * the device will see.
   */
  async downloadTeamProvisioningProfile(
    teamId: string, appIdId: string,
  ): Promise<ProvisioningProfileReply> {
    const profile: PlistDict = await this.action(
      "downloadTeamProvisioningProfile", { teamId, appIdId }, "provisioningProfile")
    const bytes = bytesField(profile, "encodedProfile")
    if (bytes === undefined) throw new Error("the profile reply had no encodedProfile")
    return {
      encodedProfile: bytes,
      filename: str(profile, "filename") ?? "profile.mobileprovision",
      uuid: str(profile, "UUID") ?? "",
      name: str(profile, "name") ?? "",
    }
  }
}
