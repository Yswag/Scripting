// The `Account.sideconf` hand-off: the certificate, its private key and the anisette identity the
// account signed in with, in the shape SideStore's importer reads.
//
// Why it exists: SideStore can only sign with a certificate whose key it holds. Without this file it
// revokes the certificate that signed it and makes its own on first sign-in, which is the "Resign
// SideStore" prompt. The file is plaintext JSON in a Files-visible folder until it is imported, so
// the Apple ID password is deliberately not in it.
import { toBase64, utf8, type Bytes } from "../util"
import { buildPkcs12, type RsaJwk } from "../sign"

/** The name the importer looks for, relative to the app's Documents. */
export const SIDECONF_FILE_NAME = "Account.sideconf"

/** The format version SideStore's own import writes. */
export const SIDECONF_VERSION = "2.0"

export interface SideconfOptions {
  email: string
  /** The certificate's DER, as the portal handed it over. */
  certificateDer: Bytes
  /** The private key that belongs to it. */
  jwk: RsaJwk
  /** What the archive is protected with — and what the file tells the app it is. */
  password: string
  /** The anisette identity the token was issued to: 16 bytes, and the provisioned ADI blob. */
  anisetteIdentifier: Bytes
  anisetteAdiBlob: Bytes
}

/**
 * The JSON for `Documents/Account.sideconf`.
 *
 * `certType: "encrypted"` is the one that carries a PKCS#12 protected by `certificatePassword`;
 * `"unencrypted"` is the other value the importer knows.
 */
export function buildSideconf(options: SideconfOptions): string {
  const archive = buildPkcs12({
    certificateDer: options.certificateDer,
    jwk: options.jwk,
    password: options.password,
  })
  return JSON.stringify({
    version: SIDECONF_VERSION,
    email: options.email,
    certificateData: toBase64(archive),
    certType: "encrypted",
    certificatePassword: options.password,
    anisetteIdentifier: toBase64(options.anisetteIdentifier),
    anisetteAdiBlob: toBase64(options.anisetteAdiBlob),
  })
}

/** The same, as the bytes that go into the container. */
export function sideconfBytes(options: SideconfOptions): Bytes {
  return utf8(buildSideconf(options))
}

/**
 * A string only the SideStore builds whose importer asks for a file password carry.
 *
 * Two importers are in the wild: one reads `Account.sideconf`, adopts the certificate and deletes the
 * file; the other raises `ImportAccountAlertController`, accepts only its own encrypted format and
 * keeps the file, so a plaintext hand-over would make it ask on **every** launch. Version numbers do
 * not tell them apart, which is why the reference scans the binary for this key
 * (`SideInstaller`'s `Engine.swift`) and hands over nothing to the prompting kind — the same thing
 * iLoader does.
 */
export const PROMPTING_IMPORTER_MARKER = "acctFileChecksum"

/** Whether a SideStore executable imports `Account.sideconf` without asking for a password. */
export function importsAccountConfigSilently(executable: Bytes): boolean {
  return !containsBytes(executable, utf8(PROMPTING_IMPORTER_MARKER))
}

/**
 * A byte search.
 *
 * The binary is tens of megabytes and the needle is ASCII, so the scan skips ahead on the first byte
 * rather than decoding the file to a string, which would double it in memory.
 */
function containsBytes(haystack: Bytes, needle: Bytes): boolean {
  if (needle.length === 0) return true
  const first = needle[0]
  const last = haystack.length - needle.length
  outer: for (let i = 0; i <= last; i++) {
    if (haystack[i] !== first) continue
    for (let j = 1; j < needle.length; j++) {
      if (haystack[i + j] !== needle[j]) continue outer
    }
    return true
  }
  return false
}
