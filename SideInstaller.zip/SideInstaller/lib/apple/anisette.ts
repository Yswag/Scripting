// Anisette remote v3: the device-attestation identity and the per-request headers Apple
// checks. The ADI library behind it is a closed Apple component, so a volunteer server
// runs it and this side only ever handles base64, SHA-256 and JSON.
import { Bytes, fromBase64, fromUtf8, randomBytes, toBase64, toHex } from "../util"
import { canAskPageDirectly, isLocalAnisette, mintLocalHeaders, LOCAL_ROUTING_INFO } from "./local-anisette"
import { PlistDict, asDict, parsePlist } from "../util"
import { hashWith } from "../util"
import { AppleHttpError, HeaderMap, HeaderSource, requireStr, send, xmlBytes } from "./http"

const sha256 = hashWith("SHA-256")

/** How long a set of minted headers is reused: the app's own anisette-data lifetime. */
const ANISETTE_HEADERS_TTL_SECONDS = 60

export const PROVISIONING_PATH = "/v3/provisioning_session"
const PROVISION_TIMEOUT_MS = 30000

/** One server from the community list, serving the device-attestation data Apple checks. */
export interface AnisetteServerEntry {
  name: string
  address: string
}

/** The public list SideStore and iLoader read, which the snapshot below is of. */
const ANISETTE_LIST_URL = "https://servers.sidestore.io/servers.json"

/** Servers on Apple's Windows ADI library that aren't on the community list, added to it. */
const EXTRA_ANISETTE_SERVERS: AnisetteServerEntry[] = [
  { name: "StikStore (Windows ADI)", address: "https://ani2.stikstore.app" },
]

/** Snapshot of the community list, used when the live one can't be fetched. */
export const DEFAULT_ANISETTE_SERVERS: AnisetteServerEntry[] = [
  { name: "SideStore", address: "https://ani.sidestore.io" },
  { name: "SideStore (.app)", address: "https://ani.sidestore.app" },
  { name: "SideStore (.zip)", address: "https://ani.sidestore.zip" },
  { name: "SideStore (.xyz)", address: "https://ani.846969.xyz" },
  { name: "SideStore (New)", address: "https://new.ani.sidestore.io" },
  { name: "SideStore (Windows ADI)", address: "https://win.ani.sidestore.io" },
  { name: "jkcoxson", address: "https://mac-ani.jkcoxson.com" },
  { name: "jkcoxson (Windows ADI)", address: "https://ani.jkcoxson.com" },
  { name: "nythepegasus", address: "https://ani.npeg.us" },
  { name: "Macley", address: "http://5.249.163.88:6969" },
  { name: "WE. Studio", address: "https://anisette.wedotstud.io" },
  { name: "SteX", address: "https://ani.xu30.top" },
  { name: "owoellen", address: "https://ani.owoellen.rocks" },
  { name: "iDH Server", address: "https://ani.idevicehacked.com" },
  { name: "neoarz", address: "https://ani.neoarz.com" },
  { name: "pythonplayer123", address: "https://ani3server.fly.dev" },
  { name: "Jayden's Server", address: "https://ani.jaydenha.uk" },
  { name: "crystall1nedev's server", address: "https://anisette.crystall1ne.dev" },
  { name: "ethxn's omnisette server :3", address: "https://omni.ethxn.xyz" },
  ...EXTRA_ANISETTE_SERVERS,
]

/** The default server for a first sign-in, and the fallback when a saved one can't be honoured. */
export const FALLBACK_ANISETTE_URL = "https://ani.jkcoxson.com"

/** The default until 1.5.2, on Apple's Android ADI library. */
export const LEGACY_DEFAULT_ANISETTE_URL = "https://ani.sidestore.io"

/**
 * The community list, or the snapshot when it can't be fetched. The Windows-ADI servers the app
 * knows about that aren't on it are appended, so they are there either way.
 */
export async function fetchAnisetteServers(): Promise<{ servers: AnisetteServerEntry[]; live: boolean }> {
  try {
    const res = await send({
      method: "GET",
      url: ANISETTE_LIST_URL,
      headers: { "User-Agent": "SideInstaller" },
      timeoutSeconds: 15,
      label: "anisette server list",
    })
    if (res.status !== 200) throw new AppleHttpError(res.status, ANISETTE_LIST_URL)
    const payload: any = JSON.parse(fromUtf8(res.body))
    const listed: AnisetteServerEntry[] = (payload?.servers ?? [])
      .map((entry: any) => ({ name: String(entry?.name ?? ""), address: String(entry?.address ?? "") }))
      .filter((entry: AnisetteServerEntry) => entry.address !== "")
    if (listed.length === 0) throw new Error("the anisette server list was empty")
    const have = new Set(listed.map(entry => normalizedAddress(entry.address)))
    const extras = EXTRA_ANISETTE_SERVERS.filter(extra => !have.has(normalizedAddress(extra.address)))
    return { servers: [...listed, ...extras], live: true }
  } catch {
    return { servers: DEFAULT_ANISETTE_SERVERS, live: false }
  }
}

/** An address as the app compares them: no surrounding space, no trailing slash, lower case. */
function normalizedAddress(address: string): string {
  return address.trim().replace(/\/+$/, "").toLowerCase()
}

/**
 * The Apple ADI library a server makes its anisette data with. An identity is provisioned through
 * one server and works with every server on the same library, while the others answer -45061 — so
 * a server is only worth trying as a fallback for the library it runs.
 */
export type AdiLibrary = "mac" | "windows" | "android"

/** The device a sign-in through a server on this library reports to Apple. */
export type ReportedDevice = "mac" | "windows"

/** An identity provisioned through one of these works with all of them (-45061 elsewhere). */
export const WINDOWS_ADI_HOSTS = ["ani.jkcoxson.com", "win.ani.sidestore.io", "ani2.stikstore.app"]

/** Hosts that run Apple's macOS library, which is the one Xcode signs in with. */
export const MAC_ADI_HOSTS = ["mac-ani.jkcoxson.com", "new.ani.sidestore.io"]

/** The host of a server address, lower case, or "" when it isn't a URL. */
function hostOf(address: string): string {
  try {
    return new URL(address).hostname.toLowerCase()
  } catch {
    return ""
  }
}

/**
 * The library `address` runs: a known host's, else what the list's name for it says ("… (Windows
 * ADI)", "… (Mac ADI)"), else Android's.
 *
 * Which library an identity came from is what Apple answers on: -45061 when the server asking was
 * on another one. The older community servers all run Android's and hand out the stock MacBook
 * string nobody signs in as, which `clientInfoToUse` replaces with a Windows PC.
 */
export function adiLibraryOf(url: string, servers: AnisetteServerEntry[] = DEFAULT_ANISETTE_SERVERS): AdiLibrary {
  const key = normalizedAddress(url)
  const host = hostOf(key)
  if (MAC_ADI_HOSTS.includes(host)) return "mac"
  if (WINDOWS_ADI_HOSTS.includes(host)) return "windows"
  const name = servers.find(entry => normalizedAddress(entry.address) === key)?.name.toLowerCase() ?? ""
  if (name.includes("mac adi")) return "mac"
  if (name.includes("windows")) return "windows"
  return "android"
}

/** What Apple's HTTP 503 refusals are counted by; see `AppleRefusals`. */
export function reportedDevice(library: AdiLibrary): ReportedDevice {
  return library === "mac" ? "mac" : "windows"
}

/**
 * The addresses to try, de-duplicated, in the app's own order (`AnisetteServer.candidates`): the
 * pick, then the rest of its library unless that is Android's, then the Windows-ADI servers, then
 * everything that isn't a macOS one, then all of them (the macOS servers last).
 *
 * The pick keeps its anisette identity, and with it the saved token and Apple's trust in that
 * machine, and so do the servers on its library. The Windows servers come before the Android ones
 * because on them the Windows PC sign-in reports is the machine the data comes from. The macOS
 * servers come last: through them Apple took the password of a real account with trusted devices,
 * then asked for a code by text instead of sending one to the devices, and answered the request
 * for it with HTTP 403. Apple refusing one reported device doesn't end the sign-in while servers
 * reporting the other are left (`AppleRefusals`).
 */
export function anisetteCandidates(preferred: string, servers: AnisetteServerEntry[] = DEFAULT_ANISETTE_SERVERS): string[] {
  const seen = new Set<string>()
  const out: string[] = []
  const add = (address: string) => {
    const key = normalizedAddress(address)
    if (key !== "" && !seen.has(key)) {
      seen.add(key)
      out.push(address.trim())
    }
  }
  add(preferred)
  const addresses = servers.map(entry => entry.address)
  const pickLibrary = adiLibraryOf(preferred, servers)
  if (pickLibrary !== "android") addresses.filter(url => adiLibraryOf(url, servers) === pickLibrary).forEach(add)
  addresses.filter(url => adiLibraryOf(url, servers) === "windows").forEach(add)
  addresses.filter(url => adiLibraryOf(url, servers) !== "mac").forEach(add)
  addresses.forEach(add)
  return out
}

/**
 * Apple's HTTP 503 refusals during one sign-in, counted by the device sign-in reports.
 *
 * Apple refuses a reported device the same through every server, so once it has refused one twice
 * the servers left that report it are skipped. One refusal only moves on to the next server, since
 * Apple has also sent a 503 that passed on retry. The sign-in stops when every server left reports
 * a device Apple has refused twice.
 */
export class AppleRefusals {
  /** Refusals so far. */
  count = 0
  private readonly byDevice: Record<ReportedDevice, number> = { mac: 0, windows: 0 }

  constructor(private readonly servers: AnisetteServerEntry[] = DEFAULT_ANISETTE_SERVERS) {}

  /** Counts a refusal of the attempt through `server`. */
  record(server: string): void {
    this.count += 1
    this.byDevice[reportedDevice(adiLibraryOf(server, this.servers))] += 1
  }

  /** Whether a sign-in through `server` would report a device Apple has refused twice already. */
  rulesOut(server: string): boolean {
    return this.byDevice[reportedDevice(adiLibraryOf(server, this.servers))] >= 2
  }

  /** Whether, after a refusal, the sign-in should stop: two refusals, and `remaining` all ruled out. */
  endsSignIn(remaining: string[]): boolean {
    return this.count >= 2 && remaining.every(url => this.rulesOut(url))
  }
}

/**
 * The client info GrandSlam is told when the anisette server's own can't be used. A Windows PC,
 * as iTunes reports itself — what the Windows-ADI servers hand out themselves.
 */
export const GSA_CLIENT_INFO = "<PC> <Windows;6.2(0,0);9200> <com.apple.AuthKit/1 (com.apple.iTunes/12.12.4.1)>"
export const GSA_USER_AGENT = "akd/1.0 CFNetwork/808.1.4"

/** The device-and-OS line of the stock client infos anisette-v3-server and omnisette hand out. */
const STOCK_CLIENTS = ["<MacBookPro13,2> <macOS;13.1;22C65>", "<MacBookPro15,1> <Mac OS X;10.15.2;19C57>"]

/** The server is not provisioned with this identity (ADI error -45061). */
export class AnisetteNotProvisionedError extends Error {}

export interface AnisetteIdentity {
  /** 16 raw bytes: the "identifier" handed to the ADI library. */
  identifier: Bytes
  /** The provisioning blob the ADI library handed back. */
  adiPb: Bytes
}

// MARK: - identity derivations

/**
 * `Uuid::from_bytes(identifier).to_string()`: the 16 bytes go into the string verbatim.
 * This is deliberately NOT a v4 UUID — nothing stamps version/variant bits, and doing so
 * would change the device id GrandSlam sees.
 */
export function deviceIdFromIdentifier(identifier: Bytes): string {
  if (identifier.length !== 16) throw new Error(`anisette: the identifier must be 16 bytes, got ${identifier.length}`)
  const hex = toHex(identifier)
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20, 32)}`
}

/** `X-Apple-I-MD-LU`, sent only while provisioning. */
export function mdLuFromIdentifier(identifier: Bytes): string {
  return toHex(sha256(identifier))
}

export function provisioningHeaders(identifier: Bytes): HeaderMap {
  return {
    "X-Apple-I-MD-LU": mdLuFromIdentifier(identifier),
    "X-Mme-Device-Id": deviceIdFromIdentifier(identifier),
  }
}

// MARK: - client info

export interface AnisetteClientInfo {
  clientInfo: string
  userAgent: string
}

/**
 * Whether a client info is one of the stock strings a stock anisette server advertises, which
 * Apple's edge answers with its own 503 page before GrandSlam reads the request.
 */
function isStockClientInfo(info: string): boolean {
  return STOCK_CLIENTS.some(stock => info.startsWith(stock))
}

/**
 * The client info to tell GrandSlam, given what a server hands out: its own, unless it is a stock
 * one or an Android phone's (which Apple answers with 503) — then a Windows PC.
 *
 * A server that hands out something else made it for the library it runs, as the Windows-ADI
 * servers do and the macOS-ADI ones, and keeps it.
 */
export function clientInfoToUse(advertised: AnisetteClientInfo, shape: SignInShape = "xcode"): AnisetteClientInfo {
  const client = (advertised.clientInfo ?? "").trim()
  // The TestFlight shape is the one the machine on this device was made for: it keeps the
  // description that machine advertises.
  if (shape === "testflight") {
    if (client === "") return { clientInfo: GSA_CLIENT_INFO, userAgent: GSA_USER_AGENT }
    const own = (advertised.userAgent ?? "").trim()
    return { clientInfo: client, userAgent: own === "" ? GSA_USER_AGENT : own }
  }
  if (client === "" || client.includes("<Android;") || isStockClientInfo(client)) {
    return { clientInfo: GSA_CLIENT_INFO, userAgent: GSA_USER_AGENT }
  }
  const userAgent = (advertised.userAgent ?? "").trim()
  return { clientInfo: client, userAgent: userAgent === "" ? GSA_USER_AGENT : userAgent }
}

// MARK: - the shape of a sign-in

/**
 * What a sign-in tells Apple it is. `xcode` is the shape this app has always sent; `testflight`
 * is the one the desktop tool that signs in today sends, and it is what the machine that runs on
 * this device is: an Android device presenting itself over iTunes as TestFlight.
 */
export type SignInShape = "xcode" | "testflight"

export function signInShape(server: string): SignInShape {
  return isLocalAnisette(server) ? "testflight" : "xcode"
}

function toWebSocketUrl(server: string): string {
  return server.replace(/^https:/, "wss:").replace(/^http:/, "ws:")
}

// MARK: - the provisioning socket

/**
 * A one-message-at-a-time view of the provisioning socket. The servers drive the exchange:
 * each `Give*` message is answered, and answering one of the two middle steps means doing
 * an HTTP round trip to Apple first, which is why `next()` has to be awaitable.
 */
class ProvisioningChannel {
  private readonly messages: string[] = []
  private readonly waiters: Array<(message: string | null) => void> = []
  private readonly openWaiters: Array<() => void> = []
  private readonly openFailures: Array<(error: Error) => void> = []
  private openState: "pending" | "open" | "gone" = "pending"

  constructor(private readonly socket: any) {
    socket.onopen = () => {
      this.openState = "open"
      for (const waiter of this.openWaiters.splice(0)) waiter()
    }
    socket.onmessage = (message: any) => {
      this.push(typeof message === "string" ? message : String((message as any)?.toRawString?.() ?? ""))
    }
    socket.onclose = () => this.gone("the provisioning socket closed")
    socket.onerror = () => this.gone("the provisioning socket errored")
  }

  private gone(why: string): void {
    if (this.openState === "pending") {
      this.openState = "gone"
      for (const fail of this.openFailures.splice(0)) fail(new Error(`anisette: ${why}`))
    }
    this.push(null)
  }

  private push(message: string | null): void {
    const waiter = this.waiters.shift()
    if (waiter !== undefined) waiter(message)
    else if (message !== null) this.messages.push(message)
  }

  /**
   * Both of these are deliberately free of timers. Scripting refuses to create one from
   * inside a WebSocket callback — "Timer requires its active script on the main JS execution
   * queue" — and every continuation of this handshake runs in exactly that context. The
   * overall deadline is therefore armed by `provision()` before the socket is opened.
   */
  waitForOpen(): Promise<void> {
    if (this.openState === "open") return Promise.resolve()
    if (this.openState === "gone") return Promise.reject(new Error("anisette: the provisioning socket never opened"))
    return new Promise((resolve, reject) => {
      this.openWaiters.push(resolve)
      this.openFailures.push(reject)
    })
  }

  /** The next text frame, or null once the peer goes away. */
  next(): Promise<string | null> {
    const queued = this.messages.shift()
    if (queued !== undefined) return Promise.resolve(queued)
    if (this.openState === "gone") return Promise.resolve(null)
    return new Promise(resolve => this.waiters.push(resolve))
  }

  sendJson(payload: unknown): void {
    this.socket.send(JSON.stringify(payload))
  }

  close(): void {
    try { this.socket.close(1000, "done") } catch { /* already gone */ }
  }
}

// MARK: - the server

/** A plist POST to GrandSlam, used for the two `mid*Provisioning` legs of the handshake. */
export type PlistPoster = (url: string, body: PlistDict, extraHeaders: HeaderMap) => Promise<PlistDict>

export interface ProvisioningUrls {
  midStartProvisioning: string
  midFinishProvisioning: string
}

/**
 * One anisette server, and the identity used with it. An identity is provisioned through
 * one server and works with every server on the same ADI library; a server on another
 * library answers -45061, which is why the identity a token belongs to is remembered.
 */
export class AnisetteServer implements HeaderSource {
  readonly url: string
  readonly clientInfo: AnisetteClientInfo
  /** Which shape a sign-in through this server takes; see `SignInShape`. */
  readonly shape: SignInShape
  /** Kept because the 2FA pages are the only ones that send `X-Apple-I-MD-RINFO`. */
  routingInfo = "0"
  /** The slot `selectIdentity` chose this server's identity under, for a session to record. */
  slotKey = ""
  identity: AnisetteIdentity
  /** Headers minted within the last minute, which one sign-in's several requests are answered from. */
  private cachedHeaders: HeaderMap | null = null
  private cachedAt = 0

  private constructor(url: string, clientInfo: AnisetteClientInfo, identity: AnisetteIdentity, shape: SignInShape) {
    this.url = url.replace(/\/+$/, "")
    this.clientInfo = clientInfo
    this.identity = identity
    this.shape = shape
  }

  /**
   * Detect the protocol and prepare an identity. v3 answers `/v3/client_info`; a v1 server
   * answers `/` with headers instead, which this port does not implement.
   */
  static async connect(server: string, identity?: AnisetteIdentity): Promise<AnisetteServer> {
    const url = server.replace(/\/+$/, "")
    const res = await send({ method: "GET", url: `${url}/v3/client_info`, timeoutSeconds: 15, label: "anisette client_info" })
    if (res.status !== 200) throw new AppleHttpError(res.status, `${url}/v3/client_info`)
    let payload: any = {}
    try { payload = JSON.parse(fromUtf8(res.body)) } catch { payload = {} }
    if (typeof payload.client_info !== "string" || typeof payload.user_agent !== "string") {
      throw new Error(`${url} is not an anisette v3 server (no client_info)`)
    }
    const shape = signInShape(url)
    const advertised = clientInfoToUse({ clientInfo: payload.client_info, userAgent: payload.user_agent }, shape)
    return new AnisetteServer(url, advertised, identity ?? { identifier: randomBytes(16), adiPb: new Uint8Array(0) }, shape)
  }

  get deviceId(): string {
    return deviceIdFromIdentifier(this.identity.identifier)
  }

  get isProvisioned(): boolean {
    return this.identity.adiPb.length > 0
  }

  /**
   * The WebSocket handshake: Apple's own two provisioning endpoints are called from here,
   * mid-conversation, so this needs the URL bag and a way to POST a plist.
   */
  async provision(urls: ProvisioningUrls, post: PlistPoster): Promise<AnisetteIdentity> {
    const identifier = this.identity.identifier
    const headers = provisioningHeaders(identifier)
    const channel = new ProvisioningChannel(new (globalThis as any).WebSocket(toWebSocketUrl(this.url) + PROVISIONING_PATH))
    // Armed here, on the ordinary queue, for the reason spelled out on the channel.
    let deadline: number | null = null
    const expired = new Promise<never>((_, reject) => {
      deadline = setTimeout(() => reject(new Error("anisette: provisioning timed out")), PROVISION_TIMEOUT_MS)
    })
    try {
      await Promise.race([this.handshake(channel, urls, post, headers, identifier), expired])
      return this.identity
    } finally {
      if (deadline !== null) clearTimeout(deadline)
      channel.close()
    }
  }

  private async handshake(channel: ProvisioningChannel, urls: ProvisioningUrls, post: PlistPoster, headers: HeaderMap, identifier: Bytes): Promise<void> {
    await channel.waitForOpen()
    for (;;) {
      const raw = await channel.next()
      if (raw === null) throw new Error("anisette: the provisioning socket closed before it finished")
      const message: any = JSON.parse(raw)
      switch (message.result) {
        case "GiveIdentifier":
          channel.sendJson({ identifier: toBase64(identifier) })
          break
        case "GiveStartProvisioningData": {
          const reply = await post(urls.midStartProvisioning, { Header: {}, Request: {} }, headers)
          channel.sendJson({ spim: requireStr(reply, "spim", "Apple's start-provisioning reply") })
          break
        }
        case "GiveEndProvisioningData": {
          const reply = await post(
            urls.midFinishProvisioning,
            { Header: {}, Request: { cpim: requireStr(message, "cpim", "the provisioning socket's message") } },
            headers,
          )
          channel.sendJson({
            ptm: requireStr(reply, "ptm", "Apple's end-provisioning reply"),
            tk: requireStr(reply, "tk", "Apple's end-provisioning reply"),
          })
          break
        }
        case "ProvisioningSuccess":
          this.identity = { identifier, adiPb: fromBase64(requireStr(message, "adi_pb", "the provisioning socket's success message")) }
          return
        case "Timeout":
        case "InvalidIdentifier":
          throw new Error(`anisette: provisioning failed (${message.result})`)
        default:
          throw new Error(`anisette: provisioning failed (${message.message ?? message.result ?? raw})`)
      }
    }
  }

  /**
   * The three headers Apple checks. A set minted within the last minute is handed back as it is:
   * a sign-in makes several requests, and the server is not asked again for each of them.
   */
  async headers(): Promise<HeaderMap> {
    if (this.cachedHeaders !== null && Math.floor(Date.now() / 1000) - this.cachedAt <= ANISETTE_HEADERS_TTL_SECONDS) {
      return this.cachedHeaders
    }
    const { identifier, adiPb } = this.identity
    if (adiPb.length === 0) throw new Error("anisette: this identity has not been provisioned")
    const headers = await this.requestHeaders({
      identifier: toBase64(identifier),
      adi_pb: toBase64(adiPb),
    })
    this.cacheHeaders(headers)
    return headers
  }

  /**
   * The `hsc 434` resync: Apple hands the anisette server the blob it needs to finish
   * provisioning this (Windows-)ADI identity, then the same request goes through.
   */
  async headersAfterResync(sim: string): Promise<HeaderMap> {
    const { identifier, adiPb } = this.identity
    if (adiPb.length === 0) throw new Error("anisette: this identity has not been provisioned")
    const headers = await this.requestHeaders({
      identifier: toBase64(identifier),
      adi_pb: toBase64(adiPb),
      sim,
      device_id: this.deviceId,
      md_lu: mdLuFromIdentifier(identifier),
    })
    this.cacheHeaders(headers)
    return headers
  }

  private cacheHeaders(headers: HeaderMap): void {
    this.cachedHeaders = headers
    this.cachedAt = Math.floor(Date.now() / 1000)
  }

  private async requestHeaders(payload: Record<string, string>): Promise<HeaderMap> {
    // The machine on this device is asked directly when that is allowed — a caller that is not on
    // the main thread (a sign-in's anisette call is not) would have WebKit kill the process. The
    // endpoint serves everyone else, and Scripting marshals its handler. The resync payload is
    // Apple's Windows-ADI path, which this machine is not, so it always goes over the endpoint.
    if (isLocalAnisette(this.url) && payload.sim === undefined && canAskPageDirectly()) {
      const minted = await mintLocalHeaders(payload.identifier ?? "", payload.adi_pb ?? "")
      this.routingInfo = LOCAL_ROUTING_INFO
      return {
        "X-Mme-Device-Id": this.deviceId,
        "X-Apple-I-MD": minted.otp,
        "X-Apple-I-MD-M": minted.mid,
      }
    }
    const res = await send({
      method: "POST",
      url: `${this.url}/v3/get_headers`,
      headers: { "Content-Type": "application/json" },
      json: payload,
      timeoutSeconds: 30,
      label: "anisette get_headers",
    })
    let reply: any = {}
    try { reply = JSON.parse(fromUtf8(res.body)) } catch { reply = {} }
    if (res.status !== 200 || reply.result !== "Headers") {
      const message = String(reply.message ?? `HTTP ${res.status}`)
      if (message.includes("-45061")) throw new AnisetteNotProvisionedError(message)
      throw new Error(`anisette: the server refused to mint headers — ${message}`)
    }
    this.routingInfo = String(reply["X-Apple-I-MD-RINFO"] ?? "0")
    return {
      "X-Mme-Device-Id": this.deviceId,
      "X-Apple-I-MD": String(reply["X-Apple-I-MD"]),
      "X-Apple-I-MD-M": String(reply["X-Apple-I-MD-M"]),
    }
  }
}

// MARK: - local state

/**
 * Which identity each server takes, and when each was last used — the same table the app
 * keeps, so a later sign-in does not re-provision. The identities themselves live under
 * their own keys as XML plists of `keychain_identifier` + `adi_pb`.
 */
export interface AnisetteSlotTable {
  servers: Record<string, string>
  used: Record<string, number>
}

export const ANISETTE_LEGACY_IDENTITY_KEY = "anisette_state"
export const ANISETTE_SLOTS_KEY = "anisette_slots.json"

/** Where a sign-in gets its headers from, plus the identity the resulting token belongs to. */
export interface AnisetteIdentityRef {
  server: string
  identityKey: string
}

export function identityKeyForIndex(index: number): string {
  return index <= 1 ? ANISETTE_LEGACY_IDENTITY_KEY : `${ANISETTE_LEGACY_IDENTITY_KEY}_${index}`
}

export class AnisetteStore {
  static loadIdentity(key: string): AnisetteIdentity | null {
    const text = Storage.get<string>(key)
    if (typeof text !== "string") return null
    try {
      const dict = asDict(parsePlist(text))
      const identifier = dict["keychain_identifier"]
      const adiPb = dict["adi_pb"]
      if (!(identifier instanceof Uint8Array) || !(adiPb instanceof Uint8Array)) return null
      if (identifier.length !== 16 || adiPb.length === 0) return null
      return { identifier, adiPb }
    } catch {
      return null
    }
  }

  static saveIdentity(key: string, identity: AnisetteIdentity): void {
    const dict: PlistDict = { keychain_identifier: identity.identifier, adi_pb: identity.adiPb }
    Storage.set(key, fromUtf8(xmlBytes(dict)))
  }

  static loadSlots(): AnisetteSlotTable {
    const saved = Storage.get<AnisetteSlotTable>(ANISETTE_SLOTS_KEY)
    if (saved === null || typeof saved !== "object") return { servers: {}, used: {} }
    return {
      servers: { ...(saved.servers ?? {}) },
      used: { ...(saved.used ?? {}) },
    }
  }

  static saveSlots(slots: AnisetteSlotTable): void {
    Storage.set(ANISETTE_SLOTS_KEY, slots)
  }

  /** The next free identity key, in the app's own naming. */
  static nextIdentityKey(slots: AnisetteSlotTable): string {
    for (let index = 1; ; index++) {
      const key = identityKeyForIndex(index)
      if (slots.used[key] === undefined && this.loadIdentity(key) === null) return key
    }
  }

  static remember(slots: AnisetteSlotTable, server: string, key: string): void {
    slots.servers[server] = key
    slots.used[key] = Math.floor(Date.now() / 1000)
    this.saveSlots(slots)
  }
}

/** The storage key of the anisette server in use. */
export const ANISETTE_PICK_KEY = "anisetteServerURL"

/**
 * The anisette server in use: the saved pick, else the server a first sign-in starts with, saved.
 *
 * An install that signed in before servers were remembered keeps the identity it has, whose
 * library is the old default's, so it starts there rather than on the new one.
 */
export function savedAnisettePick(): string {
  const saved = Storage.get<string>(ANISETTE_PICK_KEY)
  if (typeof saved === "string" && saved.trim() !== "") return saved
  const start = AnisetteStore.loadIdentity(ANISETTE_LEGACY_IDENTITY_KEY) !== null
    ? LEGACY_DEFAULT_ANISETTE_URL
    : FALLBACK_ANISETTE_URL
  Storage.set(ANISETTE_PICK_KEY, start)
  return start
}

/** Remembers the server a sign-in went through. */
export function saveAnisettePick(url: string): void {
  Storage.set(ANISETTE_PICK_KEY, url)
}

/**
 * Pick the identity a server should use: the one it took last time, else a stored one it
 * accepts, else a newly provisioned one — which is verified with `get_headers` before it is
 * kept, so a server that cannot use what it provisioned leaves nothing behind.
 *
 * With `rejected`, the server has just refused the identity in use as not provisioned with it
 * (-45061), and that one is left out of the pick: the same server is asked once more with
 * another of the stored identities, or with a new one.
 */
export async function selectIdentity(
  server: AnisetteServer,
  urls: ProvisioningUrls,
  post: PlistPoster,
  store = AnisetteStore,
  rejected = false,
): Promise<AnisetteIdentityRef> {
  const slots = store.loadSlots()
  const skip = new Set<string>()
  if (rejected) {
    const refused = server.slotKey !== "" ? server.slotKey : slots.servers[server.url]
    if (refused !== undefined) {
      if (slots.servers[server.url] === refused) delete slots.servers[server.url]
      skip.add(refused)
    }
    server.identity = { identifier: randomBytes(16), adiPb: new Uint8Array(0) }
  }
  const remembered = skip.has(slots.servers[server.url] ?? "") ? undefined : slots.servers[server.url]
  if (remembered !== undefined) {
    const identity = store.loadIdentity(remembered)
    if (identity !== null) {
      server.identity = identity
      try {
        await server.headers()
        server.slotKey = remembered
        return { server: server.url, identityKey: remembered }
      } catch (error) {
        if (!(error instanceof AnisetteNotProvisionedError)) throw error
      }
    }
  }

  const keys = Object.keys(slots.used).sort((a, b) => slots.used[b] - slots.used[a])
  if (keys.indexOf(ANISETTE_LEGACY_IDENTITY_KEY) === -1) keys.push(ANISETTE_LEGACY_IDENTITY_KEY)
  for (const key of keys) {
    if (skip.has(key)) continue
    const identity = store.loadIdentity(key)
    if (identity === null) continue
    server.identity = identity
    try {
      await server.headers()
      store.remember(slots, server.url, key)
      server.slotKey = key
      return { server: server.url, identityKey: key }
    } catch (error) {
      if (!(error instanceof AnisetteNotProvisionedError)) throw error
    }
  }

  server.identity = { identifier: randomBytes(16), adiPb: new Uint8Array(0) }
  await server.provision(urls, post)
  await server.headers()
  const key = store.nextIdentityKey(slots)
  store.saveIdentity(key, server.identity)
  store.remember(slots, server.url, key)
  server.slotKey = key
  return { server: server.url, identityKey: key }
}
