// The persisted developer session: the (adsid, xcode.auth token) pair, its expiry, and the
// anisette identity the token was issued to.
//
// Kept in the global `Storage` API rather than a file: it is a few short strings, it needs no
// file-system grant, and the domain is already per-script. The Apple ID password is never
// part of this — only a hash of the address, which is what Apple itself keys a session on.
import { toHex } from "../util"
import { hashWith } from "../util"
import { AnisetteIdentityRef } from "./anisette"
import { AppToken } from "./grandslam"
import { PortalError } from "./http"

const sha256 = hashWith("SHA-256")

/** Reuse a token until ten minutes before Apple says it dies. */
export const EXPIRY_MARGIN_SECONDS = 600

export interface SavedSession {
  adsid: string
  token: string
  /** Seconds since the epoch, or 0 when Apple's `expiry` could not be read as a date. */
  expiresAt: number
  duration: number
  /** Which anisette server, and which of its identities, this token belongs to. */
  anisette: AnisetteIdentityRef
}

/** Apple keys a session on the address; hashing keeps it out of storage in the clear. */
export function accountHash(email: string): string {
  return toHex(sha256(new TextEncoder().encode(email.toLowerCase())))
}

export function sessionKey(email: string): string {
  return `developer_session.${accountHash(email)}`
}

export function saveSession(email: string, token: AppToken, anisette: AnisetteIdentityRef): SavedSession {
  const session: SavedSession = {
    adsid: token.adsid,
    token: token.token,
    expiresAt: token.expiresAt,
    duration: token.duration,
    anisette,
  }
  Storage.set(sessionKey(email), session)
  return session
}

export function loadSession(email: string): SavedSession | null {
  const saved = Storage.get<SavedSession>(sessionKey(email))
  if (saved === null || typeof saved !== "object") return null
  if (typeof saved.token !== "string" || typeof saved.adsid !== "string" || saved.token === "") return null
  return {
    adsid: saved.adsid,
    token: saved.token,
    expiresAt: typeof saved.expiresAt === "number" ? saved.expiresAt : 0,
    duration: typeof saved.duration === "number" ? saved.duration : 0,
    anisette: saved.anisette ?? { server: "", identityKey: "" },
  }
}

export function clearSession(email: string): void {
  Storage.remove(sessionKey(email))
}

/**
 * Whether a saved token can be used without touching GrandSlam at all. An unknown expiry is
 * treated as usable: the portal answers 1100 for a dead token anyway, and that path drops
 * the session, so guessing "unusable" would only cost a full sign-in.
 */
export function isSessionUsable(session: SavedSession, nowSeconds = Math.floor(Date.now() / 1000)): boolean {
  if (session.expiresAt === 0) return true
  return nowSeconds < session.expiresAt - EXPIRY_MARGIN_SECONDS
}

/**
 * What a portal failure means for the saved session. `1100` (and an HTTP 401) is "ask again",
 * so the session is dropped; `1102` and `2160` are the account refusing outright, and
 * retrying sign-in cannot change that.
 */
export type SessionVerdict = "usable" | "expired" | "refused"

export function verdictFor(error: unknown): SessionVerdict {
  if (error instanceof PortalError) {
    if (error.code === 1100) return "expired"
    if (error.code === 1102 || error.code === 2160) return "refused"
    return "usable"
  }
  const status = (error as { status?: number })?.status
  return status === 401 ? "expired" : "usable"
}
