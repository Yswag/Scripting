// Apple-facing HTTP: exact header casing, plist/JSON bodies, and Apple's two structured
// error shapes (GrandSlam's Status.ec, the portal's top-level resultCode).
import { fetch } from "scripting"
import { Bytes, fromUtf8, utf8 } from "../util"
import { PlistDict, PlistReal, PlistUid, PlistValue, asDict, parsePlist, plistNumber, str, writeXml } from "../util"

export type HeaderMap = Record<string, string>

// MARK: - errors

export class AppleHttpError extends Error {
  constructor(readonly status: number, readonly url: string, readonly detail = "") {
    super(`HTTP ${status} for ${url}${detail ? ": " + detail : ""}`)
  }
}

/**
 * GrandSlam's `Status.ec` / `Status.em`, plus which half of the exchange refused it.
 *
 * The stage matters: `init` is answered from the account and `complete` is where the password
 * proof is checked, so the same code means "check the address" or "check the password" depending
 * on where it came from.
 */
export class GrandSlamError extends Error {
  constructor(readonly code: number, readonly detail: string, readonly stage = "") {
    super(`Apple rejected the request (${code})${stage === "" ? "" : ` (${stage})`}: ${detail}`)
  }
}

/** The developer portal's top-level `resultCode` / `resultString` / `userString`. */
export class PortalError extends Error {
  constructor(readonly code: number, readonly userString: string) {
    super(`Apple developer portal error ${code}: ${userString}`)
  }
}

// MARK: - pieces of a reply Apple hands back

/**
 * Anything that can mint the three anisette headers. Every request asks its source again,
 * because X-Apple-I-MD must not be replayed across requests; the one deliberate exception is
 * the two SRP legs, which share a single fetch because they are a single exchange.
 */
export interface HeaderSource {
  headers(): Promise<HeaderMap>
}

export interface AppleRequest {
  method: string
  url: string
  headers?: HeaderMap
  /** Raw body. */
  body?: Bytes | string
  /** JSON body; serialised, and Content-Type set unless the caller supplied one. */
  json?: unknown
  timeoutSeconds?: number
  label?: string
  /**
   * Whether Apple's edge refusing the request outright (503) is asked again. See
   * `retryPause` for why this is on at all, and off for the two calls that make Apple send
   * something.
   */
  retryRefusals?: boolean
}

export interface AppleResponse {
  status: number
  /** Lower-cased names; Apple is not consistent about casing on the way back. */
  headers: HeaderMap
  body: Bytes
}

/**
 * How long to wait before asking again, or `null` when this answer is the answer.
 *
 * Two statuses are worth repeating, for the same reason: neither one means Apple processed
 * the request.
 *
 * * **503** is Apple's *edge* refusing the client before GrandSlam ever reads it — its own
 *   HTML page, not a plist, and nothing to do with the password or the anisette data (the same
 *   request with a garbage MID comes back `200` with `ec -80009`). Refusals come in bursts, so
 *   the same request moments later is often answered normally: repeating it is what turns that
 *   into a sign-in, and when even the repeats are refused, `grandslam.ts` asks as a Mac instead.
 * * **429** is Apple's rate limit, which the reference retries twice (2 s, then 5 s) and then
 *   gives up on, because a lasting limit only gets longer with every attempt.
 *
 * A 4xx that *reads* the request (401, 403) is an answer, and is never repeated: on the 2FA
 * pages a repeat can mean a second code goes to the user's devices.
 */
export function retryPause(status: number, attempt: number, allowRefusalRetry = true): number | null {
  const waits = status === 429 ? RATE_LIMIT_PAUSES_MS
    : status === 503 && allowRefusalRetry ? REFUSAL_PAUSES_MS
    : null
  if (waits === null || attempt >= waits.length) return null
  return waits[attempt]
}

const REFUSAL_PAUSES_MS = [250, 800]
const RATE_LIMIT_PAUSES_MS = [2000, 5000]

function pause(milliseconds: number): Promise<void> {
  return new Promise<void>(resolve => { setTimeout(() => resolve(), milliseconds) })
}

export async function send(req: AppleRequest, anisette?: HeaderSource): Promise<AppleResponse> {
  const headers: HeaderMap = { ...(req.headers ?? {}) }
  if (anisette) Object.assign(headers, await anisette.headers())

  let body: any = req.body
  if (body !== undefined && typeof body !== "string") body = (globalThis as any).Data.fromUint8Array(body)
  if (req.json !== undefined) {
    body = JSON.stringify(req.json)
    if (headers["Content-Type"] === undefined) headers["Content-Type"] = "application/json"
  }

  // The anisette headers are deliberately not refreshed between attempts: a 503 means the edge
  // refused the request without reading it, so the same one-time password is still unused.
  const allowRefusalRetry = req.retryRefusals ?? true
  for (let attempt = 0; ; attempt++) {
    const response = await attemptOnce(req, headers, body)
    const wait = retryPause(response.status, attempt, allowRefusalRetry)
    if (wait === null) return response
    await pause(wait)
  }
}

async function attemptOnce(req: AppleRequest, headers: HeaderMap, body: any): Promise<AppleResponse> {
  const res: any = await fetch(req.url, {
    method: req.method,
    headers,
    body,
    timeout: req.timeoutSeconds ?? 30,
    debugLabel: req.label,
  })

  const got: HeaderMap = {}
  res.headers.forEach((value: string, name: string) => { got[name.toLowerCase()] = value })

  let bytes = new Uint8Array(await res.arrayBuffer())
  // The portal gzips regardless of Accept-Encoding. Native fetch usually unwraps it for us;
  // the magic check is the fallback for when it does not.
  if (bytes.length > 2 && bytes[0] === 0x1f && bytes[1] === 0x8b) {
    bytes = new Uint8Array(require("node:zlib").gunzipSync(bytes))
  }
  return { status: res.status, headers: got, body: bytes }
}

/**
 * The one readable line in a body Apple refused with, for the error message.
 *
 * A 503 is the edge's own HTML page and its whole content is the status it answered with; a
 * plist carrying a failure says more (`em`, and GrandSlam's own code) but arrives as XML, so
 * the tags come out and the words stay. Nothing here is a secret — these are the pages Apple
 * hands its own clients — and without it the message is a status code and a URL.
 */
export function bodyExcerpt(body: Bytes, limit = 140): string {
  const text = fromUtf8(body).replace(/<[^>]*>/g, " ").replace(/&amp;/g, "&").replace(/\s+/g, " ").trim()
  if (text === "") return ""
  return text.length <= limit ? text : `${text.slice(0, limit)}…`
}

/** Bodies Apple encrypts (the sign-in `spd`, the app-token `et`) are bare `<dict>` fragments. */
export function parseBarePlist(input: Bytes | string): PlistDict {
  const text = typeof input === "string" ? input : fromUtf8(input)
  const trimmed = text.trimStart()
  if (trimmed.startsWith("<dict") || trimmed.startsWith("<array") || trimmed.startsWith("<data")) {
    return asDict(parsePlist(`<?xml version="1.0" encoding="UTF-8"?>\n<plist version="1.0">${text}</plist>`))
  }
  return asDict(parsePlist(input))
}

export function xmlBytes(value: PlistValue): Bytes {
  return utf8(writeXml(value))
}

// MARK: - field access

export function bytesField(dict: PlistDict, key: string): Bytes | undefined {
  const value = dict[key]
  return value instanceof Uint8Array ? value : undefined
}

export function intField(dict: PlistDict, key: string): number | undefined {
  // Through `plistNumber`, because a plist real is a `PlistReal` and not a `number`.
  const value = plistNumber(dict[key])
  if (value !== null) return value
  const raw = dict[key]
  return typeof raw === "bigint" ? Number(raw) : undefined
}

export function dictField(dict: PlistDict, key: string): PlistDict | undefined {
  const value = dict[key]
  if (value === null || typeof value !== "object" || Array.isArray(value)
    || value instanceof Uint8Array || value instanceof PlistUid || value instanceof PlistReal) {
    return undefined
  }
  return value as PlistDict
}

export function listField(dict: PlistDict, key: string): PlistValue[] | undefined {
  const value = dict[key]
  return Array.isArray(value) ? value : undefined
}

/**
 * A plist `<date>`, which the parser hands back as a `Date`. Certificate expiries arrive this way,
 * and the XML form is the same instant in UTC, so no second parse is needed.
 */
export function dateField(dict: PlistDict, key: string): Date | undefined {
  const value = dict[key]
  return value instanceof Date ? value : undefined
}

export function requireStr(dict: PlistDict, key: string, what: string): string {
  const value = str(dict, key)
  if (value === undefined) throw new Error(`${what} is missing its '${key}'`)
  return value
}

// MARK: - the two structured errors

/** GrandSlam wraps its replies in `Response`; `Status.ec` non-zero is fatal. */
export function grandSlamResponse(document: PlistDict): PlistDict {
  const response = dictField(document, "Response")
  if (response === undefined) throw new Error("GrandSlam reply had no Response section")
  return response
}

export function checkGrandSlamStatus(response: PlistDict): PlistDict {
  const status = dictField(response, "Status") ?? response
  const code = intField(status, "ec") ?? 0
  if (code !== 0) throw new GrandSlamError(code, str(status, "em") ?? "no message")
  return response
}

/**
 * The legacy portal reports errors in the reply's own top level, not in a Status dict.
 * `gloss` lets the caller attach what a code means, so the wording lives with the codes.
 */
export function checkPortalResult(response: PlistDict, gloss?: (code: number, message: string) => string): PlistDict {
  const code = intField(response, "resultCode") ?? 0
  if (code !== 0) {
    const message = str(response, "userString") ?? str(response, "resultString") ?? "no message"
    throw new PortalError(code, gloss === undefined ? message : gloss(code, message))
  }
  return response
}
