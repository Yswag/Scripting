// The Apple IDs this device has signed in as, and which one it signs in as now.
//
// A session is keyed by a hash of the address (`session.ts`), so the addresses themselves have to
// be kept somewhere or they could not be shown again — that is this list. The team an account signs
// under lives here too: a team belongs to the account it was chosen for, not to the app.
import { accountHash, clearSession } from "./session"

const ACCOUNTS_KEY = "signin.accounts"
const ACTIVE_KEY = "signin.email"
/** What a version before the account list wrote for the account in use. */
const LEGACY_TEAM_KEY = "developer.teamId"

/** The Apple ID the app signs in as, or null when there is none. */
export function activeAccount(): string | null {
  const email = (Storage.get<string>(ACTIVE_KEY) ?? "").trim()
  return email === "" ? null : email
}

/** The Apple IDs this device has signed in as, the one in use first. */
export function loadAccounts(): string[] {
  const saved = Storage.get<string[]>(ACCOUNTS_KEY)
  const known = (Array.isArray(saved) ? saved : []).filter(email => typeof email === "string" && email.trim() !== "")
  const active = activeAccount()
  if (active === null) return known
  return [active, ...known.filter(email => email.toLowerCase() !== active.toLowerCase())]
}

/** Makes `email` the account in use, and puts it at the front of the list. */
export function rememberAccount(email: string): void {
  const address = email.trim()
  const others = loadAccounts().filter(known => known.toLowerCase() !== address.toLowerCase())
  Storage.set(ACCOUNTS_KEY, [address, ...others])
  Storage.set(ACTIVE_KEY, address)
}

/**
 * Drops `email`: its saved session goes, and so does its place in the list. The account in use
 * falls back to the next one, or to none at all.
 */
export function dropAccount(email: string): void {
  const address = email.trim().toLowerCase()
  const wasActive = activeAccount()?.toLowerCase() === address
  // Removed before the list is read, or `loadAccounts` would put the account in use back in it.
  if (wasActive) Storage.remove(ACTIVE_KEY)
  clearSession(email)
  const rest = loadAccounts().filter(known => known.toLowerCase() !== address)
  if (rest.length === 0) Storage.remove(ACCOUNTS_KEY)
  else Storage.set(ACCOUNTS_KEY, rest)
  if (wasActive && rest.length > 0) Storage.set(ACTIVE_KEY, rest[0])
}

/** Where the team chosen for `email` is kept. */
function teamKey(email: string): string {
  return `${LEGACY_TEAM_KEY}.${accountHash(email)}`
}

/**
 * The team `email` signs under. The single key a version before this one wrote is still read for
 * the account in use, so a sign-in from then does not have to be repeated.
 */
export function loadTeam(email: string): string {
  const saved = Storage.get<string>(teamKey(email))
  if (typeof saved === "string" && saved.trim() !== "") return saved.trim()
  const legacy = Storage.get<string>(LEGACY_TEAM_KEY)
  if (typeof legacy !== "string" || legacy.trim() === "") return ""
  return activeAccount()?.toLowerCase() === email.trim().toLowerCase() ? legacy.trim() : ""
}

export function saveTeam(email: string, teamId: string): void {
  Storage.set(teamKey(email), teamId)
  Storage.remove(LEGACY_TEAM_KEY)
}

/**
 * The team an account no longer needs. The single key a version before this one wrote is dropped
 * with it, since it was that account's too — it is only read for the account in use.
 */
export function forgetTeam(email: string): void {
  Storage.remove(teamKey(email))
  if (activeAccount()?.toLowerCase() === email.trim().toLowerCase()) Storage.remove(LEGACY_TEAM_KEY)
}

export interface AppIdQuota {
  used: number
  total: number
  updatedAt: string
}

function quotaKey(email: string): string {
  return `developer.quota.${accountHash(email)}`
}

export function loadAppIdQuota(email: string): AppIdQuota | null {
  const data = Storage.get<AppIdQuota>(quotaKey(email))
  if (data && typeof data.used === "number" && typeof data.total === "number") {
    return data
  }
  return null
}

export function saveAppIdQuota(email: string, quota: AppIdQuota): void {
  Storage.set(quotaKey(email), quota)
}
