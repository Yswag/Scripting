// The signing identity: the key we keep, and the certificate Apple issues for it.
//
// A free Apple ID holds two development certificates, and a certificate is worthless without the
// private key it was issued for. That makes the key — not the certificate — the thing worth
// protecting: losing it does not mean "ask for another", it means one of the two slots is now spent
// on a certificate nothing can use.
//
// So: the key is created only when there is none, a certificate is reused only when it is provably
// ours, and the one irreversible action available here (revoking) never happens unless someone was
// asked. Everything else is a portal call whose worst case is a wasted request.
import { buildCsrPem, certificatePublicKey, generateRsaKeyJwk, keyFromJwk, type RsaJwk, type RsaKey } from "../sign"
import type { Bytes } from "../util"
import { globalStore, type KeyValueStore } from "../util"
import { PortalError } from "./http"
import type { DeveloperCertificate, PortalClient } from "./portal"
import { accountHash } from "./session"

/**
 * The name every certificate this project asks for is registered under.
 *
 * It is half of how a certificate is recognised later, so it must not change: a rename orphans
 * everything already issued, and an orphan cannot be reused — which on a two-slot account is the
 * whole budget. The key inside the certificate is the other half, and the one that makes the check
 * trustworthy.
 */
export const MACHINE_NAME = "SideInstaller"

const KEY_PREFIX = "apple.signing_key"

/** One key per Apple ID, keyed on a hash of the address so the address is not in the clear. */
export function signingKeyStorageKey(email: string): string {
  return `${KEY_PREFIX}.${accountHash(email)}`
}

/**
 * The signing key for this Apple ID: the stored one if there is one, a fresh one otherwise.
 *
 * `created` reports which of the two happened, because it is a fact worth saying out loud: a key
 * generated when one was expected means every certificate the account already holds is now
 * unusable, and the two slots are spent.
 */
export async function loadOrCreateSigningKey(
  email: string, store: KeyValueStore = globalStore(),
): Promise<{ key: RsaKey, jwk: RsaJwk, created: boolean }> {
  const storageKey = signingKeyStorageKey(email)
  const saved = store.get<RsaJwk>(storageKey)
  if (saved !== null && typeof saved === "object" && typeof saved.d === "string") {
    return { key: keyFromJwk(saved), jwk: saved, created: false }
  }
  const jwk = await generateRsaKeyJwk()
  store.set(storageKey, jwk)
  return { key: keyFromJwk(jwk), jwk, created: true }
}

/** Throws the key away. Only right when the account is being started over, deliberately. */
export function forgetSigningKey(email: string, store: KeyValueStore = globalStore()): void {
  store.remove(signingKeyStorageKey(email))
}

/**
 * Whether a certificate is one this key can sign with.
 *
 * `machineName` alone is not enough — anything else this project ever runs would use the same name,
 * and a certificate for a key we do not hold is worse than no certificate, because it looks like
 * one and fails at the device.
 */
export function isOurCertificate(
  certificate: DeveloperCertificate, key: RsaKey, machineName = MACHINE_NAME,
): boolean {
  if (certificate.content === null) return false
  if (certificate.machineName !== machineName) return false
  try {
    return certificatePublicKey(certificate.content).modulus === key.modulus
  } catch {
    // Unreadable, therefore unusable. Not an error worth raising: the listing is Apple's, and it
    // contains cross-platform certificates this parser has no reason to understand.
    return false
  }
}

export interface SigningIdentity {
  certificate: DeveloperCertificate
  /** The certificate's DER, which is what the signing side takes. */
  certificateDer: Bytes
  /** True when an existing certificate was reused instead of a new one being issued. */
  reused: boolean
}

export interface EnsureIdentityOptions {
  /** Registered in the certificate. Changing it orphans what exists. */
  machineName?: string
  /**
   * Asked when Apple says the account is at its certificate limit (7460).
   *
   * Return the serial number of a certificate to revoke and the flow goes on; return null to give
   * up. Revoking stops every app already signed with that certificate, including apps this project
   * never touched, so the answer has to come from a person.
   */
  onCertificateLimit?: (certificates: DeveloperCertificate[]) => Promise<string | null>
  /** How many submissions to allow in total. */
  maxAttempts?: number
}

/**
 * The certificate for this key, reusing one if the account already has it.
 *
 * In order: look for a certificate that is ours; if there is none, submit a CSR and find what it
 * produced by `certRequestId` (the submission reply carries an id and nothing else); if Apple says
 * the account is full, ask what to revoke and start over.
 */
export async function ensureSigningIdentity(
  client: PortalClient, teamId: string, key: RsaKey, options: EnsureIdentityOptions = {},
): Promise<SigningIdentity> {
  const machineName = options.machineName ?? MACHINE_NAME
  const maxAttempts = options.maxAttempts ?? 3

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const ours = (await client.listCertificates(teamId))
      .find(certificate => isOurCertificate(certificate, key, machineName))
    if (ours !== undefined && ours.content !== null) {
      return { certificate: ours, certificateDer: ours.content, reused: true }
    }

    let requestId: string
    try {
      requestId = await client.submitDevelopmentCSR(teamId, buildCsrPem(key), machineName)
    } catch (error) {
      if (!(error instanceof PortalError) || error.code !== 7460) throw error

      const serial = await askWhatToRevoke(client, teamId, options)
      if (serial === null) {
        throw new Error(
          "This account is at its certificate limit and nothing was revoked. A free Apple ID " +
          "holds two development certificates; revoke one at " +
          "https://developer.apple.com/account/resources/certificates and run this again.",
        )
      }
      // A 7252 from here means the serial is not in the listing at all — already revoked, by this
      // app or another one — and `revokeCertificate` has already tried deleting it by id. Nothing
      // about the picker would help, so the error is left to travel.
      await client.revokeCertificate(teamId, serial)
      continue
    }

    const issued = (await client.listCertificates(teamId))
      .find(certificate => certificate.certificateId === requestId)
    if (issued === undefined || issued.content === null) {
      // Apple took the CSR and did not hand back what it made. Retrying would spend another slot.
      throw new Error(
        `Apple issued certificate ${requestId} for this key, but the listing did not carry it`,
      )
    }
    return { certificate: issued, certificateDer: issued.content, reused: false }
  }

  throw new Error(
    `the account was still at its certificate limit after ${maxAttempts} submissions`,
  )
}

/** The revocable certificates, handed to whoever agreed to choose one. */
async function askWhatToRevoke(
  client: PortalClient, teamId: string, options: EnsureIdentityOptions,
): Promise<string | null> {
  if (options.onCertificateLimit === undefined) return null
  const certificates = (await client.listCertificates(teamId))
    .filter(certificate => certificate.serialNumber !== null)
  return options.onCertificateLimit(certificates)
}
