// GrandSlam: the URL bag, the two SRP legs, `spd` unwrapping, 2FA and the app-token exchange.
import { Bytes, concat, fromUtf8, toBase64, utf8 } from "../util"
import { PlistDict, PlistValue, str } from "../util"
import { SRPClient, SRP_GROUP_2048, applePasswordKey, hashWith } from "../util"
import { AnisetteServer, type SignInShape } from "./anisette"
import {
  AppleHttpError, AppleRequest, AppleResponse, GrandSlamError, HeaderMap, HeaderSource,
  bodyExcerpt, checkGrandSlamStatus, dictField, grandSlamResponse, intField, bytesField, parseBarePlist,
  requireStr, send, xmlBytes,
} from "./http"

export type UrlBag = Record<string, string>

export const GSA_URL_BAG = "https://gsa.apple.com/grandslam/GsService2/lookup"
export const GSA_HOST = "https://gsa.apple.com"
export const GSA_2FA_ROOT = "https://gsa.apple.com/auth"
export const XCODE_VERSION = "14.2 (14C18)"
export const APP_INFO = "com.apple.gs.xcode.auth"
export const XCODE_AUTH_APP = "com.apple.gs.xcode.auth"
/** What the URL-bag lookup and the /auth pages fall back to (see the Python port's notes). */
export const GSA_MAC_CLIENT_INFO = "<Mac15,7> <macOS;27.0;26A5378j> <com.apple.AuthKit/1 (com.apple.akd/1.0)>"

/** The app the TestFlight shape signs in as; see `SignInShape`. */
const TESTFLIGHT_APP_NAME = "TestFlight"
const TESTFLIGHT_BUNDLE_ID = "com.apple.TestFlight"
export const GSA_BAG_KEYS = [
  "gsService", "midStartProvisioning", "midFinishProvisioning",
  "trustedDeviceSecondaryAuth", "secondaryAuth", "validateCode",
]

const sha256 = hashWith("SHA-256")

// MARK: - primitives the runtime does not give us as one call

/** `Crypto.hmacSHA256(data, key)` is the only synchronous HMAC here. */
function hmacSha256(message: Bytes, key: Bytes): Bytes {
  const D: any = (globalThis as any).Data
  const Crypto: any = (globalThis as any).Crypto
  return new Uint8Array(Crypto.hmacSHA256(D.fromUint8Array(message), D.fromUint8Array(key)).toUint8Array())
}

/** `crypto.subtle` has no AES-CBC in this runtime, so the fake node:crypto does it. */
function aesCbcDecrypt(blob: Bytes, key: Bytes, iv: Bytes): Bytes {
  const crypto: any = require("node:crypto")
  const decipher = crypto.createDecipheriv("aes-256-cbc", Buffer.from(key), Buffer.from(iv))
  return new Uint8Array(Buffer.concat([decipher.update(Buffer.from(blob)), decipher.final()]))
}

/**
 * Unwrap an app token. Apple uses a **16-byte nonce**, which `crypto.subtle` refuses (it
 * accepts 12 bytes only), and `"XYZ"` travels in the clear as the GCM AAD:
 * `"XYZ" ‖ nonce(16) ‖ ciphertext ‖ tag(16)`.
 */
export function decryptTokenContainer(blob: Bytes, key: Bytes): Bytes {
  if (blob.length < 3 + 16 + 16) throw new Error(`the encrypted token is too short (${blob.length} bytes)`)
  const header = blob.subarray(0, 3)
  if (fromUtf8(header) !== "XYZ") throw new Error(`the encrypted token is in an unknown format (${fromUtf8(header)})`)
  const crypto: any = require("node:crypto")
  const decipher = crypto.createDecipheriv("aes-256-gcm", Buffer.from(key), Buffer.from(blob.subarray(3, 19)))
  decipher.setAAD(Buffer.from(header))
  decipher.setAuthTag(Buffer.from(blob.subarray(blob.length - 16)))
  return new Uint8Array(Buffer.concat([decipher.update(Buffer.from(blob.subarray(19, blob.length - 16))), decipher.final()]))
}

/**
 * Unwrap the AES-256-CBC "extra data" that comes back with M2. This is the one place two
 * working implementations disagree about the HMAC key: isideload keys it on the raw
 * premaster `S`, everything built on pysrp on `H(S)`. Try both and keep whichever yields a
 * parseable plist rather than betting on one.
 */
export function decryptExtraData(blob: Bytes, sessionKey: Bytes, premaster: Bytes): PlistDict {
  const failures: string[] = []
  const bases: [string, Bytes][] = [["H(S)", sessionKey], ["S", premaster]]
  for (const [label, base] of bases) {
    const key = hmacSha256(utf8("extra data key:"), base)
    const iv = hmacSha256(utf8("extra data iv:"), base).subarray(0, 16)
    try {
      return parseBarePlist(aesCbcDecrypt(blob, key, iv))
    } catch (error) {
      failures.push(`${label}: ${error}`)
    }
  }
  throw new Error(`could not decrypt the sign-in response (${failures.join("; ")})`)
}

// MARK: - the URL bag

export function bagIsComplete(bag: UrlBag): boolean {
  for (const key of GSA_BAG_KEYS) {
    if (bag[key] === undefined) return false
  }
  return (bag["gsService"] ?? "").startsWith("https://gsa.apple.com/")
}

export function baseHeaders(clientInfo: string, userAgent: string, plist = true, shape: SignInShape = "xcode"): HeaderMap {
  if (shape === "testflight") {
    const headers: HeaderMap = { "User-Agent": userAgent }
    if (plist) {
      headers["Content-Type"] = "text/x-xml-plist"
      headers["Accept"] = "*/*"
    }
    headers["X-Apple-AK-Context-Type"] = "itunes"
    headers["X-Apple-I-Client-Bundle-Id"] = TESTFLIGHT_BUNDLE_ID
    headers["X-MMe-Client-Info"] = clientInfo
    return headers
  }
  const headers: HeaderMap = {}
  if (plist) {
    headers["Content-Type"] = "text/x-xml-plist"
    headers["Accept"] = "text/x-xml-plist"
  }
  headers["X-Mme-Client-Info"] = clientInfo
  headers["User-Agent"] = userAgent
  headers["X-Xcode-Version"] = XCODE_VERSION
  headers["X-Apple-App-Info"] = APP_INFO
  return headers
}

/**
 * Endpoint discovery. The bag GrandSlam hands a non-Mac client can lack the URLs this port
 * uses, in which case the lookup is repeated claiming to be a Mac.
 */
export async function fetchUrlBag(clientInfo: string, userAgent: string): Promise<UrlBag> {
  const first = await lookupBag(clientInfo, userAgent)
  if (bagIsComplete(first) || clientInfo.includes("<macOS;")) return first
  const second = await lookupBag(GSA_MAC_CLIENT_INFO, userAgent)
  return second
}

async function lookupBag(clientInfo: string, userAgent: string): Promise<UrlBag> {
  const res = await send({
    method: "GET",
    url: GSA_URL_BAG,
    headers: baseHeaders(clientInfo, userAgent),
    timeoutSeconds: 30,
    label: "gsa url bag",
  })
  if (res.status !== 200) throw new AppleHttpError(res.status, GSA_URL_BAG, bodyExcerpt(res.body))
  const doc = parseBarePlist(res.body)
  const urls = dictField(doc, "urls")
  if (urls === undefined) throw new Error("Apple's URL bag had no 'urls' section")
  const bag: UrlBag = {}
  for (const key of Object.keys(urls)) {
    const value = str(urls, key)
    if (value !== undefined) bag[key] = value
  }
  return bag
}

// MARK: - request bodies (pure, so the shapes can be asserted without a live account)

/**
 * The client-provided data. These really are the strings "true"/"false", not plist booleans
 * — isideload sends them that way and Apple accepts it.
 */
export function clientProvidedData(anisetteHeaders: HeaderMap, shape: SignInShape = "xcode"): PlistDict {
  if (shape === "testflight") {
    return {
      bootstrap: true,
      pbe: false,
      svct: "itunesstore",
      loc: "en_US",
      ...anisetteHeaders,
      "X-Apple-I-Client-Time": new Date().toISOString().replace(/\.\d{3}Z$/, ""),
      "X-Apple-Client-App-Name": TESTFLIGHT_APP_NAME,
      "X-Apple-I-Client-Bundle-Id": TESTFLIGHT_BUNDLE_ID,
    }
  }
  return {
    bootstrap: "true",
    icscrec: "true",
    loc: "en_US",
    pbe: "false",
    prkgen: "true",
    svct: "iCloud",
    "X-Mme-Device-Id": anisetteHeaders["X-Mme-Device-Id"],
    "X-Apple-I-MD": anisetteHeaders["X-Apple-I-MD"],
    "X-Apple-I-MD-M": anisetteHeaders["X-Apple-I-MD-M"],
  }
}

export function buildInitRequest(email: string, a2k: Bytes, cpd: PlistDict): PlistDict {
  return {
    Header: { Version: "1.0.1" },
    Request: { A2k: a2k, cpd, o: "init", ps: ["s2k", "s2k_fo"], u: email },
  }
}

export function buildCompleteRequest(email: string, m1: Bytes, context: string, cpd: PlistDict): PlistDict {
  return {
    Header: { Version: "1.0.1" },
    Request: { M1: m1, c: context, cpd, o: "complete", u: email },
  }
}

export function normaliseAppName(app: string): string {
  return app.startsWith("com.apple.gs.") ? app : `com.apple.gs.${app}`
}

function buildAppTokensRequest(adsid: string, app: string, context: Bytes, checksum: Bytes, cpd: PlistDict, idmsToken: string): PlistDict {
  return {
    Header: { Version: "1.0.1" },
    Request: { app: [app], c: context, checksum, cpd, o: "apptokens", u: adsid, t: idmsToken },
  }
}

/**
 * GrandSlam codes that mean the credentials themselves were refused.
 *
 * Apple moved one of these: an unknown Apple ID used to answer -20101 and now answers -20970
 * instead (the reference app documents the change). -22406 is also what Apple
 * returns for a *correct* password while it is throttling sign-in attempts, which is why the
 * message that goes with this has to mention waiting.
 */
const CREDENTIAL_CODES = [-20101, -20970, -22406]

export function isCredentialRejection(code: number): boolean {
  return CREDENTIAL_CODES.includes(code)
}

/**
 * What a reply actually carried.
 *
 * Values are described, never printed: the point is to tell `c` being a string from `c` being
 * absent, and a reply here can hold things that belong in a log no more than a password does.
 */
function describeReply(response: PlistDict): string {
  const describe = (value: PlistValue): string => {
    if (value === null) return "null"
    if (value instanceof Uint8Array) return `data(${value.length})`
    if (Array.isArray(value)) return `array(${value.length})`
    if (typeof value === "object") return "dict"
    if (typeof value === "string") return `string(${value.length})`
    return `${typeof value}(${String(value)})`
  }
  return Object.keys(response).sort().map(key => `${key}=${describe(response[key])}`).join(" ")
}

/** HMAC-SHA256(key = `spd.sk`, msg = "apptokens" ‖ adsid ‖ app). */
export function appTokenChecksum(sessionKey: Bytes, adsid: string, app: string): Bytes {
  return hmacSha256(concat(utf8("apptokens"), utf8(adsid), utf8(app)), sessionKey)
}

// MARK: - reading what Apple sent back

export type SignInStep = "ok" | "device-2fa" | "device-2fa-sent" | "sms-2fa" | "repair" | "extra"

export function nextSignInStep(status: PlistDict): SignInStep {
  const au = str(status, "au")
  if (au === "trustedDeviceSecondaryAuth") return "device-2fa"
  if (au === "secondaryAuth") return "sms-2fa"
  if (au === "repair") return "repair"
  if (au === undefined) {
    // hsc 409 with no `au` means a second step is still due and a code has already been
    // pushed. Taking that for a finished sign-in makes the app-token request fail -22411.
    return intField(status, "hsc") === 409 ? "device-2fa-sent" : "ok"
  }
  return "extra"
}

/** The resync blob an ADI server needs, or null when Apple did not ask for one. */
export function resyncToken(status: PlistDict): string | null {
  if (intField(status, "hsc") !== 434) return null
  const data = status["X-Apple-I-MD-DATA"]
  if (data === undefined) return null
  return typeof data === "string" ? data : toBase64(data as Bytes)
}

export interface SignInSession {
  adsid: string
  idmsToken: string
  /** `sk`: keys both the app-token checksum and the token container itself. */
  sessionKey: Bytes
  /** `c`: echoed back in the app-token request. */
  context: Bytes
  pet: string | null
  name: string | null
  /** What to show the user when Apple wants a second step. */
  message: string | null
}

export function sessionFromSpd(spd: PlistDict): SignInSession {
  const pet = dictField(dictField(spd, "t") ?? {}, "com.apple.gs.idms.pet")
  const first = str(spd, "fn")
  const last = str(spd, "ln")
  return {
    adsid: requireStr(spd, "adsid", "the sign-in response"),
    idmsToken: requireStr(spd, "GsIdmsToken", "the sign-in response"),
    sessionKey: requireBytes(spd, "sk"),
    context: requireBytes(spd, "c"),
    pet: pet === undefined ? null : (str(pet, "token") ?? null),
    name: (first ?? last) === undefined ? null : [first, last].filter(Boolean).join(" "),
    message: str(spd, "sm") ?? null,
  }
}

function requireBytes(dict: PlistDict, key: string): Bytes {
  const value = bytesField(dict, key)
  if (value === undefined) throw new Error(`the sign-in response is missing its '${key}'`)
  return value
}

export interface AppToken {
  token: string
  adsid: string
  duration: number
  /** Seconds since the epoch, or 0 when Apple's number cannot be read as a date. */
  expiresAt: number
}

/**
 * `duration`/`expiry` units are undocumented. The FFI reads `expiry` as milliseconds when
 * it is ≥ 1e11 and as seconds when it is ≥ 1e9; anything smaller is not a timestamp.
 */
export function parseExpiry(value: number | undefined): number {
  if (value === undefined || !Number.isFinite(value)) return 0
  if (value >= 1e11) return Math.floor(value / 1000)
  if (value >= 1e9) return Math.floor(value)
  return 0
}

export function parseAppTokenReply(et: Bytes, sessionKey: Bytes, app: string, adsid: string): AppToken {
  const inner = parseBarePlist(decryptTokenContainer(et, sessionKey))
  const statusCode = intField(inner, "status-code")
  if (statusCode !== 200) throw new Error(`Apple refused the developer token (status ${statusCode})`)
  const entry = dictField(dictField(inner, "t") ?? {}, app)
  if (entry === undefined) throw new Error(`the app-token reply has no entry for ${app}`)
  return {
    token: requireStr(entry, "token", `the ${app} token`),
    adsid,
    duration: intField(entry, "duration") ?? 0,
    expiresAt: parseExpiry(intField(entry, "expiry")),
  }
}

// MARK: - the client

/**
 * `base64("<adsid>:<GsIdmsToken>")` — what the `/auth` pages are authenticated with.
 *
 * Both references build it this way from `spd`; the pages do not take the GS token the portal uses.
 */
export function identityToken(session: { adsid: string, idmsToken: string }): string {
  return toBase64(utf8(`${session.adsid}:${session.idmsToken}`))
}

/**
 * Whether Apple refused the client rather than answering it.
 *
 * **Only a 403**, and only one with no `serviceErrors` in it. A 401 does *not* count: these pages
 * answer a **made-up identity token with 401 — "(it was read)" — as a Mac just as much as as a
 * Windows PC**, which is why the reference stopped asking them as a Mac at all, and its own test
 * asserts `refuses_client(401, "")` is false.
 *
 * Which means a 401 from these pages is Apple saying it *read* our identity token and did not accept
 * it. Retrying that as a Mac would only hide the only clue we have.
 */
function refusedAsClient(status: number, body: Bytes): boolean {
  return status === 403 && !fromUtf8(body).includes("serviceErrors")
}

/**
 * What Apple's `/auth` failure pages actually say.
 *
 * They are HTML with the real complaint buried in a `<script id="401_args">` blob; printing the
 * first 200 bytes of that only ever shows the stylesheet. (That page is what a 401 from these
 * endpoints is: Apple's own "enter the password for the Apple Account {0}" HTML.)
 */
export function authFailureDetail(body: Bytes): string {
  const text = fromUtf8(body)
  const message = /"msg"\s*:\s*"([^"]*)"/.exec(text)
  if (message !== null && message[1] !== "") return `Apple's page says: ${message[1]}`
  const trimmed = text.trim()
  return trimmed === "" ? "(an empty body)" : trimmed.slice(0, 200)
}

export interface SignInLeg {
  response: PlistDict
  cpd: PlistDict
  /** The anisette headers this exchange was started with, reused for the second leg. */
  anisetteHeaders: HeaderMap
}

/**
 * GrandSlam itself. Everything it sends carries the base headers and a fresh set of the
 * three anisette headers, except where a caller deliberately freezes one.
 */
export class GrandSlam {
  /**
   * Whether the `/auth` pages have already been asked as a Mac.
   *
   * They refuse the Windows/ADI client with a bare 403 and answer the same request once the
   * client-info says Mac; once that has been learned, every later /auth call in the run goes
   * straight there. See `authRequest`.
   */
  authAsMac = false

  constructor(readonly bag: UrlBag, readonly anisette: AnisetteServer, readonly clientInfo = anisette.clientInfo.clientInfo, readonly userAgent = anisette.clientInfo.userAgent,
    /**
     * How the `/auth` requests go out. Injected so the 403 rule can be tested without an account —
     * it is the one part of sign-in that is neither exercised against Apple nor testable by
     * construction.
     */
    readonly authSender: (req: AppleRequest, anisette?: HeaderSource) => Promise<AppleResponse> = send) {}

  static async connect(anisette: AnisetteServer): Promise<GrandSlam> {
    const bag = await fetchUrlBag(anisette.clientInfo.clientInfo, anisette.clientInfo.userAgent)
    return new GrandSlam(bag, anisette)
  }

  url(key: string): string {
    const value = this.bag[key]
    if (value === undefined) throw new Error(`Apple's URL bag has no '${key}' entry`)
    return this.endpoint(value)
  }

  /**
   * Where a request actually goes. The bag hands out `gsa.apple.com`, which is the host the Xcode
   * shape talks to; the TestFlight shape is answered on `gsd.apple.com` — the other host the
   * desktop tool's own list allows — and `gsa` answers that shape with its 503 page.
   */
  private endpoint(url: string): string {
    if (this.anisette.shape !== "testflight") return url
    return url.replace("//gsa.apple.com/", "//gsd.apple.com/")
  }

  baseHeaders(plist = true): HeaderMap {
    return baseHeaders(this.clientInfo, this.userAgent, plist, this.anisette.shape)
  }

  /**
   * The anisette provisioning legs. These carry the base headers plus the two provisioning
   * headers and nothing else — asking for the three anisette headers here would be circular,
   * since this is the call that provisions the identity they come from.
   */
  postPlist = async (url: string, body: PlistDict, extraHeaders: HeaderMap): Promise<PlistDict> => {
    const headers = this.baseHeaders()
    Object.assign(headers, extraHeaders)
    const res = await send({ method: "POST", url, headers, body: xmlBytes(body), timeoutSeconds: 60, label: "gsa provisioning" })
    if (res.status !== 200) throw new AppleHttpError(res.status, url, bodyExcerpt(res.body))
    return checkGrandSlamStatus(grandSlamResponse(parseBarePlist(res.body)))
  }

  async plist(url: string, body: PlistDict, extraHeaders?: HeaderMap, frozenAnisetteHeaders?: HeaderMap): Promise<PlistDict> {
    const headers = this.baseHeaders()
    Object.assign(headers, extraHeaders ?? {}, frozenAnisetteHeaders ?? {})
    const res = await send({
      method: "POST",
      url,
      headers,
      body: xmlBytes(body),
      timeoutSeconds: 60,
      label: "grandslam",
    }, frozenAnisetteHeaders === undefined ? this.anisette : undefined)
    if (res.status !== 200) throw new AppleHttpError(res.status, url, bodyExcerpt(res.body))
    return grandSlamResponse(parseBarePlist(res.body))
  }

    /** SRP `init`, including the `hsc 434` resync that a Windows-ADI identity needs once. */
  async init(email: string, srp: SRPClient, frozenAnisetteHeaders?: HeaderMap): Promise<SignInLeg> {
    const send2 = (cpd: PlistDict, headers?: HeaderMap): Promise<PlistDict> =>
      this.plist(this.url("gsService"), buildInitRequest(email, srp.aPub, cpd), undefined, headers)

    let anisetteHeaders = frozenAnisetteHeaders ?? await this.anisette.headers()
    let cpd = clientProvidedData(anisetteHeaders, this.anisette.shape)
    let response = await send2(cpd, frozenAnisetteHeaders)
    const status = dictField(response, "Status") ?? response
    const sim = resyncToken(status)
    if (sim !== null) {
      anisetteHeaders = await this.anisette.headersAfterResync(sim)
      cpd = clientProvidedData(anisetteHeaders, this.anisette.shape)
      response = await send2(cpd, frozenAnisetteHeaders)
    }
    return { response: checkGrandSlamStatus(response), cpd, anisetteHeaders }
  }

  /** SRP `complete`. The anisette headers of the `init` leg are reused on purpose. */
  async complete(email: string, m1: Bytes, context: string, cpd: PlistDict, anisetteHeaders: HeaderMap): Promise<PlistDict> {
    const response = await this.plist(
      this.url("gsService"),
      buildCompleteRequest(email, m1, context, cpd),
      { Connection: "close" },
      anisetteHeaders,
    )
    return checkGrandSlamStatus(response)
  }

  async appTokens(session: SignInSession, app: string): Promise<AppToken> {
    const name = normaliseAppName(app)
    const anisetteHeaders = await this.anisette.headers()
    const response = await this.plist(
      this.url("gsService"),
      buildAppTokensRequest(
        session.adsid, name, session.context,
        appTokenChecksum(session.sessionKey, session.adsid, name),
        clientProvidedData(anisetteHeaders, this.anisette.shape), session.idmsToken,
      ),
      undefined,
      anisetteHeaders,
    )
    const et = bytesField(checkGrandSlamStatus(response), "et")
    if (et === undefined) throw new Error("Apple's app-token reply had no 'et'")
    return parseAppTokenReply(et, session.sessionKey, name, session.adsid)
  }

  // MARK: 2FA

  /** The 2FA pages authenticate with the SRP session itself, not a separate token. */
  identityHeaders(session: SignInSession): HeaderMap {
    return {
      "X-Apple-Identity-Token": identityToken(session),
      "X-Apple-I-MD-RINFO": this.anisette.routingInfo,
    }
  }

  /**
   * What we sent, in the shape that matters when Apple refuses it.
   *
   * A 401 from these pages means Apple **read** the identity token and did not accept it, so the
   * question becomes *what* it read. The token itself never goes in a message; its length and the
   * account it names are enough to tell "a real token Apple dislikes" from "an empty one".
   */
  private identitySummary(session: SignInSession): string {
    return `[identity token ${identityToken(session).length} chars for adsid ${JSON.stringify(session.adsid)}` +
      `, RINFO ${JSON.stringify(this.anisette.routingInfo)}]`
  }

  /**
   * A request to a page under `gsa.apple.com/auth`.
   *
   * These pages refuse the Windows/ADI client with a **bare 403** — no `serviceErrors` in the body,
   * just a refusal — and answer the very same request when the client says it is a Mac. The
   * reference implementation learned this the hard way and says so in a comment; the retry happens
   * once per sign-in and is remembered, so every later /auth call in the run is made as a Mac.
   *
   * `plist` and `json` mirror the reference's own flags: the pages that speak plist get plist
   * headers, the ones that speak JSON get JSON headers, and one of them (`secondaryAuth`) gets
   * neither. `retry` is off for the two calls that make Apple *send* something — see
   * `AppleRequest.retryRefusals`.
   */
  async authRequest(
    method: string, url: string, extraHeaders: HeaderMap,
    options: { json?: unknown, plist?: boolean, retry?: boolean } = {},
  ): Promise<{ status: number, body: Bytes }> {
    for (;;) {
      const headers = this.baseHeaders(options.plist ?? true)
      if (this.authAsMac) headers["X-Mme-Client-Info"] = GSA_MAC_CLIENT_INFO
      Object.assign(headers, extraHeaders)
      if (options.json !== undefined) {
        headers["Content-Type"] = "application/json"
        headers["Accept"] = "application/json, text/javascript, */*; q=0.01"
      }
      const res = await this.authSender({
        method, url, headers, json: options.json, timeoutSeconds: 60, label: "gsa auth",
        retryRefusals: options.retry ?? true,
      }, this.anisette)
      if (!this.authAsMac && refusedAsClient(res.status, res.body)) {
        this.authAsMac = true
        continue
      }
      return { status: res.status, body: res.body }
    }
  }

  /** Push a code to the trusted devices.
   *
   * Told not to repeat itself: a repeat would push a second code, and the person is reading the
   * first one.
   */
  async requestDeviceCode(session: SignInSession): Promise<void> {
    const url = this.url("trustedDeviceSecondaryAuth")
    const res = await this.authRequest("GET", url, this.identityHeaders(session), { retry: false })
    if (res.status >= 400) {
      throw new AppleHttpError(res.status, url, `${authFailureDetail(res.body)} ${this.identitySummary(session)}`)
    }
  }

  async validateDeviceCode(session: SignInSession, code: string): Promise<void> {
    const headers = { ...this.identityHeaders(session), "security-code": code }
    const url = this.url("validateCode")
    const res = await this.authRequest("GET", url, headers)
    if (res.status >= 400) {
      throw new AppleHttpError(res.status, url, `${authFailureDetail(res.body)} ${this.identitySummary(session)}`)
    }
    checkGrandSlamStatus(parseBarePlist(res.body))
  }

  /**
   * Ask Apple to send a code by SMS.
   *
   * The page is the bag's `secondaryAuth` — the URL Apple hands out for exactly this — and it names
   * no number: that flow starts from phone 1 (see the reference's note on `secondaryAuth`). It is a
   * GET, and `plist: false` because this page answers neither plist nor JSON.
   */
  async requestSmsCode(session: SignInSession): Promise<void> {
    const url = this.url("secondaryAuth")
    const res = await this.authRequest("GET", url, this.identityHeaders(session), { plist: false, retry: false })
    if (res.status >= 400) {
      throw new AppleHttpError(res.status, url, `${authFailureDetail(res.body)} ${this.identitySummary(session)}`)
    }
  }

  /** Hand the SMS code back. Phone 1, mode sms — the shape both references post. */
  async submitSmsCode(session: SignInSession, code: string): Promise<void> {
    const url = `${GSA_2FA_ROOT}/verify/phone/securitycode`
    const res = await this.authRequest(
      "POST", url, this.identityHeaders(session),
      { json: { securityCode: { code }, phoneNumber: { id: 1 }, mode: "sms" }, plist: false },
    )
    if (res.status >= 400) throw twoFactorError(res.status, res, "Apple rejected the SMS code", url)
  }
}

/** `-21669` is a wrong code, which the caller is expected to retry. */
export class WrongVerificationCodeError extends Error {}

function twoFactorError(status: number, res: { body: Bytes }, what: string, url: string): Error {
  const text = fromUtf8(res.body)
  try {
    const first = JSON.parse(text).serviceErrors[0]
    if (first.code === -21669) return new WrongVerificationCodeError(`${what}: ${first.message ?? "wrong code"}`)
    return new Error(`${what}: ${first.title ?? ""} — ${first.message ?? ""}`)
  } catch {
    // Named URL, not the root: this is also the path a bare 403 lands on, and "HTTP 403 for
    // https://gsa.apple.com/auth" says nothing about which of these pages refused.
    return new AppleHttpError(status, url, text.slice(0, 200))
  }
}

/**
 * Which part of the sign-in Apple refused.
 *
 * The legs fail for different reasons and the code alone does not say which: `init` is answered
 * from the account, `complete` is where the password proof is checked, and the app-token exchange
 * comes after a sign-in that worked. Without the label, "check the address" and "check the
 * password" arrive looking identical — and an HTTP refusal (a 503 is Apple's edge turning the
 * client away, the one failure here that nobody can fix) says which request met it.
 */
function withStage<T>(which: string, run: () => Promise<T>): Promise<T> {
  return run().catch((error: unknown) => {
    if (error instanceof GrandSlamError) throw new GrandSlamError(error.code, error.detail, which)
    if (error instanceof AppleHttpError) {
      const detail = [error.detail, `(${which})`].filter(part => part !== "").join(" ")
      throw new AppleHttpError(error.status, error.url, detail)
    }
    throw error
  })
}

/** The trusted numbers Apple will send to: a landline can only take a voice call. */
export interface TrustedPhoneNumber {
  numberWithDialCode: string
  lastTwoDigits: string
  pushMode: "sms" | "voice"
  id: number
}

// MARK: - the sign-in itself

export interface SignInResult {
  session: SignInSession
  step: SignInStep
  spd: PlistDict
}

export class AppleAccount {
  constructor(readonly grandSlam: GrandSlam, readonly anisette: AnisetteServer) {}

  /**
   * One SRP exchange. The password is read here and nowhere else: it is never stored, never
   * logged, and never put in a request body — Apple only ever sees a proof derived from it.
   * The caller's reference is dropped when this returns.
   */
  async signInOnce(email: string, password: string): Promise<{ step: SignInStep, spd: PlistDict, session: SignInSession }> {
    const srp = new SRPClient({ group: SRP_GROUP_2048, hash: sha256, username: email, usernameForX: "" })
    const first = await withStage("while checking the account", () => this.grandSlam.init(email, srp))

    const salt = bytesField(first.response, "s")
    const iterations = intField(first.response, "i")
    const protocol = str(first.response, "sp") ?? ""
    const bPub = bytesField(first.response, "B")
    if (salt === undefined || iterations === undefined || bPub === undefined) {
      throw new Error(`Apple's SRP reply has no s, i or B (it carried ${describeReply(first.response)})`)
    }
    if (protocol !== "s2k" && protocol !== "s2k_fo") throw new Error(`Apple asked for an unsupported SRP protocol: ${protocol}`)

    // `c` is a STRING in this reply, unlike the `Data` its siblings are — isideload reads it with
    // `get_str` and echoes it back verbatim. Reading it as bytes is what the first real sign-in
    // caught the hard way: the error said "missing its 'c'" while the field sat right there.
    const context = str(first.response, "c")
    if (context === undefined) {
      throw new Error(`Apple's SRP reply has no 'c' (it carried ${describeReply(first.response)})`)
    }

    const passwordKey = applePasswordKey(password, salt, iterations, protocol)
    const m1 = srp.process(salt, bPub, passwordKey)
    password = ""

    const second = await withStage("while checking the password", () =>
      this.grandSlam.complete(email, m1, context, first.cpd, first.anisetteHeaders))

    const m2 = bytesField(second, "M2")
    if (m2 === undefined) throw new Error("Apple's SRP reply had no M2")
    if (!srp.verifyM2(m2)) throw new Error("Apple's server proof did not verify. Refusing to continue.")

    const spdBlob = bytesField(second, "spd")
    if (spdBlob === undefined) throw new Error("Apple's sign-in response had no spd")
    const spd = decryptExtraData(spdBlob, srp.sessionKey!, srp.premaster!)
    const status = dictField(second, "Status") ?? second
    return { step: nextSignInStep(status), spd, session: sessionFromSpd(spd) }
  }

  /**
   * The whole loop: sign in, clear 2FA if Apple asks for it, sign in again. `askCode` is
   * whatever the UI uses to collect a six-digit code. It is called at most once per step.
   *
   * The password stays live for the whole loop on purpose: clearing 2FA does **not** finish a
   * sign-in — Apple wants a second, complete SRP exchange afterwards, and that exchange starts
   * from the password again. The reference keeps it for exactly this reason. Clearing it after the
   * first attempt (which this did, as a tidiness) made every 2FA'd sign-in re-sign-in with an empty
   * password, and Apple answers that as a credentials rejection.
   */
  async signIn(email: string, password: string, askCode: (prompt: string) => Promise<string>): Promise<SignInResult> {
    try {
      let attempt = await this.signInOnce(email, password)
      for (let round = 0; round < 10; round++) {
        if (attempt.step === "ok") return attempt
        if (attempt.step === "device-2fa" || attempt.step === "device-2fa-sent") {
          await this.clearDeviceSecondFactor(attempt.session, attempt.step === "device-2fa", askCode)
        } else if (attempt.step === "sms-2fa") {
          await this.clearSmsSecondFactor(attempt.session, askCode)
        } else if (attempt.session.pet !== null) {
          return attempt
        } else {
          throw new Error("Apple wants an extra sign-in step this port cannot do. Sign in once at https://appleid.apple.com in Safari, then retry.")
        }
        attempt = await this.signInOnce(email, password)
      }
      throw new Error("sign-in did not settle after 10 attempts")
    } finally {
      password = ""
    }
  }

  private async clearDeviceSecondFactor(session: SignInSession, sendCode: boolean, askCode: (prompt: string) => Promise<string>): Promise<void> {
    if (sendCode) await this.grandSlam.requestDeviceCode(session)
    await this.grandSlam.validateDeviceCode(session, await askCode("Two-factor code"))
  }

  private async clearSmsSecondFactor(session: SignInSession, askCode: (prompt: string) => Promise<string>): Promise<void> {
    for (;;) {
      await this.grandSlam.requestSmsCode(session)
      try {
        await this.grandSlam.submitSmsCode(session, await askCode("SMS code"))
        return
      } catch (error) {
        if (!(error instanceof WrongVerificationCodeError)) throw error
      }
    }
  }
}

/** The whole "sign in and prove it" milestone, in one call. */
export async function signInForDeveloperToken(
  email: string,
  password: string,
  askCode: (prompt: string) => Promise<string>,
  anisette: AnisetteServer,
  /** The bag the caller already has, so a sign-in asks Apple for it once. */
  bag?: UrlBag,
): Promise<AppToken> {
  const grandSlam = bag === undefined ? await GrandSlam.connect(anisette) : new GrandSlam(bag, anisette)
  const account = new AppleAccount(grandSlam, anisette)
  const result = await account.signIn(email, password, askCode)
  return withStage("while exchanging the developer token", () => grandSlam.appTokens(result.session, XCODE_AUTH_APP))
}

export { GrandSlamError, xmlBytes }
