// An anisette server that runs on this device.
//
// The ADI is emulated in a WebView (the assets under `ASSET_DIRECTORY` are lbr77/anisette-js's
// build); the three endpoints `/v3/client_info`, `/v3/get_headers` and the provisioning
// WebSocket are served from here, so the app's own client talks to it unchanged.
//
// This server follows the desktop tool that signs in today: the machine is the Android ADI the
// assets carry, and the device description it advertises is that machine's own. Remote servers
// keep the app's older shape (see `signInShape` in ./anisette).
import { Path, Script } from "scripting"
import { fromBase64, fromUtf8 } from "../util"

/**
 * The port the API listens on. It is fixed because the address is what an identity is filed
 * under (`anisette_slots.json`): a new port every run would mean provisioning afresh every run.
 */
const API_PORT = 8798

/** Where the page and the ADI blobs are. They ship beside the script, in `local-anisette/`. */
const ASSET_DIRECTORY = Path.join(Script.directory, "local-anisette")

/** What the emulated machine is; `assets/client-info.json` from the same tool. */
export const LOCAL_CLIENT_INFO = "<Pixel 7> <Android;14;UQ1A.240205.002> <com.apple.AuthKit/1 (com.apple.akd/1.0)>"
export const LOCAL_USER_AGENT = "akd/1.0 CFNetwork/1404.0.5 Darwin/22.3.0"

interface Running {
  url: string
  pages: HttpServer
  api: HttpServer
  controller: WebViewController
}

let running: Running | null = null

/** The page of the running machine, and the device description it was booted with. */
let pageEvaluate: ((script: string) => Promise<unknown>) | null = null
let pageDevice: unknown = null

/** What the emulated machine answers to `X-Apple-I-MD-RINFO`; the desktop tool's Android ADI. */
export const LOCAL_ROUTING_INFO = "17106176"

/**
 * Whether the page may be asked from here.
 *
 * `evaluateJavaScript` is main-thread-only, and WebKit kills the whole process when it is called
 * from another thread (`crashDueToApplicationCallingMainThreadOnlyWebKitAPIFromBackgroundThread`,
 * seen on this device). So the direct path is taken only where that is allowed — a sign-in leaves the
 * anisette call on a background thread — and everyone else goes through the loopback endpoint, which
 * Scripting marshals itself.
 */
export function canAskPageDirectly(): boolean {
  const thread = (globalThis as any).Thread
  return thread !== undefined && thread.isMainThread === true
}

/**
 * One password, asked of the page from the caller's own flow.
 *
 * For a caller that cannot use the loopback endpoint: a request arrives in an HTTP handler, and a
 * script that is not the active one — an intent, a background run — may not evaluate from there.
 */
export async function mintLocalHeaders(identifierBase64: string, adiPbBase64: string): Promise<{ otp: string, mid: string }> {
  // Checked before the machine is brought up: the WebView itself may only be touched from here.
  if (!canAskPageDirectly()) throw new Error("anisette: the machine on this device may only be asked from the main thread")
  if (pageEvaluate === null || pageDevice === null) await startLocalAnisette()
  const evaluate = pageEvaluate
  if (evaluate === null || pageDevice === null) throw new Error("the local anisette page is not loaded")
  const args = [JSON.stringify(pageDevice), adiIdentifier(identifierBase64), adiPbBase64]
  const answer = await evaluate(
    `return window.ani.runSync("headersSync", ${JSON.stringify(JSON.stringify(args))})`)
  if (typeof answer === "string" && answer.startsWith("ERR: ")) throw new Error(answer.slice(5))
  const minted = JSON.parse(String(answer))
  if (!minted.ok) throw new Error(String(minted.error))
  return { otp: String(minted.otp), mid: String(minted.mid) }
}

/** Whether an anisette address is this server, rather than one on the network. */
export function isLocalAnisette(address: string): boolean {
  return address.trim().replace(/\/+$/, "").startsWith("http://127.0.0.1:")
}

export function localAnisetteIsRunning(): boolean {
  return running !== null
}

/** Where a v3 client (or a person) finds this server. */
export function localAnisetteUrl(): string {
  if (running === null) throw new Error("the local anisette server is not running")
  return running.url
}

/**
 * A v3 client's identifier is 16 bytes; the ADI's android id is 16 hex characters, so the first
 * eight bytes are what the machine gets. Deterministic, which is what makes the adi_pb a client
 * stores usable again on its next request.
 */
function adiIdentifier(identifierBase64: string): string {
  const bytes = fromBase64(identifierBase64)
  return [...bytes.slice(0, 8)].map(byte => byte.toString(16).padStart(2, "0")).join("")
}

function json(payload: unknown): HttpResponse {
  return HttpResponse.ok(HttpResponseBody.text(JSON.stringify(payload)))
}

/**
 * `HttpServer.start` answers with an error message when it fails and with nothing when it
 * succeeds — `undefined` in practice, whatever the signature says — so only a truthy answer is
 * a failure.
 */
function startFailure(server: HttpServer, port: number): string | null {
  const answer = server.start({ port, forceIPv4: true }) as string | null | undefined
  return answer ? String(answer) : null
}

/**
 * Start the machine and the endpoints. Safe to call twice: the second call answers with the same
 * address, and both servers keep running until `stopLocalAnisette`.
 */
export async function startLocalAnisette(): Promise<string> {
  if (running !== null) return running.url

  const pages = new HttpServer()
  const api = new HttpServer()
  const controller = new WebViewController()
  try {
    pages.listenAddressIPv4 = "127.0.0.1"
    pages.registerFilesFromDirectory("/:file", Path.join(ASSET_DIRECTORY))
    const pageError = startFailure(pages, 0)
    if (pageError !== null) throw new Error(pageError)
    const pagePort = pages.port
    if (pagePort === null) throw new Error("the page server did not report a port")

    await controller.loadURL(`http://127.0.0.1:${pagePort}/index.html`)
    const evaluate = async (script: string): Promise<string> => controller.evaluateJavaScript<string>(script)
    /** evaluateJavaScript does not wait for promises: page work is a job this polls. */
    const call = async (name: string, args: unknown[] = [], timeoutMs = 90_000): Promise<any> => {
      const id = await evaluate(`return window.ani.run(${JSON.stringify(name)}, ${JSON.stringify(JSON.stringify(args))})`)
      const deadline = Date.now() + timeoutMs
      for (;;) {
        const value = await evaluate(`return window.ani.poll(${JSON.stringify(id)})`)
        if (typeof value === "string" && value !== "") {
          if (value.startsWith("ERR: ")) throw new Error(`${name}: ${value.slice(5)}`)
          return JSON.parse(value)
        }
        if (Date.now() > deadline) throw new Error(`${name}: no answer after ${timeoutMs} ms`)
        await new Promise(resolve => setTimeout(() => resolve(undefined), 100))
      }
    }

    const device = {
      UUID: (globalThis as any).crypto.randomUUID().toUpperCase(),
      clientInfo: LOCAL_CLIENT_INFO,
      identifier: randomHex(8),
      localUUID: randomHex(32).toUpperCase(),
    }
    const booted = await call("init", [JSON.stringify(device)])
    if (!booted.ok) throw new Error(String(booted.error))
    pageEvaluate = async (script: string) => controller.evaluateJavaScript<unknown>(script)
    pageDevice = device

    api.listenAddressIPv4 = "127.0.0.1"
    api.registerAsyncHandler("/v3/client_info", async () => json({ client_info: LOCAL_CLIENT_INFO, user_agent: LOCAL_USER_AGENT }))

    api.registerAsyncHandler("/v3/get_headers", async request => {
      const text = fromUtf8(new Uint8Array((request.body as any).toArrayBuffer()))
      const body = text === "" ? {} : JSON.parse(text)
      const identifier = String(body.identifier ?? "")
      const adiPb = String(body.adi_pb ?? "")
      if (identifier === "" || adiPb === "") return json({ result: "Fail", message: "identifier and adi_pb are required" })
      try {
        // This endpoint serves a client that does not know it is talking to the machine on this
        // device: this app's own client asks the page directly (`mintLocalHeaders`), because a script
        // that is not the active one — an intent — may not evaluate from a handler.
        const args = [JSON.stringify(device), adiIdentifier(identifier), adiPb]
        const answer = await evaluate(
          `return window.ani.runSync("headersSync", ${JSON.stringify(JSON.stringify(args))})`)
        if (typeof answer === "string" && answer.startsWith("ERR: ")) throw new Error(answer.slice(5))
        const otp = JSON.parse(String(answer))
        if (!otp.ok) return json({ result: "Fail", message: String(otp.error) })
        return json({
          result: "Headers",
          "X-Apple-I-MD": String(otp.otp),
          "X-Apple-I-MD-M": String(otp.mid),
          "X-Apple-I-MD-RINFO": LOCAL_ROUTING_INFO,
        })
      } catch (error) {
        return json({ result: "Fail", message: error instanceof Error ? error.message : String(error) })
      }
    })

    api.registerWebsocket("/v3/provisioning_session", {
      onConnected: session => { session.writeText(JSON.stringify({ result: "GiveIdentifier" })) },
      handleText: (session, text) => {
        void (async () => {
          const message = JSON.parse(text)
          if (typeof message.identifier === "string") {
            const placed = await call("setState", [JSON.stringify(device), adiIdentifier(message.identifier), ""])
            if (!placed.ok) throw new Error(String(placed.error))
            session.writeText(JSON.stringify({ result: "GiveStartProvisioningData" }))
            return
          }
          if (typeof message.spim === "string") {
            const started = await call("start", [message.spim])
            if (!started.ok) throw new Error(String(started.error))
            session.writeText(JSON.stringify({ result: "GiveEndProvisioningData", cpim: started.cpim }))
            return
          }
          if (typeof message.ptm === "string") {
            const ended = await call("end", [message.ptm, message.tk])
            if (!ended.ok) throw new Error(String(ended.error))
            const stored = await call("readAdiPb")
            session.writeText(JSON.stringify({ result: "ProvisioningSuccess", adi_pb: stored.adiPb }))
          }
        })().catch(error => {
          session.writeText(JSON.stringify({ result: "Fail", message: error instanceof Error ? error.message : String(error) }))
        })
      },
    })

    // The fixed port first; a random one if something else has it, at the cost of provisioning
    // this run rather than reloading the identity filed under the fixed address.
    let apiError = startFailure(api, API_PORT)
    if (apiError !== null) {
      const fallback = startFailure(api, 0)
      apiError = fallback
    }
    if (apiError !== null) throw new Error(apiError)
    const apiPort = api.port
    if (apiPort === null) throw new Error("the anisette server did not report a port")

    running = { url: `http://127.0.0.1:${apiPort}`, pages, api, controller }
    return running.url
  } catch (error) {
    try { pages.stop() } catch { /* not started */ }
    try { api.stop() } catch { /* not started */ }
    controller.dismiss()
    controller.dispose()
    throw error instanceof Error ? error : new Error(String(error))
  }
}

/** Tear the machine down. The WebView goes with it, which is the only way to give the memory back. */
export function stopLocalAnisette(): void {
  const current = running
  if (current === null) return
  running = null
  pageEvaluate = null
  pageDevice = null
  try { current.pages.stop() } catch { /* already down */ }
  try { current.api.stop() } catch { /* already down */ }
  current.controller.dismiss()
  current.controller.dispose()
}

function randomHex(bytes: number): string {
  const values = new Uint8Array(bytes)
  ;(globalThis as any).crypto.getRandomValues(values)
  return [...values].map(byte => byte.toString(16).padStart(2, "0")).join("")
}
