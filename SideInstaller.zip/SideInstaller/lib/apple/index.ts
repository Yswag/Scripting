// The apple package's public surface — the only thing outside `lib/apple` should import.
//
// One seam: sign an Apple ID in, and keep using what that produced. Reach an anisette server for
// the device-attestation identity Apple demands, sign in on GrandSlam for a developer token, spend
// that token at the developer portal — and remember it between runs, because a token belongs to the
// anisette identity it was issued for.
//
// Everything else in this directory is implementation, deliberately unexported here: the SRP legs,
// the plist and JSON body helpers, the anisette slot table, app-token parsing, the portal's request
// envelopes. Tests that need those reach in directly from `dev/`.
//
// A second seam hangs off the first: signing in produces a session, but signing an app needs an
// identity. `identity.ts` — the key that is never regenerated, and the certificate Apple issues for
// it — is what the gate between "signed in" and "paired" runs.

// --- why the calls can fail --------------------------------------------------------------------

export { AppleHttpError, GrandSlamError, PortalError } from "./http"

// --- anisette: the device-attestation identity, and the headers built from it -------------------

export {
  AnisetteNotProvisionedError, AnisetteServer, AppleRefusals, anisetteCandidates, fetchAnisetteServers,
  GSA_CLIENT_INFO, GSA_USER_AGENT, saveAnisettePick, savedAnisettePick, selectIdentity,
} from "./anisette"
export type { AnisetteIdentity, AnisetteServerEntry, ProvisioningUrls, SignInShape } from "./anisette"

// --- the server that runs on this device, and the shape a sign-in through it takes --------------

export {
  isLocalAnisette, localAnisetteIsRunning, localAnisetteUrl, startLocalAnisette, stopLocalAnisette,
  LOCAL_CLIENT_INFO, LOCAL_USER_AGENT,
} from "./local-anisette"
export { signInShape } from "./anisette"

// --- GrandSlam: the URL bag, then the two SRP legs up to a developer token ----------------------

export { GrandSlam, fetchUrlBag, isCredentialRejection, signInForDeveloperToken } from "./grandslam"
export type { AppToken } from "./grandslam"

// --- the developer portal, opened with a token --------------------------------------------------

export { PortalClient } from "./portal"
export type { AppGroup, AppId, DeveloperCertificate, Team } from "./portal"

// --- the signing identity: the key we keep, and the certificate Apple issues for it -------------

export { ensureSigningIdentity, loadOrCreateSigningKey, MACHINE_NAME } from "./identity"

// --- the session between runs ------------------------------------------------------------------

export { clearSession, isSessionUsable, loadSession, saveSession, verdictFor } from "./session"

// --- the Apple IDs this device knows, and which one is in use ----------------------------------

export { activeAccount, dropAccount, forgetTeam, loadAccounts, loadTeam, rememberAccount, saveTeam } from "./accounts"

// --- the account hand-off: what SideStore imports to reuse our certificate ---------------------

export { buildSideconf, sideconfBytes, SIDECONF_FILE_NAME, importsAccountConfigSilently } from "./sideconf"
export type { SideconfOptions } from "./sideconf"

// --- what a caller writes with: the sign package's key types -----------------------------------

export type { RsaJwk } from "../sign"
