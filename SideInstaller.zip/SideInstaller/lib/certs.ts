// The Certificates tool: the Apple ID's development certificates, listed and revoked one at a time.
// The port of the Swift app's `CertManager.swift` — developer portal only, so nothing here touches
// the device.
//
// Upstream holds a Rust `CertSession` for as long as the app runs, and signs in with the password it
// keeps in memory. This port holds one `PortalClient` for as long as the account stays the same, and
// cannot keep a password: what it has is the saved session, and the app behind `CertsHost` is asked
// for the password when there is none to reuse.
import type { TranslationKey } from "./i18n"
import type { DeveloperCertificate, PortalClient, Team } from "./apple"
import { StepError, type LogLevel } from "./engine"

/** What the tool needs from the app it runs in. Injected, so a test can answer without a portal. */
export interface CertsHost {
  /** The Apple ID this device uses, or null when none has signed in. */
  account(): string | null
  /**
   * A portal client for `email`, from the session already saved — or null when there is none usable.
   * Never asks anything.
   */
  savedPortal(email: string): Promise<PortalClient | null>
  /** Signs `email` in — password, then the second factor — and saves the session. */
  signIn(email: string): Promise<boolean>
  say(key: TranslationKey, params?: Record<string, string | number>, level?: LogLevel): void
}

/** One row of the list: the certificate, and whether Apple's expiry for it has already passed. */
export interface CertRow {
  certificate: DeveloperCertificate
  expired: boolean
}

/** What identifies a certificate in the list: the serial revocation keys on, else its id. */
export function certificateKey(certificate: DeveloperCertificate): string {
  const serial = certificate.serialNumber
  return serial !== null && serial !== "" ? serial : certificate.certificateId ?? ""
}

/** What a certificate is called, before the page adds its own wording for an unnamed one. */
export function certificateName(certificate: DeveloperCertificate): string {
  return certificate.name !== "" ? certificate.name : certificate.machineName ?? ""
}

/** Apple's own reading of an expiry: past its date. One the listing left undated never is. */
export function isExpired(certificate: DeveloperCertificate, now = new Date()): boolean {
  const at = certificate.expirationDate
  return at !== null && at.getTime() < now.getTime()
}

/**
 * The list, and the two things that can be done to it.
 *
 * Fields are read by the page and written only here, which is as close as this gets to upstream's
 * `private(set)`.
 */
export class Certificates {
  /** The rows the page draws; empty until a list has arrived. */
  certs: CertRow[] = []
  /** The team the certificates belong to, once a list has been fetched. */
  team: Team | null = null
  /** A session is held, so a refresh needs nothing from the person. */
  signedIn = false
  /** A sign-in, a load or a refresh is under way. */
  working = false
  /** The `certificateKey` of the certificate being revoked, or null. */
  revoking: string | null = null
  /** True once a list has arrived — tells "not loaded" apart from "no certificates". */
  loaded = false
  /** Why the last action failed, as a key the page resolves. */
  failure: StepError | null = null

  private client: PortalClient | null = null
  private clientEmail: string | null = null
  private teamId: string | null = null
  private didAutoLoad = false
  private readonly listeners = new Set<() => void>()
  private readonly host: CertsHost

  constructor(host: CertsHost) {
    this.host = host
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  private notify() {
    for (const listener of this.listeners) listener()
  }

  /** Whether something is in flight: the page disables its controls while one is. */
  get busy(): boolean {
    return this.working || this.revoking !== null
  }

  closeFailure() {
    this.failure = null
    this.notify()
  }

  /**
   * The list, fetched once when the page first opens — and only when that costs no questions.
   *
   * The Swift app's `autoLoad` runs when it already holds the password; here the same condition is a
   * saved session that still works, so a page that opens on a device nobody has signed in on stays
   * quiet instead of putting up a password prompt nobody asked for — or a complaint about an Apple ID
   * that was never there.
   */
  autoLoad() {
    if (this.didAutoLoad || this.loaded || this.busy) return
    this.didAutoLoad = true
    void this.load(false)
  }

  /** Signs in when it must, then lists. `interactive` is what allows the password to be asked for. */
  async load(interactive = true) {
    if (this.busy) return
    const email = this.host.account()
    if (email === null) {
      // Nothing to sign in as. The page says so when a person pressed the button, and stays quiet
      // when it opened by itself — which is what the Swift app's `autoLoad` does with no credentials
      // to sign in with.
      if (interactive) this.fail(new StepError("certs.noAccount"))
      return
    }

    this.working = true
    this.failure = null
    this.host.say("certs.log.loading")
    this.notify()

    try {
      const client = await this.clientFor(email, interactive)
      // A null client has already said why, unless nothing was asked — which is not a failure.
      if (client === null) return
      await this.list(client)
    } catch (error) {
      this.fail(this.wrap(error, "certs.listFailed"))
    } finally {
      this.working = false
      this.notify()
    }
  }

  /**
   * Revokes one certificate, then lists again.
   *
   * Irreversible: every app already signed with it stops launching, on every device. The page asks
   * a person first.
   */
  async revoke(row: CertRow) {
    const client = this.client
    const teamId = this.teamId
    if (client === null || teamId === null || this.busy) return

    const serial = row.certificate.serialNumber
    if (serial === null || serial === "") {
      this.fail(new StepError("certs.noSerial"))
      return
    }

    const name = certificateName(row.certificate)
    this.revoking = certificateKey(row.certificate)
    this.failure = null
    this.host.say("certs.log.revoking", { name, serial })
    this.notify()

    try {
      try {
        await client.revokeCertificate(teamId, serial)
      } catch (error) {
        this.fail(this.wrap(error, "certs.revokeFailed"))
        return
      }
      this.host.say("certs.log.revoked", { name }, "ok")
      // Again whatever the list says now: what is on screen has to be Apple's, not this app's idea
      // of what a revocation did.
      await this.list(client)
    } catch (error) {
      // The revocation itself went through; only the list that follows it did not.
      this.fail(this.wrap(error, "certs.listFailed"))
    } finally {
      this.revoking = null
      this.notify()
    }
  }

  /**
   * The account's client: the one in hand when it belongs to this account, else whatever can be
   * opened. A client for another Apple ID is dropped — the Swift app calls `signOut` for this when
   * the account in use changes.
   */
  private async clientFor(email: string, interactive: boolean): Promise<PortalClient | null> {
    if (this.client !== null && this.clientEmail === email) return this.client
    this.dropSession()

    let client = await this.host.savedPortal(email)
    if (client === null && interactive) {
      // Upstream signs in here with the password it already holds. This port asks for it, through the
      // same sign-in the Settings page and the gates use.
      this.host.say("certs.log.signingIn", { email })
      if (!(await this.host.signIn(email))) {
        this.fail(new StepError("certs.signInFailed", { email }))
        return null
      }
      client = await this.host.savedPortal(email)
      if (client === null) {
        this.fail(new StepError("certs.noSession", { email }))
        return null
      }
    }
    if (client === null) return null

    this.client = client
    this.clientEmail = email
    this.signedIn = true
    return client
  }

  /** Lets the session go: what it holds stops meaning anything when the account changes. */
  private dropSession() {
    this.client = null
    this.clientEmail = null
    this.teamId = null
    this.team = null
    this.signedIn = false
    this.certs = []
    this.loaded = false
  }

  /**
   * The team the certificates are listed under, asked for once.
   *
   * The first one, as the Swift app's sign-in takes it: a free Apple ID has exactly one, and which
   * team signs an app is the Install page's question, not this tool's.
   */
  private async teamFor(client: PortalClient): Promise<string> {
    if (this.teamId !== null) return this.teamId
    const team = (await client.listTeams())[0]
    if (team === undefined) throw new StepError("certs.noTeams")
    this.team = team
    this.teamId = team.teamId
    this.host.say("certs.log.team", { name: team.name, teamId: team.teamId })
    return team.teamId
  }

  /** One list, as the page draws it. Throws what the portal threw, for the caller to wrap. */
  private async list(client: PortalClient) {
    const listed = await client.listCertificates(await this.teamFor(client))
    this.certs = listed.map(certificate => ({ certificate, expired: isExpired(certificate) }))
    this.loaded = true
    this.host.say("certs.log.listed", { count: listed.length }, "ok")
  }

  /**
   * A failure as the page shows it.
   *
   * A step error already carries the right key — "this account is on no team" is not a listing that
   * failed — so only a raw one from the portal or the network is wrapped in the caller's key.
   */
  private wrap(error: unknown, key: TranslationKey): StepError {
    if (error instanceof StepError) return error
    return new StepError(key, { message: error instanceof Error ? error.message : String(error) })
  }

  private fail(error: StepError) {
    this.failure = error
    // The failure is itself a key, so the log reads as the sentence a person would have seen.
    this.host.say(error.key, error.params, "error")
    this.notify()
  }
}
