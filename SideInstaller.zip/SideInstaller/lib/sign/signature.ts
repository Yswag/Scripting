// The embedded code signature: the superblob, its CodeDirectories, and verification.
//
// Three rules decide whether this is right, and all three were established against a real signed
// IPA rather than from memory:
//
//  1. The superblob magic is CSMAGIC_EMBEDDED_SIGNATURE (0xfade0cc0); CSMAGIC_CODEDIRECTORY is
//     0xfade0c02 and lives INSIDE it as a blob.
//  2. A special slot's hash covers the ENTIRE blob, magic and length included. Hashing only the
//     body is off by eight bytes and fails silently.
//  3. Special slots are addressed as hash[-number], where number 1 is Info.plist, 2 Requirements,
//     5 Entitlements, 7 DER-entitlements. Index number runs against the hash array.
import type { Bytes } from "../util"
import { concat, readU32be } from "../util"
import { algorithmForHashType, hashOf, hashLength, sha256, sha1, type HashAlgorithm } from "../util"
import { MachO } from "./macho"

export const CS_MAGIC = {
  /** The outer superblob. Not "CodeDirectory", despite the name it is often given. */
  embeddedSignature: 0xfade0cc0,
  codeDirectory: 0xfade0c02,
  requirements: 0xfade0c01,
  requirement: 0xfade0c00,
  entitlements: 0xfade7171,
  derEntitlements: 0xfade7172,
  blobWrapper: 0xfade0b01,
} as const

/** Slot numbers inside the superblob, and inside the CodeDirectory's hash array. */
export const CS_SLOT = {
  codeDirectory: 0,
  infoPlist: 1,
  requirements: 2,
  resourceDir: 3,
  application: 4,
  entitlements: 5,
  derEntitlements: 7,
  /** The CMS signature. 0x10000, and the reason a real signature "has a signature slot". */
  signature: 0x10000,
  /** A second CodeDirectory, so one blob can carry both SHA-1 and SHA-256. */
  alternateCodeDirectories: 0x1000,
} as const

export const CS_FLAG = {
  adhoc: 0x00000001,
  getTaskAllow: 0x00000002,
  kill: 0x00000004,
  hard: 0x00000008,
  noUserXattr: 0x00000100,
  restrict: 0x00000200,
  runtime: 0x00010000,
  linkerSigned: 0x00020000,
} as const

/** The default page size every signer uses. */
export const DEFAULT_PAGE_SIZE_LOG2 = 12

export class SignatureError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "SignatureError"
  }
}

// MARK: - the superblob

export interface BlobIndexEntry {
  /** The slot number. */
  type: number
  /** Offset from the start of the superblob. */
  offset: number
  magic: number
  length: number
}

export class EmbeddedSignature {
  private constructor(
    readonly bytes: Bytes,
    readonly magic: number,
    readonly length: number,
    readonly blobs: BlobIndexEntry[],
  ) {}

  static parse(bytes: Bytes): EmbeddedSignature {
    if (bytes.length < 12) throw new SignatureError("signature blob is shorter than a superblob header")
    const magic = readU32be(bytes, 0)
    if (magic !== CS_MAGIC.embeddedSignature) {
      throw new SignatureError(
        `expected CSMAGIC_EMBEDDED_SIGNATURE (0xfade0cc0), got 0x${magic.toString(16)}`,
      )
    }
    const length = readU32be(bytes, 4)
    const count = readU32be(bytes, 8)
    if (length > bytes.length) {
      throw new SignatureError(`superblob claims ${length} bytes but only ${bytes.length} are present`)
    }
    if (12 + count * 8 > length) {
      throw new SignatureError(`superblob claims ${count} blobs, which does not fit in ${length} bytes`)
    }

    const blobs: BlobIndexEntry[] = []
    for (let i = 0; i < count; i++) {
      const type = readU32be(bytes, 12 + i * 8)
      const offset = readU32be(bytes, 16 + i * 8)
      if (offset + 8 > length) {
        throw new SignatureError(`blob ${i} sits at ${offset}, past the end of the superblob`)
      }
      blobs.push({ type, offset, magic: readU32be(bytes, offset), length: readU32be(bytes, offset + 4) })
    }
    return new EmbeddedSignature(bytes, magic, length, blobs)
  }

  /** Every CodeDirectory, in the order they appear. Usually SHA-1 first, then SHA-256. */
  get codeDirectories(): CodeDirectory[] {
    return this.blobs
      .filter(blob => blob.magic === CS_MAGIC.codeDirectory)
      .map(blob => CodeDirectory.parse(this.bytes, blob.offset))
  }

  /** The first CodeDirectory, which is the one a device verifies against. */
  get primaryCodeDirectory(): CodeDirectory {
    const first = this.codeDirectories[0]
    if (first === undefined) throw new SignatureError("the signature contains no CodeDirectory")
    return first
  }

  /** The CMS signature bytes, or null for an ad-hoc signature. */
  get cmsSignature(): Bytes | null {
    const blob = this.blobs.find(entry => entry.magic === CS_MAGIC.blobWrapper)
    if (blob === undefined) return null
    return this.bytes.subarray(blob.offset + 8, blob.offset + blob.length)
  }

  /** The full bytes of a blob, header included — which is what a special slot hashes. */
  blobBytes(entry: BlobIndexEntry): Bytes {
    return this.bytes.subarray(entry.offset, entry.offset + entry.length)
  }

  /** Finds a blob by slot number. */
  blobAtSlot(type: number): BlobIndexEntry | null {
    return this.blobs.find(entry => entry.type === type) ?? null
  }
}

/**
 * The length a CSMAGIC_EMBEDDED_SIGNATURE superblob declares in its header.
 *
 * Read without parsing, so a caller can check a length before committing to it.
 */
export function embeddedSignatureLength(bytes: Bytes): number {
  if (bytes.length < 8) throw new SignatureError("signature blob is shorter than a header")
  return readU32be(bytes, 4)
}

// MARK: - the CodeDirectory

export interface CodeDirectoryFields {
  magic: number
  length: number
  version: number
  flags: number
  hashOffset: number
  identifierOffset: number
  specialSlots: number
  codeSlots: number
  codeLimit: number
  hashSize: number
  hashType: number
  platform: number
  pageSizeLog2: number
  /** Present from version 0x20400. */
  execSegBase: bigint | null
  execSegLimit: bigint | null
  execSegFlags: bigint | null
  teamIdOffset: number | null
  scatterOffset: number | null
}

export class CodeDirectory {
  private constructor(
    readonly bytes: Bytes,
    /** Offset of the CodeDirectory inside `bytes`. */
    readonly at: number,
    readonly fields: CodeDirectoryFields,
    readonly identifier: string,
    readonly teamId: string | null,
  ) {}

  static parse(bytes: Bytes, at: number): CodeDirectory {
    if (at + 44 > bytes.length) throw new SignatureError("truncated CodeDirectory")
    const magic = readU32be(bytes, at)
    if (magic !== CS_MAGIC.codeDirectory) {
      throw new SignatureError(
        `expected CSMAGIC_CODEDIRECTORY (0xfade0c02) at ${at}, got 0x${magic.toString(16)}`,
      )
    }

    const version = readU32be(bytes, at + 8)
    const hashOffset = readU32be(bytes, at + 16)
    const identifierOffset = readU32be(bytes, at + 20)

    // Field offsets inside the fixed header, and the version each one appeared in. The header
    // grows by appending, so `identifierOffset` equals the header size for whichever version
    // wrote the file — which makes "is this field inside the header" a better test than the
    // version number alone, and one that also holds for a version written by a newer signer.
    const FIELD = {
      scatterOffset: 0x2c,
      teamOffset: 0x30,
      codeLimit64: 0x38,
      execSegBase: 0x40,
      execSegLimit: 0x48,
      execSegFlags: 0x50,
    }
    const headerSize = identifierOffset
    const has = (offset: number, fieldSize: number) => headerSize >= offset + fieldSize

    const fields: CodeDirectoryFields = {
      magic,
      length: readU32be(bytes, at + 4),
      version,
      flags: readU32be(bytes, at + 12),
      hashOffset,
      identifierOffset,
      specialSlots: readU32be(bytes, at + 24),
      codeSlots: readU32be(bytes, at + 28),
      codeLimit: readU32be(bytes, at + 32),
      hashSize: bytes[at + 36],
      hashType: bytes[at + 37],
      platform: bytes[at + 38],
      pageSizeLog2: bytes[at + 39],
      execSegBase: has(FIELD.execSegBase, 8) ? readU64be(bytes, at + FIELD.execSegBase) : null,
      execSegLimit: has(FIELD.execSegLimit, 8) ? readU64be(bytes, at + FIELD.execSegLimit) : null,
      execSegFlags: has(FIELD.execSegFlags, 8) ? readU64be(bytes, at + FIELD.execSegFlags) : null,
      teamIdOffset: version >= 0x20200 && has(FIELD.teamOffset, 4)
        ? readU32be(bytes, at + FIELD.teamOffset) : null,
      scatterOffset: version >= 0x20100 && has(FIELD.scatterOffset, 4)
        ? readU32be(bytes, at + FIELD.scatterOffset) : null,
    }

    // Just enough sanity that a nonsense header fails here rather than as a wrong hash later.
    if (fields.hashSize !== hashLength(algorithmForHashType(fields.hashType))) {
      throw new SignatureError(
        `CodeDirectory names hashType ${fields.hashType} but a ${fields.hashSize}-byte hash ` +
        `(they must agree: 1/sha1→20, 2/sha256→32)`,
      )
    }
    const hashArrayEnd = at + hashOffset + fields.codeSlots * fields.hashSize
    if (hashArrayEnd > bytes.length) {
      throw new SignatureError(
        `the hash array runs past the end of the blob (needs ${hashArrayEnd}, have ${bytes.length})`,
      )
    }
    const specialStart = at + hashOffset - fields.specialSlots * fields.hashSize
    if (specialStart < at) {
      throw new SignatureError("the special slots run before the start of the CodeDirectory")
    }

    // A `teamOffset` of zero means "no team", not "the team is at byte zero" — reading it as an
    // offset picks up the CodeDirectory's own magic as a string.
    const teamIdOffset = version >= 0x20200 && has(FIELD.teamOffset, 4)
      ? readU32be(bytes, at + FIELD.teamOffset) : 0
    return new CodeDirectory(
      bytes, at, { ...fields, teamIdOffset: teamIdOffset === 0 ? null : teamIdOffset },
      cString(bytes, at + identifierOffset),
      teamIdOffset === 0 ? null : cString(bytes, at + teamIdOffset),
    )
  }

  get algorithm(): HashAlgorithm {
    return algorithmForHashType(this.fields.hashType)
  }

  get pageSize(): number {
    return 1 << this.fields.pageSizeLog2
  }

  /** A code slot's stored hash: index 0 is the first page. */
  codeSlot(index: number): Bytes {
    if (index < 0 || index >= this.fields.codeSlots) {
      throw new SignatureError(`code slot ${index} is out of range (0..${this.fields.codeSlots - 1})`)
    }
    const at = this.at + this.fields.hashOffset + index * this.fields.hashSize
    return this.bytes.subarray(at, at + this.fields.hashSize)
  }

  /**
   * A special slot's stored hash, addressed by SLOT NUMBER (1 = Info.plist, 2 = Requirements,
   * 5 = Entitlements, 7 = DER-entitlements).
   *
   * The hash array is indexed backwards from the first code slot, which is the direction that is
   * easy to get wrong by one.
   */
  specialSlot(number: number): Bytes {
    if (number < 1 || number > this.fields.specialSlots) {
      throw new SignatureError(`special slot ${number} is out of range (1..${this.fields.specialSlots})`)
    }
    const at = this.at + this.fields.hashOffset - number * this.fields.hashSize
    return this.bytes.subarray(at, at + this.fields.hashSize)
  }

  isSpecialSlotEmpty(number: number): boolean {
    return this.specialSlot(number).every(byte => byte === 0)
  }

  /** The hash over the whole CodeDirectory blob — the value the world calls the cdhash. */
  cdhash(): Bytes {
    if (this.fields.hashType === 1) return sha1(this.blob)
    return sha256(this.blob)
  }

  /** The whole CodeDirectory blob, header included. */
  get blob(): Bytes {
    return this.bytes.subarray(this.at, this.at + this.fields.length)
  }
}

// MARK: - verification

export interface PageHashResult {
  slots: number
  mismatches: number
  /** The first mismatching slot index, for a useful error. */
  firstMismatch: number | null
}

export interface SpecialSlotResult {
  number: number
  name: string
  empty: boolean
  expected: Bytes | null
  matches: boolean | null
}

export interface VerificationReport {
  codeDirectories: Array<{
    slot: number
    identifier: string
    algorithm: HashAlgorithm
    version: number
    flags: number
    codeLimit: number
    pageSize: number
    pages: PageHashResult
    specialSlots: SpecialSlotResult[]
    cdhash: string
    /** True when this CodeDirectory's own slot hashes are all consistent. */
    valid: boolean
  }>
  hasCMS: boolean
  adhoc: boolean
  errors: string[]
}

const SPECIAL_SLOT_NAMES: Record<number, string> = {
  1: "Info.plist",
  2: "Requirements",
  3: "ResourceDir",
  4: "Application",
  5: "Entitlements",
  7: "DER-entitlements",
}

/**
 * Recomputes every hash in a signed Mach-O and reports what disagrees.
 *
 * This is the check to run on anything this project produces: a wrong page size, a wrong
 * special-slot rule, or a signature written at the wrong offset all show up here rather than
 * three layers later on a device.
 */
export function verifyMachOSignature(file: Bytes): VerificationReport {
  const errors: string[] = []
  const macho = MachO.parse(file)
  const signature = macho.signatureBytes()
  if (signature === null) {
    return {
      codeDirectories: [], hasCMS: false, adhoc: false,
      errors: ["the Mach-O has no LC_CODE_SIGNATURE"],
    }
  }

  const embedded = EmbeddedSignature.parse(signature)
  const base = macho.base

  const reports: VerificationReport["codeDirectories"] = []
  for (const entry of embedded.blobs) {
    if (entry.magic !== CS_MAGIC.codeDirectory) continue
    const cd = CodeDirectory.parse(embedded.bytes, entry.offset)

    const page = cd.pageSize
    const limit = cd.fields.codeLimit
    const expectedSlots = limit === 0 ? 0 : Math.ceil(limit / page)
    if (expectedSlots !== cd.fields.codeSlots) {
      errors.push(
        `CodeDirectory ${cd.identifier}: codeLimit ${limit} at page size ${page} implies ` +
        `${expectedSlots} slots, but ${cd.fields.codeSlots} are stored`,
      )
    }

    let mismatches = 0
    let firstMismatch: number | null = null
    for (let i = 0; i < cd.fields.codeSlots; i++) {
      const start = base + i * page
      const end = Math.min(start + page, base + limit)
      if (end > file.length) {
        errors.push(`CodeDirectory ${cd.identifier}: page ${i} runs past the end of the file`)
        mismatches++
        firstMismatch ??= i
        continue
      }
      const computed = hashOf(cd.algorithm, file.subarray(start, end))
      if (!equalBytes(computed, cd.codeSlot(i))) {
        mismatches++
        firstMismatch ??= i
      }
    }

    const specials: SpecialSlotResult[] = []
    for (let number = cd.fields.specialSlots; number >= 1; number--) {
      const name = SPECIAL_SLOT_NAMES[number] ?? `slot ${number}`
      const empty = cd.isSpecialSlotEmpty(number)
      const expected = empty ? null : hashOf(cd.algorithm, matchingBlobBody(embedded, number))
      specials.push({
        number, name, empty, expected,
        matches: expected === null ? null : equalBytes(expected, cd.specialSlot(number)),
      })
    }

    reports.push({
      slot: entry.type,
      identifier: cd.identifier,
      algorithm: cd.algorithm,
      version: cd.fields.version,
      flags: cd.fields.flags,
      codeLimit: limit,
      pageSize: page,
      pages: { slots: cd.fields.codeSlots, mismatches, firstMismatch },
      specialSlots: specials,
      cdhash: toHexBytes(cd.cdhash()),
      valid: mismatches === 0 && expectedSlots === cd.fields.codeSlots,
    })
  }

  return {
    codeDirectories: reports,
    hasCMS: embedded.cmsSignature !== null,
    adhoc: reports.some(report => (report.flags & CS_FLAG.adhoc) !== 0),
    errors,
  }
}

/**
 * The blob a special slot should cover, by slot number.
 *
 * Returns an empty slice when the slot has no counterpart, which callers detect via the empty flag.
 * The FULL blob — magic and length included — is what gets hashed.
 */
function matchingBlobBody(embedded: EmbeddedSignature, slotNumber: number): Bytes {
  const wantMagic = slotNumber === CS_SLOT.requirements ? CS_MAGIC.requirements
    : slotNumber === CS_SLOT.entitlements ? CS_MAGIC.entitlements
      : slotNumber === CS_SLOT.derEntitlements ? CS_MAGIC.derEntitlements
        : null
  if (wantMagic === null) return new Uint8Array(0)
  const entry = embedded.blobs.find(blob => blob.magic === wantMagic)
  if (entry === undefined) return new Uint8Array(0)
  return embedded.blobBytes(entry)
}

// MARK: - helpers

function cString(bytes: Bytes, at: number): string {
  let end = at
  while (end < bytes.length && bytes[end] !== 0) end++
  return new TextDecoder().decode(bytes.subarray(at, end))
}

function equalBytes(a: Bytes, b: Bytes): boolean {
  if (a.length !== b.length) return false
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false
  return true
}

function toHexBytes(bytes: Bytes): string {
  let out = ""
  for (const byte of bytes) out += byte.toString(16).padStart(2, "0")
  return out
}

function readU64be(bytes: Bytes, at: number): bigint {
  let out = 0n
  for (let i = 0; i < 8; i++) out = (out << 8n) | BigInt(bytes[at + i])
  return out
}

export { concat }
