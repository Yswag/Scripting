// The detached CMS signature that goes in slot 0x10000.
//
// RFC 5652 SignedData, and the content it signs is the primary CodeDirectory blob. Five details
// decide whether a verifier accepts it:
//
//   - the inner content type is `id-data` (1.2.840.113549.1.7.1) and there is NO eContent: the
//     signature is detached, with the CodeDirectory supplied separately;
//   - `signedAttrs` is SIGNED in its `SET OF` form (tag 0x31) but STORED with the implicit
//     `[0]` tag (0xA0). Signing the stored form is the classic mistake and produces a signature
//     that verifies nowhere;
//   - `sid` must carry the issuer Name's exact DER and the serial number's exact INTEGER content,
//     not a re-encoding of the serial as a fresh integer;
//   - the messageDigest attribute is the digest of the content, which is what `openssl cms
//     -verify -content …` recomputes;
//   - the certificate set carries the signer's chain, root included.
//
// Apple's own codesign adds two proprietary signed attributes, and AMFI reads them back out of the
// blob it is handed:
//
//   1.2.840.113635.100.9.2 — `SEQUENCE { algorithm OID, digest OCTET STRING }`, one per
//   CodeDirectory, so the SHA-1 and the SHA-256 digest of each blob;
//   1.2.840.113635.100.9.1 — an OCTET STRING holding an XML plist `{ cdhashes = [...] }` with one
//   20-byte hash per CodeDirectory, ending in a newline.
//
// Both are what Apple's own CMS carries, plist bytes and all: a signer that writes only the RFC
// 5652 attributes leaves a blob AMFI cannot initialise.
import type { Bytes } from "../util"
import { concat, equal, toHex, utf8 } from "../util"
import { hashOf, sha256, type HashAlgorithm } from "../util"
import { writeXml, type PlistValue } from "../util"
import {
  derContext, derEncode, derInteger, derOctetString, derOid, derSequence, derSet, derUtcTime,
} from "./der"
import { parseCertificateIdentity, type CertificateIdentity } from "./asn1"
import { APPLE_CA_CERTIFICATES } from "./apple-ca"
import { OID_RSA_ENCRYPTION, type RsaPrivateKey, rsaSignSha256 } from "./rsa"

/** The OIDs this file writes. */
export const OID = {
  signedData: "1.2.840.113549.1.7.2",
  data: "1.2.840.113549.1.7.1",
  sha1: "1.3.14.3.2.26",
  sha256: "2.16.840.1.101.3.4.2.1",
  contentType: "1.2.840.113549.1.9.3",
  messageDigest: "1.2.840.113549.1.9.4",
  signingTime: "1.2.840.113549.1.9.5",
  /** The cdhashes plist. */
  appleCodeDirectoryHashes: "1.2.840.113635.100.9.1",
  /** The per-CodeDirectory digests. */
  appleCodeDirectoryDigest: "1.2.840.113635.100.9.2",
} as const

/** `AlgorithmIdentifier` with no parameters, which every algorithm here wants. */
function algorithm(oid: string): Bytes {
  return derSequence(derOid(oid))
}

/** `Attribute ::= SEQUENCE { attrType OID, attrValues SET OF value }`. */
function attribute(oid: string, ...values: Bytes[]): Bytes {
  return derSequence(derOid(oid), derSet(...values))
}

/** An INTEGER carrying content that is already correct, so no re-encoding happens. */
function integerFromContent(content: Bytes): Bytes {
  return derEncode(0x02, content)
}

/**
 * One CodeDirectory the CMS attests to.
 *
 * `algorithm` is used twice: it hashes the blob for both Apple attributes, and it selects the OID
 * that goes next to the digest in the first of them.
 */
export interface CodeDirectoryDigest {
  algorithm: HashAlgorithm
  bytes: Bytes
}

export interface CmsOptions {
  /**
   * Every CodeDirectory to attest to, primary first. The primary is what the signature covers.
   *
   * A SHA-256 entry is required: Apple's attributes name a SHA-1 and a SHA-256 CodeDirectory, and a
   * CMS naming only one of them is not the shape a device reads.
   */
  codeDirectories: CodeDirectoryDigest[]
  /** The signer's certificate, DER. */
  certificate: Bytes
  /**
   * Certificates to build the signer's chain from, DER, in any order — a profile's
   * `DeveloperCertificates`, typically. The chain is walked out of these plus the bundled Apple CAs
   * by matching issuer and subject names; a certificate that certifies nothing here is left out.
   */
  chain?: Bytes[]
  privateKey: RsaPrivateKey
  /** Defaults to now. Fixed in tests so the output is reproducible. */
  signingTime?: Date
}

export interface CmsResult {
  /** The complete ContentInfo, ready to place in a blob wrapper. */
  cms: Bytes
  /** The signed attributes as they were signed, for tests to re-check. */
  signedAttributesDer: Bytes
  /** The digest that went into the messageDigest attribute. */
  contentDigest: Bytes
  identity: CertificateIdentity
}

/**
 * Builds a detached SignedData over the primary CodeDirectory.
 *
 * The digest algorithm is SHA-256 and the signature algorithm is RSA PKCS#1 v1.5, which is what
 * Apple's developer certificates use.
 */
export function buildCmsSignature(options: CmsOptions): CmsResult {
  const primary = options.codeDirectories[0]
  if (primary === undefined) throw new Error("cms: there is no CodeDirectory to attest to")
  if (!options.codeDirectories.some(entry => entry.algorithm === "sha256")) {
    throw new Error("cms: Apple's attributes need a SHA-256 CodeDirectory, and there is none")
  }

  const identity = parseCertificateIdentity(options.certificate)
  const digest = sha256(primary.bytes)
  const when = options.signingTime ?? new Date()

  // The signed attributes, in their SET OF form. This exact encoding is what gets signed.
  const signedAttributesDer = derSet(
    attribute(OID.contentType, derOid(OID.data)),
    attribute(OID.messageDigest, derOctetString(digest)),
    attribute(OID.signingTime, derUtcTime(when)),
    codeDirectoryDigestsAttribute(options.codeDirectories),
    codeDirectoryHashesAttribute(options.codeDirectories),
  )

  const signature = rsaSignSha256(options.privateKey, signedAttributesDer)

  const certificates = certificateSet(options.certificate, options.chain ?? [])

  const signerInfo = derSequence(
    derInteger(1),
    // sid: IssuerAndSerialNumber, both taken verbatim from the certificate.
    derSequence(identity.issuerDer, integerFromContent(identity.serialNumber)),
    algorithm(OID.sha256),
    // Stored with the implicit [0] tag; signed with the 0x31 tag above.
    derContext(0, signedAttributesDer.subarray(derHeaderLength(signedAttributesDer))),
    derSequence(derOid(OID_RSA_ENCRYPTION), derEncode(0x05, new Uint8Array(0))),
    derOctetString(signature),
  )

  const signedData = derSequence(
    derInteger(1),
    derSet(algorithm(OID.sha256)),
    // EncapsulatedContentInfo with no eContent: detached.
    derSequence(derOid(OID.data)),
    derContext(0, concat(...certificates)),
    derSet(signerInfo),
  )

  const cms = derSequence(
    derOid(OID.signedData),
    derContext(0, signedData),
  )

  return { cms, signedAttributesDer, contentDigest: digest, identity }
}

/** The digest OID that goes with a CodeDirectory's algorithm. */
function digestOid(algorithm: HashAlgorithm): string {
  switch (algorithm) {
    case "sha1": return OID.sha1
    case "sha256": return OID.sha256
    default: throw new Error(`cms: ${algorithm} has no digest OID here`)
  }
}

/** `SEQUENCE { algorithm OID, digest OCTET STRING }` for one CodeDirectory. */
function codeDirectoryDigest(entry: CodeDirectoryDigest): Bytes {
  return derSequence(
    derOid(digestOid(entry.algorithm)),
    derOctetString(hashOf(entry.algorithm, entry.bytes)),
  )
}

/**
 * Attribute 100.9.2: one CodeDirectory digest per CodeDirectory.
 *
 * The values are a SET OF, so they come out in canonical order — SHA-1's shorter encoding first,
 * which is also the order Apple's own writer puts them in.
 */
function codeDirectoryDigestsAttribute(codeDirectories: CodeDirectoryDigest[]): Bytes {
  return attribute(OID.appleCodeDirectoryDigest, ...codeDirectories.map(codeDirectoryDigest))
}

/**
 * Attribute 100.9.1: an XML plist with one 20-byte cdhash per CodeDirectory — the SHA-1 digest, or
 * the first 20 bytes of the SHA-256 one — ending in a newline.
 */
function codeDirectoryHashesAttribute(codeDirectories: CodeDirectoryDigest[]): Bytes {
  const cdhashes: PlistValue = codeDirectories.map(entry =>
    hashOf(entry.algorithm, entry.bytes).subarray(0, 20))
  const xml = writeXml({ cdhashes })
  const text = xml.endsWith("\n") ? xml : `${xml}\n`
  return attribute(OID.appleCodeDirectoryHashes, derOctetString(utf8(text)))
}

/**
 * The certificates to carry: the signer's chain, and then the signer itself.
 *
 * The chain is walked, not sorted, and it is walked by name: each step looks for the candidate whose
 * subject is the issuer of the step before, starting at the signer and stopping at the self-signed
 * root. A signer that is its own issuer has no chain. Candidates are the caller's own list first, so
 * a profile's copy of an intermediate wins over the bundled one.
 *
 * Deduplication is by certificate bytes. The order these go on the wire in is the SET's canonical
 * one — ascending by encoding, which is what DER asks of a `SET OF` and what Apple's own signature
 * carries. That sort decides nothing about membership.
 */
function certificateSet(signer: Bytes, chain: Bytes[]): Bytes[] {
  const candidates = [...chain, ...APPLE_CA_CERTIFICATES.map(certificate => certificate.der)]
  const set: Bytes[] = []
  for (const certificate of [...certificateChain(signer, candidates), signer]) {
    if (!set.some(seen => equal(seen, certificate))) set.push(certificate)
  }
  return set.sort(compareBytes)
}

/** The chain that certifies `signer`, issuer first and root last. */
function certificateChain(signer: Bytes, candidates: Bytes[]): Bytes[] {
  const signerIdentity = parseCertificateIdentity(signer)
  if (equal(signerIdentity.issuerDer, signerIdentity.subjectDer)) return []

  const parsed = candidates.map(der => ({ der, identity: parseCertificateIdentity(der) }))
  const chain: Bytes[] = []
  let issuer = signerIdentity.issuerDer

  for (;;) {
    const found = parsed.find(candidate => equal(candidate.identity.subjectDer, issuer))
    if (found === undefined) {
      throw new Error(
        `cms: nothing in the chain issues ${toHex(issuer).slice(0, 40)}, so the CMS would carry an ` +
        `incomplete chain`,
      )
    }
    if (chain.some(certificate => equal(certificate, found.der))) {
      throw new Error("cms: the certificate chain is a cycle")
    }
    chain.push(found.der)
    issuer = found.identity.issuerDer
    if (equal(found.identity.subjectDer, found.identity.issuerDer)) return chain
  }
}

/** How many bytes the tag and length of an element occupy, so its content can be re-tagged. */
function derHeaderLength(element: Bytes): number {
  const first = element[1]
  return (first & 0x80) === 0 ? 2 : 2 + (first & 0x7f)
}

function compareBytes(a: Bytes, b: Bytes): number {
  const shorter = Math.min(a.length, b.length)
  for (let i = 0; i < shorter; i++) if (a[i] !== b[i]) return a[i] - b[i]
  return a.length - b.length
}

/** Reads a certificate's identity without building anything, for callers that want to check it. */
export function certificateIdentity(certificateDer: Bytes): CertificateIdentity {
  return parseCertificateIdentity(certificateDer)
}
