// Writing the blobs a signature is made of.
//
// `buildCodeDirectory` reproduces a real signer's output byte for byte. The layout:
//
//   header (88 bytes for version 0x20400) | identifier + NUL | special slots | code slots
//
// with `hashOffset` pointing at the FIRST CODE SLOT, so the special slots sit before it and slot
// number N lives at `hashOffset - N * hashSize`.
import type { Bytes } from "../util"
import { concat, u32be, u64be } from "../util"
import { hashOf, type HashAlgorithm } from "../util"
import { writeXml, type PlistDict } from "../util"
import { CS_MAGIC, DEFAULT_PAGE_SIZE_LOG2 } from "./signature"
import { entitlementsBlob, derEntitlementsBlob, wrapBlob } from "./entitlements"

/** The version this project writes. 0x20400 adds the execSeg fields. */
export const CODE_DIRECTORY_VERSION = 0x20400

/** The fixed header size for that version, which is also where the identifier starts. */
export const CODE_DIRECTORY_HEADER_SIZE = 88

/** `__TEXT` bounds, which the CodeDirectory records as the executable segment. */
export interface ExecutableSegment {
  base: bigint
  limit: bigint
  /**
   * 0x11 for an executable (main binary or app extension), 0 for a dylib. 0x1 is
   * CS_EXECSEG_MAIN_BINARY.
   */
  flags: bigint
}

/**
 * The `execSegFlags` bits, as the reference signer names and composes them
 * (`apple-codesign-quick`'s `signature.rs`). 0x11 for an executable whose entitlements allow
 * unsigned code is 0x1 | 0x10.
 */
export const EXEC_SEG_FLAGS_MAIN_BINARY = 0x1n
export const EXEC_SEG_FLAGS_ALLOW_UNSIGNED = 0x10n
export const EXEC_SEG_FLAGS_LIBRARY = 0x0n

/** Entitlements that add a bit to `execSegFlags`, and the bit each adds. */
const EXEC_SEG_FLAG_FOR_ENTITLEMENT: Array<[string, bigint]> = [
  ["get-task-allow", EXEC_SEG_FLAGS_ALLOW_UNSIGNED],
  ["run-unsigned-code", EXEC_SEG_FLAGS_ALLOW_UNSIGNED],
  ["com.apple.private.cs.debugger", 0x20n],
  ["dynamic-codesigning", 0x40n],
  ["com.apple.private.skip-library-validation", 0x80n],
  ["com.apple.private.amfi.can-load-cdhash", 0x100n],
  ["com.apple.private.amfi.can-execute-cdhash", 0x200n],
]

/**
 * What goes in `execSegFlags`: the binary's own kind, plus what its entitlements permit.
 *
 * The reference signer's `entitlement_exec_flags`. "Main binary" here means the Mach-O is an
 * executable at all — a framework's binary or a dylib gets no MAIN_BINARY bit, whatever bundle it
 * sits in.
 */
export function execSegFlagsFor(entitlements: PlistDict, isExecutable: boolean): bigint {
  let flags = isExecutable ? EXEC_SEG_FLAGS_MAIN_BINARY : EXEC_SEG_FLAGS_LIBRARY
  for (const [key, flag] of EXEC_SEG_FLAG_FOR_ENTITLEMENT) {
    if (entitlements[key] === true) flags |= flag
  }
  return flags
}

/** The hashType values this project emits, and the matching hashSize. */
export const HASH_TYPE_SHA1 = 1
export const HASH_TYPE_SHA256 = 2

/** SHA-1 needs hashType 3 when the CodeDirectory stores a truncated digest; not used here. */
export interface CodeDirectoryOptions {
  /** The bundle executable's name. Not the bundle id. */
  identifier: string
  hashType: number
  /** CS_FLAG bits. */
  flags: number
  /** Bytes covered by the page hashes: everything before the signature. */
  codeLimit: number
  pageSizeLog2?: number
  /**
   * Special slots keyed by SLOT NUMBER (1, 2, 5, 7). Each value must already be the hash of the
   * complete blob — `specialSlotHash` does that.
   */
  specialSlots: Map<number, Bytes>
  executableSegment: ExecutableSegment
  /** The page hashes, in order. */
  codeSlots: Bytes[]
  /** The number of special slots reserved, which must be at least the highest slot number. */
  specialSlotCount: number
  teamId?: string | null
}

/**
 * Builds a CodeDirectory.
 *
 * The result is intended to be byte-identical to what a real signer produces for the same inputs.
 */
export function buildCodeDirectory(options: CodeDirectoryOptions): Bytes {
  const hashSize = options.hashType === HASH_TYPE_SHA1 ? 20
    : options.hashType === HASH_TYPE_SHA256 ? 32
      : (() => { throw new Error(`codedirectory: unsupported hashType ${options.hashType}`) })()
  const pageSizeLog2 = options.pageSizeLog2 ?? DEFAULT_PAGE_SIZE_LOG2

  const identifierBytes = concat(new TextEncoder().encode(options.identifier), new Uint8Array([0]))
  // A team id is a second NUL-terminated string between the identifier and the special slots, and
  // `teamOffset` says where it starts. Zero means "none" — which is what the artifact this project
  // reproduces byte for byte has, so leaving it out stays byte-identical.
  const teamId = options.teamId ?? null
  const teamBytes = teamId === null ? new Uint8Array(0) : concat(new TextEncoder().encode(teamId), new Uint8Array([0]))
  const teamOffset = teamId === null ? 0 : CODE_DIRECTORY_HEADER_SIZE + identifierBytes.length
  const specialBytes = options.specialSlotCount * hashSize
  const headerSize = CODE_DIRECTORY_HEADER_SIZE
  const hashOffset = headerSize + identifierBytes.length + teamBytes.length + specialBytes
  const length = hashOffset + options.codeSlots.length * hashSize

  const header = new Uint8Array(headerSize)
  const put32 = (at: number, value: number) => {
    const bytes = u32be(value)
    header.set(bytes, at)
  }
  const put64 = (at: number, value: bigint) => {
    header.set(u64be(value), at)
  }

  put32(0x00, CS_MAGIC.codeDirectory)
  put32(0x04, length)
  put32(0x08, CODE_DIRECTORY_VERSION)
  put32(0x0c, options.flags)
  put32(0x10, hashOffset)
  put32(0x14, headerSize)
  put32(0x18, options.specialSlotCount)
  put32(0x1c, options.codeSlots.length)
  put32(0x20, options.codeLimit)
  header[0x24] = hashSize
  header[0x25] = options.hashType
  header[0x26] = 0 // platform
  header[0x27] = pageSizeLog2
  put32(0x2c, 0) // scatterOffset
  put32(0x30, teamOffset)
  put32(0x34, 0) // spare3
  put32(0x38, 0) // codeLimit64; the 32-bit codeLimit is what this project signs
  put64(0x40, options.executableSegment.base)
  put64(0x48, options.executableSegment.limit)
  put64(0x50, options.executableSegment.flags)

  // Special slots, in the order the hash array holds them: index -specialSlotCount first.
  const specials = new Uint8Array(specialBytes)
  for (let number = options.specialSlotCount; number >= 1; number--) {
    const hash = options.specialSlots.get(number)
    if (hash === undefined) continue // absent slots stay zero, which readers treat as "skip"
    if (hash.length !== hashSize) {
      throw new Error(
        `codedirectory: slot ${number} has a ${hash.length}-byte hash, expected ${hashSize}`,
      )
    }
    const at = (options.specialSlotCount - number) * hashSize
    specials.set(hash, at)
  }

  const codeSlots = new Uint8Array(options.codeSlots.length * hashSize)
  options.codeSlots.forEach((hash, index) => {
    if (hash.length !== hashSize) {
      throw new Error(`codedirectory: code slot ${index} has ${hash.length} bytes, expected ${hashSize}`)
    }
    codeSlots.set(hash, index * hashSize)
  })

  return concat(header, identifierBytes, teamBytes, specials, codeSlots)
}

/**
 * The page hashes for a Mach-O slice.
 *
 * The last page is short: it runs to `codeLimit`, not to a whole page boundary. Getting that
 * wrong changes only the final slot, which is exactly the kind of error that survives a casual
 * check.
 */
export function codeSlotHashes(
  file: Bytes,
  algorithm: HashAlgorithm,
  codeLimit: number,
  sliceBase = 0,
  pageSizeLog2 = DEFAULT_PAGE_SIZE_LOG2,
): Bytes[] {
  const page = 1 << pageSizeLog2
  const count = codeLimit === 0 ? 0 : Math.ceil(codeLimit / page)
  const slots: Bytes[] = []
  for (let i = 0; i < count; i++) {
    const start = sliceBase + i * page
    const end = Math.min(start + page, sliceBase + codeLimit)
    if (end > file.length) {
      throw new Error(
        `codedirectory: page ${i} needs bytes ${start}..${end} but the file is ${file.length} bytes`,
      )
    }
    slots.push(hashOf(algorithm, file.subarray(start, end)))
  }
  return slots
}

/**
 * The hash for a special slot.
 *
 * The rule is the whole blob — magic and length included. Hashing only the body is off by eight
 * bytes and fails silently, and this was confirmed numerically against a real signature.
 */
export function specialSlotHash(algorithm: HashAlgorithm, blob: Bytes): Bytes {
  return hashOf(algorithm, blob)
}

// MARK: - planning the region

/**
 * The room a CMS blob is given when a region is reserved, so that a later re-sign with a bigger CMS
 * still fits. The reference signer's `DEFAULT_CMS_BLOB_RESERVATION`.
 */
export const DEFAULT_CMS_BLOB_RESERVATION = 16 * 1024

/** The next reservation to try when a CMS did not fit, which is how the reference signer grows it. */
export function nextCmsReservation(current: number, actual: number): number {
  const doubled = Math.max(current * 2, DEFAULT_CMS_BLOB_RESERVATION)
  return Math.ceil(Math.max(doubled, actual) / 4096) * 4096
}

export interface PlannedSignatureLengthInput {
  identifier: string
  teamId?: string | null
  /** Where the signature would start, as it stands before the region is reserved. */
  codeLimit: number
  isExecutable: boolean
  entitlements: PlistDict
  requirementsLength: number
  hasCms: boolean
  cmsReservation: number
  pageSizeLog2?: number
}

/**
 * How long the signature region has to be, worked out from lengths alone.
 *
 * The region has to exist — and the header has to be final — before the page hashes can be taken, and
 * the block sizes depend on where the region starts, so the region is planned first and the hashes
 * come after (`apple-codesign-quick`'s `planned_superblob_len_from_parts`). The CMS is not built yet
 * at this point, so a reservation stands in for it; the caller retries with a bigger one if the real
 * CMS does not fit.
 */
export function plannedSignatureLength(input: PlannedSignatureLengthInput): number {
  const identifierBytes = new TextEncoder().encode(input.identifier).length
  const teamBytes = input.teamId == null ? 0 : new TextEncoder().encode(input.teamId).length + 1
  const page = 1 << (input.pageSizeLog2 ?? DEFAULT_PAGE_SIZE_LOG2)
  const codeSlots = input.codeLimit === 0 ? 0 : Math.ceil(input.codeLimit / page)
  const specialSlots = input.isExecutable ? 7 : 5
  const directory = (hashSize: number) => CODE_DIRECTORY_HEADER_SIZE
    + identifierBytes + 1 + teamBytes + (specialSlots + codeSlots) * hashSize

  const entitlements = entitlementsBlob(writeXml(input.entitlements)).length
  const der = input.isExecutable
    ? derEntitlementsBlob(input.entitlements as Record<string, never>).length
    : 0
  const blobs = 4 + (der === 0 ? 0 : 1) + (input.hasCms ? 1 : 0)

  return 12 + blobs * 8
    + directory(20) + directory(32)
    + input.requirementsLength + entitlements + der
    + (input.hasCms ? input.cmsReservation : 0)
}

// MARK: - assembling the signature

export interface SignatureBlobsInput {
  identifier: string
  /**
   * The XML entitlements dictionary. Always written, even when empty: the reference signer writes
   * slot 5 for every binary, an empty dictionary included.
   */
  entitlements: PlistDict
  /**
   * Whether the DER entitlements go in slot 7 too. The reference signer writes them for executables
   * only, so a framework's binary or a dylib has slot 5 but no slot 7.
   */
  derEntitlements: boolean
  /** The requirements blob, or null to omit it. */
  requirements: Bytes | null
  codeLimit: number
  executableSegment: ExecutableSegment
  /** Bytes that go in slot 0x10000. Null produces an ad-hoc signature. */
  cms: Bytes | null
  pageSizeLog2?: number
  flags: number
  /**
   * The signing team, written into the CodeDirectory (and appended after the identifier). The
   * reference signer always sets it; omit it and the field is zero, which is what the artifact this
   * project reproduces byte for byte has.
   */
  teamId?: string | null
  sliceBase?: number
  /** The file the page hashes are taken from, signature excluded. */
  file: Bytes
  /**
   * The bundle's `Info.plist`, for slot 1, and `_CodeSignature/CodeResources`, for slot 3.
   *
   * Both are optional and both are what an Apple-signed bundle carries; the zsign-shaped artifact
   * in this project's fixture leaves them empty. Passing them is the more complete form.
   */
  infoPlist?: Bytes | null
  codeResources?: Bytes | null
}

export interface SignatureBlobsOutput {
  /** The complete CSMAGIC_EMBEDDED_SIGNATURE superblob. */
  superblob: Bytes
  /** The cdhash to expect, for logging and for comparing with a device's report. */
  cdhashSHA1: string
  cdhashSHA256: string
  /** The primary (SHA-1) CodeDirectory's bytes, which is what the CMS signs. */
  primaryCodeDirectory: Bytes
  /** The SHA-256 alternate's bytes, which the CMS attests to alongside the primary. */
  alternateCodeDirectory: Bytes
}

/**
 * Builds the whole superblob: a SHA-1 primary CodeDirectory, a SHA-256 alternate, requirements,
 * entitlements (XML, and DER when the binary is an executable), optionally the Info.plist and the
 * resource envelope, and optionally the CMS.
 *
 * The two-code-directory layout is what the real IPA carries, so it is what gets written. The
 * SHA-1 one is first and is the one a CMS signs over.
 *
 * `nSpecialSlots` is the highest populated slot number: 7 for an executable, 5 for anything else.
 */
export function buildSignatureBlobs(input: SignatureBlobsInput): SignatureBlobsOutput {
  const xmlBlob = entitlementsBlob(writeXml(input.entitlements))
  const derBlob = input.derEntitlements
    ? derEntitlementsBlob(input.entitlements as Record<string, never>)
    : null

  const slotNumbers: number[] = []
  if (input.infoPlist != null) slotNumbers.push(1)
  if (input.requirements !== null) slotNumbers.push(2)
  if (input.codeResources != null) slotNumbers.push(3)
  slotNumbers.push(5)
  if (derBlob !== null) slotNumbers.push(7)
  const slotCount = Math.max(...slotNumbers)

  const cdhashSHA1 = buildOne(HASH_TYPE_SHA1)
  const cdhashSHA256 = buildOne(HASH_TYPE_SHA256)

  function specialsFor(algorithm: HashAlgorithm): Map<number, Bytes> {
    const map = new Map<number, Bytes>()
    if (input.infoPlist != null) map.set(1, specialSlotHash(algorithm, input.infoPlist))
    if (input.requirements !== null) map.set(2, specialSlotHash(algorithm, input.requirements))
    if (input.codeResources != null) map.set(3, specialSlotHash(algorithm, input.codeResources))
    map.set(5, specialSlotHash(algorithm, xmlBlob))
    if (derBlob !== null) map.set(7, specialSlotHash(algorithm, derBlob))
    return map
  }

  function buildOne(hashType: number) {
    const algorithm: HashAlgorithm = hashType === HASH_TYPE_SHA1 ? "sha1" : "sha256"
    return buildCodeDirectory({
      identifier: input.identifier,
      hashType,
      flags: input.flags,
      codeLimit: input.codeLimit,
      pageSizeLog2: input.pageSizeLog2,
      specialSlots: specialsFor(algorithm),
      executableSegment: input.executableSegment,
      codeSlots: codeSlotHashes(
        input.file, algorithm, input.codeLimit, input.sliceBase ?? 0, input.pageSizeLog2,
      ),
      specialSlotCount: slotCount,
      ...(input.teamId != null ? { teamId: input.teamId } : {}),
    })
  }

  const primary = cdhashSHA1
  const alternate = cdhashSHA256

  const blobs: Array<[number, Bytes]> = [
    [0, primary],
    [2, input.requirements ?? wrapBlob(CS_MAGIC.requirements, new Uint8Array(0))],
    [5, xmlBlob],
  ]
  // Only an executable has DER entitlements, which is what the reference signer does and what makes
  // an Apple-signed framework report three special slots while an app reports seven.
  if (derBlob !== null) blobs.push([7, derBlob])
  blobs.push([0x1000, alternate])
  if (input.cms !== null) blobs.push([0x10000, wrapBlob(CS_MAGIC.blobWrapper, input.cms)])

  // Offsets are from the start of the superblob, and the index comes first.
  const indexSize = 12 + blobs.length * 8
  let at = indexSize
  const placed = blobs.map(([type, bytes]) => {
    const offset = at
    at += bytes.length
    return { type, bytes, offset }
  })

  const header = new Uint8Array(indexSize)
  header.set(u32be(CS_MAGIC.embeddedSignature), 0)
  header.set(u32be(at), 4)
  header.set(u32be(blobs.length), 8)
  placed.forEach(({ type, offset }, index) => {
    header.set(u32be(type), 12 + index * 8)
    header.set(u32be(offset), 16 + index * 8)
  })

  return {
    superblob: concat(header, ...placed.map(entry => entry.bytes)),
    cdhashSHA1: hex(hashOf("sha1", primary)),
    cdhashSHA256: hex(hashOf("sha256", alternate)),
    primaryCodeDirectory: primary,
    alternateCodeDirectory: alternate,
  }
}

function hex(bytes: Bytes): string {
  let out = ""
  for (const byte of bytes) out += byte.toString(16).padStart(2, "0")
  return out
}
