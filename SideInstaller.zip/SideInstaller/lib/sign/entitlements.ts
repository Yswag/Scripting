// The DER form of an entitlements dictionary.
//
// Apple's encoding is a SET of SEQUENCEs, each holding a key and its value:
//
//     SET {
//       SEQUENCE { UTF8String "get-task-allow", BOOLEAN true }
//       SEQUENCE { UTF8String "com.apple.developer.team-identifier", UTF8String "TEAMID" }
//       ...
//     }
//
// Two details were confirmed against a real signed bundle. The top level is a SET (so DER's
// "sort by encoding" rule puts the entries in length order, not alphabetical), and the whole
// thing is hashed as blob slot 7.
import type { Bytes } from "../util"
import { concat } from "../util"
import { PlistReal } from "../util"
import {
  derBoolean, derInteger, derOctetString, derSequence, derSet, derUtf8String,
} from "./der"

/** The subset of a plist value that can appear in entitlements. */
export type EntitlementValue =
  | boolean
  | number
  | string
  | Bytes
  | EntitlementValue[]
  | { [key: string]: EntitlementValue }

/**
 * Encodes one entitlements dictionary as DER.
 *
 * `strictDerBooleans` defaults to false so that TRUE is written as 0x01, matching what Apple's
 * encoder produces. Pass true for specification-pure DER (0xFF); a device accepts both, but only
 * the default reproduces a real signature byte for byte.
 *
 * A dictionary value becomes a SEQUENCE of its own key/value SEQUENCEs, which is the same shape
 * the top level uses. That nesting has no sample to match, so it follows the specification.
 */
export function entitlementsToDer(
  entitlements: Record<string, EntitlementValue>,
  strictDerBooleans = false,
): Bytes {
  const entries = Object.entries(entitlements).map(([key, value]) =>
    derSequence(derUtf8String(key), entitlementValueToDer(value, key, strictDerBooleans)))
  return derSet(...entries)
}

function entitlementValueToDer(
  value: EntitlementValue,
  key: string,
  strictBooleans: boolean,
): Bytes {
  if (typeof value === "boolean") return derBoolean(value, strictBooleans)
  if (typeof value === "number") return derInteger(value)
  if (value instanceof PlistReal) {
    // The DER entitlements format has no real type, so a whole-valued real is written as an integer
    // and anything else is refused rather than guessed at. Silently truncating would change what
    // the device reads.
    if (!Number.isInteger(value.value)) {
      throw new Error(
        `entitlements: ${key} is a non-integer real (${value.value}), whose DER form is unknown`,
      )
    }
    return derInteger(value.value)
  }
  if (typeof value === "string") return derUtf8String(value)
  if (value instanceof Uint8Array) return derOctetString(value)
  if (Array.isArray(value)) {
    return derSequence(...value.map(entry => entitlementValueToDer(entry, key, strictBooleans)))
  }
  if (value !== null && typeof value === "object") {
    const nested = Object.entries(value as Record<string, EntitlementValue>).map(([k, v]) =>
      derSequence(derUtf8String(k), entitlementValueToDer(v, k, strictBooleans)))
    return derSequence(...nested)
  }
  throw new Error(`entitlements: ${key} has a value this encoder cannot express (${typeof value})`)
}

/** Convenience: the DER form wrapped as a CSMAGIC_DER_ENTITLEMENTS blob. */
export function derEntitlementsBlob(
  entitlements: Record<string, EntitlementValue>,
  strictDerBooleans = false,
): Bytes {
  return wrapBlob(0xfade7172, entitlementsToDer(entitlements, strictDerBooleans))
}

/** Convenience: XML entitlements wrapped as a CSMAGIC_ENTITLEMENTS blob. */
export function entitlementsBlob(xml: string): Bytes {
  return wrapBlob(0xfade7171, new TextEncoder().encode(xml))
}

/**
 * A CS_Blob: magic, length, then the body. The length counts the header, which is why a special
 * slot's hash is computed over the whole thing.
 */
export function wrapBlob(magic: number, body: Bytes): Bytes {
  const length = 8 + body.length
  const header = new Uint8Array(8)
  header[0] = (magic >>> 24) & 0xff
  header[1] = (magic >>> 16) & 0xff
  header[2] = (magic >>> 8) & 0xff
  header[3] = magic & 0xff
  header[4] = (length >>> 24) & 0xff
  header[5] = (length >>> 16) & 0xff
  header[6] = (length >>> 8) & 0xff
  header[7] = length & 0xff
  return concat(header, body)
}
