// Signing a whole bundle: rewrite the identifier, drop in the profile, seal the resources, sign the
// executable, and do the nested bundles first so the outer envelope covers their final bytes.
//
// The order is forced by what seals what:
//
//   1. nested bundles, because their files change and the outer envelope lists them;
//   2. `Info.plist`, because slot 1 hashes it;
//   3. `embedded.mobileprovision`;
//   4. `_CodeSignature/CodeResources`, which hashes everything above and is itself hashed into
//      slot 3;
//   5. the executable last, because signing it writes the CodeDirectory that references all of it.
import { Bytes } from "../util"
import { asDict, equal, parsePlist, str, writeXml, type PlistDict } from "../util"
import { codeSignatureOffset, reserveSignatureRegion, writeSignature } from "./attach"
import { MachO, MH_FILE_TYPE, buildFatBinary, fatBinary, CPU_TYPE_ARM64 } from "./macho"
import { buildCodeResources, type ResourceEntry } from "./coderesources"
import { buildCmsSignature } from "./cms"
import { emptyRequirements } from "./requirements"
import type { RsaPrivateKey } from "./rsa"
import {
  buildSignatureBlobs, execSegFlagsFor, plannedSignatureLength, nextCmsReservation,
  DEFAULT_CMS_BLOB_RESERVATION,
} from "./writer"
import {
  entitlementsFor, nestedBundleIdentifier, type ProvisioningProfile,
} from "./provisioning"

/**
 * The two directories whose children are nested code bundles.
 *
 * The rule is the reference implementation's (`isideload`'s `bundle.rs`): app extensions live under
 * `PlugIns/` and frameworks under `Frameworks/`, and nothing else is a nested bundle. A `.bundle`
 * full of resources is not one, whatever it is named: Apple seals its files with the host's
 * envelope, and there is nothing inside it to sign anyway.
 */
const CODE_BUNDLE_PARENTS = ["PlugIns", "Frameworks"]

export class BundleError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "BundleError"
  }
}

function fs(): any {
  const manager: any = (globalThis as any).FileManager
  if (manager === undefined) throw new BundleError("this build has no FileManager")
  return manager
}

/** Reads a file as bytes. The runtime's byte reader returns an ArrayBuffer despite its types. */
export function readBytes(path: string): Bytes {
  const raw = fs().readAsBytesSync(path)
  return raw instanceof Uint8Array ? raw : new Uint8Array(raw as ArrayBuffer)
}

/** Writes bytes. Sync on purpose: an unawaited async write is dropped when the script ends. */
export function writeBytes(path: string, bytes: Bytes): void {
  fs().writeAsBytesSync(path, bytes)
}

export function readPlistFile(path: string): PlistDict {
  return asDict(parsePlist(readBytes(path)))
}

/**
 * Sets `CFBundleIdentifier`, leaving every other key as it was.
 *
 * The dictionary is copied rather than mutated: rewriting a parsed `Info.plist` should not have a
 * side effect on the value the caller still holds.
 */
export function rewriteBundleIdentifier(info: PlistDict, identifier: string): PlistDict {
  const current = str(info, "CFBundleIdentifier")
  if (current === undefined) {
    throw new BundleError("this Info.plist has no CFBundleIdentifier to rewrite")
  }
  return { ...info, CFBundleIdentifier: identifier }
}

/**
 * Whether a directory is a nested code bundle this signer descends into.
 *
 * `parent` names the directory holding it — only a direct child of `PlugIns/` or `Frameworks/`
 * qualifies — and it has to carry an `Info.plist` to be a bundle at all. Those are the reference
 * implementation's own two filters. Anything else is walked like an ordinary directory, so its files
 * end up sealed by the host's envelope.
 */
function isCodeBundle(parent: string, path: string): boolean {
  return CODE_BUNDLE_PARENTS.includes(parent) && fs().existsSync(`${path}/Info.plist`)
}

export interface BundleLayout {
  /** The executable, named by `CFBundleExecutable`. */
  executableName: string
  /** Resource files, relative paths, excluding the executable, `_CodeSignature`, and nested bundles. */
  resources: ResourceEntry[]
  /** Nested bundle directories, relative paths. Signed first, and NOT listed in the envelope. */
  nested: string[]
  /** `.dylib` files anywhere in the bundle, relative paths: signed on their own, and sealed too. */
  libraries: string[]
}

/**
 * Gathers a bundle's resource files and nested bundle directories.
 *
 * Separate from `inspectBundle` because the caller has to be able to gather *after* writing the
 * new `Info.plist` and the profile: an envelope built from a snapshot taken earlier would seal the
 * old bytes and omit the profile, and a device reports that as "a sealed resource is missing or
 * invalid".
 *
 * Nested bundle directories are returned separately and are NOT walked here: the caller signs them
 * first and seals each of their files, re-rooted under this bundle, into this bundle's envelope, so
 * listing their files here as well would seal every one of them twice.
 *
 * Only the children of `PlugIns/` and `Frameworks/` count as nested — anything else is walked like
 * an ordinary directory, so its files are sealed by the host's envelope.
 */
export function collectResources(bundlePath: string, executableName: string): {
  resources: ResourceEntry[]
  nested: string[]
  libraries: string[]
} {
  const manager = fs()
  const resources: ResourceEntry[] = []
  const nested: string[] = []
  const libraries: string[] = []

  const walk = (relative: string, parent: string) => {
    const absolute = relative === "" ? bundlePath : `${bundlePath}/${relative}`
    // Sorted so the walk does not depend on the order the file system happens to report.
    const names = (manager.readDirectorySync(absolute) as string[]).slice().sort()
    for (const name of names) {
      if (name === "." || name === "..") continue
      if (name === "_CodeSignature" || name === "CodeResources") continue
      const childRelative = relative === "" ? name : `${relative}/${name}`
      if (manager.isDirectorySync(`${bundlePath}/${childRelative}`)) {
        if (isCodeBundle(parent, `${bundlePath}/${childRelative}`)) {
          nested.push(childRelative)
        } else {
          walk(childRelative, name)
        }
        continue
      }
      if (childRelative === executableName) continue // sealed by the CodeDirectory, not here
      // A `.dylib` is signed in its own right AND sealed as a resource — the reference signer's
      // `should_hash_resource` only exempts files *inside* a nested bundle, not the dylib itself.
      if (name.endsWith(".dylib")) libraries.push(childRelative)
      resources.push({ path: childRelative, bytes: readBytes(`${bundlePath}/${childRelative}`) })
    }
  }
  walk("", "")

  resources.sort((a, b) => (a.path < b.path ? -1 : a.path > b.path ? 1 : 0))
  nested.sort()
  libraries.sort()
  return { resources, nested, libraries }
}

/** What a bundle contains right now: the executable name plus everything `collectResources` finds. */
export function inspectBundle(bundlePath: string): BundleLayout {
  const info = readPlistFile(`${bundlePath}/Info.plist`)
  const executableName = str(info, "CFBundleExecutable")
  if (executableName === undefined) {
    throw new BundleError(`${bundlePath}/Info.plist has no CFBundleExecutable`)
  }
  return { executableName, ...collectResources(bundlePath, executableName) }
}

export interface SignBundleOptions {
  /** Profile to sign this bundle with. */
  profile: ProvisioningProfile
  /** The signer's certificate, DER. */
  certificate: Bytes
  /** Certificates the signer's chain can be built from, DER, in any order. */
  chain?: Bytes[]
  privateKey: RsaPrivateKey
  /** The identifier to give this bundle. */
  identifier: string
  /** Fixed in tests so the output is reproducible. */
  signingTime?: Date
  /**
   * The App Groups this bundle's AltStore-family readers should use, written as `ALTAppGroups` into
   * the app's and each extension's `Info.plist`.
   *
   * A re-signed app is registered under a new group (`group.<id>.<team>`), while the group its code
   * asks for is the one it was built with, so the two only meet through this key. Frameworks and
   * dylibs are not given it.
   */
  altAppGroups?: string[]
  /** Called after each bundle is signed, for progress. */
  onBundle?: (path: string, identifier: string) => void
}

export interface SignedBundle {
  path: string
  identifier: string
  /** The identifier this bundle had before, so nested ones can be re-derived. */
  originalIdentifier: string
  cdhash: string
  nested: SignedBundle[]
  /** The identifiers the `.dylib` files in this bundle were signed under. */
  libraries: string[]
}

/**
 * Signs a bundle in place, nested bundles first.
 *
 * What each kind of bundle is given is the reference implementation's rule (`isideload`'s `sign.rs`
 * over `apple-codesign-quick`'s `bundle.rs`) rather than a per-case guess:
 *
 *   * the application — the identifier it was given, the profile, and the entitlements cut for it;
 *   * an app extension — the identifier derived from its host's, a copy of the host's profile (a host
 *     reads an extension's copy back), and the profile's entitlements **cut for that extension's own
 *     identifier**;
 *   * a framework — neither a profile nor anything but an empty entitlements dictionary;
 *   * a `.dylib` — signed on its own, under its own file name;
 *   * and every nested bundle's files, executable and envelope are sealed into its host's envelope.
 */
export function signBundle(bundlePath: string, options: SignBundleOptions): SignedBundle {
  return signOne(bundlePath, options, null).signed
}

/** A signed bundle, plus what it contributes to the envelope of the bundle holding it. */
interface SignedBundleResult {
  signed: SignedBundle
  contributions: ResourceEntry[]
}

/** `_CodeSignature`, where a bundle's envelope lives. */
const CODE_SIGNATURE_DIR = "_CodeSignature"

/** What a nested bundle takes from the bundle it sits in. */
interface HostContext {
  /** The identifier the host had before this run; a plugin's identifier is derived from it. */
  identifierBefore: string
  /** The host's profile, copied into each extension. */
  profile: Bytes
}

function signOne(
  bundlePath: string,
  options: SignBundleOptions,
  host: HostContext | null,
): SignedBundleResult {
  // The executable name and the nested bundles come from the Info.plist as it is now; the
  // resource list is gathered AFTER the writes below, because the envelope has to seal the bytes
  // that will actually be in the bundle.
  const infoBefore = readPlistFile(`${bundlePath}/Info.plist`)
  const executableName = str(infoBefore, "CFBundleExecutable")
  if (executableName === undefined) {
    throw new BundleError(`${bundlePath}/Info.plist has no CFBundleExecutable`)
  }
  const wasIdentifier = str(infoBefore, "CFBundleIdentifier")
  if (wasIdentifier === undefined) {
    throw new BundleError(`${bundlePath}/Info.plist has no CFBundleIdentifier`)
  }
  const layoutBefore = collectResources(bundlePath, executableName)
  const nestedBefore = layoutBefore.nested

  // An extension's identifier follows its host's; a framework keeps its own.
  const isExtension = bundlePath.endsWith(".appex")
  const identifier = host === null
    ? options.identifier
    : isExtension
      ? nestedBundleIdentifier(options.identifier, host.identifierBefore, wasIdentifier)
      : wasIdentifier

  // What this bundle is signed with: the profile's entitlements, cut for the identifier the *profile*
  // covers.
  //
  // That is the application's identifier for an extension too — an extension does not claim its own.
  // Apple's own signed appex does claim its own, but its profile is a *team* profile whose
  // `application-identifier` is a wildcard, so any App ID the
  // team owns is covered. The profile the portal hands out here is scoped to one App ID
  // (`6HGT5G4D3S.com.SideStore.…`), and an extension claiming something else is refused with
  // `0xe8008015` — "a valid provisioning profile for this executable was not found". The reference
  // signer does the same, and says so in its comment. Covering each extension individually would mean
  // registering an App ID and downloading a profile per extension.
  //
  // A framework gets an empty dictionary rather than nothing, because the reference signer always
  // writes slot 5.
  const signedEntitlements: PlistDict =
    host === null || isExtension
      ? entitlementsFor(options.profile, host === null ? identifier : options.identifier)
      : {}
  const profile = host === null ? options.profile.raw : host.profile
  const carriesProfile = host === null || isExtension

  // 1. nested bundles first, so the outer envelope sees their final bytes. Each is told what its
  // host was before this run, which is what it derives its own identifier from.
  const childResults = nestedBefore.map(relative =>
    signOne(`${bundlePath}/${relative}`, options, {
      identifierBefore: wasIdentifier, profile,
    }))
  const nested: SignedBundle[] = childResults.map(result => result.signed)

  // 2. the `.dylib` files, which are signed in their own right.
  const libraries = layoutBefore.libraries.map(relative =>
    signLibrary(`${bundlePath}/${relative}`, relative, options))

  // 3. Info.plist, because slot 1 hashes it. Written when the identifier moves, and whenever a key
  // has to go in — a framework's file keeps the bytes it shipped with either way.
  const infoAfter = withAltAppGroups(infoBefore, options, host, isExtension)
  if (identifier !== wasIdentifier || infoAfter !== infoBefore) {
    writeBytes(`${bundlePath}/Info.plist`, new TextEncoder().encode(writeXml(
      identifier === wasIdentifier ? infoAfter : rewriteBundleIdentifier(infoAfter, identifier))))
  }

  // 4. the profile, which only the application and its extensions carry.
  if (carriesProfile) writeBytes(`${bundlePath}/embedded.mobileprovision`, profile)

  // 5. the resource envelope, gathered now that the bundle is in its final shape. Whatever an
  // earlier signer left in `_CodeSignature` goes first: a stray `ResourceRules.plist` would survive
  // unsealed, and a device reads that as a sealed resource gone missing.
  const infoBytes = readBytes(`${bundlePath}/Info.plist`)
  const layout = collectResources(bundlePath, executableName)
  // A nested bundle's files are sealed one by one, re-rooted under this bundle, and so are its
  // executable and its own envelope. The reference signer's `merge_sub_bundle_resources` does
  // exactly this; leaving them out was this project's own guess, and it was wrong.
  const sealed: ResourceEntry[] = [...layout.resources]
  childResults.forEach((result, index) => {
    for (const entry of result.contributions) {
      sealed.push({ path: `${nestedBefore[index]}/${entry.path}`, bytes: entry.bytes })
    }
  })
  const envelope = buildCodeResources(sealed)
  const envelopeBytes = new TextEncoder().encode(writeXml(envelope.envelope))
  const codeSignatureDir = `${bundlePath}/${CODE_SIGNATURE_DIR}`
  if (fs().existsSync(codeSignatureDir)) fs().removeSync(codeSignatureDir)
  fs().createDirectorySync(codeSignatureDir, true)
  writeBytes(`${codeSignatureDir}/CodeResources`, envelopeBytes)

  // 6. the executable, last.
  const executablePath = `${bundlePath}/${executableName}`
  const signed = signExecutable(executablePath, {
    entitlements: signedEntitlements,
    infoPlist: infoBytes,
    codeResources: envelopeBytes,
    certificate: options.certificate,
    chain: options.chain,
    teamId: options.profile.teamIdentifier,
    privateKey: options.privateKey,
    identifier,
    ...(options.signingTime !== undefined ? { signingTime: options.signingTime } : {}),
  })

  options.onBundle?.(bundlePath, identifier)

  // What this bundle gives the envelope of the bundle it sits in.
  const contributions: ResourceEntry[] = [
    ...layout.resources,
    { path: executableName, bytes: readBytes(executablePath) },
    { path: `${CODE_SIGNATURE_DIR}/CodeResources`, bytes: envelopeBytes },
  ]

  return {
    signed: {
      path: bundlePath,
      identifier,
      originalIdentifier: wasIdentifier,
      cdhash: signed.cdhash,
      nested,
      libraries,
    },
    contributions,
  }
}

/**
 * The `Info.plist` to seal, with `ALTAppGroups` in it when the app asks for one.
 *
 * The application and its extensions both read the key, each from its own `Info.plist`; a framework
 * gets nothing. The reference implementation writes it for the apps that carry this convention
 * (`AltStore`, `SideStore`, and a LiveContainer build holding SideStore).
 */
function withAltAppGroups(
  info: PlistDict,
  options: SignBundleOptions,
  host: HostContext | null,
  isExtension: boolean,
): PlistDict {
  const groups = options.altAppGroups
  if (groups === undefined || groups.length === 0) return info
  if (host !== null && !isExtension) return info
  return { ...info, ALTAppGroups: [...groups] }
}

/**
 * Signs one `.dylib` in place, the way the reference signer does: the file's own name is its
 * identifier (`TweakLoader.dylib`, extension and all), it carries an empty entitlements dictionary,
 * and it has neither an `Info.plist` nor a resource envelope of its own — it is a file, not a bundle.
 */
function signLibrary(path: string, relative: string, options: SignBundleOptions): string {
  const identifier = relative.slice(relative.lastIndexOf("/") + 1)
  signExecutable(path, {
    entitlements: {},
    infoPlist: null,
    codeResources: null,
    certificate: options.certificate,
    chain: options.chain,
    teamId: options.profile.teamIdentifier,
    privateKey: options.privateKey,
    identifier,
    ...(options.signingTime !== undefined ? { signingTime: options.signingTime } : {}),
  })
  return identifier
}

export interface SignExecutableOptions {
  /** What the binary is allowed to do: the profile's entitlements, or an empty dictionary. */
  entitlements: PlistDict
  /** `Info.plist`, for slot 1. Null for a file that is not a bundle, such as a dylib. */
  infoPlist: Bytes | null
  /** `_CodeSignature/CodeResources`, for slot 3. Null for a file that is not a bundle. */
  codeResources: Bytes | null
  certificate: Bytes
  /** Certificates the signer's chain can be built from, DER, in any order. */
  chain?: Bytes[]
  /** The signing team, which goes into the CodeDirectory. Null or absent leaves it out. */
  teamId?: string | null
  privateKey: RsaPrivateKey
  identifier: string
  signingTime?: Date
}

/**
 * `execSegFlags` by what the file IS, which is what a real signer writes: an executable that may run
 * unsigned code is 0x11, a library is 0. The reference signer composes the same bits from the
 * entitlements.
 */
function execSegFlagsForFile(entitlements: PlistDict, fileType: number): bigint {
  return execSegFlagsFor(entitlements, (MH_FILE_TYPE as Record<number, string>)[fileType] === "executable")
}

/**
 * Signs one Mach-O in place: requirements, entitlements, the resource envelope, a CMS over the
 * primary CodeDirectory, and the signature appended to the file.
 *
 * The blobs are built twice on purpose. The CMS signs the primary CodeDirectory, and the
 * CodeDirectory does not depend on the CMS — a CMS is a sibling blob in the superblob — so the
 * first build produces the CodeDirectory, the CMS is made over it, and the second build emits the
 * superblob with the CMS in place. Both builds must be given identical inputs, so they are made
 * from one options object here.
 */
export function signExecutable(path: string, options: SignExecutableOptions): { cdhash: string } {
  const file = readBytes(path)
  const slices = fatBinary(file)
  if (slices === null) {
    const signed = signThinMachO(file, options)
    writeBytes(path, signed.file)
    return { cdhash: signed.cdhash }
  }

  // A universal binary is signed one slice at a time, because each slice is a Mach-O in its own
  // right: its load-command offsets count from its own first byte, so nothing of the container
  // reaches the hashes. The container is then rebuilt around the slices that came back, since a
  // signature that had to grow moves every slice after it.
  let cdhash = ""
  const signed = slices.map(slice => {
    const result = signThinMachO(file.subarray(slice.offset, slice.offset + slice.size), options)
    if (slice.cpuType === CPU_TYPE_ARM64 && cdhash === "") cdhash = result.cdhash
    return {
      cpuType: slice.cpuType, cpuSubtype: slice.cpuSubtype, align: slice.align, bytes: result.file,
    }
  })
  if (cdhash === "") {
    throw new BundleError(
      "a universal binary with no arm64 slice cannot be signed (cpu types " +
      slices.map(slice => `0x${slice.cpuType.toString(16)}`).join(", ") + ")",
    )
  }
  writeBytes(path, buildFatBinary(signed))
  return { cdhash }
}

/**
 * Signs one thin Mach-O held in memory and hands the signed bytes back.
 *
 * The region is reserved before anything is hashed, the order the reference signer uses: reserving
 * writes into the Mach-O header, the header is inside the first page, and the page hashes cover that
 * page — so hashing first would leave page 0 describing bytes that no longer exist. The region's
 * length is planned from the blob sizes plus a reservation for the CMS, which cannot be built until
 * the CodeDirectories exist; the CMS is therefore built from a provisional pair, and a reservation
 * that turns out too small is doubled and the whole region re-planned.
 */
function signThinMachO(file: Bytes, options: SignExecutableOptions): { file: Bytes, cdhash: string } {
  const macho = MachO.parse(file)

  const text = macho.segments.find(segment => segment.name === "__TEXT")
  if (text === undefined) throw new BundleError("this Mach-O has no __TEXT segment")

  const isExecutable = (MH_FILE_TYPE as Record<number, string>)[macho.header.fileType] === "executable"

  // The reference signer writes an empty requirements superblob; see `emptyRequirements`.
  const requirement = emptyRequirements()

  const blobsFor = (cms: Bytes | null, bytes: Bytes, codeLimit: number) => buildSignatureBlobs({
    identifier: options.identifier,
    entitlements: options.entitlements,
    derEntitlements: isExecutable,
    requirements: requirement,
    codeLimit,
    executableSegment: {
      base: text.fileOffset,
      // The reference signer records the END of `__TEXT` (`fileoff + filesize`), which is the same
      // number as `filesize` alone only while the segment starts at offset zero.
      limit: text.fileOffset + text.fileSize,
      flags: execSegFlagsForFile(options.entitlements, macho.header.fileType),
    },
    cms,
    flags: 0,
    ...(options.teamId != null ? { teamId: options.teamId } : {}),
    file: bytes,
    infoPlist: options.infoPlist,
    codeResources: options.codeResources,
  })

  //
  // The region starts where the current signature does, or at the end of the file when there is none.
  let planCodeLimit = codeSignatureOffset(macho).offset
  let reservation = DEFAULT_CMS_BLOB_RESERVATION
  for (let attempt = 0; attempt < 8; attempt++) {
    const planned = plannedSignatureLength({
      identifier: options.identifier,
      teamId: options.teamId ?? null,
      codeLimit: planCodeLimit,
      isExecutable,
      entitlements: options.entitlements,
      requirementsLength: requirement.length,
      hasCms: true,
      cmsReservation: reservation,
    })

    const region = reserveSignatureRegion(file, planned)
    planCodeLimit = region.codeLimit

    const provisional = blobsFor(null, region.file, region.codeLimit)
    const cms = buildCmsSignature({
      // Both CodeDirectories, so the Apple attributes can name a SHA-1 and a SHA-256 digest of the
      // same binary. Neither depends on the CMS, which is why the provisional build's two are the
      // final ones.
      codeDirectories: [
        { algorithm: "sha1", bytes: provisional.primaryCodeDirectory },
        { algorithm: "sha256", bytes: provisional.alternateCodeDirectory },
      ],
      certificate: options.certificate,
      ...(options.chain !== undefined ? { chain: options.chain } : {}),
      privateKey: options.privateKey,
      ...(options.signingTime !== undefined ? { signingTime: options.signingTime } : {}),
    })
    if (8 + cms.cms.length > reservation) {
      reservation = nextCmsReservation(reservation, 8 + cms.cms.length)
      continue
    }

    const blobs = blobsFor(cms.cms, region.file, region.codeLimit)
    if (!equal(blobs.primaryCodeDirectory, provisional.primaryCodeDirectory)
      || !equal(blobs.alternateCodeDirectory, provisional.alternateCodeDirectory)) {
      throw new BundleError("the CMS changed the CodeDirectory it signs, so the signature would not verify")
    }

    return { file: writeSignature(region.file, blobs.superblob, region), cdhash: blobs.cdhashSHA1 }
  }
  throw new BundleError("the CMS did not fit the reserved region after repeated growth")
}
