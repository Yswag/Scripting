// PKCS#10 certificate requests — the one thing this project hands to Apple rather than computes.
//
// A CSR is a public key plus a self-signature over it. Apple's portal reads it, issues a
// development certificate for that key, and from then on the private half is what signs every
// bundle. So the key is the durable thing: lose it and the certificate is worthless, and one of a
// free account's two certificate slots is gone with it.
//
// `dev/test-csr.ts` compares the output byte for byte against openssl's for the same key and
// subject. Byte equality is possible because RSA PKCS#1 v1.5 is deterministic, and it is worth
// having: it pins down every free choice in here, including the subject's string types, which are
// not free at all — see `defaultCsrSubject`.
import type { Bytes } from "../util"
import { pemEncode } from "../util"
import {
  derBigInteger, derBitString, derContext, derInteger, derNull, derOid, derPrintableString,
  derSequence, derSet, derUtf8String,
} from "./der"
import { OID_RSA_ENCRYPTION, rsaSignSha256, type RsaPrivateKey } from "./rsa"

/** `sha256WithRSAEncryption`, what a CSR's own signature algorithm names. */
export const OID_SHA256_WITH_RSA = "1.2.840.113549.1.1.11"

/** The `rsaEncryption` key type's public exponent. Every client of this portal sends 65537. */
export const RSA_PUBLIC_EXPONENT = 65537n

/** Attribute type OIDs, in the order a distinguished name conventionally lists them. */
export const SUBJECT_OID = {
  country: "2.5.4.6",
  state: "2.5.4.8",
  locality: "2.5.4.7",
  organization: "2.5.4.10",
  commonName: "2.5.4.3",
} as const

export interface CsrAttribute {
  oid: string
  value: string
  /** `true` encodes a UTF8String, `false` a PrintableString. */
  utf8: boolean
}

/**
 * What every other client of this portal sends, and therefore the one that costs no thought:
 * openssl's `-subj /C=US/ST=STATE/L=LOCAL/O=ORGNIZATION/CN=CN`, which the Python reference uses
 * verbatim. None of it is inspected — it lands in the certificate's subject for a human to read in
 * the developer portal.
 *
 * The string types are openssl's: the country as a PrintableString, because RFC 5280 requires one
 * for `C`, and everything else as a UTF8String. Mismatching them would still be a valid CSR that
 * Apple accepts, but it would also be a CSR that cannot be compared against the oracle, which is
 * the only check this module has.
 */
export function defaultCsrSubject(): CsrAttribute[] {
  return [
    { oid: SUBJECT_OID.country, value: "US", utf8: false },
    { oid: SUBJECT_OID.state, value: "STATE", utf8: true },
    { oid: SUBJECT_OID.locality, value: "LOCAL", utf8: true },
    { oid: SUBJECT_OID.organization, value: "ORGNIZATION", utf8: true },
    { oid: SUBJECT_OID.commonName, value: "CN", utf8: true },
  ]
}

/** An `RDNSequence`: one attribute per SET, which is what openssl writes. */
export function subjectDer(attributes: CsrAttribute[]): Bytes {
  if (attributes.length === 0) throw new Error("csr: a subject needs at least one attribute")
  return derSequence(...attributes.map(attribute => derSet(derSequence(
    derOid(attribute.oid),
    attribute.utf8 ? derUtf8String(attribute.value) : derPrintableString(attribute.value),
  ))))
}

/** `SubjectPublicKeyInfo` for an RSA key: the algorithm, then the key as a BIT STRING. */
export function rsaPublicKeyInfo(modulus: bigint, publicExponent: bigint): Bytes {
  return derSequence(
    derSequence(derOid(OID_RSA_ENCRYPTION), derNull()),
    derBitString(derSequence(derBigInteger(modulus), derBigInteger(publicExponent))),
  )
}

/**
 * `CertificationRequestInfo`: everything the signature covers and the only part Apple parses.
 *
 * The trailing `[0]` is the attributes, which PKCS#10 allows to be empty and which no client of
 * this portal fills in. It is a constructed tag with an empty content, not an omission.
 */
export function certificationRequestInfo(
  attributes: CsrAttribute[], publicKey: Bytes,
): Bytes {
  return derSequence(
    derInteger(0),
    subjectDer(attributes),
    publicKey,
    derContext(0, new Uint8Array(0)),
  )
}

export interface CsrKey extends RsaPrivateKey {
  publicExponent?: bigint
}

/** The CSR as DER: `SEQUENCE { info, sha256WithRSAEncryption, signature BIT STRING }`. */
export function buildCsrDer(
  key: CsrKey, attributes: CsrAttribute[] = defaultCsrSubject(),
): Bytes {
  const info = certificationRequestInfo(
    attributes,
    rsaPublicKeyInfo(key.modulus, key.publicExponent ?? RSA_PUBLIC_EXPONENT),
  )
  return derSequence(
    info,
    derSequence(derOid(OID_SHA256_WITH_RSA), derNull()),
    derBitString(rsaSignSha256(key, info)),
  )
}

/** The same, PEM-wrapped, which is the form the portal's `csrContent` field takes. */
export function buildCsrPem(
  key: CsrKey, attributes: CsrAttribute[] = defaultCsrSubject(),
): string {
  return pemEncode("CERTIFICATE REQUEST", buildCsrDer(key, attributes))
}
