// Attaching a signature to a Mach-O.
//
// The manoeuvre follows the reference signer (`apple-codesign-quick`'s `macho.rs`), which matters
// because re-signing a distributed app has to fit into the room the previous signer left:
//
//   1. no `LC_CODE_SIGNATURE` at all — put the command in the header's padding (between the last
//      load command and the first section's data) and the signature after `__LINKEDIT`;
//   2. a signature that fits in the existing region — keep the region exactly as long as it is and
//      write into it, leaving zeros behind. The file does not change length;
//   3. a signature that needs more room — only when the region ends the file: grow `__LINKEDIT` and
//      re-extend the file.
//
// In every case `codeLimit` is where the signature starts, and it is what the page hashes cover. The
// circularity that looks like it should exist does not: the CodeDirectory hashes only the bytes
// before `codeLimit`, and the signature lives at and after it.
//
// Only thin Mach-Os are handled. The reference signer handles universal binaries by signing each
// slice and rebuilding the fat header; this does not.
import type { Bytes } from "../util"
import { readU32le } from "../util"
import { LC_CODE_SIGNATURE, MachO, MachOError } from "./macho"
import { CS_MAGIC, embeddedSignatureLength } from "./signature"

/** The page size arm64 uses for segment alignment. */
export const SEGMENT_PAGE_SIZE = 0x4000

/** `linkedit_data_command` is `cmd, cmdsize, dataoff, datasize`. */
const LINKEDIT_DATA_COMMAND_SIZE = 16

/**
 * The alignment a newly allocated signature region starts at.
 *
 * The reference signer (`apple-codesign-quick`'s `allocate_code_signature`) aligns the offset to 16,
 * and writes the superblob with no padding of its own: the region is exactly as long as the blob
 * when it is created or grown, and keeps its old length when the new signature fits into it.
 */
export const CODE_SIGNATURE_ALIGNMENT = 16

export const SIGNATURE_ALIGNMENT = CODE_SIGNATURE_ALIGNMENT

export interface AttachSignatureOptions {
  /** The whole Mach-O, signature included if it has one. */
  file: Bytes
  /** The complete CSMAGIC_EMBEDDED_SIGNATURE superblob. */
  signature: Bytes
}

export interface AttachSignatureResult {
  /** The new file: old content up to `codeLimit`, then the signature and its padding. */
  file: Bytes
  /** The offset the signature starts at, which is the value the CodeDirectory must have hashed. */
  codeLimit: number
  /** The padded size written into `LC_CODE_SIGNATURE.dataSize`. */
  installedSize: number
  /** How the file changed, for logging. */
  previousFileSize: number
  previousSignatureSize: number
}

/**
 * Where a signature would go: the current one's offset, or the end of the file when there is none.
 *
 * The reference signer aligns that second case up from the end of `__LINKEDIT` to 16 bytes
 * (`allocate_code_signature`), which for the files it was written against is the same place as the
 * end of the file. Using the end of the file keeps the two in step: `__LINKEDIT` always finishes at
 * or before it, so the signature never lands on bytes something else owns.
 *
 * For an unsigned file this is also the `codeLimit` the CodeDirectory hashes to, which is what makes
 * a first signature possible at all — the page hashes must cover bytes that exist.
 */
export function codeSignatureOffset(macho: MachO): { offset: number, size: number, exists: boolean } {
  const existing = macho.codeSignature
  if (existing !== null) {
    return { offset: existing.dataOffset, size: existing.dataSize, exists: true }
  }
  if (macho.linkedit === null) throw new MachOError("no LC_CODE_SIGNATURE and no __LINKEDIT to append to")
  return { offset: macho.file.length, size: 0, exists: false }
}

/**
 * A region reserved for a signature, before anything has been hashed.
 *
 * `reserveSignatureRegion` is the reference signer's `reserve_code_signature`: installing the
 * `LC_CODE_SIGNATURE` command writes into the Mach-O header, the header is inside the first page, and
 * the page hashes cover that page. Hashing before the command exists leaves page 0 describing bytes
 * that are no longer there, which the kernel refuses at exec (`EBADEXEC`) while every static check
 * passes.
 */
export interface SignatureRegion {
  /** The file with the command installed and the region zeroed: the bytes the page hashes cover. */
  file: Bytes
  /** Where the signature goes, and what the CodeDirectory's `codeLimit` must be. */
  codeLimit: number
  /** The region's length, which is what `LC_CODE_SIGNATURE.dataSize` ends up saying. */
  size: number
  previousFileSize: number
  previousSignatureSize: number
}

/**
 * Makes room for a `plannedLength`-byte signature, and returns the file the hashes must come from.
 *
 * Three cases, as the reference signer has them:
 *
 *   1. no region at all — allocate one at the end of `__LINKEDIT`, aligned to 16;
 *   2. a region long enough — keep its length exactly and zero it, since a later signature may need
 *      the room and shortening the file would move every offset after it;
 *   3. a region that is too small but ends the file — grow `__LINKEDIT` and extend the file.
 */
export function reserveSignatureRegion(file: Bytes, plannedLength: number): SignatureRegion {
  if (plannedLength <= 0) throw new MachOError("reserveSignatureRegion: nothing to reserve")

  const macho = MachO.parse(file)
  if (macho.base !== 0 || isFat(file)) {
    throw new MachOError(
      "reserveSignatureRegion: universal binaries are not supported (later slices would need moving)",
    )
  }
  if (macho.linkedit === null) throw new MachOError("reserveSignatureRegion: no __LINKEDIT segment")

  const existing = macho.codeSignature
  if (existing !== null && existing.dataOffset + existing.dataSize > file.length) {
    throw new MachOError("reserveSignatureRegion: the existing signature runs past the end of the file")
  }

  let out: Uint8Array = new Uint8Array(file)
  let commandOffset = macho.commands.find(command => command.command === LC_CODE_SIGNATURE)?.offset
  if (commandOffset === undefined) commandOffset = installCodeSignatureCommand(out, macho)

  const previousFileSize = file.length
  const previousSignatureSize = existing?.dataSize ?? 0
  const dataOffset = readU32le(out, commandOffset + 8)
  const dataSize = readU32le(out, commandOffset + 12)

  // 1. The command is there but nothing was ever allocated: the region goes after `__LINKEDIT`.
  if (dataSize === 0) {
    const linkeditEnd = linkeditFileEnd(macho)
    const at = align(linkeditEnd, CODE_SIGNATURE_ALIGNMENT)
    const grown = truncateAndGrow(out, linkeditEnd, at + plannedLength)
    patchU32le(grown, commandOffset + 8, at)
    patchU32le(grown, commandOffset + 12, plannedLength)
    patchLinkeditSize(grown, macho, at + plannedLength)
    return {
      file: grown, codeLimit: at, size: plannedLength, previousFileSize, previousSignatureSize,
    }
  }

  if (dataOffset + dataSize > out.length) {
    throw new MachOError("reserveSignatureRegion: the existing signature runs past the end of the file")
  }

  // 2. It fits: the region keeps its length and is emptied.
  if (plannedLength <= dataSize) {
    out.fill(0, dataOffset, dataOffset + dataSize)
    return {
      file: out, codeLimit: dataOffset, size: dataSize, previousFileSize, previousSignatureSize,
    }
  }

  // 3. It has to grow, which is only safe when the region is the end of the file.
  if (dataOffset + dataSize !== out.length) {
    throw new MachOError(
      `reserveSignatureRegion: the signature cannot grow — its region ends at ` +
      `${dataOffset + dataSize} and the file is ${out.length} bytes long`,
    )
  }
  const grown = truncateAndGrow(out, dataOffset, dataOffset + plannedLength)
  patchU32le(grown, commandOffset + 12, plannedLength)
  patchLinkeditSize(grown, macho, dataOffset + plannedLength)
  return {
    file: grown, codeLimit: dataOffset, size: plannedLength, previousFileSize, previousSignatureSize,
  }
}

/** Writes a signature into a reserved region, zeroing whatever is left of it. */
export function writeSignature(
  file: Bytes,
  signature: Bytes,
  region: { codeLimit: number, size: number },
): Bytes {
  if (signature.length > region.size) {
    throw new MachOError(
      `writeSignature: the signature is ${signature.length} bytes but the region is ${region.size}`,
    )
  }
  const out = new Uint8Array(file)
  out.set(signature, region.codeLimit)
  out.fill(0, region.codeLimit + signature.length, region.codeLimit + region.size)
  return out
}

/** Everything at and after `from` goes; the file then runs to `to`, zero-filled. */
function truncateAndGrow(file: Uint8Array, from: number, to: number): Uint8Array {
  if (from > file.length) throw new MachOError("attachSignature: a resize would start past the end of the file")
  if (to < from) throw new MachOError("attachSignature: a resize would shorten the file")
  const out = new Uint8Array(to)
  out.set(file.subarray(0, from))
  return out
}

/** Where `__LINKEDIT`'s data ends in the file. */
function linkeditFileEnd(macho: MachO): number {
  const linkedit = macho.linkedit
  if (linkedit === null) throw new MachOError("this Mach-O has no __LINKEDIT segment")
  return Number(linkedit.fileOffset + linkedit.fileSize)
}

/**
 * Installs an `LC_CODE_SIGNATURE` in the header's padding, for a binary that has none.
 *
 * The command goes after the last load command. The room for it ends where the first section's data
 * begins — the header and its commands sit inside the first segment, ahead of that section. The same
 * manoeuvre as the reference signer's `install_code_signature_command`, including its refusal when
 * that room is gone or not empty.
 *
 * Returns the command's offset in the file.
 */
function installCodeSignatureCommand(target: Uint8Array, macho: MachO): number {
  const headerSize = macho.header.is64 ? 32 : 28
  const commandOffset = macho.base + headerSize + macho.header.sizeOfCommands
  const commandEnd = commandOffset + LINKEDIT_DATA_COMMAND_SIZE
  const limit = macho.firstSectionOffset === null
    ? target.length
    : macho.base + macho.firstSectionOffset

  if (commandEnd > Math.min(limit, target.length)) {
    throw new MachOError(
      `attachSignature: no room for an LC_CODE_SIGNATURE — the load commands end at ${commandOffset}` +
      ` and the first section starts at ${limit}`,
    )
  }
  for (let i = commandOffset; i < commandEnd; i++) {
    if (target[i] !== 0) {
      throw new MachOError(
        `attachSignature: the padding where an LC_CODE_SIGNATURE would go is not empty (offset ${i})`,
      )
    }
  }

  patchU32le(target, commandOffset, LC_CODE_SIGNATURE)
  patchU32le(target, commandOffset + 4, LINKEDIT_DATA_COMMAND_SIZE)
  patchU32le(target, commandOffset + 8, 0)
  patchU32le(target, commandOffset + 12, 0)
  patchU32le(target, macho.base + 16, macho.header.nCommands + 1)
  patchU32le(target, macho.base + 20, macho.header.sizeOfCommands + LINKEDIT_DATA_COMMAND_SIZE)
  return commandOffset
}

/** Keeps `__LINKEDIT` covering the signature, which is what the kernel reads to find it. */
function patchLinkeditSize(target: Uint8Array, macho: MachO, signatureEnd: number): void {
  const linkedit = macho.linkedit
  if (linkedit === null) throw new MachOError("attachSignature: no __LINKEDIT segment")
  const fileOffset = Number(linkedit.fileOffset)
  if (signatureEnd < fileOffset) {
    throw new MachOError("attachSignature: the signature would start before __LINKEDIT")
  }
  const newFileSize = signatureEnd - fileOffset
  patchU64le(target, macho.base + linkedit.commandOffset + 48, BigInt(newFileSize))
  patchU64le(target, macho.base + linkedit.commandOffset + 32, BigInt(align(newFileSize, SEGMENT_PAGE_SIZE)))
}

/**
 * Reserves a region and writes a finished signature into it: `attachSignature({file, signature})` is
 * what a caller that already has the bytes uses, and what `signExecutable` does not, because it has
 * to hash the reserved file before it can build the signature at all.
 */
export function attachSignature(options: AttachSignatureOptions): AttachSignatureResult {
  const { file, signature } = options
  if (signature.length === 0) throw new MachOError("attachSignature: the signature is empty")

  const declared = embeddedSignatureLength(signature)
  if (declared !== signature.length) {
    throw new MachOError(
      `attachSignature: the superblob declares ${declared} bytes but ${signature.length} were given`,
    )
  }
  if (readU32be(signature, 0) !== CS_MAGIC.embeddedSignature) {
    throw new MachOError("attachSignature: the blob is not a CSMAGIC_EMBEDDED_SIGNATURE superblob")
  }

  const region = reserveSignatureRegion(file, signature.length)
  return {
    file: writeSignature(region.file, signature, region),
    codeLimit: region.codeLimit,
    installedSize: region.size,
    previousFileSize: region.previousFileSize,
    previousSignatureSize: region.previousSignatureSize,
  }
}

function align(value: number, to: number): number {
  return Math.ceil(value / to) * to
}

function isFat(file: Bytes): boolean {
  return readU32be(file, 0) === 0xcafebabe || readU32be(file, 0) === 0xbebafeca
}

function patchU32le(target: Uint8Array, at: number, value: number): void {
  if (at + 4 > target.length) throw new MachOError(`patch at ${at} is past the end of the file`)
  target[at] = value & 0xff
  target[at + 1] = (value >>> 8) & 0xff
  target[at + 2] = (value >>> 16) & 0xff
  target[at + 3] = (value >>> 24) & 0xff
}

function patchU64le(target: Uint8Array, at: number, value: bigint): void {
  if (at + 8 > target.length) throw new MachOError(`patch at ${at} is past the end of the file`)
  let remaining = value
  for (let i = 0; i < 8; i++) {
    target[at + i] = Number(remaining & 0xffn)
    remaining >>= 8n
  }
}

function readU32be(bytes: Bytes, at: number): number {
  return ((bytes[at] << 24) | (bytes[at + 1] << 16) | (bytes[at + 2] << 8) | bytes[at + 3]) >>> 0
}
