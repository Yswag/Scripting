// The sign package's public surface — the only thing outside `lib/sign` should import.
//
// Two seams, and the check that tells you whether the second one worked:
//
//   identity — make a key, ask Apple to issue a certificate over it, and read a key back out of a
//   certificate to see whether that certificate is ours.
//   signing  — sign a bundle (or one Mach-O) in place, given a profile and that key.
//
// Everything else in this directory is implementation, deliberately unexported here: the DER and
// Mach-O readers, the blob writer, the CMS builder, the resource-envelope rules, requirements, and
// attaching a signature to a file. Tests that need those reach in directly, from
// `dev/internal/sign/`.
//
// `Bytes` comes from `lib/util/bytes` and `PlistDict` from `lib/util/plist`; util is a toolbox of
// small entry points, so those are imported by name rather than re-exported here.

// --- identity -------------------------------------------------------------------------------

export { generateRsaKeyJwk, keyFromJwk } from "./rsa"
export type { RsaJwk, RsaKey, RsaPrivateKey } from "./rsa"
export { buildCsrPem } from "./csr"
export type { CsrAttribute, CsrKey } from "./csr"
export { certificatePublicKey } from "./asn1"
export type { RsaPublicKey } from "./asn1"

// --- the key, as a PKCS#12 SideStore can import --------------------------------------------

export { buildPkcs12, completeRsaNumbers, pkcs12Key, MAC_ITERATIONS, PBKDF2_ITERATIONS, PKCS12_ID_MAC } from "./p12"
export type { Pkcs12Options, RsaNumbers } from "./p12"

// --- profile --------------------------------------------------------------------------------

export { parseProvisioningProfile, entitlementsFor, ProvisioningError } from "./provisioning"
export type { ProvisioningProfile } from "./provisioning"

// --- signing --------------------------------------------------------------------------------

export { BundleError, inspectBundle, signBundle, signExecutable } from "./bundle"
export type {
  BundleLayout, SignBundleOptions, SignExecutableOptions, SignedBundle,
} from "./bundle"
export type { ResourceEntry } from "./coderesources"

// --- verification ---------------------------------------------------------------------------

export { verifyMachOSignature } from "./signature"
export type { PageHashResult, SpecialSlotResult, VerificationReport } from "./signature"
