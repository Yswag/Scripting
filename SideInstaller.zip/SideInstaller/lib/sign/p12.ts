// PKCS#12: a certificate and its private key in one password-protected archive.
//
// What SideStore's `Account.sideconf` carries, and what its importer hands to `SecPKCS12Import`. The
// layout is OpenSSL's: the certificates sit in a plain `SafeContents`, the key in one encrypted with
// PBES2 (PBKDF2-HMAC-SHA256 → AES-256-CBC), and the archive carries an HMAC-SHA256 under the
// PKCS#12 key derivation. `openssl pkcs12` reads the result — the external check this module has.
import type { Bytes } from "../util"
import { concat, fromBase64Url, randomBytes, sha256, utf8 } from "../util"
import {
  derBigInteger, derContext, derEncode, derInteger, derNull, derOctetString, derOid, derSequence,
} from "./der"
import type { RsaJwk } from "./rsa"

// MARK: - OIDs

const OID_DATA = "1.2.840.113549.1.7.1"
const OID_ENCRYPTED_DATA = "1.2.840.113549.1.7.6"
const OID_SHA256 = "2.16.840.1.101.3.4.2.1"

/** The bag identifiers, RFC 7292 appendix A. */
const KEY_BAG_ID = "1.2.840.113549.1.12.10.1.1"
const CERT_BAG_ID = "1.2.840.113549.1.12.10.1.3"
/** `x509Certificate`, the only certificate a CertBag here holds. */
const CERT_TYPE_X509 = "1.2.840.113549.1.9.22.1"

/** PBES2, PBKDF2, HMAC-SHA256 and AES-256-CBC. */
const OID_PBES2 = "1.2.840.113549.1.5.13"
const OID_PBKDF2 = "1.2.840.113549.1.5.12"
const OID_HMAC_SHA256 = "1.2.840.113549.2.9"
const OID_AES256_CBC = "2.16.840.1.101.3.4.1.42"

/** PKCS#1 `rsaEncryption`, which is what a `PrivateKeyInfo` names. */
const OID_RSA_ENCRYPTION = "1.2.840.113549.1.1.1"

/** The PBKDF2 rounds the key is protected with — OpenSSL's own default for PKCS#12. */
export const PBKDF2_ITERATIONS = 2048
/** And the rounds the MAC's key gets. */
export const MAC_ITERATIONS = 2048

/** The KDF's own constants, by what `id` means (RFC 7292 appendix B.2). */
export const PKCS12_ID_KEY = 1
export const PKCS12_ID_MAC = 3

const SHA256_BLOCK = 64
const SHA256_LENGTH = 32

// MARK: - the archive

export interface Pkcs12Options {
  /** The certificate's DER, as the portal handed it over. */
  certificateDer: Bytes
  /** Any further certificates (the issuer chain), DER, in order. */
  chain?: Bytes[]
  /** The private key, as the stored JWK. */
  jwk: RsaJwk
  /** What the archive is protected with. SideStore is given the certificate's machine id. */
  password: string
  /** Fixed in tests so the archive is reproducible. */
  random?: (count: number) => Bytes
}

/**
 * Builds a PKCS#12 archive holding the certificate, its chain and the private key.
 *
 * This is the shape `certType: "encrypted"` names: the key sits in an encrypted `SafeContents`, the
 * certificates do not.
 */
export function buildPkcs12(options: Pkcs12Options): Bytes {
  const random = options.random ?? randomBytes
  const password = utf8(options.password)

  // 1. the certificates, in a plain SafeContents.
  const certificates = [options.certificateDer, ...(options.chain ?? [])]
  const certificateBags = certificates.map(certificate => derSequence(
    derOid(CERT_BAG_ID),
    derContext(0, derSequence(
      derOid(CERT_TYPE_X509),
      derContext(0, derOctetString(certificate)),
    )),
  ))
  const certificateContentInfo = contentInfo(OID_DATA, derOctetString(derSequence(...certificateBags)))

  // 2. the private key, in a SafeContents that is encrypted.
  const keyBag = derSequence(
    derOid(KEY_BAG_ID),
    derContext(0, privateKeyInfo(completeRsaNumbers(options.jwk))),
  )
  const encrypted = pbes2Encrypt(
    derSequence(keyBag), password, random(16), PBKDF2_ITERATIONS, random(16))
  const keyContentInfo = contentInfo(OID_ENCRYPTED_DATA, derSequence(
    derInteger(0), // EncryptedData's version
    derSequence(derOid(OID_DATA), encrypted.algorithm, implicitOctetString(0, encrypted.ciphertext)),
  ))

  // 3. both of them, and the MAC over that DER.
  const authenticatedSafe = derSequence(certificateContentInfo, keyContentInfo)
  const macSalt = random(16)
  const macKey = pkcs12Key(password, macSalt, PKCS12_ID_MAC, SHA256_LENGTH, MAC_ITERATIONS)
  const macData = derSequence(
    derSequence(
      derSequence(derOid(OID_SHA256), derNull()),
      derOctetString(hmacSha256(authenticatedSafe, macKey)),
    ),
    derOctetString(macSalt),
    derInteger(MAC_ITERATIONS),
  )

  return derSequence(
    derInteger(3), // PFX version
    contentInfo(OID_DATA, derOctetString(authenticatedSafe)),
    macData,
  )
}

/**
 * `[n] IMPLICIT OCTET STRING`: a primitive context tag, as `EncryptedContentInfo`'s
 * `encryptedContent` is. A constructed tag there is what OpenSSL reports as "wrong tag".
 */
function implicitOctetString(number: number, content: Bytes): Bytes {
  return derEncode(0x80 | number, content)
}

/** `ContentInfo ::= SEQUENCE { contentType OID, content [0] EXPLICIT ANY }`. */
function contentInfo(contentType: string, content: Bytes): Bytes {
  return derSequence(derOid(contentType), derContext(0, content))
}

/** `PrivateKeyInfo` around the PKCS#1 key: the algorithm, then the key as an OCTET STRING. */
function privateKeyInfo(numbers: RsaNumbers): Bytes {
  const rsaPrivateKey = derSequence(
    derInteger(0), // version: two-prime
    derBigInteger(numbers.modulus),
    derBigInteger(numbers.publicExponent),
    derBigInteger(numbers.privateExponent),
    derBigInteger(numbers.p),
    derBigInteger(numbers.q),
    derBigInteger(numbers.dp),
    derBigInteger(numbers.dq),
    derBigInteger(numbers.qinv),
  )
  return derSequence(
    derInteger(0),
    derSequence(derOid(OID_RSA_ENCRYPTION), derNull()),
    derOctetString(rsaPrivateKey),
  )
}

// MARK: - the encrypted half

/**
 * PBES2: PBKDF2-HMAC-SHA256 derives the key, AES-256-CBC encrypts with it.
 *
 * Every parameter is spelled out: the scheme's defaults are SHA-1 and a different cipher, and a
 * reader that takes the defaults would find neither here.
 */
function pbes2Encrypt(
  plaintext: Bytes, password: Bytes, salt: Bytes, iterations: number, iv: Bytes,
): { algorithm: Bytes, ciphertext: Bytes } {
  const key = pbkdf2Sha256(password, salt, iterations, 32)
  const ciphertext = aes256CbcEncrypt(key, iv, plaintext)
  const kdf = derSequence(
    derOid(OID_PBKDF2),
    derSequence(
      derOctetString(salt),
      derInteger(iterations),
      derInteger(32),
      derSequence(derOid(OID_HMAC_SHA256), derNull()),
    ),
  )
  const scheme = derSequence(derOid(OID_AES256_CBC), derOctetString(iv))
  return {
    algorithm: derSequence(derOid(OID_PBES2), derSequence(kdf, scheme)),
    ciphertext,
  }
}

// MARK: - the key, completed

export interface RsaNumbers {
  modulus: bigint
  publicExponent: bigint
  privateExponent: bigint
  p: bigint
  q: bigint
  dp: bigint
  dq: bigint
  qinv: bigint
}

/**
 * A JWK with every number a `RSAPrivateKey` has a field for.
 *
 * WebCrypto exports the CRT half along with `n`, `e` and `d`. A JWK that arrives without it is
 * completed here by factoring the modulus, which having `d` makes possible.
 */
export function completeRsaNumbers(jwk: RsaJwk): RsaNumbers {
  const modulus = bytesToBigInt(fromBase64Url(jwk.n))
  const publicExponent = bytesToBigInt(fromBase64Url(jwk.e))
  const privateExponent = bytesToBigInt(fromBase64Url(jwk.d))

  let p: bigint
  let q: bigint
  if (jwk.p !== undefined && jwk.q !== undefined) {
    p = bytesToBigInt(fromBase64Url(jwk.p))
    q = bytesToBigInt(fromBase64Url(jwk.q))
  } else {
    const found = factorModulus(modulus, publicExponent, privateExponent)
    p = found.p
    q = found.q
  }
  if (p < q) [p, q] = [q, p]
  return {
    modulus, publicExponent, privateExponent, p, q,
    dp: privateExponent % (p - 1n),
    dq: privateExponent % (q - 1n),
    qinv: modInverse(q, p),
  }
}

/**
 * The modulus's two primes, from `e` and `d`.
 *
 * `d·e − 1` is a multiple of `λ(n)`, so a random base raised to `(d·e − 1)/2^i` yields a square root
 * of one whose non-trivial value splits `n`. A key WebCrypto made has no small factor to find.
 */
function factorModulus(n: bigint, e: bigint, d: bigint): { p: bigint, q: bigint } {
  let k = d * e - 1n
  let shifts = 0
  while (k % 2n === 0n) {
    k /= 2n
    shifts++
  }
  for (let attempt = 0; attempt < 128; attempt++) {
    const base = bytesToBigInt(randomBytes(8)) % (n - 3n) + 2n
    let x = modPow(base, k, n)
    if (x === 1n || x === n - 1n) continue
    for (let i = 0; i < shifts; i++) {
      const next = (x * x) % n
      if (next === 1n) {
        const factor = gcd(x - 1n, n)
        if (factor > 1n && factor < n) return { p: factor, q: n / factor }
        break
      }
      if (next === n - 1n) break
      x = next
    }
  }
  throw new Error("p12: the modulus could not be factored from e and d")
}

// MARK: - PKCS#12's key derivation (RFC 7292 appendix B)

/**
 * The PKCS#12 KDF: `A_i = H^r(D || I)`, concatenated until `length` bytes are had.
 *
 * `id` says what the key is for — `PKCS12_ID_KEY` for the cipher, `PKCS12_ID_MAC` for the MAC — and
 * the password goes in as a BMPString, which the standard requires and PBES2's PBKDF2 does not.
 */
export function pkcs12Key(
  password: Bytes, salt: Bytes, id: number, length: number, iterations: number,
): Bytes {
  const D = new Uint8Array(SHA256_BLOCK).fill(id)
  const I = concat(
    repeatToMultiple(salt, SHA256_BLOCK),
    repeatToMultiple(utf16be(password), SHA256_BLOCK),
  )

  const out: Bytes[] = []
  let produced = 0
  for (;;) {
    const a = iteratedSha256(concat(D, I), iterations)
    out.push(a)
    produced += a.length
    if (produced >= length) break

    // I_j = I_j + 1, over the v-byte blocks the digest's expanded form covers.
    const expanded = repeatToMultiple(a, SHA256_BLOCK)
    const carry = new Uint8Array(I.length)
    carry.set(expanded.subarray(0, SHA256_BLOCK), 0)
    for (let at = 0; at < I.length; at += SHA256_BLOCK) {
      let value = 0
      for (let i = SHA256_BLOCK - 1; i >= 0; i--) {
        value += I[at + i] + carry[i]
        I[at + i] = value & 0xff
        value >>= 8
      }
    }
  }
  return concat(...out).subarray(0, length)
}

/** `H^r(input)`: the hash applied to itself `r` times. */
function iteratedSha256(input: Bytes, rounds: number): Bytes {
  let digest = sha256(input)
  for (let round = 1; round < rounds; round++) digest = sha256(digest)
  return digest
}

/** Repeats `bytes` until the length is a multiple of `v`, which is what the KDF's S and P are. */
function repeatToMultiple(bytes: Bytes, v: number): Bytes {
  if (bytes.length === 0) return new Uint8Array(0)
  const out = new Uint8Array(Math.ceil(bytes.length / v) * v)
  for (let at = 0; at < out.length; at += bytes.length) {
    out.set(bytes.subarray(0, Math.min(bytes.length, out.length - at)), at)
  }
  return out
}

/** The password as a BMPString: UTF-16 big-endian, with the terminating null word. */
function utf16be(bytes: Bytes): Bytes {
  const text = new TextDecoder().decode(bytes)
  const out = new Uint8Array((text.length + 1) * 2)
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i)
    out[i * 2] = code >> 8
    out[i * 2 + 1] = code & 0xff
  }
  return out
}

// MARK: - the primitives, from the runtime

function pbkdf2Sha256(password: Bytes, salt: Bytes, iterations: number, length: number): Bytes {
  const node: any = require("node:crypto")
  return new Uint8Array(node.pbkdf2Sync(password, salt, iterations, length, "sha256"))
}

function aes256CbcEncrypt(key: Bytes, iv: Bytes, plaintext: Bytes): Bytes {
  const node: any = require("node:crypto")
  const cipher = node.createCipheriv("aes-256-cbc", key, iv)
  return concat(new Uint8Array(cipher.update(plaintext)), new Uint8Array(cipher.final()))
}

function hmacSha256(message: Bytes, key: Bytes): Bytes {
  const Crypto: any = (globalThis as any).Crypto
  const D: any = (globalThis as any).Data
  return new Uint8Array(
    Crypto.hmacSHA256(D.fromUint8Array(message), D.fromUint8Array(key)).toUint8Array(),
  )
}

// MARK: - BigInt arithmetic

function bytesToBigInt(bytes: Bytes): bigint {
  let value = 0n
  for (const byte of bytes) value = (value << 8n) | BigInt(byte)
  return value
}

function modPow(base: bigint, exponent: bigint, modulus: bigint): bigint {
  let result = 1n
  let b = base % modulus
  let e = exponent
  while (e > 0n) {
    if (e & 1n) result = (result * b) % modulus
    b = (b * b) % modulus
    e >>= 1n
  }
  return result
}

function gcd(a: bigint, b: bigint): bigint {
  let x = a < 0n ? -a : a
  let y = b < 0n ? -b : b
  while (y !== 0n) [x, y] = [y, x % y]
  return x
}

/** The modular inverse of `a` mod `m`, by the extended Euclidean algorithm. */
function modInverse(a: bigint, m: bigint): bigint {
  let [oldR, r] = [((a % m) + m) % m, m]
  let [oldS, s] = [1n, 0n]
  while (r !== 0n) {
    const quotient = oldR / r
    ;[oldR, r] = [r, oldR - quotient * r]
    ;[oldS, s] = [s, oldS - quotient * s]
  }
  if (oldR !== 1n) throw new Error("p12: this number has no modular inverse")
  return ((oldS % m) + m) % m
}
