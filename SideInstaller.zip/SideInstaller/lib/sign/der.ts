// A small DER encoder — just the pieces code signing and CMS need.
//
// The one rule that catches people out is SET OF: in DER (unlike BER) the elements of a SET must
// be sorted by their own encodings. Apple's DER entitlements are a SET, and getting the order
// wrong produces a blob that hashes differently and is rejected. The ordering was confirmed
// against a real signed bundle rather than assumed.
import type { Bytes } from "../util"
import { bigIntToBytes, concat, utf8 } from "../util"

export const DER_TAG = {
  boolean: 0x01,
  integer: 0x02,
  bitString: 0x03,
  octetString: 0x04,
  null: 0x05,
  oid: 0x06,
  utf8String: 0x0c,
  printableString: 0x13,
  ia5String: 0x16,
  utcTime: 0x17,
  generalizedTime: 0x18,
  sequence: 0x30,
  set: 0x31,
} as const

/** A context-specific constructed tag, as CMS uses for `[0]` etc. */
export function contextTag(number: number): number {
  return 0xa0 | number
}

/** DER length: short form below 128, otherwise long form with the fewest bytes needed. */
export function derLength(length: number): Bytes {
  if (length < 0) throw new Error(`der: negative length ${length}`)
  if (length < 0x80) return new Uint8Array([length])
  const bytes: number[] = []
  let remaining = length
  while (remaining > 0) {
    bytes.unshift(remaining & 0xff)
    remaining >>>= 8
  }
  if (bytes.length > 4) throw new Error(`der: length ${length} needs more than four bytes`)
  return new Uint8Array([0x80 | bytes.length, ...bytes])
}

/** One tag-length-value. */
export function derEncode(tag: number, content: Bytes): Bytes {
  return concat(new Uint8Array([tag]), derLength(content.length), content)
}

export function derSequence(...elements: Bytes[]): Bytes {
  return derEncode(DER_TAG.sequence, concat(...elements))
}

/**
 * A SET, with its elements sorted by their own encodings as DER requires.
 *
 * Sorting is by unsigned byte comparison over the whole encoding, not by any inner value. For
 * entitlements that means the order depends on each entry's length byte first, which is why the
 * real blob is not in alphabetical order.
 */
export function derSet(...elements: Bytes[]): Bytes {
  const sorted = elements.slice().sort(compareBytes)
  return derEncode(DER_TAG.set, concat(...sorted))
}

function compareBytes(a: Bytes, b: Bytes): number {
  const shorter = Math.min(a.length, b.length)
  for (let i = 0; i < shorter; i++) {
    if (a[i] !== b[i]) return a[i] - b[i]
  }
  return a.length - b.length
}

/**
 * A BOOLEAN.
 *
 * Strict DER requires 0xFF for TRUE, and that is the default here. Apple's entitlements encoder
 * instead writes 0x01, which is why `entitlementsToDer` passes `strict: false`: a real signed
 * bundle carries 0x01, so matching it is what makes the slot hash come out right. iOS accepts
 * either.
 */
export function derBoolean(value: boolean, strict = true): Bytes {
  return derEncode(DER_TAG.boolean, new Uint8Array([value ? (strict ? 0xff : 0x01) : 0x00]))
}

/**
 * An INTEGER. DER integers are two's-complement and minimal, so a leading zero byte is added only
 * when the top bit would otherwise make a positive value look negative.
 */
export function derInteger(value: number): Bytes {
  if (!Number.isInteger(value)) throw new Error(`der: ${value} is not an integer`)
  if (value < 0) {
    // Two's complement, which CMS uses for nothing here but is cheap to get right.
    let v = value
    const bytes: number[] = []
    do {
      bytes.unshift(v & 0xff)
      v >>= 8
    } while (v !== -1 || (bytes[0] & 0x80) === 0)
    return derEncode(DER_TAG.integer, new Uint8Array(bytes))
  }
  const bytes: number[] = []
  let v = value
  do {
    bytes.unshift(v & 0xff)
    v = Math.floor(v / 256)
  } while (v > 0)
  if ((bytes[0] & 0x80) !== 0) bytes.unshift(0)
  return derEncode(DER_TAG.integer, new Uint8Array(bytes))
}

/**
 * An INTEGER from a bigint, which is how an RSA key's numbers are written.
 *
 * The minimal two's-complement rule is the whole content of this function: a 2048-bit modulus has
 * its top bit set, so it needs a leading zero byte to stay positive, while the public exponent
 * 65537 must not get one.
 */
export function derBigInteger(value: bigint): Bytes {
  if (value < 0n) {
    throw new Error("der: a negative bigint needs two's complement, which nothing here uses")
  }
  const bytes = bigIntToBytes(value)
  if ((bytes[0] & 0x80) === 0) return derEncode(DER_TAG.integer, bytes)
  const positive = new Uint8Array(bytes.length + 1)
  positive.set(bytes, 1)
  return derEncode(DER_TAG.integer, positive)
}

export function derUtf8String(text: string): Bytes {
  return derEncode(DER_TAG.utf8String, utf8(text))
}

/**
 * A `PrintableString`: the ASCII subset RFC 5280 requires for some attributes.
 *
 * The guard is the point. Passing a name with an accent through here would otherwise produce an
 * element whose bytes are not in the charset its own tag claims — accepted by lenient parsers,
 * rejected by strict ones, and impossible to see in a hex dump.
 */
export function derPrintableString(text: string): Bytes {
  const PRINTABLE = /^[A-Za-z0-9 '()+,\-./:=?]*$/
  if (!PRINTABLE.test(text)) {
    throw new Error(`der: ${JSON.stringify(text)} has characters a PrintableString cannot hold`)
  }
  return derEncode(DER_TAG.printableString, utf8(text))
}

export function derOctetString(bytes: Bytes): Bytes {
  return derEncode(DER_TAG.octetString, bytes)
}

/**
 * A BIT STRING, with the leading count of unused bits that DER puts inside the content.
 *
 * Zero for both uses here — a public key and a signature are whole bytes — and zero is also what
 * openssl writes, which is what lets a CSR be compared byte for byte against its output.
 */
export function derBitString(bytes: Bytes): Bytes {
  return derEncode(DER_TAG.bitString, concat(new Uint8Array([0]), bytes))
}

export function derNull(): Bytes {
  return derEncode(DER_TAG.null, new Uint8Array(0))
}

/** An OBJECT IDENTIFIER from dotted-decimal. */
export function derOid(dotted: string): Bytes {
  const parts = dotted.split(".").map(part => {
    const value = Number(part)
    if (!Number.isInteger(value) || value < 0) throw new Error(`der: bad OID arc ${part}`)
    return value
  })
  if (parts.length < 2) throw new Error(`der: OID ${dotted} needs at least two arcs`)

  const content: number[] = [parts[0] * 40 + parts[1]]
  for (const arc of parts.slice(2)) {
    const encoded: number[] = []
    let v = arc
    do {
      encoded.unshift(v & 0x7f)
      v = Math.floor(v / 128)
    } while (v > 0)
    // Continuation bits on every byte but the last.
    for (let i = 0; i < encoded.length - 1; i++) encoded[i] |= 0x80
    content.push(...encoded)
  }
  return derEncode(DER_TAG.oid, new Uint8Array(content))
}

/** `UTCTime`, as CMS wants for signingTime. Accepts a Date; always UTC with a Z suffix. */
export function derUtcTime(when: Date): Bytes {
  const pad = (value: number) => String(value).padStart(2, "0")
  const text =
    pad(when.getUTCFullYear() % 100) +
    pad(when.getUTCMonth() + 1) +
    pad(when.getUTCDate()) +
    pad(when.getUTCHours()) +
    pad(when.getUTCMinutes()) +
    pad(when.getUTCSeconds()) +
    "Z"
  // UTCTime is IA5String-based, so the tag stays 0x17 while the content is ASCII.
  return derEncode(DER_TAG.utcTime, utf8(text))
}

/** A `[n]` constructed context tag whose content is already DER. */
export function derContext(number: number, content: Bytes): Bytes {
  return derEncode(contextTag(number), content)
}
