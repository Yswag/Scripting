// `_CodeSignature/CodeResources`: the envelope that seals a bundle's resources.
//
// Three things about the format:
//
//   - `files[name]` is the raw SHA-1 digest; `files2[name]` is `{ hash2: <raw SHA-256> }`;
//   - the rule tables are emitted verbatim, including the real weights, and they differ between
//     `rules` and `rules2` — `rules2` omits `Info.plist` and `PkgInfo`, which is why the real
//     envelope lists `Info.plist` in `files` but not in `files2`;
//   - the envelope is sealed into CodeDirectory slot 3, and `Info.plist` into slot 1. The
//     Apple-signed framework does both; the zsign-signed app in the same IPA does neither.
import type { Bytes } from "../util"
import { sha1, sha256 } from "../util"
import { PlistReal, plistNumber, type PlistDict, type PlistValue } from "../util"

/**
 * The classic rule table, reproduced field for field from a real envelope.
 *
 * The weights are Apple's own and the values are load-bearing: `omit` keeps a path out of the
 * envelope, `optional` tolerates its absence, and the weight decides which rule wins.
 */
export const RESOURCE_RULES: PlistDict = {
  "^.*": true,
  "^.*\\.lproj/": { optional: true, weight: new PlistReal(1000) },
  "^.*\\.lproj/locversion.plist$": { omit: true, weight: new PlistReal(1100) },
  "^Base\\.lproj/": { weight: new PlistReal(1010) },
  "^version.plist$": true,
}

/** The newer table. Its `omit` entries are what keep the executable and Info.plist out of files2. */
export const RESOURCE_RULES2: PlistDict = {
  ".*\\.dSYM($|/)": { weight: new PlistReal(11) },
  "^(.*/)?\\.DS_Store$": { omit: true, weight: new PlistReal(2000) },
  "^.*": true,
  "^.*\\.lproj/": { optional: true, weight: new PlistReal(1000) },
  "^.*\\.lproj/locversion.plist$": { omit: true, weight: new PlistReal(1100) },
  "^Base\\.lproj/": { weight: new PlistReal(1010) },
  "^Info\\.plist$": { omit: true, weight: new PlistReal(20) },
  "^PkgInfo$": { omit: true, weight: new PlistReal(20) },
  "^embedded\\.provisionprofile$": { weight: new PlistReal(20) },
  "^version\\.plist$": { weight: new PlistReal(20) },
}

/** What a rule says about a path. */
export type RuleVerdict = "hash" | "omit" | "optional"

interface Rule {
  pattern: RegExp
  weight: number
  omit: boolean
  optional: boolean
}

function compileRules(table: PlistDict): Rule[] {
  const rules: Rule[] = []
  for (const [pattern, value] of Object.entries(table)) {
    let weight = 1
    let omit = false
    let optional = false
    if (value === true || value === false) {
      // A bare boolean means "hash it"; the default weight applies.
    } else if (value !== null && typeof value === "object" && !Array.isArray(value)) {
      const dict = value as Record<string, PlistValue>
      // The weights are `PlistReal`, so `typeof === "number"` would miss every one of them.
      const parsed = plistNumber(dict.weight)
      if (parsed !== null) weight = parsed
      omit = dict.omit === true
      optional = dict.optional === true
    }
    // The patterns are POSIX extended regexes with escaped dots; JavaScript reads them the same.
    rules.push({ pattern: new RegExp(pattern), weight, omit, optional })
  }
  // Highest weight wins, and the order in the table breaks ties.
  return rules.sort((a, b) => b.weight - a.weight)
}

const COMPILED_RULES = compileRules(RESOURCE_RULES)
const COMPILED_RULES2 = compileRules(RESOURCE_RULES2)

/** Applies a rule table to a path. */
export function ruleFor(rules: Rule[], path: string): Rule | null {
  return rules.find(rule => rule.pattern.test(path)) ?? null
}

/** Whether a path is hashed into `files` / `files2`, omitted, or hashed with an `optional` mark. */
export function verdictFor(table: "rules" | "rules2", path: string): RuleVerdict {
  const rules = table === "rules" ? COMPILED_RULES : COMPILED_RULES2
  const rule = ruleFor(rules, path)
  if (rule === null) return "hash"
  if (rule.omit) return "omit"
  // The stock tables mark a `.lproj` entry optional, which is written into the envelope as a flag
  // on the digest rather than left out.
  return rule.optional ? "optional" : "hash"
}

export interface ResourceEntry {
  /** Path relative to the bundle, e.g. `Frameworks/A.framework/A` or `Assets.car`. */
  path: string
  bytes: Bytes
}

export interface CodeResourcesResult {
  /** The plist to write at `_CodeSignature/CodeResources`. */
  envelope: PlistDict
  /** How many paths each table recorded. The two can differ: `rules2` omits more. */
  hashed: number
  hashed2: number
  /** Paths a `rules` entry kept out of `files` (none of the stock rules do). */
  omittedFromFiles: string[]
  /**
   * Paths a `rules2` entry kept out of `files2`. `Info.plist` and `PkgInfo` are always here,
   * which is why a real envelope lists `Info.plist` in `files` but not in `files2`.
   */
  omittedFromFiles2: string[]
}

/**
 * Builds the envelope for a bundle's resources.
 *
 * `entries` must already exclude the main executable and anything under `_CodeSignature`: the
 * binary is sealed by the CodeDirectory itself, and the envelope cannot seal itself.
 */
export function buildCodeResources(entries: ResourceEntry[]): CodeResourcesResult {
  const files: PlistDict = {}
  const files2: PlistDict = {}
  const omittedFromFiles: string[] = []
  const omittedFromFiles2: string[] = []
  let hashed = 0
  let hashed2 = 0

  for (const entry of entries) {
    if (isExcluded(entry.path)) {
      throw new Error(
        `coderesources: ${entry.path} must not be listed (the executable and _CodeSignature are ` +
        `sealed elsewhere)`,
      )
    }

    // `rules` governs `files`.
    const inFiles = verdictFor("rules", entry.path)
    if (inFiles === "omit") {
      omittedFromFiles.push(entry.path)
    } else if (inFiles === "optional") {
      // An optional file is one the bundle may legitimately not have at run time (a localization,
      // say), so its digest is advisory: a dictionary with `optional` set, as in the reference
      // signer's `insert_hash`.
      files[entry.path] = { hash: sha1(entry.bytes), optional: true }
      hashed++
    } else {
      files[entry.path] = sha1(entry.bytes)
      hashed++
    }

    // `rules2` governs `files2`, independently of the first table.
    const inFiles2 = verdictFor("rules2", entry.path)
    if (inFiles2 === "omit") {
      omittedFromFiles2.push(entry.path)
    } else if (inFiles2 === "optional") {
      files2[entry.path] = { hash: sha1(entry.bytes), hash2: sha256(entry.bytes), optional: true }
      hashed2++
    } else {
      // Both digests: the reference signer writes `hash` alongside `hash2` in every entry, and a
      // reader on an older system reads the SHA-1 one.
      files2[entry.path] = { hash: sha1(entry.bytes), hash2: sha256(entry.bytes) }
      hashed2++
    }
  }

  return {
    envelope: { files, files2, rules: RESOURCE_RULES, rules2: RESOURCE_RULES2 },
    hashed,
    hashed2,
    omittedFromFiles,
    omittedFromFiles2,
  }
}

function isExcluded(path: string): boolean {
  return path.startsWith("_CodeSignature/")
    || path === "_CodeSignature"
    || path === "CodeResources"
}

/** Reads an envelope back, for checking what was written. */
export interface ParsedCodeResources {
  files: Map<string, Bytes>
  files2: Map<string, Bytes>
  rules: PlistDict
  rules2: PlistDict
}

export function parseCodeResources(root: PlistDict): ParsedCodeResources {
  const files = new Map<string, Bytes>()
  const files2 = new Map<string, Bytes>()

  const rawFiles = root.files
  if (rawFiles !== null && typeof rawFiles === "object" && !Array.isArray(rawFiles)) {
    for (const [name, value] of Object.entries(rawFiles as Record<string, PlistValue>)) {
      if (value instanceof Uint8Array) files.set(name, value)
      else if (value !== null && typeof value === "object" && !Array.isArray(value)) {
        // The older form nests the digest under `hash`.
        const nested = (value as Record<string, PlistValue>).hash
        if (nested instanceof Uint8Array) files.set(name, nested)
      }
    }
  }

  const rawFiles2 = root.files2
  if (rawFiles2 !== null && typeof rawFiles2 === "object" && !Array.isArray(rawFiles2)) {
    for (const [name, value] of Object.entries(rawFiles2 as Record<string, PlistValue>)) {
      if (value instanceof Uint8Array) files2.set(name, value)
      else if (value !== null && typeof value === "object" && !Array.isArray(value)) {
        const nested = (value as Record<string, PlistValue>).hash2
        if (nested instanceof Uint8Array) files2.set(name, nested)
      }
    }
  }

  const asDict = (value: PlistValue | undefined): PlistDict =>
    value !== null && typeof value === "object" && !Array.isArray(value) && !(value instanceof Uint8Array)
      ? value as PlistDict
      : {}

  return {
    files, files2,
    rules: asDict(root.rules),
    rules2: asDict(root.rules2),
  }
}
