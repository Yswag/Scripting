// A Mach-O reader, enough to find and interpret the code signature.
//
// The endianness rule is the first thing to get right: Mach-O constants are in HOST order. On
// ARM the file is little-endian, so the magic reads as MH_CIGAM_64 (0xcffaedfe) when examined
// big-endian. Everything below goes through the detected endianness. Getting this wrong produces
// nonsense rather than an error.
import type { Bytes } from "../util"
import { fromUtf8 } from "../util"

export const MH_MAGIC = 0xfeedface
export const MH_MAGIC_64 = 0xfeedfacf
export const MH_CIGAM = 0xcefaedfe
export const MH_CIGAM_64 = 0xcffaedfe
export const FAT_MAGIC = 0xcafebabe
export const FAT_CIGAM = 0xbebafeca

export const LC_SEGMENT = 0x1
export const LC_SEGMENT_64 = 0x19
export const LC_CODE_SIGNATURE = 0x1d
export const LC_UUID = 0x1b

/**
 * The file's `LC_UUID` as lowercase hex, or null when it has none.
 *
 * A real signer puts it in the identifier of a binary that has no bundle: LiveContainer's own
 * `TweakLoader.dylib` shipped as `TweakLoader-55554944adee1f7e97a0346b93e412bab55cbbd0`, whose tail
 * is exactly this value.
 */
export function machoUuid(macho: MachO, bytes: Bytes): string | null {
  const command = macho.commands.find(entry => entry.command === LC_UUID)
  if (command === undefined || command.size < 24) return null
  const at = macho.base + command.offset + 8
  if (at + 16 > bytes.length) return null
  let out = ""
  for (let i = 0; i < 16; i++) out += bytes[at + i].toString(16).padStart(2, "0")
  return out
}

/** The file types worth naming. */
export const MH_FILE_TYPE = {
  1: "object",
  2: "executable",
  6: "dylib",
  8: "bundle",
} as const

export type Endianness = "little" | "big"

export interface LoadCommand {
  command: number
  /** Offset of the command within the Mach-O, not the file. */
  offset: number
  size: number
}

export interface Segment {
  name: string
  vmAddress: bigint
  vmSize: bigint
  fileOffset: bigint
  fileSize: bigint
  sections: number
  /** The offset of this segment's load command within the Mach-O, for patching. */
  commandOffset: number
}

export interface MachOHeader {
  is64: boolean
  endianness: Endianness
  cpuType: number
  cpuSubtype: number
  fileType: number
  nCommands: number
  sizeOfCommands: number
  flags: number
}

export class MachOError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "MachOError"
  }
}

/** A thin Mach-O, or one slice of a universal binary. */
export class MachO {
  private constructor(
    /** The whole file, including any fat header. */
    readonly file: Bytes,
    /** Where this slice's header starts. */
    readonly base: number,
    readonly header: MachOHeader,
    readonly commands: LoadCommand[],
    readonly segments: Segment[],
    /**
     * The lowest section offset in the slice, or null when no section has one.
     *
     * Room for a new load command ends here: the header and its commands live inside the first
     * segment, and a section's data is what follows. Slice-relative, like every other Mach-O offset.
     */
    readonly firstSectionOffset: number | null,
  ) {}

  /**
   * Parses a Mach-O. A universal binary is reduced to its arm64 slice when there is one,
   * because that is the only slice this project ever signs.
   */
  static parse(file: Bytes): MachO {
    if (file.length < 4) throw new MachOError("file is shorter than a magic number")
    const first = readU32be(file, 0)

    if (first === FAT_MAGIC) {
      const slice = pickFatSlice(file)
      const inner = MachO.parseThin(file, slice.offset)
      const size = readU32be(file, slice.offset + 4)
      void size
      return inner
    }
    if (first === FAT_CIGAM) {
      throw new MachOError("fat binaries in little-endian byte order are not supported")
    }
    return MachO.parseThin(file, 0)
  }

  /** Parses exactly one thin Mach-O at `base`. Throws when there is no header there. */
  static parseThin(file: Bytes, base: number): MachO {
    if (base + 28 > file.length) throw new MachOError("truncated Mach-O header")

    const magic = readU32be(file, base)
    let endianness: Endianness
    let is64: boolean
    if (magic === MH_MAGIC_64) { endianness = "big"; is64 = true }
    else if (magic === MH_MAGIC) { endianness = "big"; is64 = false }
    else if (magic === MH_CIGAM_64) { endianness = "little"; is64 = true }
    else if (magic === MH_CIGAM) { endianness = "little"; is64 = false }
    else {
      throw new MachOError(
        `not a Mach-O at ${base}: magic 0x${magic.toString(16).padStart(8, "0")} ` +
        `(a little-endian 64-bit file reads as 0xcffaedfe, not 0xfeedfacf)`,
      )
    }

    const le = endianness === "little"
    const u32 = (offset: number) => (le ? readU32le(file, offset) : readU32be(file, offset))
    const u64 = (offset: number) => (le ? readU64le(file, offset) : readU64be(file, offset))

    const header: MachOHeader = {
      is64,
      endianness,
      cpuType: u32(base + 4),
      cpuSubtype: u32(base + 8),
      fileType: u32(base + 12),
      nCommands: u32(base + 16),
      sizeOfCommands: u32(base + 20),
      flags: u32(base + 24),
    }

    const headerSize = is64 ? 32 : 28
    if (base + headerSize + header.sizeOfCommands > file.length) {
      throw new MachOError("load commands run past the end of the file")
    }

    const commands: LoadCommand[] = []
    const segments: Segment[] = []
    let firstSectionOffset: number | null = null
    const noteSection = (offset: number) => {
      if (offset <= 0) return
      if (firstSectionOffset === null || offset < firstSectionOffset) firstSectionOffset = offset
    }
    let at = base + headerSize
    for (let i = 0; i < header.nCommands; i++) {
      const command = u32(at)
      const size = u32(at + 4)
      if (size < 8 || at + size > file.length) {
        throw new MachOError(`load command ${i} has an implausible size ${size}`)
      }
      commands.push({ command, offset: at - base, size })

      if (command === LC_SEGMENT_64 && is64) {
        const sections = u32(at + 64)
        segments.push({
          name: fromUtf8(file.subarray(at + 8, at + 24)).replace(/\0.*$/, ""),
          vmAddress: u64(at + 24),
          vmSize: u64(at + 32),
          fileOffset: u64(at + 40),
          fileSize: u64(at + 48),
          sections,
          commandOffset: at - base,
        })
        // section_64: sectname 16 + segname 16 + addr/size 8+8, then `offset` as a u32.
        for (let s = 0; s < sections; s++) {
          const section = at + 72 + s * 80
          if (section + 52 > file.length) break
          noteSection(u32(section + 48))
        }
      } else if (command === LC_SEGMENT && !is64) {
        const sections = u32(at + 48)
        segments.push({
          name: fromUtf8(file.subarray(at + 8, at + 24)).replace(/\0.*$/, ""),
          vmAddress: BigInt(u32(at + 24)),
          vmSize: BigInt(u32(at + 28)),
          fileOffset: BigInt(u32(at + 32)),
          fileSize: BigInt(u32(at + 36)),
          sections,
          commandOffset: at - base,
        })
        for (let s = 0; s < sections; s++) {
          const section = at + 56 + s * 68
          if (section + 44 > file.length) break
          noteSection(u32(section + 40))
        }
      }
      at += size
    }

    return new MachO(file, base, header, commands, segments, firstSectionOffset)
  }

  /** The LC_CODE_SIGNATURE payload location, in FILE offsets (not slice-relative). */
  get codeSignature(): { dataOffset: number, dataSize: number } | null {
    const le = this.header.endianness === "little"
    for (const command of this.commands) {
      if (command.command !== LC_CODE_SIGNATURE) continue
      const at = this.base + command.offset
      const u32 = (offset: number) => (le ? readU32le(this.file, offset) : readU32be(this.file, offset))
      return { dataOffset: u32(at + 8), dataSize: u32(at + 12) }
    }
    return null
  }

  /** The `__LINKEDIT` segment, which the signature sits at the end of. */
  get linkedit(): Segment | null {
    return this.segments.find(segment => segment.name === "__LINKEDIT") ?? null
  }

  /** The signature bytes, or null when the binary is unsigned. */
  signatureBytes(): Bytes | null {
    const location = this.codeSignature
    if (location === null) return null
    const end = location.dataOffset + location.dataSize
    if (end > this.file.length) {
      throw new MachOError(
        `the signature claims ${location.dataSize} bytes at ${location.dataOffset}, ` +
        `past the end of a ${this.file.length}-byte file`,
      )
    }
    return this.file.subarray(location.dataOffset, end)
  }
}

// MARK: - fat binaries

interface FatSlice {
  cpuType: number
  offset: number
  size: number
}

/**
 * The arm64 slice of a universal binary.
 *
 * A fat header is always big-endian regardless of the slices inside it, which is a separate rule
 * from the slice endianness and worth stating once.
 */
export function fatSlices(file: Bytes): FatSlice[] {
  if (readU32be(file, 0) !== FAT_MAGIC) throw new MachOError("not a fat binary")
  const count = readU32be(file, 4)
  const slices: FatSlice[] = []
  for (let i = 0; i < count; i++) {
    const at = 8 + i * 20
    slices.push({
      cpuType: readU32be(file, at),
      offset: readU32be(file, at + 8),
      size: readU32be(file, at + 12),
    })
  }
  return slices
}

const CPU_TYPE_ARM64 = 0x0100000c

function pickFatSlice(file: Bytes): FatSlice {
  const slices = fatSlices(file)
  if (slices.length === 0) throw new MachOError("fat binary with no slices")
  const arm64 = slices.find(slice => slice.cpuType === CPU_TYPE_ARM64)
  if (arm64 === undefined) {
    throw new MachOError(
      `no arm64 slice (found cpu types ${slices.map(s => `0x${s.cpuType.toString(16)}`).join(", ")})`,
    )
  }
  return arm64
}

// MARK: - local readers

// Duplicated from lib/util/bytes on purpose: that module only has the big-endian pair, and
// these two are the whole reason this file exists.
function readU32be(bytes: Bytes, at: number): number {
  return ((bytes[at] << 24) | (bytes[at + 1] << 16) | (bytes[at + 2] << 8) | bytes[at + 3]) >>> 0
}

function readU32le(bytes: Bytes, at: number): number {
  return (bytes[at] | (bytes[at + 1] << 8) | (bytes[at + 2] << 16) | (bytes[at + 3] << 24)) >>> 0
}

function readU64be(bytes: Bytes, at: number): bigint {
  let out = 0n
  for (let i = 0; i < 8; i++) out = (out << 8n) | BigInt(bytes[at + i])
  return out
}

function readU64le(bytes: Bytes, at: number): bigint {
  let out = 0n
  for (let i = 7; i >= 0; i--) out = (out << 8n) | BigInt(bytes[at + i])
  return out
}
