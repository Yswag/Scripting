// The designated-requirement blob.
//
// A requirement is a small postfix opcode language, encoded big-endian, with one alignment rule:
// **after every length-prefixed string or blob, pad to a multiple of four bytes**. Getting that
// wrong shifts everything after it.
//
// The expression written here is the shape a real signer produces:
//
//     And( Ident "<identifier>",
//          And( AppleGenericAnchor,
//               And( CertField(0, "subject.CN", equal, False),
//                    CertGeneric(1, 1.2.840.113635.100.6.2.1, exists) ) ) )
//
// The `False` operand on CertField looks odd, but it is what the real blob contains: the match
// operator wants a value operand and the signer writes an empty one. Reproducing it byte for byte
// is the point; inventing a "correct" value would produce a requirement no other signer agrees with.
import type { Bytes } from "../util"
import { concat, u32be } from "../util"

/** The requirement opcodes used in the encoded expression. */
export const REQ_OP = {
  false: 0,
  true: 1,
  ident: 2,
  appleAnchor: 3,
  and: 6,
  or: 7,
  cdhash: 8,
  not: 9,
  certField: 11,
  certGeneric: 14,
  appleGenericAnchor: 15,
} as const

/**
 * How a field is compared. Only two appear in the reference expression.
 */
export const REQ_MATCH = {
  exists: 0,
  equal: 1,
  contains: 2,
} as const

/**
 * The OID a designated requirement checks on the *intermediate* certificate:
 * 1.2.840.113635.100.6.2.1, as the raw OID bytes.
 */
export const APPLE_DEVELOPER_OID = new Uint8Array([
  0x2a, 0x86, 0x48, 0x86, 0xf7, 0x63, 0x64, 0x06, 0x02, 0x01,
])

/** The field name checked on the leaf certificate. */
export const LEAF_FIELD = "subject.CN"

/** CSMAGIC values for the requirements wrappers. */
export const CSMAGIC_REQUIREMENTS = 0xfade0c01
export const CSMAGIC_REQUIREMENT = 0xfade0c00

/** Requirement kinds, from Apple's Requirement.h. */
export const REQUIREMENT_KIND = {
  host: 1,
  guest: 2,
  designated: 3,
  library: 4,
  plugin: 5,
} as const

// MARK: - primitives

function u32(value: number): Bytes {
  return new Uint8Array([
    (value >>> 24) & 0xff,
    (value >>> 16) & 0xff,
    (value >>> 8) & 0xff,
    value & 0xff,
  ])
}

/**
 * A length-prefixed blob, padded so that the stream length after it is a multiple of four.
 *
 * `streamLength` is the length of everything written so far, which is what the padding aligns —
 * not the length of the blob on its own.
 */
function lengthPrefixed(bytes: Bytes, streamLength: number): Bytes {
  const written = streamLength + 4 + bytes.length
  const padding = (4 - (written % 4)) % 4
  return concat(u32(bytes.length), bytes, new Uint8Array(padding))
}

// MARK: - the expression

/**
 * The requirements blob the reference signer writes: a `CSMAGIC_REQUIREMENTS` superblob with **no
 * entries at all** — magic, a length of 12, and a count of 0 (`apple-codesign-quick`'s
 * `signature.rs::empty_requirements_blob`, which is all it is).
 *
 * Signers disagree here: zsign and Apple both write the designated-requirement expression above, and
 * what a device makes of the difference is not something this project can measure. Signing follows
 * the reference; `buildDesignatedRequirement` stays because reproducing the real blobs is how the
 * opcode encoding above was established.
 */
export function emptyRequirements(): Bytes {
  const out = new Uint8Array(12)
  out.set(u32be(CSMAGIC_REQUIREMENTS), 0)
  out.set(u32be(12), 4)
  out.set(u32be(0), 8)
  return out
}

export interface DesignatedRequirementOptions {
  /** The bundle executable's name. Not the bundle identifier. */
  identifier: string
  /**
   * The requirement kind. Real signers write 1 (host) even for a designated requirement, which
   * is what `kind` reproduces; the superblob entry's type is 3.
   */
  kind?: number
  /** The superblob entry type. Defaults to 3, the designated requirement. */
  type?: number
}

/**
 * Builds the requirement expression.
 *
 * Written as an explicit sequence rather than a general expression compiler, because only this one
 * shape is needed and a general one would be far harder to check against the reference bytes.
 */
export function designatedRequirementExpression(identifier: string): Bytes {
  const identifierBytes = new TextEncoder().encode(identifier)
  const fieldBytes = new TextEncoder().encode(LEAF_FIELD)

  // Explicitly typed: `new Uint8Array(0)` infers the narrower `Uint8Array<ArrayBuffer>`,
  // which will not accept what `concat` returns.
  let out: Bytes = new Uint8Array(0)
  const push = (...parts: Bytes[]) => { out = concat(out, ...parts) }

  push(u32(REQ_OP.and))
  push(u32(REQ_OP.ident))
  push(lengthPrefixed(identifierBytes, out.length))

  push(u32(REQ_OP.and))
  push(u32(REQ_OP.appleGenericAnchor))
  push(u32(REQ_OP.and))

  // CertField: the certificate number, the field, the match, then the value operand.
  push(u32(REQ_OP.certField))
  push(u32(0)) // the leaf certificate
  push(lengthPrefixed(fieldBytes, out.length))
  push(u32(REQ_MATCH.equal))
  push(u32(REQ_OP.false)) // the empty value operand the real signer writes

  // CertGeneric: a different certificate, an OID, and an existence test — no value operand.
  push(u32(REQ_OP.certGeneric))
  push(u32(1)) // the certificate at index 1
  push(lengthPrefixed(APPLE_DEVELOPER_OID, out.length))
  push(u32(REQ_MATCH.exists))

  return out
}

/**
 * The full CSMAGIC_REQUIREMENTS blob: a superblob holding one requirement.
 *
 * Offsets inside it are from the start of the superblob, header included.
 */
export function buildDesignatedRequirement(options: DesignatedRequirementOptions): Bytes {
  const expression = designatedRequirementExpression(options.identifier)
  const kind = options.kind ?? REQUIREMENT_KIND.host
  const type = options.type ?? REQUIREMENT_KIND.designated

  const requirement = concat(u32(CSMAGIC_REQUIREMENT), u32(12 + expression.length), u32(kind), expression)

  const indexSize = 12 + 8
  const offset = indexSize
  const total = indexSize + requirement.length

  const header = concat(
    u32(CSMAGIC_REQUIREMENTS),
    u32(total),
    u32(1),
    u32(type),
    u32(offset),
  )
  return concat(header, requirement)
}
