// LiveContainer's certificate, and the one way to hand it over.
//
// LiveContainer signs the apps it runs with a certificate it keeps in its own app group, and on
// iOS 26 it runs nothing at all without one. That slot cannot be written from outside the app
// (there is no channel into an app group's container), so the hand-over is a URL its own scheme
// takes: `handleURL` stores the two values, and the scheme is the app's own.
import { toBase64, type Bytes } from "./util"

/** LiveContainer's bundle id. An install of it lands as `<this>.<team id>`. */
export const LIVE_CONTAINER_IDENTIFIER = "com.kdt.livecontainer"

/** True for LiveContainer itself, as the IPA names it or as it was installed. */
export function isLiveContainer(identifier: string): boolean {
  return identifier === LIVE_CONTAINER_IDENTIFIER
    || identifier.startsWith(`${LIVE_CONTAINER_IDENTIFIER}.`)
}

/** The key the prepared URL is kept under, for the popup that offers to send it. */
export const CERTIFICATE_KEY = "install.certificate"

/**
 * The URL that hands LiveContainer a certificate.
 *
 * Its handler decodes `cert` but takes `password` as it stands, so only the base64 is escaped and
 * the password has to be one that survives a query string — SideInstaller's is the certificate's
 * machine id, which does.
 */
export function certificatePushURL(p12: Bytes, password: string): string {
  return `livecontainer://certificate?cert=${encodeURIComponent(toBase64(p12))}&password=${password}`
}
