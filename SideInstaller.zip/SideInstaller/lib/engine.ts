// Orchestration: the ordered gates of the install flow, a log bus, and the one place the UI
// talks to. Steps carry translation KEYS, never literals, and the translate function is
// injected — so this module has no opinion about language and stays testable on its own.
//
// A step with no `run` is not a failure: it reports `blocked` with a reason, so a gate that
// is not wired up yet never looks like it succeeded.
import { Script, fetch } from "scripting"
import type { TranslationKey } from "./i18n"
import {
  AnisetteNotProvisionedError, AnisetteServer, AppleHttpError, AppleRefusals, GSA_CLIENT_INFO, GSA_USER_AGENT,
  GrandSlam, GrandSlamError, PortalClient, PortalError, SIDECONF_FILE_NAME, MACHINE_NAME, anisetteCandidates, clearSession,
  ensureSigningIdentity, fetchAnisetteServers, fetchUrlBag, isCredentialRejection, isSessionUsable,
  importsAccountConfigSilently, loadOrCreateSigningKey, loadSession, saveAnisettePick, saveSession, savedAnisettePick,
  selectIdentity, sideconfBytes,
  localAnisetteIsRunning, localAnisetteUrl, startLocalAnisette, stopLocalAnisette, isLocalAnisette,
  activeAccount, dropAccount, forgetTeam, loadAccounts, loadAppIdQuota, loadTeam,
  rememberAccount, saveAppIdQuota, saveTeam,
  signInForDeveloperToken, verdictFor,
  type AnisetteIdentity, type AnisetteServerEntry, type AppId, type AppIdQuota, type AppToken, type DeveloperCertificate,
  type ProvisioningUrls, type RsaJwk, type Team,
} from "./apple"
import { signBundle, parseProvisioningProfile, entitlementsFor, buildPkcs12, type ProvisioningProfile } from "./sign"
import {
  certificateBlocksRefresh, deviceAppFrom, deviceStateOf, installedRecords, forgetInstalled, loadRefreshScope,
  recordOfInstall, refreshableOnDevice, rememberInstalled, saveRefreshScope, splitApplicationIdentifier,
  statusOfRecord, updateCertificateStatus, updateDeviceStates, updateInstalledDates,
  type DeviceApp, type DeviceFacts, type DeviceProfile, type DeviceState,
  type InstalledRecord, type ListedCertificate, type RefreshScope,
} from "./apps"
import {
  AfcClient, InstallationProxy, MisagentClient, REMOTED_PORT, SERVICES, deployBundle, documentsPrefix,
  openDeviceLink, pairingTargetFor, preferencesPath, probeTcp, seedPairingFile, writeIntoDocuments,
  type DeviceLink, type SeedOutcome, type TcpProbe,
} from "./rsd"
import {
  PairSetupHost, PairStore, SocketPeer,
  pairingFileToXml, exportPairingRecord, publishPairableHost, seesOwnPairableHost,
  type PairingFile, type PairingExportFormat,
} from "./rpp"
import { loadConnectionSettings } from "./connection"
import { DdiError, ensureDeveloperImage, type DdiStage } from "./ddi"
import { EnableJITError, enableJIT, scriptForAppName, type EnableStep } from "./jit"
import { CERTIFICATE_KEY, certificatePushURL, isLiveContainer } from "./livecontainer"
import { asDict, parsePlist, str, unpackIpa, type Bytes, type PlistDict } from "./util"
import {
  INSTALL_SOURCES, RELEASE_CHANNELS, channelName, displayName as buildDisplayName, fileSha256,
  getJson, releaseCatalog, repo as repoOf, repoGone, searchFor,
  type InstallSource, type ReleaseCatalog, type ReleaseChannel, type ReleaseVersion,
} from "./builds"

export type StepId = string
export type StepState = "pending" | "running" | "done" | "failed" | "blocked" | "skipped"

export type LogLevel = "info" | "ok" | "warn" | "error"

export interface LogLine {
  at: Date
  level: LogLevel
  text: string
}

export type Translate = (key: TranslationKey, params?: Record<string, string | number>) => string

/**
 * Where the pairing code is shown to a person who is in Settings.
 *
 * The engine decides *when* and says nothing about *how*: pairing this device means typing a code
 * this app shows into a prompt in Settings, with the app behind it, so the code has to be drawn
 * somewhere visible from there — a Live Activity, here. Injected the way `t` is, so a test can watch
 * the sequence and a build without one still pairs (the log carries the code either way).
 *
 * The shape is the original app's `PairingCodeSurface`.
 */
export interface PairingCodeSurface {
  /**
   * Pairing has begun, with the app still in front — a card cannot be started later, so this is the
   * only moment one can be raised. Returns why none was, or null when it is up.
   */
  start(pin: string): Promise<PairingCardProblem | null> | PairingCardProblem | null
  /** The device dialled in, so the code is about to be asked for. */
  prompt(pin: string): Promise<void> | void
  /** Pairing ended, however it went. */
  finish(paired: boolean, device: string): Promise<void> | void
}

/** Why no card could be drawn, as a key so the step can log it in the reader's language. */
export interface PairingCardProblem {
  key: TranslationKey
  /** The system's own words, when there were any. */
  message?: string
}

export interface EngineContext {
  say: (key: TranslationKey, params?: Record<string, string | number>, level?: LogLevel) => void
  /** Raw device output, which no catalogue should pretend to phrase. Redacted, like everything else. */
  sayRaw: (text: string, level?: LogLevel) => void
  /** Resolves a catalogue key, for the bits that build their own text. */
  t: Translate
  /** Absolute path of the project directory, for modules that need to write files. */
  directory: string
  /** Null when nothing draws the code; the step then only logs it. */
  surface: PairingCodeSurface | null
  /** Which build to install, resolved from the picker. Absent means this project's one default. */
  build?: BuildChoice | { source: "import", ipa: DownloadedIpa | null }
  /** A manual request to pair again rather than reuse the saved record. */
  forcePairing?: boolean
}

/** The build the picker settled on. */
export interface BuildChoice {
  source: InstallSource
  channel: ReleaseChannel
  /** The release picked under Advanced, when one was. */
  version?: ReleaseVersion
}

export interface StepDefinition {
  id: StepId
  titleKey: TranslationKey
  summaryKey: TranslationKey
  /** Shown as the reason when `run` is absent. */
  blockedKey?: TranslationKey
  /**
   * Runs the gate. Throw to fail. Absent while the module it depends on is still being
   * written — that is the `blocked` path, not an error.
   */
  run?: (ctx: EngineContext) => Promise<void>
}

export interface EngineOptions {
  t?: Translate
  /** Defaults to `Script.directory`. */
  directory?: string
  /** Defaults to none: the pairing step still works, it just logs the code. */
  surface?: PairingCodeSurface
}

// MARK: - errors

/**
 * A failure whose message is a catalogue key rather than a literal. Steps throw this so the
 * engine can resolve the text in the active language instead of leaking a raw key.
 */
export class StepError extends Error {
  readonly key: TranslationKey
  readonly params?: Record<string, string | number>

  constructor(key: TranslationKey, params?: Record<string, string | number>) {
    super(key)
    this.name = "StepError"
    this.key = key
    this.params = params
  }
}

// MARK: - redaction

/**
 * Backstop only. The design keeps secrets out of the log in the first place — the Apple ID
 * password is never passed to `say`, never stored, and never put in an error message.
 */
export function redact(text: string): string {
  return text
    // JWTs and other long base64-ish blobs
    .replace(/\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g, "<token>")
    // p12 / adi blobs
    .replace(/\bMII[A-Za-z0-9+/]{60,}={0,2}\b/g, "<blob>")
    // "password": "..." in any blob we might one day log
    .replace(/("(?:password|passwd|pwd)"\s*:\s*")[^"]*(")/gi, "$1<redacted>$2")
}

// MARK: - engine

const SOURCE_KEY = "install.source"
const CHANNEL_KEY = "install.channel"

/** How long a fetched release list is reused, as the Swift app does. */
const CATALOG_TTL_MS = 15 * 60 * 1000

function versionKey(source: InstallSource, channel: ReleaseChannel): string {
  return `install.version.${source}.${channel}`
}

/** Every release a catalogue holds, the two latest ones included. */
function catalogVersions(catalog: ReleaseCatalog): ReleaseVersion[] {
  return [
    ...(catalog.latest.stable === undefined ? [] : [catalog.latest.stable]),
    ...catalog.others.stable,
    ...(catalog.latest.nightly === undefined ? [] : [catalog.latest.nightly]),
    ...catalog.others.nightly,
  ]
}

/** Used when no translator is injected: the key itself, which is what tests assert on. */
const passthrough: Translate = key => key

export type RefreshState = "pending" | "working" | "done" | "failed"

/** One app in a refresh run, and how it went. */
export interface RefreshJob {
  /** The record's identifier, which is also the app's bundle id on the device. */
  bundleId: string
  name: string
  state: RefreshState
  /** Why it failed, in the reader's language. */
  reason: string
}

/** How a run is run. */
export interface RefreshOptions {
  /**
   * Leave the reflection alone: what a Shortcut needs, since nobody is in front of the app to
   * answer for a VPN, and a run that starts one behind a shortcut is a surprise. The address has to
   * be live already, and a run without one fails with a message saying so.
   */
  background?: boolean
}

/** What a run did, for a caller that is not the page (a Shortcut). */
export interface RefreshSummary {
  ok: boolean
  /** How many apps the run meant to renew. */
  total: number
  /** How many of them now have a new profile. */
  refreshed: number
  /** Why nothing happened, or the run's failure; null when every app was renewed. */
  message: string | null
}

/** What one look at the device said about the records. */
export interface DeviceCheckSummary {
  ok: boolean
  /** How many records were asked about. */
  total: number
  /** How many are still the app this app installed. */
  ours: number
  /** How many are not on the device at all. */
  missing: number
  /** How many carry another team's signature. */
  foreign: number
  /** How many are ours but are running under a different profile than the record says. */
  stale: number
  /** Why the check did not happen; null when it did. */
  message: string | null
}

/** The stage an enabling run stopped at, named in the log line that reports it. */
const JIT_STAGE: Record<EnableStep, TranslationKey> = {
  launch: "apps.jitStage.launch",
  attach: "apps.jitStage.attach",
  regions: "apps.jitStage.regions",
  detach: "apps.jitStage.detach",
}

/** The same, for getting the developer image onto the device first. */
const DDI_STAGE: Record<DdiStage, TranslationKey> = {
  check: "apps.ddi.check",
  download: "apps.ddi.download",
  identify: "apps.ddi.identify",
  nonce: "apps.ddi.nonce",
  ticket: "apps.ddi.ticket",
  install: "apps.ddi.install",
  verify: "apps.ddi.verify",
}

/**
 * Keeps this script running while another app is in front, and hands back the release.
 *
 * A background script's timers and socket callbacks stop, which turns a 20-second wait into "as long
 * as the person stays away". Only the main app can ask for this, so a run elsewhere goes without.
 */
async function holdBackground(): Promise<() => Promise<void>> {
  const keeper: any = (globalThis as any).BackgroundKeeper
  if (keeper === undefined) return async () => {}

  let held = false
  try {
    held = await keeper.keepAlive()
  } catch {
    held = false
  }
  if (!held) return async () => {}

  return async () => {
    try {
      await keeper.stopKeepAlive()
    } catch {
      // Nothing to release if the engine is already gone.
    }
  }
}

export class Engine {
  readonly steps: StepDefinition[]
  private readonly t: Translate
  readonly directory: string
  private readonly surface: PairingCodeSurface | null
  private readonly state = new Map<StepId, StepState>()
  private readonly details = new Map<StepId, string>()
  /** The catalogue key a step failed with, for the pages that answer to one particular failure. */
  private readonly failureKeys = new Map<StepId, TranslationKey>()
  private readonly lines: LogLine[] = []
  private readonly listeners = new Set<() => void>()
  /** A sign-in started from Settings, which is not a gate; see `useAccount`. */
  private accountSignIn = false

  // What to install. Read from `Storage` on first use rather than here: this module is imported
  // before `Script.requestAccess` has settled, and until it has, `Storage` hands out an empty store.
  private selectionLoaded = false
  private source: InstallSource | "import" = "sideStore"
  private importedIpa: DownloadedIpa | null = null
  private channel: ReleaseChannel = "stable"
  private loadingCatalog: InstallSource | null = null
  private readonly picked = new Map<string, string>()
  private readonly catalogs = new Map<InstallSource, ReleaseCatalog>()
  private readonly catalogFailures = new Map<InstallSource, string>()

  constructor(steps: StepDefinition[], options: EngineOptions = {}) {
    this.steps = steps
    this.t = options.t ?? passthrough
    this.directory = options.directory ?? Script.directory
    this.surface = options.surface ?? null
    for (const step of steps) this.state.set(step.id, "pending")
  }

  // MARK: observation

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  private notify() {
    for (const listener of this.listeners) listener()
  }

  stateOf(id: StepId): StepState {
    return this.state.get(id) ?? "pending"
  }

  detailOf(id: StepId): string {
    return this.details.get(id) ?? ""
  }

  titleOf(step: StepDefinition): string {
    if (step.id === "install") return this.t(step.titleKey, { name: this.installTargetName() })
    return this.t(step.titleKey)
  }

  /** What the install step's title names, before its IPA has been unpacked. */
  private installTargetName(): string {
    if (this.source === "import") return this.importedName ?? this.t("install.import")
    return this.source === "sideStore" ? "SideStore" : "LiveContainer"
  }

  /** Newest first — that is how the console reads. */
  get log(): LogLine[] {
    return this.lines.slice().reverse()
  }

  /** The first gate that still needs work, or null when they are all settled. */
  get currentStep(): StepDefinition | null {
    for (const step of this.steps) {
      const s = this.stateOf(step.id)
      if (s === "pending" || s === "running" || s === "failed") return step
    }
    return null
  }

  get doneCount(): number {
    let n = 0
    for (const step of this.steps) if (this.stateOf(step.id) === "done") n++
    return n
  }

  get isRunning(): boolean {
    return this.steps.some(s => this.stateOf(s.id) === "running")
  }

  // MARK: what to install

  private loadSelection() {
    if (this.selectionLoaded) return
    this.selectionLoaded = true
    const source = Storage.get<string>(SOURCE_KEY)
    if (source === "import" || INSTALL_SOURCES.includes(source as InstallSource)) {
      this.source = source as InstallSource | "import"
    }
    const channel = Storage.get<string>(CHANNEL_KEY)
    if (channel === "stable" || channel === "nightly") this.channel = channel
    for (const saved of INSTALL_SOURCES) {
      for (const track of RELEASE_CHANNELS) {
        const tag = Storage.get<string>(versionKey(saved, track))
        if (typeof tag === "string" && tag.length > 0) this.picked.set(`${saved}|${track}`, tag)
      }
    }
  }

  get installSource(): InstallSource | "import" {
    this.loadSelection()
    return this.source
  }

  setInstallSource(source: InstallSource | "import") {
    this.loadSelection()
    if (this.source === source) return
    this.source = source
    Storage.set(SOURCE_KEY, source)
    if (this.stateOf("install") !== "pending") this.reset("install")
    this.notify()
  }

  get importedFileName(): string | null {
    return this.source === "import" ? this.importedName : null
  }

  setImportedIpa(ipa: DownloadedIpa, name: string) {
    const previous = this.importedIpa?.path
    this.importedIpa = ipa
    this.importedName = name
    if (this.stateOf("install") !== "pending") this.reset("install")
    this.notify()
    if (previous !== undefined && previous !== ipa.path) FileManager.removeSync(previous)
  }

  private importedName: string | null = null

  get releaseChannel(): ReleaseChannel {
    this.loadSelection()
    return this.channel
  }

  setReleaseChannel(channel: ReleaseChannel) {
    this.loadSelection()
    if (this.channel === channel) return
    this.channel = channel
    Storage.set(CHANNEL_KEY, channel)
    if (this.stateOf("install") !== "pending") this.reset("install")
    this.notify()
  }

  /** The release picked under Advanced for this build and channel, or undefined for "Latest". */
  get pickedTag(): string | undefined {
    this.loadSelection()
    return this.source === "import" ? undefined : this.picked.get(`${this.source}|${this.channel}`)
  }

  setPickedTag(tag: string | undefined) {
    this.loadSelection()
    if (this.source === "import") return
    const key = `${this.source}|${this.channel}`
    if (tag === undefined) this.picked.delete(key)
    else this.picked.set(key, tag)
    Storage.set(versionKey(this.source, this.channel), tag ?? "")
    if (this.stateOf("install") !== "pending") this.reset("install")
    this.notify()
  }

  /** The picked release itself, resolved against the loaded catalogue. */
  get selectedVersion(): ReleaseVersion | undefined {
    const tag = this.pickedTag
    if (tag === undefined) return undefined
    if (this.installSource === "import") return undefined
    const catalog = this.catalogOf(this.installSource)
    if (catalog === undefined) return undefined
    return catalogVersions(catalog).find(version => version.tag === tag)
  }

  catalogOf(source: InstallSource): ReleaseCatalog | undefined {
    return this.catalogs.get(source)
  }

  catalogErrorOf(source: InstallSource): string | undefined {
    return this.catalogFailures.get(source)
  }

  get catalogLoading(): InstallSource | null {
    return this.loadingCatalog
  }

  /** Lists a build's releases for the version picker, reusing a list fetched in the last 15 minutes. */
  async loadCatalog(source: InstallSource, force = false): Promise<void> {
    if (this.loadingCatalog === source) return
    const cached = this.catalogs.get(source)
    if (!force && cached !== undefined && Date.now() - cached.fetched < CATALOG_TTL_MS) return
    this.loadingCatalog = source
    this.catalogFailures.delete(source)
    this.notify()
    try {
      const catalog = await releaseCatalog(source, getJson, Date.now())
      this.catalogs.set(source, catalog)
      this.say("build.listed", {
        name: buildDisplayName(source),
        stable: catalog.others.stable.length,
        nightly: catalog.others.nightly.length,
      })
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      this.catalogFailures.set(source, message)
      this.say("build.listFailed", { name: buildDisplayName(source), message }, "warn")
    } finally {
      if (this.loadingCatalog === source) this.loadingCatalog = null
      this.notify()
    }
  }

  // MARK: what Settings shows

  /** The Apple ID this device signs in as, or null when none was saved. */
  get savedAccount(): string | null {
    return activeAccount()
  }

  /** The Apple IDs this device has signed in as, the one in use first. */
  get savedAccounts(): string[] {
    return loadAccounts()
  }

  /** Whether a sign-in started from Settings is running; the gates have their own `isRunning`. */
  get accountBusy(): boolean {
    return this.accountSignIn
  }

  /**
   * Signs in as `email` — one of the saved Apple IDs, or one being added — and makes it the
   * account this device uses.
   *
   * Not a gate, so a sign-in that fails here leaves the store exactly as it was: this device is
   * never left pointing at an Apple ID that never worked. On success the gates after sign-in are
   * reset, because what they hold (the team, the signed app) is the previous account's.
   */
  async useAccount(email: string): Promise<boolean> {
    if (this.isRunning || this.accountSignIn) {
      this.say("log.busy", undefined, "warn")
      return false
    }
    const address = email.trim()
    if (address === "") return false

    const previous = this.savedAccount
    const changed = previous === null || previous.toLowerCase() !== address.toLowerCase()
    this.accountSignIn = true
    this.notify()
    try {
      await signInAs(this.context(), address)
    } catch (error) {
      this.say("settings.account.failed", { email: address, message: this.describe(error) }, "error")
      return false
    } finally {
      this.accountSignIn = false
      this.notify()
    }

    this.say("settings.account.signedIn", { email: address }, "ok")
    if (changed) {
      this.reset("identity")
      this.reset("install")
    }
    return true
  }

  /** Asks for an Apple ID, then signs in as it. See `useAccount`. */
  async addAccount(): Promise<void> {
    if (this.isRunning || this.accountSignIn) {
      this.say("log.busy", undefined, "warn")
      return
    }
    const typed = await ask(this.context(), "settings.account.add", "", false)
    const email = (typed ?? "").trim()
    if (email === "") return
    if (!/^[^@\s]+@[^@\s]+$/.test(email)) {
      this.say("settings.account.add.invalid", { email }, "warn")
      return
    }
    await this.useAccount(email)
  }

  /**
   * Forgets the Apple ID in use: its session, the team chosen for it, and its place in the list.
   * Another saved account becomes the one in use. The signing key stays — it is what the account's
   * certificate was issued for, and dropping it would waste one of the two slots a free Apple ID
   * has.
   */
  forgetAccount() {
    const email = this.savedAccount
    if (email === null) return
    // The team goes first: which account is in use is half of where it is kept.
    forgetTeam(email)
    dropAccount(email)
    this.reset("signin")
    this.reset("identity")
    this.reset("install")
    this.say("settings.account.forgot")
    this.notify()
  }

  // MARK: the Apps page
  //
  // The list is this app's own records of what it installed, so opening the page reads nothing from
  // the device and works with no link up; a refresh only replaces the profile behind one App ID.
  // A Shortcut drives the same two methods with no page open.

  private jobs: RefreshJob[] = []
  private refreshing = false
  private refreshStop = false
  private checkingDevice = false

  /** What this app has put on the device. */
  get installedApps(): InstalledRecord[] {
    return installedRecords()
  }

  /**
   * Drops one entry from that list, for an app that is no longer on the device.
   *
   * The record is this app's own note, so this touches nothing on the device.
   */
  forgetInstalledApp(identifier: string): void {
    const record = this.installedApps.find(candidate => candidate.identifier === identifier)
    if (record === undefined) return
    forgetInstalled(identifier)
    this.jobs = this.jobs.filter(job => job.bundleId !== identifier)
    this.say("apps.removed", { name: record.name }, "ok")
    this.notify()
  }

  // MARK: JIT

  private jitTarget: string | null = null
  private readonly jitFailures = new Map<string, string>()

  /** The app whose JIT is being enabled right now, if any. */
  get enablingJIT(): string | null {
    return this.jitTarget
  }

  /** Why enabling JIT last failed for that app, until it is tried again. */
  jitFailureOf(identifier: string): string {
    return this.jitFailures.get(identifier) ?? ""
  }

  /**
   * Attaches a debugger to an app and answers its requests for executable regions.
   *
   * The app is launched stopped, so an app the device refuses to start is the first thing that can
   * fail — before anything is attached or prepared.
   */
  async enableJIT(identifier: string): Promise<void> {
    const record = this.installedApps.find(candidate => candidate.identifier === identifier)
    if (record === undefined || this.jitTarget !== null) return

    this.jitTarget = identifier
    this.jitFailures.delete(identifier)
    this.notify()
    this.say("apps.jitBegin", { name: record.name })

    // Launching the app puts this one in the background, and a background script stops running:
    // the debugger's wait would only resume once the person came back, by which time the app has
    // given up. The request is made while this app is still in front.
    const release = await holdBackground()

    let device: DeviceLink | null = null
    try {
      const address = await reflectionForDevice(this.context())
      if (address.length === 0) throw new StepError("apps.reflectionNeeded")
      device = await openDeviceLink({ address, onStep: message => this.sayRaw(message) })

      const image = await ensureDeveloperImage(device, {
        onProgress: (stage, detail) => {
          if (stage === "download" && detail !== undefined) this.say("apps.ddiDownload", { detail })
          else if (detail !== undefined) this.say("apps.ddiDetail", { stage: this.t(DDI_STAGE[stage]), detail })
          else this.say(DDI_STAGE[stage])
        },
      })
      if (image.installed) this.say("apps.ddiInstalled", { version: image.version }, "ok")
      else this.say("apps.ddiReady", { version: image.version }, "ok")

      // The service table was read before the image was there, so it names none of its services.
      if (image.installed) {
        await device.close()
        device = await openDeviceLink({ address, onStep: message => this.sayRaw(message) })
      }

      const result = await enableJIT(device, {
        bundleIdentifier: identifier,
        // Which dialect this app speaks; the table is StikDebug's AutoScriptAssignments.
        script: scriptForAppName(record.name),
        // StikDebug waits forever (its own socket, no read deadline). Our tunnel refuses a read that
        // has been blocked for 120 s, so a wait is bounded just under that and a dropped connection
        // is replaced instead of ending the session — see `nextStop`.
        windowMs: 110_000,
        onStep: (step, detail) => {
          if (step === "launch") this.say("apps.jitLaunched", { pid: detail ?? "" })
          if (step === "attach") this.say("apps.jitAttached")
          if (step === "regions") this.say("apps.jitRegions", { count: Number(detail ?? "0") })
        },
        onTrace: line => this.sayRaw(line),
      })
      if (result.regions > 0) {
        this.say("apps.jitDone", { name: record.name, count: result.regions }, "ok")
      } else {
        // Nothing was prepared: the app never asked. On a device without TXM the attach alone is
        // all it needed; on one with it, this app is not JIT-capable (or did not get that far).
        const message = this.t("apps.jitNoRequest", { name: record.name })
        this.jitFailures.set(identifier, message)
        this.say("apps.jitNoRequest", { name: record.name }, "warn")
      }
    } catch (error) {
      const stage = error instanceof EnableJITError
        ? `${this.t(JIT_STAGE[error.stage])}: `
        : error instanceof DdiError ? `${this.t(DDI_STAGE[error.stage])}: ` : ""
      const message = `${stage}${this.describe(error)}`
      this.jitFailures.set(identifier, message)
      // The daemon names the mount point when something else already holds it.
      if (message.includes("mkdir custom mount path")) this.say("apps.ddiMountConflict", { message }, "error")
      else this.say("apps.jitFailed", { name: record.name, message }, "error")
    } finally {
      if (device !== null) await device.close()
      await release()
      this.jitTarget = null
      this.notify()
    }
  }

  /** The refresh scope: "currentAccount" or "allAccounts". */
  get refreshScope(): RefreshScope {
    return loadRefreshScope()
  }

  setRefreshScope(scope: RefreshScope): void {
    saveRefreshScope(scope)
    this.notify()
  }

  /**
   * The records this device can renew: based on the configured refresh scope.
   * If scope is "allAccounts", includes apps signed by any saved account with a known team.
   * Otherwise, only the currently active account.
   */
  get refreshableApps(): InstalledRecord[] {
    // A record the device check found gone, or signed by another team, has no app for a new profile
    // to apply to: asking Apple for one would spend a request and change nothing.
    const present = this.installedApps.filter(record => refreshableOnDevice(record.deviceState))
    const scope = this.refreshScope
    if (scope === "allAccounts") {
      const saved = this.savedAccounts.map(a => a.toLowerCase())
      return present.filter(record => {
        const acc = record.account.trim().toLowerCase()
        const team = record.teamId.trim()
        if (acc.length > 0 && saved.includes(acc)) {
          return loadTeam(record.account) !== ""
        }
        return this.savedAccounts.some(account => loadTeam(account) === team)
      })
    }
    const teamId = loadTeam(this.savedAccount ?? "")
    if (teamId === "") return []
    return present.filter(record => record.teamId === teamId)
  }

  get isRefreshing(): boolean {
    return this.refreshing
  }

  get isCheckingDevice(): boolean {
    return this.checkingDevice
  }

  /** The cached App ID quota for the currently active Apple ID. */
  get appIdQuota(): AppIdQuota | null {
    const email = this.savedAccount
    if (email === null) return null
    return loadAppIdQuota(email)
  }

  /** Queries Apple Developer Portal for the active account's App ID quota and caches it. */
  async refreshAppIdQuota(): Promise<AppIdQuota | null> {
    const email = this.savedAccount
    if (email === null) return null
    const teamId = loadTeam(email)
    if (teamId === "") return null
    try {
      const bag = await fetchUrlBag(GSA_CLIENT_INFO, GSA_USER_AGENT)
      const client = await openSavedSession(email, this.sayFor, bag, provisioningFrom(bag))
      if (client === null) return null
      const listed = await client.listAppIds(teamId)
      const quota: AppIdQuota = {
        used: listed.appIds.length,
        total: listed.maxQuantity ?? 10,
        updatedAt: new Date().toISOString(),
      }
      saveAppIdQuota(email, quota)
      this.notify()
      return quota
    } catch {
      return null
    }
  }

  /** The number of apps installed under the active account (or all apps if none is active). */
  get activeAccountAppsCount(): number {
    const email = this.savedAccount
    if (email === null) return this.installedApps.length
    const teamId = loadTeam(email)
    const apps = this.installedApps.filter(record =>
      (record.account.length > 0 && record.account.toLowerCase() === email.toLowerCase()) ||
      (teamId !== "" && record.teamId === teamId),
    )
    return apps.length
  }

  /** The shortest remaining days among installed apps for the active account. */
  get minDaysLeft(): number | null {
    const email = this.savedAccount
    const teamId = email ? loadTeam(email) : ""
    const apps = this.installedApps.filter(record =>
      !email ||
      (record.account.length > 0 && record.account.toLowerCase() === email.toLowerCase()) ||
      (teamId !== "" && record.teamId === teamId),
    )
    if (apps.length === 0) return null
    let minDays: number | null = null
    for (const app of apps) {
      if (app.expiresAt === null) continue
      const expiry = new Date(app.expiresAt)
      if (Number.isNaN(expiry.getTime())) continue
      const diffDays = Math.ceil((expiry.getTime() - Date.now()) / (1000 * 60 * 60 * 24))
      if (minDays === null || diffDays < minDays) {
        minDays = diffDays
      }
    }
    return minDays
  }

  /** The run's per-app results, or the last run's until another starts. */
  get refreshJobs(): RefreshJob[] {
    return this.jobs
  }

  /**
   * Renews the profile of each app this account signed, one app at a time.
   *
   * `bundleIds` narrows the run to those apps. Stopping takes effect between apps: a profile install
   * is one request and is not interrupted. The summary is for a caller that cannot read the page — a
   * Shortcut runs it with `options.background`.
   */
  async refreshApps(bundleIds?: string[], options: RefreshOptions = {}): Promise<RefreshSummary> {
    const nothing = (key: TranslationKey): RefreshSummary => ({
      ok: false, total: 0, refreshed: 0, message: this.t(key),
    })
    if (this.refreshing || this.isRunning) {
      this.say("log.busy", undefined, "warn")
      return nothing("log.busy")
    }
    const refreshable = this.refreshableApps
    const targets = bundleIds === undefined
      ? refreshable
      : refreshable.filter(record => bundleIds.includes(record.identifier))
    if (targets.length === 0) {
      const email = this.savedAccount ?? ""
      const teamId = loadTeam(email)
      if (email === "" || teamId === "") {
        this.say("apps.refreshNoTeam", undefined, "warn")
        return nothing("apps.refreshNoTeam")
      }
      this.say("apps.nothingToRefresh", undefined, "warn")
      return nothing("apps.nothingToRefresh")
    }

    this.refreshing = true
    this.refreshStop = false
    this.jobs = targets.map(record => ({
      bundleId: record.identifier,
      name: record.name,
      state: "pending" as RefreshState,
      reason: "",
    }))
    this.notify()
    this.say("apps.refreshBegin", { count: this.jobs.length })

    // Every change to a job replaces it rather than filling the old one in: the page is handed the
    // list, and a list of the same objects with new fields inside reads as unchanged to it.
    const setJob = (index: number, patch: Partial<RefreshJob>) => {
      this.jobs = this.jobs.map((job, at) => (at === index ? { ...job, ...patch } : job))
      this.notify()
    }

    let done = 0
    let firstFailure: string | null = null
    try {
      // One session and one device link for the whole run: the portal is rate-limited, and a tunnel
      // allows four connections at a time.
      const bag = await fetchUrlBag(GSA_CLIENT_INFO, GSA_USER_AGENT)
      const address = options.background === true
        // Nobody is in front of the app to answer for a VPN, so a background run uses whatever is
        // already live and says so when nothing is.
        ? await liveReflectionAddress()
        : await reflectionForDevice(this.context())
      if (address.length === 0) throw new StepError("apps.reflectionNeeded")
      this.say("apps.address", { address })
      const device = await openDeviceLink({ address, onStep: message => this.sayRaw(message) })

      let currentAccount = ""
      let currentTeamId = ""
      let client: PortalClient | null = null
      let listedAppIds: AppId[] = []
      let listedCertificates: ListedCertificate[] = []

      try {
        for (const [index, job] of this.jobs.entries()) {
          if (this.refreshStop) break
          setJob(index, { state: "working" })
          this.say("apps.refreshing", { name: job.name })
          try {
            const target = targets[index]
            const targetAccount = target.account.trim() || this.savedAccount || ""
            const targetTeam = target.teamId.trim() || loadTeam(targetAccount)
            if (targetAccount === "" || targetTeam === "") {
              throw new StepError("apps.refreshNoTeam")
            }

            if (client === null || targetAccount.toLowerCase() !== currentAccount.toLowerCase()) {
              currentAccount = targetAccount
              currentTeamId = targetTeam
              client = await openSavedSession(targetAccount, this.sayFor, bag, provisioningFrom(bag))
              if (client === null) throw new StepError("identity.noSession", { email: targetAccount })
              this.say("apps.session", { email: targetAccount })
              const listed = await client.listAppIds(targetTeam)
              saveAppIdQuota(targetAccount, {
                used: listed.appIds.length,
                total: listed.maxQuantity ?? 10,
                updatedAt: new Date().toISOString(),
              })
              listedAppIds = listed.appIds
              this.say("apps.listing", { count: listedAppIds.length })

              // SideStore's verifyCertificate, once per account: the certificates Apple still
              // honours. A profile cut for one it does not installs and leaves a dead app, so the
              // reading is taken before any request is spent on one.
              listedCertificates = await client.listCertificates(currentTeamId)
              this.say("apps.certificates", { count: listedCertificates.length })
            }

            const profile = await this.renewProfile(
              target, listedAppIds, client, currentTeamId, device, listedCertificates)
            updateInstalledDates(job.bundleId, profile)
            // The certificate behind that profile is the one just used, so this reading is the good
            // one — a row that said REVOKED a moment ago says a countdown again. A record written
            // before the certificate was kept has nothing to re-read, so it stays unknown.
            if (target.certificateSerial !== null) updateCertificateStatus(job.bundleId, "valid")
            // The device now holds the profile this run installed, so a row that said the profile
            // differed does not any more. Whether the app itself is still there was not this run's
            // question; that answer stays as the last check left it.
            if (target.deviceState === "stale") {
              updateDeviceStates([{ identifier: job.bundleId, state: "ours" }])
            }
            setJob(index, { state: "done" })
            done++
            this.say("apps.refreshed", { name: job.name }, "ok")
          } catch (error) {
            const reason = this.describe(error)
            setJob(index, { state: "failed", reason })
            if (firstFailure === null) firstFailure = `${job.name}: ${reason}`
            this.say("apps.refreshFailed", { name: job.name, message: reason }, "error")
          }
        }
      } finally {
        await device.close()
      }
    } catch (error) {
      // Failing before the loop is the run's failure, not one app's.
      const reason = this.describe(error)
      if (firstFailure === null) firstFailure = reason
      this.jobs = this.jobs.map(job => job.state === "pending" ? { ...job, state: "failed", reason } : job)
      this.say("apps.refreshAborted", { message: reason }, "error")
    } finally {
      this.refreshing = false
      this.notify()
      setTimeout(() => {
        if (!this.refreshing) {
          this.jobs = []
          this.notify()
        }
      }, 1500)
    }

    this.say("apps.refreshDone", { done, total: this.jobs.length }, done === this.jobs.length ? "ok" : "warn")
    return { ok: done === this.jobs.length, total: this.jobs.length, refreshed: done, message: firstFailure }
  }

  /** Stops the run after the app being refreshed; a profile install is not interrupted. */
  cancelRefresh(): void {
    if (!this.refreshing) return
    this.refreshStop = true
    this.say("apps.stopping", undefined, "warn")
    this.notify()
  }

  /**
   * Asks the device what it really holds, once, because someone asked.
   *
   * This is the only thing on the Apps page that reads the device, and it is a person's decision —
   * the page itself never opens a link. What it answers is kept on the records, so from then on a
   * row that was re-signed elsewhere, or removed, says so instead of carrying a countdown.
   */
  async checkDeviceRecords(): Promise<DeviceCheckSummary> {
    const nothing = (key: TranslationKey): DeviceCheckSummary => ({
      ok: false, total: 0, ours: 0, missing: 0, foreign: 0, stale: 0, message: this.t(key),
    })
    if (this.checkingDevice || this.refreshing || this.isRunning) {
      this.say("log.busy", undefined, "warn")
      return nothing("log.busy")
    }
    const records = this.installedApps
    if (records.length === 0) return nothing("apps.empty")

    this.checkingDevice = true
    this.notify()
    this.say("apps.checkBegin", { count: records.length })
    try {
      const address = await reflectionForDevice(this.context())
      if (address.length === 0) throw new StepError("apps.checkNeedsDevice")
      this.say("apps.address", { address })
      const device = await openDeviceLink({ address, onStep: message => this.sayRaw(message) })
      let facts: DeviceFacts
      try {
        facts = await this.readDevice(device, records)
      } finally {
        await device.close()
      }

      const states = records.map(record => ({
        identifier: record.identifier,
        state: deviceStateOf(record, facts),
      }))
      updateDeviceStates(states)
      const count = (state: DeviceState) => states.filter(entry => entry.state === state).length
      const ours = count("ours")
      const missing = count("missing")
      const foreign = count("foreign")
      const stale = count("stale")
      this.say("apps.checkDone", { ours, missing, foreign, stale }, "ok")
      return { ok: true, total: states.length, ours, missing, foreign, stale, message: null }
    } catch (error) {
      const reason = this.describe(error)
      this.say("apps.checkFailed", { message: reason }, "error")
      return { ok: false, total: 0, ours: 0, missing: 0, foreign: 0, stale: 0, message: reason }
    } finally {
      this.checkingDevice = false
      this.notify()
    }
  }

  /**
   * The two device facts a record is checked against: what is installed, and which profiles the
   * device holds. One request each — a second call per record would ask for an answer already in
   * hand.
   */
  private async readDevice(device: DeviceLink, records: InstalledRecord[]): Promise<DeviceFacts> {
    const apps: DeviceApp[] = []
    const installer = await InstallationProxy.connect(
      await device.open(SERVICES.installationProxy), "installer")
    try {
      const listing = await installer.lookup()
      for (const record of records) {
        const info = listing[record.identifier]
        if (info === undefined) continue
        apps.push(deviceAppFrom(record.identifier, info))
      }
    } finally {
      await installer.disconnect()
    }

    const profiles: DeviceProfile[] = []
    const misagent = await MisagentClient.connect(await device.open(SERVICES.misagent), "misagent")
    try {
      for (const raw of await misagent.copyAll()) {
        // A profile this parser cannot read is not evidence about any record here.
        try {
          const parsed = parseProvisioningProfile(raw)
          const split = splitApplicationIdentifier(parsed.applicationIdentifier ?? "")
          if (split === null) continue
          profiles.push({ applicationIdentifier: split.applicationIdentifier, expirationDate: parsed.expirationDate })
        } catch {
          continue
        }
      }
    } finally {
      await misagent.disconnect()
    }
    return { apps, profiles }
  }

  /**
   * One app's refresh: cut a profile for its App ID again, and install it on the device.
   *
   * The app is not touched — its bundle, its signature and its data stay as they are. What changes is
   * the profile the device holds for that App ID, which is what its seven days are. The caller takes
   * the new expiry from the profile this returns.
   */
  private async renewProfile(
    record: InstalledRecord,
    appIds: AppId[],
    client: PortalClient,
    teamId: string,
    device: DeviceLink,
    certificates: ListedCertificate[],
  ): Promise<ProvisioningProfile> {
    // SideStore's two certificate steps, in one: a revoked or expired certificate leaves nothing a
    // new profile can fix, so the app is failed with the reason and the row is marked with it.
    const certificateStatus = statusOfRecord(record, certificates)
    if (certificateBlocksRefresh(certificateStatus)) {
      updateCertificateStatus(record.identifier, certificateStatus)
      throw new StepError(
        certificateStatus === "revoked" ? "apps.certificateRevoked" : "apps.certificateExpired",
        { name: record.name },
      )
    }

    let appId = appIds.find(candidate => candidate.identifier === record.identifier)
    if (appId === undefined) {
      // SideStore registers an App ID again rather than failing the refresh: the app is on the
      // device, so the ID it was signed as belongs on the account.
      appId = await client.addAppId(teamId, record.identifier, record.name)
      appIds.push(appId)
      this.say("apps.appIdAdded", { identifier: record.identifier })
    }

    // The App Group goes first, exactly as it did at install: a profile grants one only when the App
    // ID may hold it, and an app that keeps its data in a group will not launch without it.
    if (record.appGroup !== null) {
      const group = await client.ensureAppGroup(teamId, record.name, record.appGroup)
      const withGroup = await client.ensureAppGroupCapability(teamId, appId)
      await client.assignAppGroup(teamId, group, withGroup.appIdId)
    }

    const reply = await client.downloadTeamProvisioningProfile(teamId, appId.appIdId)
    const profile = parseProvisioningProfile(reply.encodedProfile)

    const misagent = await MisagentClient.connect(
      await device.open(SERVICES.misagent), `misagent: install ${record.identifier}`)
    try {
      await misagent.install(profile.raw)
    } finally {
      await misagent.disconnect()
    }
    return profile
  }

  // MARK: what a milestone's popup names

  /** The six digits the device is asking for while it pairs, or null when none is up. */
  get pairingCode(): string | null {
    const pin = (Storage.get<string>("pair.pin") ?? "").trim()
    return pin.length === 0 ? null : pin
  }

  /** The app the last successful install put on the device, or null when none has. */
  get installedApp(): { name: string, version: string } | null {
    const name = (Storage.get<string>("install.name") ?? "").trim()
    if (name.length === 0) return null
    return { name, version: (Storage.get<string>("install.version") ?? "").trim() }
  }

  /**
   * The certificate the last install left ready to hand over, or null when it left none.
   *
   * Only LiveContainer produces one: its own app group cannot be written from here, so the
   * certificate travels in a URL its scheme takes (`lib/livecontainer.ts`).
   */
  get certificatePush(): string | null {
    const url = (Storage.get<string>(CERTIFICATE_KEY) ?? "").trim()
    return url.length === 0 ? null : url
  }

  /** The URL the last push was for, and how it went. Kept so it is not reported as pending later. */
  private pushedURL: string | null = null
  private pushedSent = false

  /** Whether the certificate this install prepared has been handed over, and whether it took. */
  get certificatePushState(): "idle" | "sent" | "failed" {
    if (this.pushedURL === null || this.pushedURL !== this.certificatePush) return "idle"
    return this.pushedSent ? "sent" : "failed"
  }

  /**
   * Opens LiveContainer's own scheme with this account's certificate in it.
   *
   * LiveContainer keeps the certificate in its app group and signs the apps it runs with it; on
   * iOS 26 it runs none at all until it has one. It has to be trusted to open at all, which is the
   * step before this one.
   */
  async pushCertificate(): Promise<boolean> {
    const url = this.certificatePush
    if (url === null) return false
    let opened = false
    try {
      opened = await Safari.openURL(url)
    } catch {
      opened = false
    }
    this.pushedURL = url
    this.pushedSent = opened
    this.say(opened ? "install.certificateSent" : "install.certificateRefused", {}, opened ? "ok" : "warn")
    this.notify()
    return opened
  }

  /**
   * Whether this script holds a pairing record, whatever is or is not on disk.
   *
   * The record in `Storage` is what pairs and what gets exported — the file is written from it on
   * demand — so a pairing made before that file existed still counts.
   */
  get hasPairingRecord(): boolean {
    return new PairStore().hasRecord()
  }

  /** Imports a complete pairing record, replacing the host identity and device selection together. */
  async importPairingRecord(input: Bytes | string): Promise<void> {
    if (this.isRunning) throw new Error("Cannot import while installing")
    const { udid, name } = await new PairStore().importRecord(input)
    Storage.set("device.udid", udid)
    Storage.set("device.name", name)
    this.reset("pair")
    this.reset("install")
    this.notify()
  }

  /** Serialized record for file export or clipboard. Contains the host private key. */
  pairingExport(format: PairingExportFormat): Bytes | string | null {
    const file = new PairStore().load()
    if (file === null) return null
    return exportPairingRecord(file, (Storage.get<string>("device.udid") ?? "").trim(),
      (Storage.get<string>("device.name") ?? "").trim(), format)
  }

  /** The iPhone the last successful pairing was with, or null when none has paired. */
  get pairedDevice(): { name: string, udid: string } | null {
    const name = (Storage.get<string>("device.name") ?? "").trim()
    if (name.length === 0) return null
    return { name, udid: (Storage.get<string>("device.udid") ?? "").trim() }
  }

  /** The catalogue key a step failed with, when it failed with one. */
  failureKeyOf(id: StepId): TranslationKey | null {
    return this.failureKeys.get(id) ?? null
  }

  /** Ends a pairing that is still waiting for the device; see `stopWaitingForDevice`. */
  cancelPairing(): void {
    stopWaitingForDevice?.()
  }

  // MARK: mutation

  say(key: TranslationKey, params?: Record<string, string | number>, level: LogLevel = "info") {
    this.push(this.t(key, params), level)
  }

  /** For raw device output that is not a catalogue string. Still redacted. */
  sayRaw(text: string, level: LogLevel = "info") {
    this.push(text, level)
  }

  private push(text: string, level: LogLevel) {
    this.lines.push({ at: new Date(), level, text: redact(text) })
    // Keep memory bounded; the log is a debug console, not an archive.
    if (this.lines.length > 500) this.lines.splice(0, this.lines.length - 500)
    this.notify()
  }

  private setState(id: StepId, state: StepState, detail = "") {
    this.state.set(id, state)
    if (detail.length > 0) this.details.set(id, detail)
    this.notify()
  }

  reset(id: StepId) {
    this.details.delete(id)
    this.failureKeys.delete(id)
    this.setState(id, "pending")
  }

  clearLog() {
    this.lines.length = 0
    this.notify()
  }

  /** How many `runAll` loops are open, so a step outside one knows it is the whole run. */
  private batch = 0

  /**
   * The machine on this device is started on demand and released when the work that needed it is
   * over: it holds a WebView and a wasm engine, and starting it again costs about 150 ms. Nothing
   * is done when it was never started.
   */
  private releaseLocalAnisette(): void {
    if (this.batch > 0 || !localAnisetteIsRunning()) return
    stopLocalAnisette()
  }

  async runStep(id: StepId, forcePairing = false): Promise<void> {
    const step = this.steps.find(s => s.id === id)
    if (step === undefined) throw new Error(`unknown step ${id}`)
    if (this.isRunning) {
      this.say("log.busy", undefined, "warn")
      return
    }

    const ctx = this.context(forcePairing)

    if (step.run === undefined) {
      const reasonKey: TranslationKey = step.blockedKey ?? "state.blocked"
      this.setState(id, "blocked", this.t(reasonKey))
      this.say("log.stepBlocked", { title: this.titleOf(step), reason: this.t(reasonKey) }, "warn")
      return
    }

    this.setState(id, "running", "")
    this.failureKeys.delete(id)
    this.say("log.stepBegin", { title: this.titleOf(step) })
    const t0 = Date.now()
    try {
      await step.run(ctx)
      const seconds = ((Date.now() - t0) / 1000).toFixed(1)
      this.setState(id, "done", this.t("log.stepFinishedIn", { title: this.titleOf(step), seconds }))
      this.say("log.stepDone", { title: this.titleOf(step) }, "ok")
    } catch (e) {
      if (e instanceof StepError) this.failureKeys.set(id, e.key)
      const detail = this.describe(e)
      this.setState(id, "failed", detail)
      this.say("log.stepFailed", { title: this.titleOf(step), message: detail }, "error")
    } finally {
      this.releaseLocalAnisette()
    }
  }

  /** What a step runs with; an account switch signs in through the same context. */
  private context(forcePairing = false): EngineContext {
    return {
      forcePairing,
      say: (key, params, level) => this.say(key, params, level),
      sayRaw: (text, level) => this.sayRaw(text, level),
      t: this.t,
      directory: this.directory,
      surface: this.surface,
      build: this.installSource === "import"
        ? { source: "import", ipa: this.importedIpa }
        : { source: this.installSource, channel: this.releaseChannel, version: this.selectedVersion },
    }
  }

  /** An error as the log shows it: a step's key translated, anything else its own message. */
  private describe(error: unknown): string {
    if (error instanceof StepError) return this.t(error.key, error.params)
    return error instanceof Error ? error.message : String(error)
  }

  /**
   * `say` as a value, for the calls that take one.
   *
   * A detached method loses `this`, and with it the translator: passing `this.say` into a helper
   * that calls it as a plain function fails on the first line it logs.
   */
  private get sayFor(): EngineContext["say"] {
    return (key, params, level) => this.say(key, params, level)
  }

  /** Runs every gate in order, stopping at the first failure or unavailable gate. */
  async runAll(): Promise<void> {
    this.batch += 1
    try {
      for (const step of this.steps) {
        if (this.stateOf(step.id) === "done") {
          this.say("log.skipDone", { title: this.titleOf(step) })
          continue
        }
        await this.runStep(step.id)
        const after = this.stateOf(step.id)
        if (after === "failed" || after === "blocked") {
          this.say("log.stoppedAt", { title: this.titleOf(step) })
          return
        }
      }
      this.say("log.allDone", undefined, "ok")
    } finally {
      this.batch -= 1
      this.releaseLocalAnisette()
    }
  }
}

// MARK: - prompts

/** One line of text from the user. `null` means they cancelled. */
async function ask(
  ctx: EngineContext,
  titleKey: TranslationKey,
  defaultValue: string,
  obscure: boolean,
): Promise<string | null> {
  const result = await (globalThis as any).Dialog.prompt({
    title: ctx.t(titleKey),
    defaultValue,
    obscureText: obscure,
    selectAll: true,
  })
  return result === undefined ? null : result
}

/**
 * A choice between named options. Index, or `null` when the sheet was dismissed.
 *
 * Reached through `globalThis` for the same reason `ask` is: at runtime `Dialog` is a global, and
 * a test can put a person in its place to see what the sheet was asked to offer.
 */
async function choose(
  title: string, message: string, actions: { label: string, destructive?: boolean }[],
): Promise<number | null> {
  const result = await (globalThis as any).Dialog.actionSheet({ title, message, actions })
  return typeof result === "number" ? result : null
}

/** Yes or no for something that cannot be undone. */
async function confirm(title: string, message: string, confirmLabel: string): Promise<boolean> {
  return (await (globalThis as any).Dialog.confirm({ title, message, confirmLabel })) === true
}

// MARK: - anisette

/** The community list, fetched once per run: the live one, or the snapshot when it can't be. */
let anisetteServerList: AnisetteServerEntry[] | null = null

async function loadAnisetteServers(ctx: { say: EngineContext["say"] }): Promise<AnisetteServerEntry[]> {
  if (anisetteServerList !== null) return anisetteServerList
  const { servers, live } = await fetchAnisetteServers()
  anisetteServerList = servers
  ctx.say(live ? "signin.anisetteList" : "signin.anisetteListFallback", { count: servers.length }, live ? undefined : "warn")
  return servers
}

/**
 * The server on this device, started on first use. It goes first in the candidate order: it is
 * the only one that cannot be somebody else's to take down, and the machine it runs is the one
 * the working desktop tool provisions with. A failure here is not fatal — the list behind it is.
 */
async function localAnisetteFirst(ctx: { say: EngineContext["say"] }): Promise<string[]> {
  if (localAnisetteIsRunning()) return [localAnisetteUrl()]
  try {
    const url = await startLocalAnisette()
    return [url]
  } catch (error) {
    ctx.say("signin.anisetteLocalFailed", { message: error instanceof Error ? error.message : String(error) }, "warn")
    return []
  }
}

/** Connect to one anisette server, and bring up an identity it accepts. */
async function connectAnisette(
  ctx: { say: EngineContext["say"] },
  bag: Record<string, string>,
  provisioning: ProvisioningUrls,
  url: string,
): Promise<AnisetteServer> {
  ctx.say("signin.connectingAnisette", { server: url })
  const server = await AnisetteServer.connect(url)
  await selectIdentity(server, provisioning, new GrandSlam(bag, server).postPlist)
  return server
}

/**
 * Bring up an anisette server with a usable identity, preferring the one a saved token
 * belongs to. `selectIdentity` does the interesting part: it reloads a remembered identity
 * for that server, reuses one that still works, or provisions a fresh one.
 *
 * The order is the app's (`AnisetteServer.candidates`): the pick, the rest of its ADI library,
 * then the Windows servers, then the Android ones — the macOS servers last, since Apple asked an
 * account with trusted devices for a code by text through them and then refused to send one.
 */
async function bringUpAnisette(
  ctx: { say: EngineContext["say"] },
  bag: Record<string, string>,
  provisioning: ProvisioningUrls,
  preferred: string,
): Promise<AnisetteServer> {
  const servers = await loadAnisetteServers(ctx)
  // A saved token belongs to the machine it was issued to, so a call that names a server keeps
  // that server first; the local machine only has to be running if it is the one named.
  if (isLocalAnisette(preferred)) {
    try {
      await startLocalAnisette()
    } catch (error) {
      ctx.say("signin.anisetteLocalFailed", { message: error instanceof Error ? error.message : String(error) }, "warn")
    }
  }
  const candidates = anisetteCandidates(preferred, servers)
  let lastError = ""

  for (const url of candidates) {
    try {
      return await connectAnisette(ctx, bag, provisioning, url)
    } catch (error) {
      lastError = error instanceof Error ? error.message : String(error)
      ctx.say("signin.anisetteFailed", { server: url, message: lastError }, "warn")
    }
  }
  throw new StepError("signin.noAnisette", { message: lastError })
}

// MARK: - what a failed attempt means

/**
 * Apple's rate limit (HTTP 429). Switching anisette servers doesn't avoid it, and every attempt
 * can extend the wait, so the sign-in stops.
 */
function isAppleRateLimit(error: unknown): boolean {
  if (error instanceof AppleHttpError && error.status === 429) return true
  const message = textOf(error).toLowerCase()
  return message.includes("apple.com") && message.includes("429 too many requests")
}

/** GrandSlam -20209: Apple locked the account until it is reset at iForgot. */
function isAccountLocked(error: unknown): boolean {
  if (error instanceof GrandSlamError && error.code === -20209) return true
  const message = textOf(error).toLowerCase()
  return message.includes("-20209") || message.includes("locked for security reasons") || message.includes("iforgot")
}

/** Apple developer error 1102: the account's owner is too young for developer services. */
function isUnderageError(error: unknown): boolean {
  if (error instanceof PortalError && error.code === 1102) return true
  const message = textOf(error).toLowerCase()
  return message.includes("developer error 1102") || message.includes("error 1102")
}

/** Apple developer error 2160: the account's email address isn't verified yet. */
function isEmailUnverifiedError(error: unknown): boolean {
  if (error instanceof PortalError && error.code === 2160) return true
  const message = textOf(error).toLowerCase()
  return message.includes("developer error 2160") || message.includes("error 2160")
}

/** Attempts in a row that never reached Apple before the sign-in gives up on the servers. */
const APPLE_UNREACHABLE_LIMIT = 2

/**
 * An attempt that never reached Apple: no HTTP status and no GrandSlam code came back, so the
 * request could not be sent at all. Every anisette server starts with the same request to Apple's
 * sign-in server, so more of them would fail the same way.
 */
function isAppleUnreachable(error: unknown): boolean {
  if (error instanceof AppleHttpError || error instanceof GrandSlamError || error instanceof StepError) return false
  if (error instanceof AnisetteNotProvisionedError) return false
  return true
}

function textOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

// MARK: - the saved session, and the portal it opens

/** The two anisette provisioning endpoints, which live in the URL bag. */
export function provisioningFrom(bag: Record<string, string>): ProvisioningUrls {
  const start = bag["midStartProvisioning"]
  const finish = bag["midFinishProvisioning"]
  if (start === undefined || finish === undefined) {
    throw new Error("the URL bag carried no anisette provisioning endpoints")
  }
  return { midStartProvisioning: start, midFinishProvisioning: finish }
}

/**
 * The portal client for a saved session, or null when the account has none that is still usable.
 *
 * Sign-in uses this to skip the password; a probe uses it to reach the portal without one. Both
 * matter: the token belongs to the anisette identity it was issued for, so the same server has to
 * be brought back up before the token means anything. Throws the same way sign-in would — a stale
 * session and an unreachable anisette server are both the caller's to decide about.
 */
export async function openSavedSession(
  email: string,
  say: EngineContext["say"],
  bag: Record<string, string>,
  provisioning: ProvisioningUrls,
): Promise<PortalClient | null> {
  const saved = loadSession(email)
  if (saved === null || !isSessionUsable(saved)) return null
  const anisette = await bringUpAnisette({ say }, bag, provisioning, saved.anisette.server)
  return new PortalClient(anisette, saved.token, saved.adsid)
}

// MARK: - the identity's two questions

/**
 * Which team signs the app.
 *
 * A free Apple ID is on one team, so the question is usually not worth asking; an account that
 * belongs to a real team has several, and which of them signs is the account holder's to say.
 */
export async function chooseTeam(t: Translate, teams: Team[]): Promise<Team> {
  if (teams.length === 0) throw new StepError("identity.noTeams")
  if (teams.length === 1) return teams[0]

  const index = await choose(
    t("identity.team.title"), t("identity.team.message"),
    teams.map(team => ({ label: `${team.name} — ${team.teamId}` })),
  )
  const team = index === null ? undefined : teams[index]
  if (team === undefined) throw new StepError("identity.teamCancelled")
  return team
}

/** How a certificate reads in a list: what it is called, and the serial that identifies it. */
function certificateLabel(certificate: DeveloperCertificate): string {
  const name = certificate.name.length > 0 ? certificate.name : certificate.machineName ?? "unnamed"
  return certificate.serialNumber === null ? name : `${name} — ${certificate.serialNumber}`
}

/**
 * Which certificate to give up when Apple says the account is full (7460).
 *
 * Revoking one stops every app already signed with it from launching — including apps this project
 * never signed — so it is chosen from a list, then confirmed, and anything short of a clear yes
 * leaves the certificates alone. `null` means "revoke nothing", which ends the step instead of
 * spending another attempt.
 */
export async function askWhichCertificateToRevoke(
  t: Translate, certificates: DeveloperCertificate[],
): Promise<string | null> {
  const revocable = certificates.filter(certificate => certificate.serialNumber !== null)
  if (revocable.length === 0) return null

  const index = await choose(
    t("identity.revoke.title"), t("identity.revoke.message"),
    revocable.map(certificate => ({ label: certificateLabel(certificate), destructive: true })),
  )
  const chosen = index === null ? undefined : revocable[index]
  if (chosen === undefined || chosen.serialNumber === null) return null

  const sure = await confirm(
    t("identity.revoke.title"),
    t("identity.revoke.confirm", { name: certificateLabel(chosen) }),
    t("identity.revoke.button"),
  )
  return sure ? chosen.serialNumber : null
}

// MARK: - entitlements

/**
 * The differences between what a profile grants and what a signature claims, one line each.
 *
 * A device refusing a signature with `0xe8008016` ("the executable was signed with invalid
 * entitlements") is saying the claims are not authorized by the profile. Both dictionaries have to be
 * in the log to read that, and this is the part of it worth asserting on: the comparison, not the
 * printing.
 */
export function entitlementDifferences(
  granted: Record<string, unknown>,
  claimed: Record<string, unknown>,
): string[] {
  const lines: string[] = []
  for (const key of Object.keys(claimed).sort()) {
    if (!(key in granted)) lines.push(`${key}: claimed but not granted`)
    else if (showEntitlement(granted[key]) !== showEntitlement(claimed[key])) {
      lines.push(`${key}: granted ${showEntitlement(granted[key])} but claimed ${showEntitlement(claimed[key])}`)
    }
  }
  for (const key of Object.keys(granted).sort()) {
    if (!(key in claimed)) lines.push(`${key}: granted and not claimed`)
  }
  return lines
}

/** A value as one short line: entitlements are strings, booleans and short arrays of strings. */
function showEntitlement(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(entry => showEntitlement(entry)).join(", ")}]`
  return typeof value === "string" ? value : JSON.stringify(value) ?? String(value)
}

/** Whether two byte strings are the same length and contents. */
function sameBytes(left: Bytes, right: Bytes): boolean {
  if (left.length !== right.length) return false
  for (let index = 0; index < left.length; index++) {
    if (left[index] !== right[index]) return false
  }
  return true
}

/**
 * Prints the profile's entitlements next to the ones a bundle is signed with.
 *
 * Both sides go to the log because an install that fails verification reports only that it did: the
 * dictionary is the one fact a person (or the next run) needs and cannot get afterwards.
 */
function reportEntitlements(
  ctx: EngineContext,
  profile: ProvisioningProfile,
  identifier: string,
): void {
  const granted = profile.entitlements
  const claimed = entitlementsFor(profile, identifier)
  const show = (dict: Record<string, unknown>) =>
    JSON.stringify(Object.keys(dict).sort().map(key => [key, showEntitlement(dict[key])]))

  // The identity fields too: the device also refuses a signature whose identifier is not the one the
  // profile names, and "which App ID did the profile come back for" is the first thing to check when
  // the two dictionaries agree.
  ctx.sayRaw(`profile identity: ${JSON.stringify({
    applicationIdentifier: profile.applicationIdentifier,
    identifierPrefix: profile.identifierPrefix,
    teamIdentifier: profile.teamIdentifier,
    uuid: profile.uuid,
    expires: profile.expirationDate?.toISOString() ?? null,
    provisionedDevices: profile.provisionedDevices === null ? null : profile.provisionedDevices.length,
  })}`)
  ctx.sayRaw(`signing as: ${identifier}`)
  ctx.sayRaw(`profile grants ${Object.keys(granted).length}: ${show(granted)}`)
  ctx.sayRaw(`signature claims ${Object.keys(claimed).length}: ${show(claimed)}`)

  const differences = entitlementDifferences(granted, claimed)
  if (differences.length === 0) {
    ctx.say("install.entitlementsAgree", undefined, "ok")
    return
  }
  ctx.say("install.entitlementsDiffer", { count: differences.length }, "warn")
  for (const line of differences) ctx.sayRaw(`  ${line}`, "warn")
}

// MARK: - the reflection

/** The reflected IPv4 alias in a `localDevVPN` state, or "" when there is not one. */
function reflectedAddressOf(state: any): string {
  const pool: string[] = state?.effectiveAddresses?.length
    ? state.effectiveAddresses
    : state?.resolvedAddresses?.length ? state.resolvedAddresses : state?.addresses ?? []
  const v4 = pool.find(address => /^\d+\.\d+\.\d+\.\d+$/.test(address))
  return state?.effectiveStatus === "active" && v4 !== undefined ? v4 : ""
}

/**
 * The self tunnel's state. Its concurrency control refuses a read that raced a change with "read
 * again before saving" — which is literally what one retry does.
 */
async function readLocalDevState(): Promise<any> {
  const vpn: any = (globalThis as any).VPN
  try {
    return await vpn.localDevVPN.getState()
  } catch {
    await new Promise<void>(resolve => { setTimeout(() => resolve(), 600) })
    return vpn.localDevVPN.getState()
  }
}

/** For the places where the state is only worth a log line: no state, no failure. */
async function tryReadLocalDevState(): Promise<any | null> {
  try {
    return await readLocalDevState()
  } catch {
    return null
  }
}

/**
 * Switches the LocalDevVPN intent on, which is one of the two things `openRSDTunnel` asks for (the
 * other is the reflection). It is a switch, not a VPN: it takes no VPN slot from anyone.
 */
async function switchOnIntent(vpn: any, expectedState: unknown): Promise<void> {
  await vpn.localDevVPN.setEnabled(true, { expectedState })
}

/** The same switch where a refusal is not what is wrong — the proxy mode. */
async function trySwitchOnIntent(vpn: any, ctx: EngineContext, expectedState: unknown): Promise<void> {
  try {
    await switchOnIntent(vpn, expectedState)
    ctx.say("reflection.intentOn")
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    ctx.say("reflection.intentFailed", { message }, "warn")
  }
}

/**
 * Waits for an active reflected IPv4 alias and returns it, or null if none comes up.
 *
 * Shared, because the reflection is not something the first gate can settle for the whole run. An
 * owned VPN can be gone by the time the install step dials it — the run that found this is the one
 * where the first gate started the VPN itself: pairing in Settings then worked (it goes over the LAN)
 * and `remoted` at the reflection refused the connection a minute later.
 *
 * `intervalMs` is a parameter so a test can watch the waiting without waiting for it.
 */
async function awaitReflection(ctx: EngineContext, intervalMs = 1500): Promise<string | null> {
  for (let i = 0; i < 20; i++) {
    const state = await readLocalDevState()
    const address = reflectedAddressOf(state)
    if (address.length > 0) {
      // The gates after this one need the address: the tunnel and remoted are reached at the
      // reflection, not at the loopback alias.
      Storage.set("reflection.address", address)
      ctx.say("reflection.activeAt", { address }, "ok")
      return address
    }
    ctx.say("reflection.waiting", { status: state?.effectiveStatus })
    await new Promise<void>(resolve => { setTimeout(() => resolve(), intervalMs) })
  }
  return null
}

/**
 * The address the device is reachable at right now, without bringing anything up.
 *
 * A run started by a Shortcut has nobody in front of the app to answer for a VPN, so it uses this:
 * whatever is live is used, and an empty answer means the run fails with a message instead of
 * starting a tunnel behind a shortcut.
 */
export async function liveReflectionAddress(): Promise<string> {
  const connection = loadConnectionSettings()
  if (connection.source === "proxyApp") return connection.host
  const local = await readLocalDevState()
  return local === null ? "" : reflectedAddressOf(local)
}

/**
 * The address the device is reached at, brought back up if it has gone.
 *
 * Called by the install step, which is a download and a signature away from the gate that set the
 * reflection up, with the app in the background for the pairing in between. Dialling into an address
 * nothing answers at and reporting "Connection refused" says nothing about why, and the reflection is
 * the cheapest thing to check first. With a proxy tool the address is simply the one the setting
 * names — its reflection is not this app's to read.
 */
export async function reflectionForDevice(ctx: EngineContext, intervalMs = 1500): Promise<string> {
  const vpn: any = (globalThis as any).VPN
  if (vpn === undefined) throw new StepError("reflection.noApi")

  // With a proxy tool there is nothing for us to bring up: the tool owns the one VPN slot iOS
  // allows, and the address is the one it reflects, which is why it is written down.
  const connection = loadConnectionSettings()
  if (connection.source === "proxyApp") return connection.host

  const local = await readLocalDevState()
  const live = reflectedAddressOf(local)
  if (live.length > 0) return live

  const remembered = (Storage.get<string>("reflection.address") ?? "").trim()
  ctx.say("install.reflectionGone", { status: local?.effectiveStatus ?? "unknown", address: remembered }, "warn")

  const before = await vpn.getState()
  if (!before.active) {
    const started = await vpn.start()
    ctx.say("reflection.vpnStarted", { status: started.status })
  }
  if (!local?.enabled) {
    await switchOnIntent(vpn, local?.expectedState)
    ctx.say("reflection.intentOn")
  }

  const back = await awaitReflection(ctx, intervalMs)
  if (back !== null) return back

  // Still nothing: name what was tried rather than the bare address that failed.
  throw new StepError("install.noReflection")
}

// MARK: - what the link looks like now

/**
 * The device link as a surface that has to name it can see it.
 *
 * `noService` is the one worth keeping apart from `off`: the packets came back but nothing was
 * listening, which is the reflection working and the device's remote-pairing port not.
 */
export type ReflectionState = "active" | "noService" | "off" | "unknown"

/** How long the address may take to answer before it counts as not answering. */
const PROBE_TIMEOUT_MS = 1500

/**
 * What a probe's outcome means. A refusal is the reflection working with nothing listening at that
 * port; anything else (a timeout, no route) is the packets not coming back at all.
 */
export function reflectionStateOf(probe: TcpProbe): ReflectionState {
  if (probe.open) return "active"
  return probe.code === "ECONNREFUSED" ? "noService" : "off"
}

/**
 * Whether the device is reachable right now, and if not, how far the traffic got.
 *
 * The address is the one a run would dial: the setting with a proxy tool, and the alias the built-in
 * tunnel reports otherwise. `port` is a seam for tests; it is `REMOTED_PORT` everywhere else.
 */
export async function reflectionState(port = REMOTED_PORT): Promise<ReflectionState> {
  const connection = loadConnectionSettings()
  let address = connection.host

  if (connection.source === "builtIn") {
    const vpn: any = (globalThis as any).VPN
    if (vpn === undefined) return "unknown"
    const local = await tryReadLocalDevState()
    if (local === null) return "unknown"
    // No alias means this app's own tunnel is down, which is the answer on its own.
    const live = reflectedAddressOf(local)
    if (live.length === 0) return "off"
    address = live
  }

  return reflectionStateOf(await probeTcp(address, port, PROBE_TIMEOUT_MS))
}

/**
 * Whether the system path runs over Wi-Fi right now. Null when the system will not say.
 *
 * The device's pairing listener binds to the Wi-Fi interface, so this is the one fact that turns a
 * refused probe into something a person can act on. It is not a switch reading: a Wi-Fi that is on
 * but joined to nothing may still report no Wi-Fi path.
 */
export async function wifiPresent(): Promise<boolean | null> {
  const device: any = (globalThis as any).Device
  if (device === undefined || typeof device.getNetworkState !== "function") return null
  try {
    const state = await device.getNetworkState()
    const interfaces: unknown[] = Array.isArray(state?.interfaces) ? state.interfaces : []
    return interfaces.includes("wifi")
  } catch {
    return null
  }
}

export interface ReflectionSnapshot {
  state: ReflectionState
  /** Null when the system will not say. */
  wifi: boolean | null
}

/** The link's state with the one context that explains a refusal. */
export async function reflectionSnapshot(port = REMOTED_PORT): Promise<ReflectionSnapshot> {
  const [state, wifi] = await Promise.all([reflectionState(port), wifiPresent()])
  return { state, wifi }
}

// MARK: - the gates

/**
 * The reflection must be up before anything can reach the device, so it is the first gate:
 * `openRSDTunnel` documents an active reflected IPv4 alias as a precondition. Which VPN provides the
 * reflection is the one setting this gate reads — see `lib/connection`.
 */
export const reflectionStep: StepDefinition = {
  id: "reflection",
  titleKey: "step.reflection.title",
  summaryKey: "step.reflection.summary",
  run: async ctx => {
    const VPN_ANY: any = (globalThis as any).VPN
    if (VPN_ANY === undefined) throw new StepError("reflection.noApi")

    const granted = await Script.requestAccess(["vpn", "localDevVPN"] as any)
    const missing = ["vpn", "localDevVPN"].filter(id => !granted.includes(id as any))
    if (missing.length > 0) throw new StepError("reflection.permission", { list: missing.join(", ") })

    const connection = loadConnectionSettings()
    if (connection.source === "proxyApp") {
      // Nothing here may touch a VPN: the proxy tool holds the one iOS allows. The state below is
      // read for a warning and for the switch, and neither is worth failing the gate over.
      const state = await tryReadLocalDevState()
      if (state?.vpnStatus === "connected") ctx.say("reflection.ownVpnUp", undefined, "warn")
      if (state && !state.enabled) await trySwitchOnIntent(VPN_ANY, ctx, state.expectedState)
      ctx.say("reflection.proxyAt", { host: connection.host })
      return
    }

    const before = await VPN_ANY.getState()
    ctx.say("reflection.vpnWas", { status: before.status })
    if (!before.active) {
      const state = await VPN_ANY.start()
      ctx.say("reflection.vpnStarted", { status: state.status })
    }

    const local = await readLocalDevState()
    if (!local.enabled) {
      await switchOnIntent(VPN_ANY, local.expectedState)
      ctx.say("reflection.intentOn")
    }

    // The intent is not the same as the reflection being up; poll for the real thing.
    const address = await awaitReflection(ctx)
    if (address === null) throw new StepError("reflection.failed")
  },
}

export const signinStep: StepDefinition = {
  id: "signin",
  titleKey: "step.signin.title",
  summaryKey: "step.signin.summary",
  run: async ctx => {
    // The account in use, or — on a first run — the one asked for here. A second Apple ID is
    // added in Settings, which is also where the account in use is chosen.
    await signInAs(ctx, activeAccount() ?? await askForAccount(ctx))
  },
}

/** The Apple ID of a first run: asked for once, since everything else is keyed by the address. */
async function askForAccount(ctx: EngineContext): Promise<string> {
  const typed = await ask(ctx, "signin.email.title", "", false)
  const email = (typed ?? "").trim()
  if (email === "") throw new StepError("signin.cancelled")
  return email
}

/**
 * Signs in as `email`: its saved session when that is still good, Apple's password and second
 * factor when it is not. `email` is made the account in use at the end, so an address that never
 * signed in is not left as one.
 *
 * A gate runs this for the account in use; the account picker in Settings runs it for the account
 * being switched to, and a failure there leaves the store exactly as it was.
 */
async function signInAs(ctx: EngineContext, email: string): Promise<void> {
  // The URL bag is needed either way: it also carries the anisette provisioning endpoints. It is
  // the sign-in's first request to Apple and doesn't go through a server, so when it can't be
  // sent at all, no anisette server would help (`isAppleUnreachable`).
  let bag: Record<string, string>
  try {
    bag = await fetchUrlBag(GSA_CLIENT_INFO, GSA_USER_AGENT)
  } catch (error) {
    if (!isAppleUnreachable(error)) throw error
    throw new StepError("signin.unreachable")
  }
  const start = bag["midStartProvisioning"]
  const finish = bag["midFinishProvisioning"]
  if (start === undefined || finish === undefined) throw new StepError("signin.noProvisioning")
  const provisioning: ProvisioningUrls = { midStartProvisioning: start, midFinishProvisioning: finish }

  /**
   * Uses the stored session for `email`, if there is one that is still good.
   *
   * Nothing is asked here on purpose: the token, the address it belongs to and the anisette
   * identity it was issued to are all already stored, so a sign-in that is still valid is not a
   * question. The token belongs to that identity, so `bringUpAnisette` has to bring the same one
   * back — if its slot is gone the call fails, the session is reported as stale, and the caller
   * falls through to a full sign-in rather than guessing.
   */
  const reuseSession = async (email: string): Promise<boolean> => {
    const saved = loadSession(email)
    if (saved === null || !isSessionUsable(saved)) return false
    ctx.say("signin.reusing", { email })
    try {
      const client = await openSavedSession(email, ctx.say, bag, provisioning)
      if (client === null) return false
      const teams = await client.listTeams()
      ctx.say("signin.verified", { teams: teams.length }, "ok")
      return true
    } catch (error) {
      ctx.say("signin.staleSession", { message: error instanceof Error ? error.message : String(error) }, "warn")
      // 1100, or an HTTP 401, is Apple having forgotten the token: drop it, or every later run
      // pays for the same refusal. 1102 and 2160 are the account refusing outright, which
      // signing in again cannot change either — so that session is kept.
      if (verdictFor(error) === "expired") clearSession(email)
      return false
    }
  }

  // 1. The saved session: the token, the address it belongs to and the anisette identity it was
  // issued to are all stored, so a sign-in that is still good is not a question.
  if (await reuseSession(email)) {
    rememberAccount(email)
    return
  }

  // 2. Full sign-in. The password lives in this one binding and is cleared before we return
  // — including when something throws.
  let password = await ask(ctx, "signin.password.title", "", true)
  if (password === null) throw new StepError("signin.cancelled")

  try {
    const servers = await loadAnisetteServers(ctx)
    const candidates = [...await localAnisetteFirst(ctx), ...anisetteCandidates(loadSession(email)?.anisette.server ?? savedAnisettePick(), servers)]
    const refusals = new AppleRefusals(servers)
    const askCode = async (): Promise<string> => {
      const code = await ask(ctx, "signin.code.title", "", false)
      if (code === null) throw new StepError("signin.cancelled")
      return code.trim()
    }

    // One anisette server at a time: Apple's HTTP 503 refusals go by the device sign-in reports
    // rather than by the server, so a server reporting the other one is still worth trying after
    // two of those (`AppleRefusals`). An attempt that never reached Apple is counted too: one is a
    // blip, two in a row mean something on this phone is blocking it.
    let anisette: AnisetteServer | null = null
    let token: AppToken | null = null
    let lastAnisetteError = ""
    let lastSignInError: unknown = null
    let unreachable = 0

    for (const [index, url] of candidates.entries()) {
      if (refusals.rulesOut(url)) continue

      let server: AnisetteServer
      try {
        server = await connectAnisette(ctx, bag, provisioning, url)
      } catch (error) {
        lastAnisetteError = textOf(error)
        ctx.say("signin.anisetteFailed", { server: url, message: lastAnisetteError }, "warn")
        continue
      }

      ctx.say("signin.signingIn")
      // The identity in use is picked once more when the server refuses it as not provisioned with
      // it (-45061): that one is left out and the same server is asked again with another stored
      // identity, or with a new one — how a server that moved to another ADI library is followed.
      for (let pick = 1; ; pick++) {
        try {
          // The 2FA prompt takes no text: Apple's own prompt wording would have gone in the
          // dialog's small print, and the title is what the person is reading anyway.
          token = await signInForDeveloperToken(email, password, askCode, server, bag)
          anisette = server
          break
        } catch (error) {
          // A cancelled prompt is not the server's fault.
          if (error instanceof StepError) throw error
          if (error instanceof AnisetteNotProvisionedError && pick === 1) {
            ctx.say("signin.anisetteRepick", { server: url }, "warn")
            await selectIdentity(server, provisioning, new GrandSlam(bag, server).postPlist, undefined, true)
            continue
          }
          // What Apple says about the account itself is the same through every server, so the
          // sign-in stops on it rather than spending the rest of the list.
          if (isAccountLocked(error)) throw new StepError("signin.locked")
          if (isUnderageError(error)) throw new StepError("signin.underage")
          if (isEmailUnverifiedError(error)) throw new StepError("signin.emailUnverified")
          if (error instanceof GrandSlamError && isCredentialRejection(error.code)) {
            throw new StepError("signin.rejected", { message: error.message })
          }
          lastSignInError = error
          ctx.say("signin.anisetteFailed", { server: url }, "warn")
          if (isAppleRateLimit(error)) throw new StepError("signin.rateLimited")
          if (error instanceof AppleHttpError && error.status === 503) {
            refusals.record(url)
            if (refusals.endsSignIn(candidates.slice(index + 1))) {
              throw new StepError("signin.appleRefused", { message: error.message })
            }
          }
          unreachable = isAppleUnreachable(error) ? unreachable + 1 : 0
          if (unreachable >= APPLE_UNREACHABLE_LIMIT) throw new StepError("signin.unreachable")
          break
        }
      }
      if (token !== null) break
    }

    // Nothing got through: Apple's edge turning the client away is what stopped this unless a
    // server was the last word for another reason, and with no server answering at all there
    // was no identity to sign in with.
    if (anisette === null || token === null) {
      if (lastSignInError instanceof AppleHttpError && lastSignInError.status === 503) {
        throw new StepError("signin.appleRefused", { message: lastSignInError.message })
      }
      if (lastSignInError !== null) throw lastSignInError
      throw new StepError("signin.noAnisette", { message: lastAnisetteError })
    }

    const secondsLeft = Math.max(0, token.expiresAt - Math.floor(Date.now() / 1000))
    ctx.say("signin.gotToken", { seconds: secondsLeft }, "ok")
    // The server that worked is the one later sign-ins start with (`AnisetteServer.candidates`).
    saveAnisettePick(anisette.url)

    // Prove the token works before storing it: listTeams is the cheapest authenticated call and
    // it separates "token works" from "token expired" cleanly.
    const identity = { server: anisette.url, identityKey: anisette.slotKey }
    const teams = await new PortalClient(anisette, token.token, token.adsid).listTeams()
    if (teams.length === 0) ctx.say("signin.noTeams", undefined, "warn")
    else ctx.say("signin.verified", { teams: teams.length }, "ok")

    saveSession(email, token, identity)
    rememberAccount(email)
    ctx.say("signin.saved", undefined, "ok")
  } finally {
    password = ""
  }
}

export const identityStep: StepDefinition = {
  id: "identity",
  titleKey: "step.identity.title",
  summaryKey: "step.identity.summary",
  run: async ctx => {
    // The account, not the password: this gate rides the session sign-in left behind, and it runs
    // before pairing because nothing here touches the device.
    const email = activeAccount() ?? ""
    if (email === "") throw new StepError("identity.noAccount")

    const bag = await fetchUrlBag(GSA_CLIENT_INFO, GSA_USER_AGENT)
    const client = await openSavedSession(email, ctx.say, bag, provisioningFrom(bag))
    if (client === null) throw new StepError("identity.noSession", { email })

    const team = await chooseTeam(ctx.t, await client.listTeams())
    ctx.say("identity.team", { name: team.name, teamId: team.teamId })

    // One key per Apple ID, made once. A key generated where one already existed orphans every
    // certificate the account holds, so which of the two happened is said out loud.
    const { key, created } = await loadOrCreateSigningKey(email)
    ctx.say(created ? "identity.keyCreated" : "identity.keyReused", { email })

    const identity = await ensureSigningIdentity(client, team.teamId, key, {
      onCertificateLimit: certificates => askWhichCertificateToRevoke(ctx.t, certificates),
    })
    ctx.say(
      identity.reused ? "identity.certificateReused" : "identity.certificateIssued",
      { name: certificateLabel(identity.certificate) },
      "ok",
    )

    // What the gates after this one need to know: the team every later call is filed under. The key
    // is already in `Storage` — and the certificate is deliberately not cached here, because it is
    // read back from the portal at the point of use rather than trusted from an earlier run.
    saveTeam(email, team.teamId)
  },
}

/**
 * Holds the script open while a person is in Settings.
 *
 * Everything from here on lives in this script — the advertisement, the listener, the pair-setup
 * exchange — and iOS suspends an app as soon as it goes to the background, which is exactly where
 * this step sends the person. The original app holds a silent-audio assertion for that reason, and
 * the Bonjour API says so as well: publication needs the app in front, which this flow cannot be.
 *
 * Best-effort: no API, or an audio engine that will not start, is reported rather than thrown — a
 * pairing that could still work must not be stopped by the thing meant to protect it.
 */
async function holdOpenWhileInSettings(ctx: EngineContext): Promise<boolean> {
  const keeper: any = (globalThis as any).BackgroundKeeper
  if (keeper === undefined) {
    ctx.say("step.pair.keepAliveMissing", undefined, "warn")
    return false
  }
  try {
    if (await keeper.keepAlive()) {
      ctx.say("step.pair.keepAlive", undefined, "ok")
      return true
    }
    const state = await keeper.getState()
    ctx.say("step.pair.keepAliveFailed", {
      reason: String(state?.lastFailure ?? state?.status ?? "unknown"),
    }, "warn")
  } catch (error) {
    ctx.say("step.pair.keepAliveFailed", {
      reason: error instanceof Error ? error.message : String(error),
    }, "warn")
  }
  return false
}

/** Releases the request. Other scripts may hold their own, and exiting the script releases it too. */
async function releaseHeldScript(): Promise<void> {
  const keeper: any = (globalThis as any).BackgroundKeeper
  if (keeper === undefined) return
  try { await keeper.stopKeepAlive() } catch { /* nothing was held */ }
}

/**
 * A promise with a deadline. The timer is armed here, before the race, and never inside a socket
 * callback — one made there is rejected by the runtime.
 */
async function withDeadline<T>(work: Promise<T>, ms: number, message: string): Promise<T> {
  let handle: number | null = null
  const guard = new Promise<never>((_, reject) => {
    handle = setTimeout(() => reject(new Error(message)), ms)
  })
  try {
    return await Promise.race([work, guard])
  } finally {
    // The first handle is 0, which is falsy: compare against null, never truthiness.
    if (handle !== null) clearTimeout(handle)
  }
}

// MARK: - the pairing file on disk

/**
 * Where the pairing file a person can export lives.
 *
 * `PairStore` keeps the record in `Storage`, which is enough for this script but is not a file a share
 * sheet or another app can read — so it gets written out as one. The original app keeps its copy of
 * the same record in its private store and exports that.
 */
export function pairingFilePath(): string {
  const manager: any = (globalThis as any).FileManager
  if (manager === undefined) throw new Error("this build has no file access")
  return `${manager.documentsDirectory}/rp_pairing_file.plist`
}

/** Writes `file` where the export reads it from, and returns that path. */
export function writePairingFile(file: PairingFile): string {
  const manager: any = (globalThis as any).FileManager
  if (manager === undefined) throw new Error("this build has no file access")
  const path = pairingFilePath()
  manager.writeAsStringSync(path, pairingFileToXml(file))
  return path
}

/**
 * Ends the wait for a device, while `pairStep` is in one. Nothing interrupts a device that has already
 * dialled in, which is where the original app's cancel gives up as well.
 */
let stopWaitingForDevice: (() => void) | null = null

export const pairStep: StepDefinition = {
  id: "pair",
  titleKey: "step.pair.title",
  summaryKey: "step.pair.summary",
  async run(ctx) {
    const store = new PairStore()
    const saved = store.load()
    const udid = (Storage.get<string>("device.udid") ?? "").trim()
    if (!ctx.forcePairing && saved?.deviceAltIrk && udid.length > 0) {
      ctx.say("step.pair.already_paired")
      return
    }

    const createServer = require("node:net").createServer
    ctx.say("step.pair.loading_identity")
    const identity = await store.identity()
    const signingKey = await store.signingKey(identity)

    const server = createServer()
    await new Promise<void>((resolve, reject) => {
      server.once("error", reject)
      server.listen({ port: 0, host: "0.0.0.0" }, () => resolve())
    })
    const port: number = (server as any).address().port

    // Made here rather than when the device dials in: the code has to be readable before the person
    // leaves for Settings, and it is the same six digits the device will ask for.
    const pin = Math.floor(100000 + Math.random() * 900000).toString()

    // From here on the person is in Settings, so the script has to outlive the app going away.
    const held = await holdOpenWhileInSettings(ctx)

    let published: any = null
    let socket: any = null
    let paired = false
    let device = ""

    try {
      ctx.say("step.pair.publishing")
      try {
        published = await publishPairableHost({
          info: { name: "SideInstaller", identifier: identity.identifier, model: "Mac17,7", altIrk: identity.altIrk },
          port,
          includePeerToPeer: true,
        })
        ctx.say("step.pair.published", { port: published.port })
      } catch (e) {
        throw new Error(`Failed to publish pairable host: ${e}`)
      }

      // Before asking anyone to look for it: is the advertisement really on the network? A publish
      // that resolves only means the system took the registration.
      ctx.say("step.pair.browsing")
      const visible = await seesOwnPairableHost(identity.identifier)
      ctx.say(visible ? "step.pair.browseFound" : "step.pair.browseMissing", undefined, visible ? "ok" : "warn")

      const noCard = await ctx.surface?.start(pin) ?? null
      if (noCard !== null) ctx.say(noCard.key, { message: noCard.message ?? "" }, "warn")
      ctx.say("step.pair.waiting_device", { identifier: identity.identifier, pin })

      const connected = new Promise<any>((resolve, reject) => {
        server.once("connection", (incoming: any) => resolve(incoming))
        server.once("error", reject)
        // What a cancel does: the listener goes, and this wait goes with it.
        server.once("close", () => reject(new StepError("step.pair.cancelled")))
      })
      stopWaitingForDevice = () => { try { server.close() } catch { /* already closed */ } }
      socket = await withDeadline(connected, 90_000, "Device connection timed out after 90s")
      stopWaitingForDevice = null
      ctx.say("step.pair.device_connected")

      // The device is at its code prompt now: the moment worth drawing attention to a card the person
      // is not looking at, and the moment the page gets the code to show as well.
      Storage.set("pair.pin", pin)
      await ctx.surface?.prompt(pin)
      ctx.say("step.pair.running_setup")
      const peer = new SocketPeer(socket)
      const host = new PairSetupHost({
        identity,
        signingKey,
        pin,
        onPin: displayedPin => {
          ctx.say("step.pair.pin_displayed", { pin: displayedPin })
        },
        verifyDeviceSignature: true,
      })

      const outcome = await withDeadline(host.run(peer), 90_000, "pair-setup timed out after 90s")

      store.save(outcome.file)
      // The copy a person can hand to SideStore, StikDebug or Feather. Failing to write it is not a
      // failed pairing: `pairingExport` writes it again from the record when one is asked for.
      try {
        writePairingFile(outcome.file)
      } catch (error) {
        ctx.say("step.pair.fileWriteFailed", {
          reason: error instanceof Error ? error.message : String(error),
        }, "warn")
      }
      // The install step registers this device with the team, so the UDID has to outlive the step.
      Storage.set("device.udid", outcome.device.udid)
      device = outcome.device.name.length > 0 ? outcome.device.name : "iPhone"
      Storage.set("device.name", device)
      ctx.say("step.pair.paired", { deviceName: outcome.device.name, udid: outcome.device.udid })
      paired = true
    } finally {
      // Whatever happened, the card goes and nothing is left listening or advertising.
      stopWaitingForDevice = null
      Storage.remove("pair.pin")
      await ctx.surface?.finish(paired, device)
      try { socket?.destroy() } catch {}
      try { published?.stop() } catch {}
      try { server.close() } catch {}
      if (held) await releaseHeldScript()
    }
  },
}

/**
 * What an IPA says about itself: enough to cut an App ID for it and to report what was installed.
 * Read the way the signer reads it, from the unpacked `Info.plist`.
 */
function appInfoAt(appPath: string): { identifier: string, version: string, name: string } {
  const manager: any = (globalThis as any).FileManager
  if (manager === undefined) throw new StepError("install.noFileManager")
  const raw = manager.readAsBytesSync(`${appPath}/Info.plist`)
  const bytes = raw instanceof Uint8Array ? raw : new Uint8Array(raw as ArrayBuffer)
  const info = asDict(parsePlist(bytes))
  const identifier = str(info, "CFBundleIdentifier")
  if (identifier === undefined) throw new StepError("install.noBundleId")
  const version = str(info, "CFBundleShortVersionString") ?? "?"
  const name = str(info, "CFBundleDisplayName") ?? str(info, "CFBundleName") ?? identifier
  return { identifier, version, name }
}

/** The strings in a plist array, with anything else left out. */
function stringList(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((entry): entry is string => typeof entry === "string") : []
}

/**
 * Whether this app is a LiveContainer build carrying SideStore as its guest.
 *
 * The guest's SideStore asks for the group it was built with, so that one is registered for it.
 */
function carriesSideStoreGuest(appPath: string): boolean {
  const manager: any = (globalThis as any).FileManager
  const guest = `${appPath}/Frameworks/SideStoreApp.framework/Info.plist`
  if (manager === undefined || !manager.existsSync(guest)) return false
  const raw = manager.readAsBytesSync(guest)
  const bytes = raw instanceof Uint8Array ? raw : new Uint8Array(raw as ArrayBuffer)
  const identifier = str(asDict(parsePlist(bytes)), "CFBundleIdentifier")
  return identifier === SIDE_STORE_IDENTIFIER
}

/**
 * Whether the SideStore in this bundle imports `Account.sideconf` by itself.
 *
 * A prompting importer only accepts its own encrypted format, so a plaintext hand-over would make it
 * ask for a file password on every launch; that kind gets no file at all, which is what the reference
 * does. Which kind it is cannot be read off the version, so the binary is scanned for the marker.
 */
function sideStoreImportsAccountConfigSilently(appPath: string): boolean {
  const manager: any = (globalThis as any).FileManager
  if (manager === undefined) return false
  const toBytes = (raw: any): Bytes =>
    raw instanceof Uint8Array ? raw : new Uint8Array(raw as ArrayBuffer)

  // LiveContainer nests SideStore, and the guest's copy is the one that reads the file.
  for (const bundle of [`${appPath}/Frameworks/SideStoreApp.framework`, appPath]) {
    if (!manager.existsSync(`${bundle}/Info.plist`)) continue
    const info = asDict(parsePlist(toBytes(manager.readAsBytesSync(`${bundle}/Info.plist`))))
    const identifier = str(info, "CFBundleIdentifier")
    if (identifier === undefined || !identifier.startsWith(SIDE_STORE_IDENTIFIER)) continue
    const executable = str(info, "CFBundleExecutable")
    if (executable === undefined || !manager.existsSync(`${bundle}/${executable}`)) continue
    return importsAccountConfigSilently(toBytes(manager.readAsBytesSync(`${bundle}/${executable}`)))
  }
  return false
}

const SIDE_STORE_IDENTIFIER = "com.SideStore.SideStore"

/** The group to register for an app installed as `identifier` (`group.<identifier>`, as upstream). */
function appGroupIdentifier(identifier: string, teamId: string, guest: boolean): string {
  return guest ? `group.${SIDE_STORE_IDENTIFIER}.${teamId}` : `group.${identifier}`
}

/**
 * What to write as `ALTAppGroups`, or undefined for an app that does not read the key.
 *
 * Those apps find their group container through it, because a re-signed app is registered under a
 * group its own code was not built with.
 */
function altAppGroupsFor(
  appIdentifier: string, groupIdentifier: string, guest: boolean,
): string[] | undefined {
  const readsTheKey = guest || appIdentifier === SIDE_STORE_IDENTIFIER
    || appIdentifier === "com.rileytestut.AltStore"
  return readsTheKey ? [groupIdentifier] : undefined
}

/**
 * SideStore's newest release, standing in for the question "which app to install".
 *
 * `install.ipaURL` in `Storage` overrides it without a code change. The nightly
 * (`releases/download/nightly/SideStore.ipa`) is the build that reads the split pairing files; this
 * is the build a person without this project gets, and one they have run on iOS 27.
 */
export const DEFAULT_IPA_URL = "https://github.com/SideStore/SideStore/releases/latest/download/SideStore.ipa"

export interface DownloadedIpa {
  path: string
  bytes: number
}

/**
 * Fetches an archive to the temporary directory and says where it landed.
 *
 * The synchronous write is deliberate: `writeAsBytes` returns a promise, and an unawaited one writes
 * nothing at all (see `dev/test-sign.ts`), which would show up much later as an empty archive.
 */
export async function downloadIpa(url: string, ctx: EngineContext): Promise<DownloadedIpa> {
  const manager: any = (globalThis as any).FileManager
  if (manager === undefined) throw new StepError("install.noFileManager")

  ctx.say("install.downloading", { url })
  const response: any = await fetch(url, { timeout: 120 })
  if (response.status !== 200) throw new StepError("install.downloadFailed", { status: response.status })

  const bytes = new Uint8Array(await response.arrayBuffer())
  if (bytes.length === 0) throw new StepError("install.downloadedEmpty")

  const path = `${manager.temporaryDirectory}/${url.split("/").pop() ?? "app.ipa"}`
  manager.writeAsBytesSync(path, bytes)
  return { path, bytes: bytes.length }
}

/**
 * Downloads the chosen build, trying each place the downloader knows until one answers, and returns
 * the file it landed on. A link that has gone is followed by the next *place*, never by another
 * build: the mirror is accepted only under its own hash, and a workflow that ends without a file is
 * reported as there being nothing to install.
 */
async function fetchChosenBuild(ctx: EngineContext): Promise<DownloadedIpa> {
  const choice: BuildChoice = ctx.build?.source === "import"
    ? { source: "sideStore", channel: "stable" }
    : ctx.build ?? { source: "sideStore", channel: "stable" }
  const search = searchFor(choice.source, choice.channel, choice.version, {
    getJson,
    repoGone,
    log: (key, params) => ctx.say(key, params),
    channelLabel: channel => ctx.t(channelName(channel)),
  })

  let failure: { status: number } | undefined
  for (;;) {
    const candidate = await search.next(failure)
    if (candidate === null) {
      throw new StepError("build.noBuild", {
        name: buildDisplayName(choice.source),
        channel: ctx.t(channelName(choice.channel)),
        repo: repoOf(choice.source),
      })
    }
    try {
      const downloaded = await downloadIpa(candidate.url, ctx)
      if (candidate.sha256 !== undefined) {
        const actual = fileSha256(downloaded.path)
        if (actual !== candidate.sha256) {
          ctx.say("build.mirrorReplaced", {
            asset: candidate.name, url: candidate.url, sha256: candidate.sha256,
          }, "warn")
          throw new StepError("build.mirrorReplaced", {
            asset: candidate.name, url: candidate.url, sha256: candidate.sha256,
          })
        }
      }
      return downloaded
    } catch (error) {
      // Only a link that is not there is worth following: anything else (a refusal, a hash that
      // does not match) is the answer, not a reason to look somewhere else.
      const status = error instanceof StepError ? Number((error.params as any)?.status) : NaN
      if (status !== 404) throw error
      failure = { status }
    }
  }
}

/**
 * The last gate: put the signed application on the device.
 *
 * It is the only step that needs everything the others produced — a live reflection, an account with
 * a certificate, a paired device — and the only one that spends Apple's quota. The App ID it cuts
 * is `<the IPA's bundle id>.<team id>`, which is the identifier a sideloaded app is known by and
 * what makes the plugins' identifiers follow it.
 */
export const installStep: StepDefinition = {
  id: "install",
  titleKey: "step.install.title",
  summaryKey: "step.install.summary",
  async run(ctx) {
    // What the steps before this one left behind. Each of these is a fact the person can go and fix.
    // The reflection is re-checked rather than trusted: it is the one of these that can stop being
    // true on its own, and `Connection refused` at the device link is what that looks like.
    const address = await reflectionForDevice(ctx)
    // The device's pairing listener exists only on its Wi-Fi interface. Without Wi-Fi the download
    // and the signature below would be spent before anything could reach the device.
    const link = await reflectionSnapshot()
    if (link.state === "noService" && link.wifi === false) throw new StepError("install.needsWifi")
    const udid = (Storage.get<string>("device.udid") ?? "").trim()
    if (udid === "") throw new StepError("install.notPaired")
    const deviceName = (Storage.get<string>("device.name") ?? "iPhone").trim()
    const email = activeAccount() ?? ""
    if (email === "") throw new StepError("identity.noAccount")
    const teamId = loadTeam(email)
    if (teamId === "") throw new StepError("install.noTeam")

    // 1. the archive. An imported IPA takes precedence over the URL override; remote builds
    //    continue using the existing download search.
    const override = (Storage.get<string>("install.ipaURL") ?? "").trim()
    const imported = ctx.build?.source === "import" ? ctx.build.ipa : undefined
    if (ctx.build?.source === "import" && imported === null) throw new StepError("install.importRequired")
    const downloaded = imported !== undefined && imported !== null ? imported : override.length > 0
      ? await downloadIpa(override, ctx)
      : await fetchChosenBuild(ctx)
    const ipaPath = downloaded.path
    ctx.say(imported !== undefined ? "install.imported" : "install.downloaded", {
      megabytes: (downloaded.bytes / (1024 * 1024)).toFixed(1),
      path: ipaPath,
    })

    const manager: any = (globalThis as any).FileManager
    if (manager === undefined) throw new StepError("install.noFileManager")
    if (!manager.existsSync(ipaPath)) throw new StepError("install.ipaMissing", { path: ipaPath })

    // 2. unpack it, and learn what it calls itself.
    ctx.say("install.unpacking", { path: ipaPath })
    const unpacked = await unpackIpa(ipaPath, `${manager.temporaryDirectory}/sideinstaller-install`)
    const app = appInfoAt(unpacked.appPath)
    ctx.say("install.unpacked", { identifier: app.identifier, version: app.version })

    // 3. the portal: register this device, cut an App ID, and take the profile for it. This is the
    // only place in the flow that spends the account's quota.
    const bag = await fetchUrlBag(GSA_CLIENT_INFO, GSA_USER_AGENT)
    const client = await openSavedSession(email, ctx.say, bag, provisioningFrom(bag))
    if (client === null) throw new StepError("identity.noSession", { email })

    const identifier = `${app.identifier}.${teamId}`
    const registration = await client.ensureDeviceRegistered(teamId, deviceName, udid)
    ctx.say(registration === "added" ? "install.deviceAdded" : "install.deviceKnown", { udid })

    const listing = await client.listAppIds(teamId)
    saveAppIdQuota(email, {
      used: listing.appIds.length,
      total: listing.maxQuantity ?? 10,
      updatedAt: new Date().toISOString(),
    })
    const known = listing.appIds.find(appId => appId.identifier === identifier)
    let appId = known ?? await client.addAppId(teamId, identifier, app.name)
    ctx.say(known === undefined ? "install.appIdAdded" : "install.appIdKnown", { identifier })

    // The App Group, registered and assigned before the profile is cut: a profile only grants
    // `com.apple.security.application-groups` when the App ID may hold one. An app that keeps its
    // data in a group crashes on launch without it.
    const guest = carriesSideStoreGuest(unpacked.appPath)
    const groupIdentifier = appGroupIdentifier(identifier, teamId, guest)
    const group = await client.ensureAppGroup(teamId, app.name, groupIdentifier)
    ctx.say("install.appGroup", { identifier: group.identifier })
    appId = await client.ensureAppGroupCapability(teamId, appId)
    await client.assignAppGroup(teamId, group, appId.appIdId)
    ctx.say("install.appGroupAssigned", { appId: appId.identifier })

    const reply = await client.downloadTeamProvisioningProfile(teamId, appId.appIdId)
    const profile = parseProvisioningProfile(reply.encodedProfile)
    ctx.say("install.profile", { name: profile.name ?? reply.filename })
    // The profile is what the app may open, and `ALTAppGroups` has to name one it grants.
    const granted = stringList(profile.entitlements["com.apple.security.application-groups"])
    if (!granted.includes(group.identifier)) {
      ctx.say("install.appGroupNotGranted", {
        identifier: group.identifier, granted: granted.join(", ") || "none",
      }, "warn")
    }
    const altAppGroups = altAppGroupsFor(app.identifier, granted[0] ?? group.identifier, guest)
    // What the signature will claim, next to what the profile grants: an install that fails with
    // 0xe8008016 reports only that it failed, and these two dictionaries are the whole diagnosis.
    reportEntitlements(ctx, profile, identifier)
    if (profile.provisionedDevices !== null && !profile.provisionedDevices.includes(udid)) {
      // The profile is the device's own account of who may run this app, so this is worth saying
      // before the device has to say it.
      ctx.say("install.profileWithoutDevice", { udid }, "warn")
    }

    // 4. sign it, with the certificate that belongs to the key this account already has.
    const { key, jwk } = await loadOrCreateSigningKey(email)
    const identity = await ensureSigningIdentity(client, teamId, key, {
      onCertificateLimit: certificates => askWhichCertificateToRevoke(ctx.t, certificates),
    })
    ctx.say(identity.reused ? "identity.certificateReused" : "identity.certificateIssued", {
      name: certificateLabel(identity.certificate),
    })
    // What the archives this step hands over are protected with: AltStore-family apps expect the
    // certificate's machine id, and the file carries whatever this is either way.
    const certificatePassword = identity.certificate.machineId ?? MACHINE_NAME
    const chain = profile.developerCertificates.filter(certificate =>
      !sameBytes(certificate, identity.certificateDer))
    ctx.say("install.certificateChain", { count: chain.length, team: profile.teamIdentifier ?? "none" })
    const signed = signBundle(unpacked.appPath, {
      profile,
      certificate: identity.certificateDer,
      // The profile carries the chain the device checks the signature against — this one has the
      // developer certificate and the WWDR intermediate — and the reference signer puts the whole
      // thing in the CMS; here they are the candidates it builds that chain from, Apple's own CAs
      // included. Ours used to carry the leaf alone.
      chain,
      privateKey: key,
      identifier,
      altAppGroups,
      onBundle: (path, bundleIdentifier) => ctx.say("install.signedBundle", {
        path: path.slice(unpacked.appPath.length + 1) || unpacked.bundleName,
        identifier: bundleIdentifier,
      }),
    })
    ctx.say("install.signed", { bundles: 1 + signed.nested.length, libraries: signed.libraries.length })

    // 5. the tunnel, then the two services an install uses: AFC to stage the bundle and
    // installation_proxy to ask for it to be installed.
    ctx.say("install.connecting", { address })
    const device = await openDeviceLink({ address, onStep: message => ctx.sayRaw(message) })
    try {
      const afc = await AfcClient.connect(await device.open(SERVICES.afc), "afc")
      const installer = await InstallationProxy.connect(
        await device.open(SERVICES.installationProxy), "installer")

      let lastDecile = -1
      const deployed = await deployBundle(unpacked.appPath, afc, installer, {
        bundleName: unpacked.bundleName,
        onProgress: (phase, done, total) => {
          // One line per tenth: enough to see it moving, not enough to bury the log.
          if (total <= 0) return
          const decile = Math.floor((done / total) * 10)
          if (decile === lastDecile) return
          lastDecile = decile
          ctx.say("install.progress", { percent: decile * 10, phase })
        },
      })
      ctx.say("install.installed", { bundle: unpacked.bundleName, files: deployed.files })

      // What the Apps page will list: the App ID it was signed as, the profile's seven days, and the
      // group that App ID holds. Nothing reads the device for that — this is the record.
      rememberInstalled(recordOfInstall({
        identifier,
        name: app.name,
        version: app.version,
        appGroup: granted.includes(group.identifier) ? group.identifier : null,
        teamId,
        account: email,
        profile,
        // What a refresh asks Apple about: the signature carries this certificate, and its expiry
        // tells "revoked" apart from "expired" once the serial is no longer in the listing.
        certificateSerial: identity.certificate.serialNumber,
        certificateExpiresAt: identity.certificate.expirationDate,
      }))

      // Both services are done with, and a tunnel allows four connections at a time: the container
      // writes below open one each.
      await afc.disconnect()
      await installer.disconnect()

      // The certificate hand-off only helps a SideStore that imports it by itself; the prompting
      // kind would ask for a file password on every launch instead, so it gets nothing.
      const importsSideconfSilently = sideStoreImportsAccountConfigSilently(unpacked.appPath)
      if (!importsSideconfSilently) {
        ctx.say("install.accountPromptingImporter", { app: app.name }, "warn")
      }

      await seedPairing(device, identifier, app.name, ctx, udid, {
        email,
        jwk,
        certificateDer: identity.certificateDer,
        password: certificatePassword,
        anisette: client.anisette.identity,
        importsSideconfSilently,
      }, guest)
    } finally {
      await device.close()
    }

    // What the finished run's popup names, which outlives this line.
    Storage.set("install.name", app.name)
    Storage.set("install.version", app.version)
    // LiveContainer keeps its certificate where nothing but itself can write, so it is handed over
    // afterwards instead: the popup that ends the run carries the URL its scheme takes.
    if (isLiveContainer(app.identifier)) {
      const p12 = buildPkcs12({
        certificateDer: identity.certificateDer,
        jwk,
        password: certificatePassword,
      })
      Storage.set(CERTIFICATE_KEY, certificatePushURL(p12, certificatePassword))
      ctx.say("install.certificateReady", { app: app.name })
    } else {
      Storage.remove(CERTIFICATE_KEY)
    }
    ctx.say("install.done", { name: app.name, version: app.version }, "ok")
    // The original app's own guide ends here, and it is not decoration: iOS opens no
    // development-signed app until its certificate is trusted.
    ctx.say("install.trust", { name: app.name }, "warn")
  },
}

/** What the account hand-off needs, all of it produced earlier in the step. */
interface SeedAccount {
  email: string
  jwk: RsaJwk
  certificateDer: Bytes
  /** The archive's password, which the file carries for the app that imports it. */
  password: string
  anisette: AnisetteIdentity
  /** False for a SideStore whose importer asks for a password: it gets no file. */
  importsSideconfSilently: boolean
}

/**
 * Writes this device's pairing file into the app that was just installed.
 *
 * The bundle id is the one the app was signed and installed as, and a vend for anything else comes
 * back as `ApplicationLookupFailed` from the device.
 */
async function seedPairing(
  device: DeviceLink,
  bundleId: string,
  displayName: string,
  ctx: EngineContext,
  udid: string,
  account: SeedAccount,
  /** Whether the bundle carries SideStore as its guest. It is the guest that reads both files. */
  carriesGuest: boolean,
): Promise<void> {
  const target = pairingTargetFor(displayName, bundleId)
  if (target === null) {
    ctx.say("install.pairingNoTarget", { app: displayName })
    return
  }
  // LiveContainer alone asks for neither file: nothing in it reads a pairing file, and the account
  // config is for the SideStore guest it does not carry.
  if (target.sideStoreHome === "liveContainer" && !carriesGuest) {
    ctx.say("install.pairingStandalone", { app: displayName })
    return
  }

  const file = new PairStore().load()
  if (file === null) throw new StepError("install.pairingMissing")

  ctx.say("install.pairingWriting", { app: target.name, path: target.relativePath })
  let seeded: SeedOutcome
  try {
    seeded = await seedPairingFile({
      link: device,
      bundleId,
      target,
      xml: pairingFileToXml(file),
      udid,
    })
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error)
    throw new StepError("install.pairingFailed", { app: target.name, reason })
  }
  ctx.say("install.pairingWritten", { app: target.name, bytes: seeded.bytes })

  if (target.sideStoreHome !== null && seeded.activeProtocol !== null) {
    ctx.say("install.pairingSettings", {
      app: target.name,
      protocol: seeded.activeProtocol,
      files: seeded.files.length,
      preferences: preferencesPath(target.sideStoreHome, bundleId),
    })
    // The app reads these settings as it is installed, so one that has already run picks them up on
    // its next reinstall or after a restart.
    ctx.say("install.pairingSettingsNote", { app: target.name })
  }
  if (seeded.missingLockdownKeys.length > 0) {
    ctx.say("install.pairingLockdownIncomplete", { keys: seeded.missingLockdownKeys.join(", ") }, "warn")
  }
  if (seeded.error !== null) {
    ctx.say("install.pairingNewerFormatFailed", { app: target.name, reason: seeded.error }, "warn")
  }

  // The certificate hand-off, last, as the original does it: without it SideStore revokes the
  // certificate that signed it and makes its own on first sign-in.
  if (target.sideStoreHome === null) return
  if (!account.importsSideconfSilently) return
  if (account.anisette.adiPb.length === 0) {
    ctx.say("install.accountNoIdentity", { app: target.name }, "warn")
    return
  }
  const relative = `${documentsPrefix(target.sideStoreHome)}${SIDECONF_FILE_NAME}`
  try {
    const bytes = sideconfBytes({
      email: account.email,
      certificateDer: account.certificateDer,
      jwk: account.jwk,
      password: account.password,
      anisetteIdentifier: account.anisette.identifier,
      anisetteAdiBlob: account.anisette.adiPb,
    })
    await writeIntoDocuments(device, bundleId, relative, bytes)
    ctx.say("install.accountWritten", { app: target.name, path: relative, bytes: bytes.length })
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error)
    ctx.say("install.accountFailed", { app: target.name, reason }, "warn")
  }
}

export const defaultSteps: StepDefinition[] = [
  reflectionStep, signinStep, identityStep, pairStep, installStep,
]

export function createEngine(options: EngineOptions = {}): Engine {
  const engine = new Engine(defaultSteps, options)
  engine.say("log.started")
  return engine
}
