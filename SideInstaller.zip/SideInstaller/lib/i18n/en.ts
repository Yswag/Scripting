// English is the source of truth. Every other locale is checked against its key type, so a
// typo or a missing key is a compile error rather than a blank line at runtime.
export const en = {
  "app.title": "SideInstaller",

  "tab.install": "Install",
  "tab.tools": "Tools",

  "section.advanced": "Advanced",
  "section.language": "Language",

  "settings.account": "Account",
  "settings.account.empty": "No Apple ID yet. Sign in and the session is kept for the next run.",
  "settings.account.inUse": "In use",
  "settings.account.tapToUse": "Tap to use this Apple ID",
  "settings.account.add": "Add Apple ID",
  "settings.account.add.invalid": "That is not an Apple ID.",
  "settings.account.signingIn": "Signing in…",
  "settings.account.signedIn": "{email} is the Apple ID this device uses now.",
  "settings.account.failed": "Could not sign in as {email}: {message}",
  "settings.account.forget": "Forget this Apple ID",
  "settings.account.forgetNote":
    "The saved session is deleted from this iPhone. Nothing on your Apple account changes.",
  "settings.account.forgot": "Forgot the saved Apple ID.",

  "settings.connection": "Device link",
  "settings.connection.source": "Reflection from",
  "settings.connection.builtIn": "Scripting itself",
  "settings.connection.proxyApp": "The proxy tool",
  "settings.connection.note":
    "iOS allows one VPN at a time: Scripting's own VPN takes the slot from a running proxy tool, and " +
    "the other way round. With the proxy tool this app starts no VPN at all.",
  "settings.connection.host": "Device address",
  "settings.connection.hostNote":
    "Where the device's pairing service and remoted answer under the reflection. {default} unless your " +
    "proxy tool reflects another address.",

  "settings.refresh": "App Refresh",
  "settings.refresh.scope": "Refresh scope",
  "settings.refresh.currentAccount": "Current account",
  "settings.refresh.allAccounts": "All saved accounts",
  "settings.refresh.note":
    "When set to all saved accounts, Refresh All will queue and renew apps for each account in sequence.",

  "settings.ddi": "Developer Image",
  "settings.ddi.note":
    "The image is cached in this app's Documents/DDI. Enable JIT installs it on the device when it is " +
    "missing; deleting the files only means downloading them again (about 17 MB).",
  "settings.ddi.ready": "Files are here ({size}).",
  "settings.ddi.missing": "{present} of {total} files here.",
  "settings.ddi.download": "Download Now",
  "settings.ddi.downloading": "Downloading…",
  "settings.ddi.delete": "Delete Files",
  "settings.ddi.deleteConfirm": "Delete the cached developer image files? The next JIT run downloads them again.",
  "settings.ddi.failed": "Could not download: {message}",

  "settings.log.count": "Activity Log ({count})",

  "button.close": "Close",
  "button.cancel": "Cancel",
  "button.settings": "Settings",
  "button.done": "Done",
  "button.continue": "Continue — {title}",
  "button.allDone": "All steps finished",
  "button.copy": "Copy",
  "button.clear": "Clear",

  "progress.count": "{done} of {total} steps done",

  "log.empty": "No activity yet.",
  "log.busy": "Another step is still running.",
  "log.started": "SideInstaller (Scripting port)",
  "log.stepBegin": "--- {title} ---",
  "log.stepDone": "{title}: done",
  "log.stepFinishedIn": "{title}: finished in {seconds}s",
  "log.stepFailed": "{title}: {message}",
  "log.stepBlocked": "{title}: {reason}",
  "log.skipDone": "{title}: already done, skipping",
  "log.stoppedAt": "Stopped at \"{title}\".",
  "log.allDone": "All steps finished.",

  "state.pending": "Not started",
  "state.running": "Running",
  "state.done": "Done",
  "state.failed": "Failed",
  "state.blocked": "Not available yet",
  "state.skipped": "Skipped",

  "step.reflection.title": "Device link",
  "step.reflection.summary": "Turn on the local-device reflection",
  "reflection.vpnWas": "VPN was {status}",
  "reflection.vpnStarted": "VPN started: {status}",
  "reflection.intentOn": "Reflection intent switched on",
  "reflection.activeAt": "Reflection is active at {address}",
  "reflection.waiting": "Waiting for the reflection… ({status})",
  "reflection.failed": "The reflection never became active. Check that LocalDevVPN is running.",
  "reflection.noApi": "This build of Scripting has no VPN API.",
  "reflection.permission": "Permission not granted: {list}",
  "reflection.ownVpnUp":
    "Scripting's own VPN is still connected, and it holds the one VPN slot — the proxy tool may not be " +
    "able to start.",
  "reflection.intentFailed": "Could not switch the LocalDevVPN intent on: {message}",
  "reflection.proxyAt": "The reflection comes from the proxy tool, with the device at {host}",

  "step.signin.title": "Apple ID",
  "step.signin.summary": "Sign in and obtain a developer session",
  "step.signin.blocked": "Waiting on the sign-in module.",
  "signin.email.title": "Apple ID",
  "signin.password.title": "Apple ID password",
  "signin.code.title": "Two-factor code",
  "signin.cancelled": "Sign-in was cancelled.",
  "signin.reusing": "A saved session for {email} is still valid — checking it with Apple…",
  "signin.staleSession": "The saved session was refused ({message}); signing in again.",
  "signin.rejected": "Apple refused the Apple ID or the password. Check the address and the password, then try again — if you are sure they are right, Apple may be limiting sign-in attempts, so wait a while. ({message})",
  "signin.appleRefused": "Apple's sign-in server turned the request away (HTTP 503). That is not the password and not the anisette server, so another server will not help — it clears by itself, so try again in a moment. ({message})",
  "signin.connectingAnisette": "Anisette: {server}",
  "signin.anisetteFailed": "Anisette server did not work out: {server} ({message})",
  "signin.anisetteLocalFailed": "The anisette server on this device would not start ({message}); using a community server instead.",
  "signin.noAnisette": "No anisette server could be reached. {message}",
  "signin.anisetteList": "Anisette servers: {count} from the community list.",
  "signin.anisetteListFallback": "Couldn't fetch the anisette server list; using the {count} servers the app bundles.",
  "signin.anisetteRepick": "Anisette {server} doesn't take the identity in use (-45061); picking another one there.",
  "signin.locked": "Apple has locked this Apple Account for security reasons (error -20209), so every sign-in fails until it's unlocked. Reset its password at iforgot.apple.com, then sign in again with the new password.",
  "signin.underage": "Apple won't let this Apple Account use developer services because of its owner's age (error 1102). Sign in with an adult's Apple Account instead.",
  "signin.emailUnverified": "Apple won't let this Apple Account use developer services until its email address is verified (error 2160). Verify it at account.apple.com, then try again.",
  "signin.rateLimited": "Apple is temporarily limiting sign-ins for this Apple ID or network (HTTP 429). Trying other servers won't help, and every attempt can extend the wait, so leave it a while before signing in again.",
  "signin.unreachable": "SideInstaller can't reach Apple's sign-in server (gsa.apple.com), though this iPhone has an internet connection. Something is blocking it: a firewall, a DNS filter or ad blocker, Screen Time content restrictions, or another VPN app. Turn it off or try another network, then try again.",
  "signin.noProvisioning": "Apple's URL bag has no provisioning endpoints.",
  "signin.signingIn": "Signing in to Apple…",
  "signin.gotToken": "Developer token issued, valid for {seconds}s.",
  "signin.verified": "Token accepted by Apple ({teams} team(s)).",
  "signin.noTeams": "The token works, but this account has no teams — open Xcode once, or accept the free developer agreement.",
  "signin.saved": "Session saved. The next run will reuse it.",

  "step.identity.title": "Signing certificate",
  "step.identity.summary": "Issue or reuse the certificate that signs the app",
  "identity.noAccount": "Sign in first — this step reuses the session Apple gave you.",
  "identity.noSession": "There is no usable session for {email}. Run the Apple ID step again.",
  "identity.noTeams": "This account is on no team. Open Xcode once, or accept the free developer agreement, then run this again.",
  "identity.team": "Team: {name} ({teamId})",
  "identity.team.title": "Which team should sign the app?",
  "identity.team.message": "This Apple ID belongs to more than one team.",
  "identity.teamCancelled": "No team was chosen, so no certificate was asked for.",
  "identity.keyCreated": "No signing key was stored for {email}, so one was generated. Apple issues certificates for this key from now on, and it is never replaced.",
  "identity.keyReused": "Using the signing key already stored for {email}.",
  "identity.certificateReused": "Apple already holds a certificate for this key — reusing {name}. No slot was spent.",
  "identity.certificateIssued": "Apple issued a new certificate: {name}.",
  "identity.revoke.title": "Revoke a certificate?",
  "identity.revoke.message": "This account is at its certificate limit, so Apple will not issue another one until an old certificate is revoked. Revoking stops every app already signed with it from launching — including apps this project never signed.",
  "identity.revoke.confirm": "Revoke {name}? Every app signed with this certificate stops launching.",
  "identity.revoke.button": "Revoke",

  "step.pair.title": "Pair with this iPhone",
  "step.pair.summary": "The code goes up in the Dynamic Island, then you confirm it in Settings",
  "step.pair.cardSteps":
    "Open Settings › Privacy & Security › Developer Mode.\n" +
    "Tap “Pair with SideInstaller”.\n" +
    "Enter this iPhone’s passcode if it asks for it.\n" +
    "Type the six digits shown here (or in the Dynamic Island) into the prompt in Settings.",
  "step.pair.loading_identity": "Loading pairing identity…",
  "step.pair.already_paired": "Found an old pairing file, removed it.",
  "step.pair.publishing": "Publishing pairing host…",
  "step.pair.published": "Pairing host published on port {port}.",
  "step.pair.browsing": "Checking that the advertisement answers a browse…",
  "step.pair.browseFound": "The advertisement answered a browse for it.",
  "step.pair.browseMissing":
    "Nothing answered our own browse, so the host cannot be found from Settings yet. Either the " +
    "advertisement was never published, or Scripting has no local network access " +
    "(Settings › Scripting › Local Network).",
  "step.pair.keepAlive": "Holding the script open while you are in Settings.",
  "step.pair.keepAliveMissing":
    "This build has no background keep-alive, so the app can be suspended while you are in Settings.",
  "step.pair.keepAliveFailed": "Could not hold the script open in the background ({reason}).",
  "step.pair.waiting_device": "Waiting for device (ID: {identifier}, PIN: {pin})",
  "step.pair.device_connected": "Device connected.",
  "step.pair.running_setup": "Running pair-setup…",
  "step.pair.pin_displayed": "PIN displayed: {pin}",
  "step.pair.paired": "Paired: {deviceName} ({udid})",
  "step.pair.cancelled": "Pairing was cancelled.",
  "step.pair.fileWriteFailed": "Couldn't write the pairing file: {reason}",

  "activity.pair.title": "Pairing code",
  "activity.pair.enter": "Type this code now",
  "activity.pair.where": "Settings › Privacy & Security › Developer Mode",
  "activity.pair.alert.title": "Pairing code",
  "activity.pair.alert.body": "Type it into the prompt in Settings.",
  "activity.pair.paired": "Paired",
  "activity.pair.return": "Tap to return to SideInstaller.",
  "activity.pair.failed": "Pairing did not finish",
  "activity.pair.retry": "See the log in the app.",
  "activity.pair.disabled":
    "Live Activities are off for this app, so the code is only in this log. Turn them on in " +
    "Settings › Scripting › Live Activities.",
  "activity.pair.notForeground":
    "A card cannot be raised once the app is in the background, so the code is only in this log. " +
    "Run the step again and leave for Settings only after the island shows the code.",
  "activity.pair.refused": "The system refused the card ({message}), so the code is only in this log.",

  "step.install.title": "Install {name}",
  "step.install.summary": "Sign the IPA, then install it over the device link",
  "install.needsWifi":
    "The device's pairing service only listens on Wi-Fi. Turn Wi-Fi on and try again. Nothing has " +
    "been signed yet.",
  "install.noReflection":
    "The reflection is not active and did not come back up, so there is nothing to reach the device " +
    "at. Restart the VPN (or run the first step again) and try once more.",
  "install.reflectionGone":
    "The reflection is no longer active ({status}, last seen at {address}). Bringing it back up before " +
    "opening the device link.",
  "install.notPaired": "This phone is not paired with the device yet. Run the pairing step first.",
  "install.noTeam": "No developer team is stored. Run the signing-identity step first.",
  "install.noFileManager": "This build has no file access, so the IPA cannot be read.",
  "install.noBundleId": "That IPA's Info.plist has no CFBundleIdentifier.",
  "install.importRequired": "Choose an IPA file with Import before installing.",
  "install.importWrongExtension": "The selected file is named {name}. Please choose a .ipa file.",
  "install.importInvalid": "The imported IPA is empty.",
  "install.importFailed": "Could not import the IPA: {message}",
  "install.imported": "Imported {megabytes} MB from {path}.",
  "install.ipaMissing": "There is no file at {path}.",
  "install.downloading": "Downloading {url}…",
  "install.downloaded": "Downloaded {megabytes} MB to {path}.",
  "install.downloadFailed": "The download failed with HTTP {status}.",
  "install.downloadedEmpty": "The download came back empty.",
  "install.unpacking": "Unpacking {path}…",
  "install.unpacked": "Unpacked {identifier} {version}.",
  "install.deviceAdded": "Registered this iPhone with your team ({udid}).",
  "install.deviceKnown": "This iPhone was already registered ({udid}).",
  "install.appIdAdded": "Created the App ID {identifier}.",
  "install.appIdKnown": "The App ID {identifier} already exists.",
  "install.appGroup": "Registered the App Group {identifier}.",
  "install.appGroupAssigned": "Gave it to {appId}, so the profile grants it.",
  "install.appGroupNotGranted":
    "The profile came back without the App Group {identifier} (it grants: {granted}), so an app that keeps its data in a group will not launch.",
  "install.profile": "Took the profile “{name}” for it.",
  "install.entitlementsAgree": "The signature claims exactly what the profile grants.",
  "install.certificateChain":
    "Signing with the team “{team}” and {count} extra certificate(s) from the profile's chain.",
  "install.entitlementsDiffer":
    "The signature claims {count} thing(s) the profile does not grant — the device refuses a signature " +
    "for that (0xe8008016).",
  "install.profileWithoutDevice":
    "That profile does not list this iPhone ({udid}). The device will refuse the install unless " +
    "Apple has been told about it.",
  "install.signedBundle": "Signed {path} as {identifier}.",
  "install.signed": "Signed {bundles} bundle(s) and {libraries} dylib(s).",
  "install.connecting": "Opening the device link at {address}…",
  "install.progress": "{phase}: {percent}%",
  "install.installed": "{bundle} is installed ({files} files uploaded).",
  "install.pairingNoTarget":
    "Nothing in the pairing table is a file {app} reads, so none was written.",
  "install.pairingMissing": "There is no pairing file to write. Run the pairing step first.",
  "install.pairingWriting": "Writing {app}'s pairing file to /Documents/{path}…",
  "install.pairingWritten": "{app} read the pairing file back: {bytes} bytes verified.",
  "install.pairingFailed": "Couldn't write {app}'s pairing file: {reason}",
  "install.pairingStandalone":
    "{app} on its own reads neither file, so neither was written.",
  "install.pairingSettings":
    "Pointed {app} at its {protocol} pairing file ({files} newer-format file(s)) and wrote /{preferences}.",
  "install.pairingSettingsNote":
    "{app} reads these settings as it is installed, so one that has already run picks them up when it is reinstalled or after a restart.",
  "install.pairingLockdownIncomplete":
    "The lockdown record lacks {keys}, so only the RPPairing record was handed over.",
  "install.pairingNewerFormatFailed":
    "Couldn't hand {app} the pairing file in the newer format: {reason}",
  "install.accountWritten":
    "Handed {app} the signing certificate: /Documents/{path} ({bytes} bytes). It imports and deletes it on first launch.",
  "install.accountFailed":
    "Couldn't hand {app} the signing certificate: {reason} It is installed and ready, but it will ask to resign itself on first sign-in.",
  "install.accountNoIdentity":
    "No provisioned anisette identity is stored, so no certificate was handed to {app}.",
  "install.accountPromptingImporter":
    "This {app} build asks for a file password before importing Account.sideconf, and only accepts its own encrypted format, so nothing was handed over: it will offer to resign itself on first sign-in.",
  "install.certificateReady":
    "The certificate {app} needs to run anything is ready to send.",
  "install.certificateSent": "Handed the certificate to LiveContainer.",
  "install.certificateRefused":
    "Couldn't open LiveContainer. Trust it in Settings first, then send it over again.",
  "install.done": "{name} {version} is on your iPhone.",
  "install.trust":
    "Before it can open: Settings › General › VPN & Device Management › your Apple ID › Trust, then open {name} from the Home Screen.",
  "install.certificate.title": "Import the certificate into LiveContainer",
  "install.certificate.body":
    "LiveContainer signs every app it runs with this account's certificate, and iOS 26 runs none at all without one. Trust it first, then send it over: LiveContainer opens and takes it.",
  "install.certificate.button": "Send the certificate to LiveContainer",
  "install.certificate.sent":
    "Sent. LiveContainer's Settings › JIT-Less should now show a certificate.",
  "install.certificate.failed":
    "LiveContainer didn't take it. If it isn't trusted yet: Settings › General › VPN & Device Management › your Apple ID › Trust, then send again.",

  "tools.planned": "Not ported yet",
  "tool.pairing": "Pairing",
  "tool.certificates": "Certificates",
  "tool.entitlements": "Entitlements",

  "certs.load": "Load certificates",
  "certs.refresh": "Refresh",
  "certs.signingIn": "Signing in",
  "certs.refreshing": "Refreshing",
  "certs.count": "{count} certificate(s)",
  "certs.team": "team: {name} ({teamId})",
  "certs.unnamed": "Unnamed certificate",
  "certs.expired": "Expired",
  "certs.expires": "Expires {date}",
  "certs.empty.title": "No certificates",
  "certs.empty.body": "This Apple ID has no development certificates to revoke.",
  "certs.revoke": "Revoke",
  "certs.revoking": "Revoking",
  "certs.revoke.title": "Revoke this certificate?",
  "certs.revoke.message":
    "“{name}” will be revoked. Apps already signed with it will stop launching on every device. " +
    "This can't be undone.",
  "certs.noAccount": "No Apple ID saved. Add one in Settings › Account.",
  "certs.noSession": "The session for {email} cannot be used to list certificates.",
  "certs.signInFailed": "Signing in as {email} did not work — Apple's own message is in the activity log.",
  "certs.noTeams":
    "This Apple ID is on no team, so it has no certificates. Accept the free developer agreement at " +
    "developer.apple.com, then try again.",
  "certs.noSerial": "This certificate has no serial number, so it can't be revoked.",
  "certs.listFailed": "Listing certificates failed: {message}",
  "certs.revokeFailed": "Revoke failed: {message}",
  "certs.log.loading": "Certificates: loading…",
  "certs.log.sessionFailed": "Certificates: the saved session did not work ({message})",
  "certs.log.signingIn": "Certificates: signing in as {email}…",
  "certs.log.team": "Certificates: team {name} ({teamId})",
  "certs.log.listed": "Certificates: {count} iOS development certificate(s).",
  "certs.log.revoking": "Certificates: revoking {name} ({serial})…",
  "certs.log.revoked": "Certificates: revoked {name}.",

  "entitlements.load": "Load App IDs",
  "entitlements.refresh": "Refresh",
  "entitlements.signingIn": "Signing in",
  "entitlements.refreshing": "Refreshing",
  "entitlements.count": "{count} App ID(s)",
  "entitlements.team": "team: {name} ({teamId})",
  "entitlements.empty.title": "No App IDs",
  "entitlements.empty.body":
    "This Apple ID hasn't registered any apps yet. Install something with SideInstaller first, then come back.",
  "entitlements.enabled": "{count} of {total} enabled",
  "entitlements.remoteEnabled": "Apple: {count} enabled",
  "entitlements.lastRun": "Last request: {count} of {total} accepted",
  "entitlements.group.memory": "Memory and performance",
  "entitlements.group.other": "Other free capabilities",
  "entitlements.beta": "Beta",
  "entitlements.recommended": "Recommended",
  "entitlements.selectAll": "Select all",
  "entitlements.none": "None",
  "entitlements.apply": "Enable {count} selected",
  "entitlements.applying": "Asking Apple",
  "entitlements.apply.note":
    "Apple records these for the App ID's next profile. The app has to be signed again and reinstalled — a " +
    "refresh alone does not apply them.",
  "entitlements.results.reinstall":
    "Install the app again for these to take effect: only a new signature carries the App ID's next " +
    "profile.",
  "entitlements.results.appGroups":
    "App Groups is switched on for the App ID only. The group itself is created and assigned when the app is " +
    "installed through SideInstaller.",
  "entitlements.error.title": "Something went wrong",
  "entitlements.noAccount": "No Apple ID saved. Add one in Settings › Account.",
  "entitlements.noSession": "The session for {email} cannot be used to list App IDs.",
  "entitlements.sessionChanged": "The Apple ID changed while this App ID was open. Load the App IDs again before enabling capabilities.",
  "entitlements.signInFailed":
    "Signing in as {email} did not work — Apple's own message is in the activity log.",
  "entitlements.noTeams":
    "This Apple ID is on no team, so it has no App IDs. Accept the free developer agreement at " +
    "developer.apple.com, then try again.",
  "entitlements.listFailed": "Listing App IDs failed: {message}",
  "entitlements.enableFailed": "Enabling capabilities failed: {message}",
  "entitlements.log.loading": "Entitlements: loading App IDs…",
  "entitlements.log.sessionFailed": "Entitlements: the saved session did not work ({message})",
  "entitlements.log.signingIn": "Entitlements: signing in as {email}…",
  "entitlements.log.team": "Entitlements: team {name} ({teamId})",
  "entitlements.log.listed": "Entitlements: {count} App ID(s).",
  "entitlements.log.enabling": "Entitlements: asking Apple for {count} capability(ies) on {identifier}…",
  "entitlements.log.enabled": "Entitlements: Apple accepted {granted} of {total} on {identifier}.",

  "pairing.file": "Pairing file",
  "pairing.fileReady": "Pairing file ready",
  "pairing.fileNone": "No pairing file",
  "pairing.generate": "Generate pairing file",
  "pairing.regenerate": "Regenerate",
  "pairing.generating": "Pairing…",
  "pairing.export": "Export pairing file",
  "pairing.importFile": "Import from Files",
  "pairing.importClipboard": "Import from Clipboard",
  "pairing.exportClipboard": "Export to Clipboard",
  "pairing.imported": "Pairing record imported. Keep its private key confidential.",
  "pairing.replaceTitle": "Replace pairing record?",
  "pairing.replaceMessage": "This will replace the current device and host identity. The existing connection may stop working.",
  "pairing.replaceConfirm": "Replace",
  "pairing.importFailed": "Could not import pairing record: {message}",
  "pairing.exportFailed": "Could not export pairing record: {message}",
  "pairing.ready": "Pairing file ready. Export it for the app that reads one.",
  "pairing.error.title": "Something went wrong",

  "pill.tunnelOn": "Tunnel connected",
  "pill.tunnelOff": "Tunnel off",
  "pill.tunnelNoService": "Reflection up, no service",
  "pill.tunnelNoServiceNoWifi": "Turn on Wi-Fi",
  "pill.tunnelNoServiceWifi": "Wi-Fi is up, but the pairing service is not",
  "pill.tunnelUnknown": "Tunnel state unknown",

  "channel.stable": "Stable",
  "channel.nightly": "Nightly",
  "build.askApi": "No {name} on that release — asking GitHub what the asset is called now.",
  "build.scanReleases": "That release carries no {name} IPA — looking through {repo}'s other releases.",
  "build.fromOtherRelease": "{name} is not published on the {channel} release — taking {asset} from {tag} instead.",
  "build.fromMirror": "{repo} is not on GitHub right now — taking its last {channel} build from the copy on {mirror}.",
  "build.listed": "Versions: {name} has {stable} stable and {nightly} pre-release builds besides the latest.",
  "build.listFailed": "Couldn't list {name} releases: {message}",
  "build.noBuild": "There is no {name} build to install: nothing on the {channel} release, and nothing in {repo}'s other releases.",
  "build.mirrorReplaced": "{asset} on {url} is not the file this project accepts from there (SHA-256 {sha256}), so it was not installed.",

  "install.import": "Import",
  "install.importFile": "Tap to import file",
  "install.channel": "Release",
  "install.signedBy": "Signed as {account}",
  "install.noAccount": "No Apple ID signed in",
  "install.switchAccount": "Change",
  "install.signIn": "Sign in",
  "install.version.title": "{name} version",
  "install.version.latest": "Latest",
  "install.version.latestWith": "Latest ({version})",
  "install.version.failed": "Couldn't load the other versions: {message}",
  "install.version.retry": "Try again",
  "install.cta": "Install {name}",
  "install.running": "Installing",
  "install.finished": "Installed",
  "install.stepOf": "Step {index} of {total}",

  "dashboard.title": "Account limits",
  "dashboard.installedApps": "Active Apps",
  "dashboard.appIdQuota": "App IDs",
  "dashboard.certExpiry": "Profile Expiry",
  "dashboard.daysLeft": "{days}d left",
  "dashboard.noApps": "No apps",
  "dashboard.maxReached": "Max reached",
  "dashboard.remaining": "{count} left",
  "dashboard.limitTen": "Limit 10",
  "dashboard.check": "Check",
  "dashboard.valid": "Normal",
  "dashboard.expiringSoon": "Expiring soon",

  "apps.nothingToRefresh":
    "Nothing here was signed by the team you are signed in as, so there is nothing to refresh.",
  "apps.refreshNoTeam":
    "Sign in and pick a team first — a refresh has to cut the profile again from the account that " +
    "signed the app.",
  "apps.refreshBegin": "Refreshing {count} app(s)…",
  "apps.session": "Using the saved session for {email}.",
  "apps.listing": "The account lists {count} App ID(s).",
  "apps.address": "Device reachable at {address}.",
  "apps.refreshing": "Refreshing {name}…",
  "apps.refreshingShort": "Refreshing…",
  "apps.refreshed": "{name} is refreshed — the seven days start again now.",
  "apps.refreshFailed": "{name}: {message}",
  "apps.refreshAborted": "The refresh stopped: {message}",
  "apps.refreshDone": "Refreshed {done} of {total} app(s).",
  "apps.reflectionNeeded":
    "The device is not reachable right now, and a refresh started from Shortcuts does not bring the " +
    "VPN up. Open SideInstaller once with the VPN (or your proxy app) connected, then run this again.",
  "intent.done": "Refreshed {refreshed} of {total} app(s).",
  "intent.none": "No app here matches “{wanted}”.",
  "intent.timeout":
    "The refresh did not finish in time. A background run needs the VPN (or your proxy app) already " +
    "connected — open SideInstaller once and try again.",
  "apps.appIdMissing":
    "The App ID {identifier} is not on this account any more, so there is no profile to cut for it.",
  "apps.stopping": "Stopping after this app.",

  "tab.apps": "Apps",
  "apps.header.count": "{count} app(s)",
  "apps.header.urgent": "{count} need refreshing",
  "apps.refreshAll": "Refresh all",
  "apps.stop": "Stop",
  "apps.canRefresh":
    "{count} app(s) here can have their profile renewed with your Apple ID. The app keeps its data, " +
    "and its seven days start again.",
  "apps.empty": "Nothing installed from this app yet.",
  "apps.removeTitle": "Remove {name} from the list?",
  "apps.removeMessage": "This drops the record on this page only. The app on the device is left alone.",
  "apps.removeAction": "Remove from List",
  "apps.removed": "Removed {name} from the list.",
  "apps.menuMessage":
    "Enable JIT attaches a debugger to this app; removing drops it from this list only.",
  "apps.jitAction": "Enable JIT",
  "apps.jitWorking": "Enabling JIT",
  "apps.jitBegin": "Enabling JIT for {name}…",
  "apps.jitLaunched": "Started stopped at the entry point (pid {pid}).",
  "apps.jitAttached": "Debugger attached.",
  "apps.jitRegions": "Prepared {count} executable region(s).",
  "apps.jitDone": "{name} can use JIT now ({count} region(s)).",
  "apps.jitNoRequest": "{name} never asked for JIT, so nothing was prepared.",
  "apps.jitFailed": "Could not enable JIT for {name} — {message}",
  "apps.jitStage.launch": "launching the app",
  "apps.jitStage.attach": "attaching the debugger",
  "apps.jitStage.regions": "preparing executable regions",
  "apps.jitStage.detach": "detaching",
  "apps.ddi.check": "Checking for the developer image…",
  "apps.ddi.download": "Downloading the developer image…",
  "apps.ddi.identify": "Reading this device's identifiers…",
  "apps.ddi.nonce": "Reading the cryptex nonce…",
  "apps.ddi.ticket": "Asking Apple to sign the image…",
  "apps.ddi.install": "Installing the developer image…",
  "apps.ddi.verify": "Checking the image the device reports…",
  "apps.ddiDownload": "Getting {detail}.",
  "apps.ddiDetail": "{stage}: {detail}",
  "apps.ddiInstalled": "Developer image installed ({version}).",
  "apps.ddiReady": "Developer image already mounted ({version}).",
  "apps.ddiMountConflict":
    "Something already holds /System/Developer but the device will not report it as mounted. " +
    "Restart the device and try again. ({message})",
  "apps.otherAccount":
    "These were signed by another Apple ID, so they are not refreshed here — that account has to.",
  "apps.otherAccountBadge": "Other account",
  "apps.switchAccount": "Switch",
  "apps.switchingAccount": "Switching…",
  "apps.unknownAccount": "Unknown account",
  "apps.expired": "Expired {date}",
  "apps.expiresToday": "Expires today",
  "apps.expiresTomorrow": "Expires tomorrow",
  "apps.expiresInDays": "{days} days left",
  "apps.noProfile": "No profile found",

  "language.system": "System ({name})",
  "language.name.en": "English",
  "language.name.zh-Hant": "繁體中文",
  "language.name.zh-Hans": "简体中文",
} as const

export type TranslationKey = keyof typeof en
export type Catalog = Partial<Record<TranslationKey, string>>
