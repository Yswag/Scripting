// A small hand-rolled catalogue layer. The runtime has no localisation facility, so this is
// deliberate: English is the source of truth (`lib/i18n/en.ts`), other locales are partial
// maps that fall back to English per key, and a missing key shows itself rather than blank.
import { en, type Catalog, type TranslationKey } from "./en"
import { zhHant } from "./zh-Hant"
import { zhHans } from "./zh-Hans"

export type LocaleId = "en" | "zh-Hant" | "zh-Hans"
export type LocalePreference = "system" | LocaleId

const CATALOGS: Record<LocaleId, Catalog> = {
  en: en as Catalog,
  "zh-Hant": zhHant,
  "zh-Hans": zhHans,
}

export const availableLocales = Object.keys(CATALOGS) as LocaleId[]

const FALLBACK: LocaleId = "en"
const STORAGE_KEY = "i18n.locale"

export interface Translate {
  (key: TranslationKey, params?: Record<string, string | number>): string
}

// MARK: - tag handling

/** Regions that use Traditional; everything else defaults to Simplified. */
const TRADITIONAL_REGIONS = new Set(["TW", "HK", "MO", "Hant"])

/**
 * Best-effort script subtag for a tag. `Intl.Locale#maximize` does this properly; the region
 * table is the fallback for runtimes where it is missing or throws.
 */
export function scriptOf(tag: string): string | null {
  const normalized = tag.replace(/_/g, "-")
  const IntlAny: any = (globalThis as any).Intl
  if (IntlAny?.Locale !== undefined) {
    try {
      const maximized = new IntlAny.Locale(normalized).maximize()
      if (typeof maximized?.script === "string" && maximized.script.length > 0) return maximized.script
    } catch {
      // fall through to the region table
    }
  }
  const region = normalized.split("-")[1]
  if (region === undefined) return null
  const upper = region.toUpperCase()
  if (TRADITIONAL_REGIONS.has(upper)) return "Hant"
  // A bare 4-letter script already in the tag.
  if (/^[A-Za-z]{4}$/.test(region)) return region[0].toUpperCase() + region.slice(1).toLowerCase()
  return "Hans"
}

/**
 * Maps a BCP-47 tag onto a catalogue, most specific first:
 * exact tag -> language+script -> language -> English.
 */
export function resolveLocale(tag: string): LocaleId {
  const normalized = tag.replace(/_/g, "-")
  const parts = normalized.split("-").filter(p => p.length > 0)
  if (parts.length === 0) return FALLBACK
  const language = parts[0].toLowerCase()

  const candidates: string[] = [normalized]
  const script = scriptOf(normalized)
  if (script !== null) candidates.push(`${language}-${script}`)
  candidates.push(language)

  for (const candidate of candidates) {
    for (const id of availableLocales) {
      if (id.toLowerCase() === candidate.toLowerCase()) return id
    }
  }
  return FALLBACK
}

// MARK: - state

let preference: LocalePreference = "system"
let active: LocaleId = FALLBACK
const listeners = new Set<() => void>()

function notify() {
  for (const listener of listeners) listener()
}

/** The tag the system reports. `Intl` is the only reliable source here. */
export function systemTag(): string {
  const IntlAny: any = (globalThis as any).Intl
  try {
    const locale = new IntlAny.DateTimeFormat().resolvedOptions().locale
    if (typeof locale === "string" && locale.length > 0) return locale
  } catch {
    // fall through
  }
  return "en"
}

function recompute() {
  active = preference === "system" ? resolveLocale(systemTag()) : (CATALOGS[preference] ? preference : FALLBACK)
  notify()
}

/**
 * Loads the saved preference. The caller must already hold `fileSystem` access — reading
 * `Storage` before that grant settles hands back an empty store, which would silently reset
 * the language.
 *
 * Deliberately does NOT call `Script.requestAccess`: that is per-script, so it raises an
 * app-modal prompt the first time any new file runs, which hangs anything unattended. The
 * request belongs in the entry point, where a person is there to answer it.
 */
export async function initI18n(): Promise<void> {
  const saved = Storage.get<string>(STORAGE_KEY)
  if (saved === "system" || (saved !== null && saved in CATALOGS)) {
    preference = saved as LocalePreference
  }
  recompute()
}

export function getPreference(): LocalePreference {
  return preference
}

export function getLocale(): LocaleId {
  return active
}

export function setPreference(next: LocalePreference) {
  preference = next
  Storage.set(STORAGE_KEY, next)
  recompute()
}

export function subscribeToLocale(listener: () => void): () => void {
  listeners.add(listener)
  return () => {
    listeners.delete(listener)
  }
}

// MARK: - translation

function interpolate(template: string, params?: Record<string, string | number>): string {
  if (params === undefined) return template
  return template.replace(/\{(\w+)\}/g, (match, name: string) => {
    const value = params[name]
    return value === undefined ? match : String(value)
  })
}

/**
 * Resolves a key against the active catalogue, then English, then the key itself. The last
 * step is deliberate: a missing string is visible during development instead of blank.
 */
export const t: Translate = (key, params) => {
  const catalog = CATALOGS[active]
  const localized = catalog?.[key]
  if (typeof localized === "string" && localized.length > 0) return interpolate(localized, params)
  const english = (en as Catalog)[key]
  if (typeof english === "string" && english.length > 0) return interpolate(english, params)
  return String(key)
}

/** Display name for a catalogue. Falls back to the locale id. */
export function localeName(id: LocaleId): string {
  const key = `language.name.${id}` as TranslationKey
  const name = t(key)
  return name === key ? id : name
}

export type { TranslationKey, Catalog }
