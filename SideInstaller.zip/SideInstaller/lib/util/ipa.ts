/**
 * IPA unpacking: an archive in, `Payload/<name>.app` out.
 *
 * Everything goes through the `FileManager` namespace — `existsSync`, `readDirectorySync`,
 * `removeSync`, `unzip`. There is no instance API here (`FileManager.iCloud()`, `joinPath`, `mkdir`,
 * `listDirectory` do not exist in this runtime), and the path helpers are properties, not calls.
 */

export interface UnpackedIpa {
  /** The `.app` bundle directory, `Payload/<name>.app` inside `workDir`. */
  appPath: string
  /** The bundle's file name, extension included: `"SideStore.app"`. */
  bundleName: string
  /** The directory it was unpacked into. */
  workDir: string
}

function fm(): any {
  const manager: any = (globalThis as any).FileManager
  if (manager === undefined) throw new Error("unpackIpa: this build has no FileManager")
  return manager
}

/** The `.app` directories directly under `Payload/`. A real IPA has exactly one. */
function appBundlesIn(manager: any, payloadDir: string): string[] {
  return (manager.readDirectorySync(payloadDir) as string[])
    .filter(name => name.endsWith(".app"))
    .filter(name => manager.isDirectorySync(`${payloadDir}/${name}`))
    .sort()
}

/**
 * Unpacks an IPA into `workDir` and returns the bundle inside it.
 *
 * The work directory is emptied first: contents left by an earlier run would shadow the archive,
 * and a stale `Payload/` reads exactly like this run's output. Whatever `workDir` holds is
 * disposable, so it is removed rather than added to.
 *
 * The archive is not validated beyond having a `Payload/` with one `.app` in it — this is a
 * `.ipa`, not a general-purpose unzipper.
 */
export async function unpackIpa(ipaPath: string, workDir: string): Promise<UnpackedIpa> {
  const manager = fm()

  if (!manager.existsSync(ipaPath)) {
    throw new Error(`unpackIpa: no archive at ${ipaPath}`)
  }
  if (manager.existsSync(workDir)) manager.removeSync(workDir)
  manager.createDirectorySync(workDir, true)

  await manager.unzip(ipaPath, workDir)

  const payloadDir = `${workDir}/Payload`
  if (!manager.existsSync(payloadDir)) {
    throw new Error(`unpackIpa: ${ipaPath} has no Payload directory`)
  }

  const bundles = appBundlesIn(manager, payloadDir)
  if (bundles.length === 0) {
    throw new Error(`unpackIpa: ${ipaPath} has no .app bundle in Payload/`)
  }
  if (bundles.length > 1) {
    // Not a decision to make here: an archive with two applications in it is not a build of one.
    throw new Error(`unpackIpa: ${ipaPath} has ${bundles.length} .app bundles in Payload/ — ${bundles.join(", ")}`)
  }

  return {
    appPath: `${payloadDir}/${bundles[0]}`,
    bundleName: bundles[0],
    workDir,
  }
}
