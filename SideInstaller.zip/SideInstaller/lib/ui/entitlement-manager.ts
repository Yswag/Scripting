// The one Entitlements manager the app runs on, and the hook that redraws a page when it changes.
// A module of its own so the page can reach it without importing the shell — and so the picker and
// the list share one session, one set of results and one account.
import { useEffect, useObservable } from "scripting"
import { Entitlements } from "../entitlements"
import { subscribeToLocale } from "../i18n"
import { engine } from "./engine"
import { savedPortal, signIn } from "./cert-manager"

export const entitlements = new Entitlements({
  account: () => engine.savedAccount,
  // The one saved-session opener and the one sign-in the Certificates tool uses: a second pair would
  // be the second way to ask for a password, and the second way to get it wrong.
  savedPortal: (email: string) => savedPortal(email, "entitlements.log.sessionFailed"),
  signIn,
  say: (key, params, level) => engine.say(key, params, level),
})

/** Re-renders a page when the App IDs, a run or the language change. */
export function useEntitlements(): number {
  const tick = useObservable(0)
  useEffect(() => {
    const bump = () => tick.setValue((tick.value ?? 0) + 1)
    const stop = entitlements.subscribe(bump)
    const stopLocale = subscribeToLocale(bump)
    return () => {
      stop()
      stopLocale()
    }
  }, [])
  return tick.value ?? 0
}
