// The one Certificates manager the app runs on, and the hook that redraws a page when it changes.
// A module of its own so the page can reach it without importing the shell.
import { useEffect, useObservable } from "scripting"
import { GSA_CLIENT_INFO, GSA_USER_AGENT, fetchUrlBag, type PortalClient } from "../apple"
import { Certificates } from "../certs"
import { openSavedSession, provisioningFrom, type LogLevel } from "../engine"
import { subscribeToLocale, type TranslationKey } from "../i18n"
import { engine } from "./engine"

/** The engine's log, as the tool writes to it. */
function log(key: TranslationKey, params?: Record<string, string | number>, level?: LogLevel): void {
  engine.say(key, params, level)
}

/**
 * A portal client from the session already saved: the URL bag first (it carries the anisette
 * provisioning endpoints as well), then whatever the stored token buys.
 *
 * A session Apple no longer accepts comes back as null rather than as a throw — "there is nothing to
 * reuse" is an answer, and the caller's next move (ask for the password) is the same either way.
 *
 * Shared with the other portal tools, which is why the log key is the caller's: a session that would
 * not open for the Entitlements page is not news about Certificates.
 */
export async function savedPortal(
  email: string, failureKey: TranslationKey = "certs.log.sessionFailed",
): Promise<PortalClient | null> {
  try {
    const bag = await fetchUrlBag(GSA_CLIENT_INFO, GSA_USER_AGENT)
    return await openSavedSession(email, log, bag, provisioningFrom(bag))
  } catch (error) {
    log(failureKey, { message: error instanceof Error ? error.message : String(error) }, "warn")
    return null
  }
}

/**
 * The sign-in Settings and the gates already run: the anisette candidates, the 2FA prompt, and the
 * session saved at the end of it. The Swift app's tools sign in for themselves; there is nothing here
 * that repeating it would improve.
 */
export const signIn = (email: string): Promise<boolean> => engine.useAccount(email)

export const certificates = new Certificates({
  account: () => engine.savedAccount,
  savedPortal,
  signIn,
  say: log,
})

/** Re-renders a page when the certificates change, or when the language does. */
export function useCertificates(): number {
  const tick = useObservable(0)
  useEffect(() => {
    const bump = () => tick.setValue((tick.value ?? 0) + 1)
    const stop = certificates.subscribe(bump)
    const stopLocale = subscribeToLocale(bump)
    return () => {
      stop()
      stopLocale()
    }
  }, [])
  return tick.value ?? 0
}
