// Entitlements: the page behind the Tools row of the same name. It lists the Apple ID's App IDs and
// asks Apple for developer-portal capabilities on one of them — the Swift app's `EntitlementsView`,
// which is the developer portal alone, so nothing here needs the device link.
//
// What Apple accepts here is only recorded for the App ID: it reaches the app with its next profile,
// which means signing and installing it again. Neither the list nor the picker claims otherwise, and
// nothing reads back what an App ID already holds.
import {
  Button, HStack, Image, NavigationLink, Rectangle, RoundedRectangle, ScrollView, Spacer, Text, VStack,
  ZStack, useObservable, useEffect, type Color,
} from "scripting"
import { t, type TranslationKey } from "../i18n"
import {
  APP_GROUPS_CAPABILITY, CAPABILITY_GROUPS, allCapabilityIds, appDisplayName, capabilitiesIn, capabilityName,
  initialCapabilitySelection, remoteEnabledCapabilityIds, recommendedCapabilityIds,
  type AppIdentifier, type Capability, type CapabilityGroup, type CapabilityOutcome, type EntitlementReport,
} from "../entitlements"
import type { StepError } from "../engine"
import { entitlements, useEntitlements } from "./entitlement-manager"
import { pushedPageToolbar } from "./toolbar"
import {
  ACCENT2, AppBackground, BRAND, ERROR, OK, PanelCard, PopupCard, PrimaryButton, ROUNDED, StatusPill, WARN,
  BrandHeader, MilestoneOverlay, cascadeProps, withAlpha,
} from "./theme"

/** Which heading each half of the picker carries. */
const GROUP_TITLE: Record<CapabilityGroup, TranslationKey> = {
  memory: "entitlements.group.memory",
  other: "entitlements.group.other",
}

// MARK: - the App ID list

/** One App ID: what it is, and what Apple last said about it. */
function AppRow({ app, outcomes }: { app: AppIdentifier; outcomes: CapabilityOutcome[] | undefined }) {
  const granted = outcomes?.filter(outcome => outcome.ok).length ?? 0
  const remote = remoteEnabledCapabilityIds(app.features).size
  return (
    <PanelCard>
      <HStack spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <Image systemName="app.badge.checkmark" font="title3" foregroundStyle={BRAND} />
        <VStack alignment="leading" spacing={3} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Text font="subheadline" fontWeight="semibold" foregroundStyle="label" lineLimit={1}>
            {appDisplayName(app)}
          </Text>
          <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1} truncationMode="middle">
            {app.identifier}
          </Text>
          {remote > 0
            ? <Text font="caption2" fontWeight="semibold" foregroundStyle={OK}>
              {t("entitlements.remoteEnabled", { count: remote })}
            </Text>
            : null}
          {outcomes === undefined
            ? null
            : <Text
              font="caption2"
              fontWeight="semibold"
              foregroundStyle={granted > 0 ? OK : WARN}
            >
              {t("entitlements.lastRun", { count: granted, total: outcomes.length })}
            </Text>}
        </VStack>
        <Spacer />
        <Image systemName="chevron.right" font="subheadline" fontWeight="semibold" foregroundStyle="tertiaryLabel" />
      </HStack>
    </PanelCard>
  )
}

/** What an account with no App IDs at all sees. */
function EmptyAppsCard() {
  return (
    <PanelCard>
      <VStack spacing={8} frame={{ maxWidth: "infinity" }} padding={{ vertical: 8 }}>
        <Image systemName="questionmark.app.dashed" font="largeTitle" foregroundStyle={ACCENT2} />
        <Text font="headline">{t("entitlements.empty.title")}</Text>
        <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment="center">
          {t("entitlements.empty.body")}
        </Text>
      </VStack>
    </PanelCard>
  )
}

// MARK: - popups

/** One capability Apple refused, with its own words. */
function RefusalRow({ outcome }: { outcome: CapabilityOutcome }) {
  return (
    <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
      <Text font="caption" fontWeight="semibold" foregroundStyle="label" multilineTextAlignment="leading">
        {capabilityName(outcome.capability)}
      </Text>
      <Text font="caption2" foregroundStyle="secondaryLabel" multilineTextAlignment="leading">
        {outcome.error}
      </Text>
    </VStack>
  )
}

/** What Apple answered, and what has to happen before any of it means anything. */
function ResultsPopup({ report }: { report: EntitlementReport }) {
  const granted = report.outcomes.filter(outcome => outcome.ok)
  const refused = report.outcomes.filter(outcome => !outcome.ok)
  const appGroups = report.outcomes.some(outcome => outcome.capability === APP_GROUPS_CAPABILITY)

  return (
    <MilestoneOverlay>
      <PopupCard
        title={t("entitlements.enabled", { count: granted.length, total: report.outcomes.length })}
        systemImage={granted.length === 0 ? "exclamationmark.triangle.fill" : "checkmark.seal.fill"}
        tint={granted.length === 0 ? WARN : OK}
        onClose={() => entitlements.closeReport()}
      >
        <VStack alignment="leading" spacing={10} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Text font="subheadline" fontWeight="semibold" multilineTextAlignment="leading">
            {appDisplayName(report.app)}
          </Text>
          {granted.length === 0
            ? null
            : <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment="leading">
              {t("entitlements.results.reinstall")}
            </Text>}
          {appGroups
            ? <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment="leading">
              {t("entitlements.results.appGroups")}
            </Text>
            : null}
          {refused.map(outcome => <RefusalRow key={outcome.capability} outcome={outcome} />)}
        </VStack>
      </PopupCard>
    </MilestoneOverlay>
  )
}

/** Why the run stopped before Apple answered anything. */
function FailurePopup({ failure }: { failure: StepError }) {
  return (
    <MilestoneOverlay>
      <PopupCard
        title={t("entitlements.error.title")}
        systemImage="exclamationmark.triangle.fill"
        tint={ERROR}
        onClose={() => entitlements.closeFailure()}
      >
        <Text font="subheadline" multilineTextAlignment="leading">
          {t(failure.key, failure.params)}
        </Text>
      </PopupCard>
    </MilestoneOverlay>
  )
}

/** The two popups this page can put up, results under an error if both are somehow up. */
function Popups({ report, failure }: { report: EntitlementReport | null; failure: StepError | null }) {
  if (report === null && failure === null) return null
  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      {report === null ? null : <ResultsPopup report={report} />}
      {failure === null ? null : <FailurePopup failure={failure} />}
    </ZStack>
  )
}

// MARK: - the page

export function EntitlementsPage({ onSettings }: { onSettings: () => void }) {
  useEntitlements()
  const manager = entitlements
  const busy = manager.busy
  const apps = manager.apps
  const team = manager.team

  // The Swift app's `onAppear`: the list is fetched when the page opens, and only when that needs no
  // answer from the person.
  useEffect(() => {
    manager.autoLoad()
  }, [])

  // The same deferred entrance the other pages use: a flag flipped straight from `onAppear` has no
  // painted starting state, so the cascade would have nothing to interpolate from.
  const revealed = useObservable(false)
  const reveal = () => {
    setTimeout(() => revealed.setValue(true), 30)
  }
  useEffect(reveal, [])
  const box = (index: number) => ({
    spacing: 0,
    frame: { maxWidth: "infinity" as const, alignment: "leading" as const },
    ...cascadeProps(index, revealed.value === true),
  })

  // No `NavigationStack` of its own: the page is pushed onto the Tools one. Its backdrop keeps the
  // Tools level, which is the darker one.
  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <AppBackground dark />
      <ScrollView
        toolbar={pushedPageToolbar(onSettings)}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        scrollBounceBehavior="basedOnSize"
        onAppear={reveal}
      >
        <VStack spacing={18} frame={{ maxWidth: "infinity" }} padding={20}>
          <VStack {...box(0)}>
            <BrandHeader
              icon="list.bullet.rectangle.fill"
              title={t("tool.entitlements")}
              accessory={team === null
                ? undefined
                : <StatusPill
                  text={t("entitlements.team", { name: team.name, teamId: team.teamId })}
                  systemImage="person.2.fill"
                  color={OK}
                />}
            />
          </VStack>

          <VStack {...box(1)}>
            <PrimaryButton
              title={manager.working
                ? manager.signedIn ? t("entitlements.refreshing") : t("entitlements.signingIn")
                : manager.loaded ? t("entitlements.refresh") : t("entitlements.load")}
              systemImage={manager.loaded ? "arrow.clockwise" : "list.bullet.rectangle.fill"}
              busy={manager.working}
              action={() => { void manager.load() }}
              disabled={busy}
            />
          </VStack>

          {apps.length > 0
            ? <VStack spacing={14} frame={{ maxWidth: "infinity" }}>
              <VStack {...box(2)}>
                <HStack frame={{ maxWidth: "infinity", alignment: "leading" }}>
                  <Text font="subheadline" fontWeight="semibold" foregroundStyle="secondaryLabel">
                    {t("entitlements.count", { count: apps.length })}
                  </Text>
                  <Spacer />
                </HStack>
              </VStack>

              {apps.map((app, index) => (
                <VStack key={app.appIdId} {...box(3 + index)}>
                  <NavigationLink
                    destination={<EntitlementPicker app={app} onSettings={onSettings} />}
                  >
                    <AppRow app={app} outcomes={manager.outcomes[app.appIdId]} />
                  </NavigationLink>
                </VStack>
              ))}
            </VStack>
            : manager.loaded && !manager.working
              ? <VStack {...box(2)}><EmptyAppsCard /></VStack>
              : null}
        </VStack>
      </ScrollView>

      <Popups report={manager.report()} failure={manager.failure} />
    </ZStack>
  )
}

// MARK: - the picker

/** One capability, ticked or not, with what Apple said about it after the last run. */
function CapabilityRow({ capability, selected, remoteEnabled, outcome, disabled, onToggle }: {
  capability: Capability
  selected: boolean
  remoteEnabled: boolean
  outcome: CapabilityOutcome | undefined
  disabled: boolean
  onToggle: () => void
}) {
  return (
    <Button action={onToggle} disabled={disabled} frame={{ maxWidth: "infinity" }}>
      <HStack spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <Image
          systemName={selected ? "checkmark.circle.fill" : "circle"}
          font="title3"
          foregroundStyle={selected ? ACCENT2 : "secondaryLabel"}
        />
        <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          {/* Named rather than left to the button, which tints whatever it wraps. */}
          <Text font="subheadline" fontWeight="medium" foregroundStyle="label" multilineTextAlignment="leading">
            {capability.name}
          </Text>
          <Text
            font="caption2"
            foregroundStyle="secondaryLabel"
            multilineTextAlignment="leading"
            lineLimit={1}
            truncationMode="middle"
          >
            {capability.id}
          </Text>
        </VStack>
        <Spacer />
        {remoteEnabled
          ? <Image systemName="checkmark.seal" foregroundStyle={OK} />
          : null}
        {outcome === undefined
          ? null
          : <Image
            systemName={outcome.ok ? "checkmark.seal.fill" : "xmark.circle.fill"}
            foregroundStyle={outcome.ok ? OK : WARN}
          />}
      </HStack>
    </Button>
  )
}

/** One half of the catalogue: a heading, and a row per capability. */
function CapabilityGroupCard({ group, selected, remoteEnabled, outcomes, disabled, onToggle }: {
  group: CapabilityGroup
  selected: Set<string>
  remoteEnabled: Set<string>
  outcomes: CapabilityOutcome[] | undefined
  disabled: boolean
  onToggle: (id: string) => void
}) {
  const capabilities = capabilitiesIn(group)
  return (
    <PanelCard>
      <VStack alignment="leading" spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
          <Text font="headline" foregroundStyle="label">{t(GROUP_TITLE[group])}</Text>
          {/* Only the memory capabilities are known on free accounts, so the rest are marked Beta. */}
          {group === "other"
            ? <Text font="caption" fontWeight="bold" foregroundStyle={ACCENT2}>{t("entitlements.beta")}</Text>
            : null}
          <Spacer />
        </HStack>

        {capabilities.map((capability, index) => (
          <VStack key={capability.id} spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            {index === 0
              ? null
              : <Rectangle fill="rgba(255,255,255,0.06)" frame={{ maxWidth: "infinity", height: 1 }} />}
            <CapabilityRow
              capability={capability}
              selected={selected.has(capability.id)}
              remoteEnabled={remoteEnabled.has(capability.id)}
              outcome={outcomes?.find(outcome => outcome.capability === capability.id)}
              disabled={disabled}
              onToggle={() => onToggle(capability.id)}
            />
          </VStack>
        ))}
      </VStack>
    </PanelCard>
  )
}

/** A small, tinted choice of what to tick: the upstream "Recommended / Select all / None" row. */
function PresetButton({ title, tint, action }: { title: string; tint: Color; action: () => void }) {
  return (
    <Button action={action}>
      <HStack
        spacing={0}
        background={<RoundedRectangle {...ROUNDED(10)} fill={withAlpha(tint, 0.16)} />}
      >
        <Text
          font="caption"
          fontWeight="semibold"
          foregroundStyle={tint}
          padding={{ horizontal: 11, vertical: 6 }}
        >
          {title}
        </Text>
      </HStack>
    </Button>
  )
}

/** The capabilities to ask for on one App ID, and Apple's answer to the last ask. */
function EntitlementPicker({ app, onSettings }: { app: AppIdentifier; onSettings: () => void }) {
  useEntitlements()
  const manager = entitlements
  const selected = useObservable<Set<string>>(initialCapabilitySelection(app.features))
  const picked = selected.value ?? new Set<string>()
  const outcomes = manager.outcomes[app.appIdId]
  const applying = manager.applyingId === app.appIdId
  const remoteEnabled = remoteEnabledCapabilityIds(app.features)

  const toggle = (id: string) => {
    const next = new Set(picked)
    if (next.has(id)) next.delete(id)
    else next.add(id)
    selected.setValue(next)
  }

  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <AppBackground dark />
      <ScrollView
        toolbar={pushedPageToolbar(onSettings)}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        scrollBounceBehavior="basedOnSize"
        safeAreaInset={{
          bottom: {
            content: (
              <HStack
                spacing={0}
                frame={{ maxWidth: "infinity" }}
                background={<Rectangle fill="#0B0C0E" ignoresSafeArea />}
              >
                <VStack spacing={10} frame={{ maxWidth: "infinity" }} padding={{ horizontal: 20, top: 12, bottom: 16 }}>
                  {/* Said before Apple is asked, not only after: nothing here takes effect on its own. */}
                  <Text
                    font="caption2"
                    foregroundStyle="secondaryLabel"
                    multilineTextAlignment="leading"
                    frame={{ maxWidth: "infinity", alignment: "leading" }}
                  >
                    {t("entitlements.apply.note")}
                  </Text>
                  <PrimaryButton
                    title={applying
                      ? t("entitlements.applying")
                      : t("entitlements.apply", { count: picked.size })}
                    systemImage="checkmark.seal"
                    busy={applying}
                    disabled={picked.size === 0 || manager.busy}
                    action={() => { void manager.enable(Array.from(picked), app) }}
                  />
                </VStack>
              </HStack>
            ),
          },
        }}
      >
        <VStack spacing={18} frame={{ maxWidth: "infinity" }} padding={{ horizontal: 20, top: 20, bottom: 28 }}>
          <PanelCard>
            <VStack alignment="leading" spacing={6} frame={{ maxWidth: "infinity", alignment: "leading" }}>
              <Text font="title3" fontWeight="bold" foregroundStyle="label" multilineTextAlignment="leading">
                {appDisplayName(app)}
              </Text>
              <Text font="caption" foregroundStyle="secondaryLabel" lineLimit={1} truncationMode="middle">
                {app.identifier}
              </Text>
              <HStack spacing={10} frame={{ maxWidth: "infinity", alignment: "leading" }} padding={{ top: 4 }}>
                <PresetButton
                  title={t("entitlements.recommended")}
                  tint={ACCENT2}
                  action={() => selected.setValue(recommendedCapabilityIds())}
                />
                <PresetButton
                  title={t("entitlements.selectAll")}
                  tint={ACCENT2}
                  action={() => selected.setValue(allCapabilityIds())}
                />
                <PresetButton
                  title={t("entitlements.none")}
                  tint="#8E8E93"
                  action={() => selected.setValue(new Set<string>())}
                />
                <Spacer />
              </HStack>
            </VStack>
          </PanelCard>

          {CAPABILITY_GROUPS.map(group => (
            <CapabilityGroupCard
              key={group}
              group={group}
              selected={picked}
              remoteEnabled={remoteEnabledCapabilityIds(app.features)}
               outcomes={outcomes}
              disabled={manager.busy}
              onToggle={toggle}
            />
          ))}
        </VStack>
      </ScrollView>

      <Popups report={manager.report()} failure={manager.failure} />
    </ZStack>
  )
}
