// The door into the UI package: the shell, and nothing else.
export { RootView } from "./root"
