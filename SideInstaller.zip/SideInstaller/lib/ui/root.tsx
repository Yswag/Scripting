// The app shell: three tabs (Install, Apps, Tools), each drawing its own backdrop, and settings in
// the top right of every page's bar. Laid out like the iOS app this is a port of, and kept out of
// the entry point so it can be rendered on its own (see `dev/preview-ui.tsx`).
import { TabView, Tab, useObservable } from "scripting"
import { t } from "../i18n"
import { useLiveTick } from "./engine"
import { AppsPage } from "./apps"
import { InstallPage } from "./install"
import { ToolsPage } from "./tools"
import { SettingsPage } from "./settings"
import { DARK_SCHEME } from "./theme"

export function RootView() {
  useLiveTick()
  const page = useObservable("install")
  const settings = useObservable(false)

  const openSettings = () => settings.setValue(true)

  // The backdrop is drawn per page, as the Swift app does: a copy hung on the TabView instead was
  // never painted at all (dev/probe-backdrop.tsx).
  return (
    <TabView
      {...DARK_SCHEME}
      selection={page}
      sheet={{ isPresented: settings, content: <SettingsPage /> }}
    >
        <Tab title={t("tab.install")} systemImage="square.and.arrow.down" value="install">
          <InstallPage onSettings={openSettings} />
        </Tab>
        <Tab title={t("tab.apps")} systemImage="app.badge.clock" value="apps">
          <AppsPage onSettings={openSettings} />
        </Tab>
        <Tab title={t("tab.tools")} systemImage="wrench.and.screwdriver" value="tools">
          <ToolsPage onSettings={openSettings} />
        </Tab>
    </TabView>
  )
}

export default RootView
