// The developer image's files on this device: whether they are here, and the two things Settings
// offers — fetch them now, or drop them so the next run fetches them again.
import { useEffect, useObservable } from "scripting"
import { DDI_FILES, ddiDirectory, ensureDdiFiles, forgetDdiDownloads, nativeDdiDownloader } from "../ddi"
import { subscribeToLocale } from "../i18n"

export interface DeveloperImageState {
  /** Every file of the image is on disk. */
  ready: boolean
  present: number
  total: number
  /** What is already on disk. */
  bytes: number
  /** How far a download has got, 0..1, or null when none is running. */
  progress: number | null
  busy: boolean
  /** Why the last download failed, or "" when it did not. */
  failure: string
}

class DeveloperImage {
  private readonly listeners = new Set<() => void>()
  private progress: number | null = null
  private busy = false
  private failure = ""

  /** Read from disk each time: the files are the state. */
  get state(): DeveloperImageState {
    const manager: any = (globalThis as any).FileManager
    let present = 0
    let bytes = 0
    for (const item of DDI_FILES) {
      if (manager?.existsSync === undefined) break
      const path = `${ddiDirectory()}/${item.file}`
      if (manager.existsSync(path) !== true) continue
      present++
      try {
        bytes += Number(manager.statSync(path)?.size ?? 0)
      } catch {
        // A file we cannot measure still counts as present.
      }
    }
    return {
      ready: present === DDI_FILES.length,
      present,
      total: DDI_FILES.length,
      bytes,
      progress: this.progress,
      busy: this.busy,
      failure: this.failure,
    }
  }

  /** Fetches whatever is missing. Safe to call while another download is running: it is a no-op. */
  async download(): Promise<void> {
    if (this.busy) return
    this.busy = true
    this.failure = ""
    this.progress = 0
    this.notify()

    let reported = -1
    try {
      await ensureDdiFiles(nativeDdiDownloader(), (index, fraction) => {
        // One number for the whole image, so the bar moves across files too.
        this.progress = (index + fraction) / DDI_FILES.length
        const percent = Math.round(this.progress * 100)
        if (percent === reported) return
        reported = percent
        this.notify()
      })
      this.progress = 1
    } catch (error) {
      this.failure = error instanceof Error ? error.message : String(error)
    } finally {
      this.progress = null
      this.busy = false
      this.notify()
    }
  }

  /** Drops the files. The image on the device is untouched; only the download is repeated. */
  async deleteFiles(): Promise<void> {
    const manager: any = (globalThis as any).FileManager
    const directory = ddiDirectory()
    try {
      if (manager?.existsSync?.(directory) === true) manager.removeSync(directory)
      await forgetDdiDownloads()
      this.failure = ""
    } catch (error) {
      this.failure = error instanceof Error ? error.message : String(error)
    }
    this.notify()
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  private notify(): void {
    for (const listener of this.listeners) listener()
  }
}

export const developerImage = new DeveloperImage()

/** Re-renders a page when the files change, or when the language does. */
export function useDeveloperImage(): number {
  const tick = useObservable(0)
  useEffect(() => {
    const bump = () => tick.setValue((tick.value ?? 0) + 1)
    const stop = developerImage.subscribe(bump)
    const stopLocale = subscribeToLocale(bump)
    return () => {
      stop()
      stopLocale()
    }
  }, [])
  return tick.value ?? 0
}

/** Bytes as the one line Settings shows: "15.2 MB". */
export function megabytes(bytes: number): string {
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}
