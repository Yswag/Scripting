// Tools: the menu of utility pages, laid out like the Swift app's `ToolsView` — a large title over one
// card per tool, each pushing its own page.
import {
  HStack, Image, Navigation, NavigationLink, NavigationStack, Rectangle, ScrollView,
  Spacer, Text, VStack, ZStack, useObservable, useEffect, type VirtualNode,
} from "scripting"
import { t } from "../i18n"
import { CertsPage } from "./certs"
import { EntitlementsPage } from "./entitlements"
import { useLiveTick } from "./engine"
import { PairingPage } from "./pairing"
import { pageToolbar } from "./toolbar"
import { AppBackground, BRAND, DARK_SCHEME, PanelCard, ROUNDED, cascadeProps } from "./theme"

/**
 * The inside of a tool row: its glyph on the brand gradient, its name, and whatever sits on the right.
 * The name is styled rather than left to the container, which tints a tappable row's label.
 */
function ToolRowBody({ systemImage, title, trailing }: {
  systemImage: string
  title: string
  trailing: VirtualNode
}) {
  return (
    <PanelCard>
      <HStack spacing={14} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <ZStack frame={{ width: 46, height: 46 }} clipShape={ROUNDED(12)}>
          <Rectangle fill={BRAND} frame={{ width: 46, height: 46 }} />
          <Image systemName={systemImage} font={22} fontWeight="semibold" foregroundStyle="white" />
        </ZStack>

        <Text font="headline" foregroundStyle="label">{title}</Text>

        <Spacer />

        {trailing}
      </HStack>
    </PanelCard>
  )
}

/** A tool with a page behind it. */
function ToolLink({ systemImage, title, destination }: {
  systemImage: string
  title: string
  destination: VirtualNode
}) {
  return (
    <NavigationLink destination={destination}>
      <ToolRowBody
        systemImage={systemImage}
        title={title}
        trailing={(
          <Image systemName="chevron.right" font="subheadline" fontWeight="semibold" foregroundStyle="tertiaryLabel" />
        )}
      />
    </NavigationLink>
  )
}

export function ToolsPage({ onSettings }: { onSettings: () => void }) {
  const dismiss = Navigation.useDismiss()
  useLiveTick()

  // The same deferred entrance the install page uses: a flag flipped straight from `onAppear` has
  // no painted starting state, so the cascade would have nothing to interpolate from.
  const revealed = useObservable(false)
  const reveal = () => {
    setTimeout(() => revealed.setValue(true), 30)
  }
  useEffect(reveal, [])
  const box = (index: number) => ({
    spacing: 0,
    frame: { maxWidth: "infinity" as const, alignment: "leading" as const },
    ...cascadeProps(index, revealed.value === true),
  })

  return (
    <NavigationStack {...DARK_SCHEME}>
      <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
        <AppBackground />
        <ScrollView
          toolbar={pageToolbar(dismiss, onSettings)}
          frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
          scrollBounceBehavior="basedOnSize"
          onAppear={reveal}
        >
          <VStack spacing={18} frame={{ maxWidth: "infinity" }} padding={{ horizontal: 20, top: 20, bottom: 28 }}>
            <VStack {...box(0)}>
              <Text font="largeTitle" fontWeight="bold" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                {t("tab.tools")}
              </Text>
            </VStack>

            <VStack {...box(1)}>
              {/* The original hides this one below iOS 27, where a phone cannot pair itself; this port
                  pairs on the device it runs on, so the row is always there. */}
              <ToolLink
                systemImage="iphone.gen3.radiowaves.left.and.right"
                title={t("tool.pairing")}
                destination={<PairingPage onSettings={onSettings} />}
              />
            </VStack>

            <VStack {...box(2)}>
              <ToolLink
                systemImage="checkmark.seal"
                title={t("tool.certificates")}
                destination={<CertsPage onSettings={onSettings} />}
              />
            </VStack>

            <VStack {...box(3)}>
              <ToolLink
                systemImage="list.bullet.rectangle"
                title={t("tool.entitlements")}
                destination={<EntitlementsPage onSettings={onSettings} />}
              />
            </VStack>
          </VStack>
        </ScrollView>
      </ZStack>
    </NavigationStack>
  )
}
