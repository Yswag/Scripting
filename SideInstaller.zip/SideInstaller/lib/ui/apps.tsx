// Apps: what this app has installed, the profile each one is running under, how long that profile
// has left, and the one action that renews it.
//
// The list is the engine's own records, so the page paints immediately and needs no device link;
// only a refresh touches the device, and only to install a profile. Each row carries its own
// countdown pill, which is also that row's refresh button — there is no separate progress card.
import {
  Button, Capsule, GeometryReader, HStack, Image, Navigation, NavigationStack, ProgressView, Rectangle, ScrollView, Spacer,
  Text, VStack, ZStack, gradient, modifiers, useObservable, useEffect,
  type Color,
} from "scripting"
import {
  daysLeft, expiryOf, urgencyOf,
  type ExpiryUrgency, type InstalledRecord,
} from "../apps"
import { t } from "../i18n"
import type { RefreshJob } from "../engine"
import { engine, useLiveTick } from "./engine"
import { pageToolbar } from "./toolbar"
import {
  ACCENT2, AppBackground, DARK_SCHEME, ERROR, OK, PanelCard,
  WARN, cascadeProps, withAlpha,
} from "./theme"

/** A record's remaining time, as the colour its band stands for. */
const URGENCY_COLOR: Record<ExpiryUrgency, Color> = {
  expired: ERROR,
  critical: ERROR,
  soon: WARN,
  later: ACCENT2,
  comfortable: OK,
  unknown: "secondaryLabel",
}

const URGENCY_SYMBOL: Record<ExpiryUrgency, string> = {
  expired: "exclamationmark.triangle.fill",
  critical: "clock.badge.exclamationmark.fill",
  soon: "clock.fill",
  later: "clock.fill",
  comfortable: "checkmark.circle.fill",
  unknown: "questionmark.circle",
}

/** A date short enough to fit a row: "23 Aug". */
function shortDate(date: Date): string {
  try {
    return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(date)
  } catch {
    return date.toISOString().slice(0, 10)
  }
}

function expiryText(record: InstalledRecord): string {
  const expiry = expiryOf(record)
  if (expiry === null) return t("apps.noProfile")
  const days = daysLeft(record)
  if (urgencyOf(record) === "expired") return t("apps.expired", { date: shortDate(expiry) })
  if (days === null) return t("apps.noProfile")
  if (days <= 0) return t("apps.expiresToday")
  if (days === 1) return t("apps.expiresTomorrow")
  return t("apps.expiresInDays", { days })
}

/**
 * The countdown, as a capsule that refreshes the app when tapped — SideStore's arrangement.
 *
 * While that app is being refreshed the capsule keeps its words and shows a spinner in place of the
 * glyph, so the row still says how much time is left.
 */
function CountdownPill({ record, job, canRefresh }: {
  record: InstalledRecord
  job: RefreshJob | undefined
  canRefresh: boolean
}) {
  const urgency = urgencyOf(record)
  const isWorking = job?.state === "pending" || job?.state === "working"
  const isDone = job?.state === "done"
  const isFailed = job?.state === "failed"

  const color = isFailed ? ERROR : isDone ? OK : isWorking ? ACCENT2 : URGENCY_COLOR[urgency]
  const symbol = isFailed
    ? "exclamationmark.triangle.fill"
    : isDone
      ? "checkmark.circle.fill"
      : URGENCY_SYMBOL[urgency]

  const text = isWorking
    ? t("apps.refreshingShort")
    : expiryText(record)

  const body = (
    <HStack
      spacing={6}
      padding={{ horizontal: 12, vertical: 0 }}
      frame={{ height: 28 }}
      background={
        <Capsule
          fill={withAlpha(color, isWorking ? 0.28 : isDone ? 0.35 : 0.16)}
        />
      }
      overlay={isDone
        ? <Capsule stroke={{ shapeStyle: withAlpha(OK, 0.7), strokeStyle: { lineWidth: 1 } }} />
        : undefined}
      contentShape="capsule"
      scaleEffect={isDone ? 1.05 : 1}
      animation={{ animation: Animation.spring({ duration: 0.35, bounce: 0.2 }), value: job?.state ?? "idle" }}
    >
      <ZStack frame={{ width: 14, height: 14 }}>
        {isWorking
          ? <ProgressView controlSize="mini" tint={color} />
          : (
            <Image
              systemName={symbol}
              font="caption"
              fontWeight="semibold"
              foregroundStyle={color}
            />
          )}
      </ZStack>
      <Text font="caption" fontWeight="semibold" foregroundStyle={color}>
        {text}
      </Text>
    </HStack>
  )

  if (!canRefresh) return body
  return (
    <Button
      action={() => {
        withAnimation(Animation.spring({ duration: 0.35, bounce: 0.2 }), () => {
          engine.refreshApps([record.identifier])
        })
      }}
      disabled={isWorking}
    >
      {body}
    </Button>
  )
}

/** One app: its name, the App ID it was signed as, and the countdown that also refreshes it. */
function AppRow({ record, job, canRefresh }: {
  record: InstalledRecord
  job: RefreshJob | undefined
  canRefresh: boolean
}) {
  return (
    <VStack alignment="leading" spacing={6} frame={{ maxWidth: "infinity", alignment: "leading" }}>
      <HStack spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <VStack alignment="leading" spacing={3} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Text font="headline" foregroundStyle="label">{record.name}</Text>
          <Text
            font="caption2"
            foregroundStyle="tertiaryLabel"
            lineLimit={1}
            truncationMode="middle"
            frame={{ maxWidth: "infinity", alignment: "leading" }}
          >
            {record.version.length > 0 ? `${record.identifier} · ${record.version}` : record.identifier}
          </Text>
        </VStack>
        <Spacer />
        <CountdownPill record={record} job={job} canRefresh={canRefresh} />
      </HStack>
      {job?.state === "failed" && job.reason.length > 0
        ? (
          <Text font="caption2" foregroundStyle={ERROR} multilineTextAlignment="leading" frame={{ maxWidth: "infinity", alignment: "leading" }}>
            {job.reason}
          </Text>
        )
        : null}
    </VStack>
  )
}

/** An animated marquee border trimmed to a capsule, ported from the long-screenshot tool. */
function CapsuleMarqueeBorder({
  colors,
  lineWidth = 1.5,
  duration = 4.5,
}: {
  colors: [Color, Color]
  lineWidth?: number
  duration?: number
}) {
  const rotation = useObservable(0)
  useEffect(() => {
    withAnimation(Animation.linear(duration).repeatForever(false), () => {
      rotation.setValue(360)
    })
  }, [])

  return (
    <GeometryReader
      frame={{
        maxWidth: "infinity",
        maxHeight: "infinity",
        alignment: "center",
      }}
      allowsHitTesting={false}
    >
      {({ size }) => {
        const frame = {
          width: size.width,
          height: size.height,
        }
        const beamDim = Math.max(frame.width, frame.height) * 1.5

        return (
          <ZStack
            frame={frame}
            compositingGroup
            modifiers={modifiers().mask(
              <Capsule
                frame={frame}
                stroke={{
                  shapeStyle: "white",
                  strokeStyle: { lineWidth, lineJoin: "round" },
                }}
              />
            )}
          >
            <Rectangle
              frame={{ width: beamDim, height: beamDim }}
              fill={gradient("angular", {
                stops: [
                  { color: "clear", location: 0 },
                  { color: "clear", location: 0.62 },
                  { color: colors[0], location: 0.8 },
                  { color: colors[1], location: 0.93 },
                  { color: colors[0], location: 0.98 },
                  { color: "clear", location: 1 },
                ],
                center: { x: 0.5, y: 0.5 },
                startAngle: { type: "degrees", value: 0 },
                endAngle: { type: "degrees", value: 360 },
              })}
              rotationEffect={{ degrees: rotation.value ?? 0, anchor: { x: 0.5, y: 0.5 } }}
            />
          </ZStack>
        )
      }}
    </GeometryReader>
  )
}

/** Floating refresh pill that hovers above the bottom tab bar. */
function FloatingRefreshPill({
  refreshing,
  count,
  onRefresh,
  onCancel,
}: {
  refreshing: boolean
  count: number
  onRefresh: () => void
  onCancel: () => void
}) {
  if (!refreshing && count === 0) return null

  return (
    <HStack padding={{ bottom: 20 }} frame={{ maxWidth: "infinity" }}>
      <Button action={refreshing ? onCancel : onRefresh}>
        <HStack
          spacing={8}
          padding={{ horizontal: 18, vertical: 11 }}
          background={
            <Capsule
              fill={refreshing ? withAlpha(ERROR, 0.24) : "rgba(18, 26, 42, 0.92)"}
            />
          }
          overlay={
            <CapsuleMarqueeBorder
              colors={
                refreshing
                  ? ["rgba(255, 69, 58, 0.4)", "rgba(255, 120, 110, 1.0)"]
                  : ["rgba(96, 165, 250, 0.4)", "rgba(255, 255, 255, 1.0)"]
              }
              lineWidth={1.5}
              duration={4}
            />
          }
          shadow={{
            color: refreshing ? withAlpha(ERROR, 0.35) : "rgba(0, 0, 0, 0.45)",
            radius: 16,
            x: 0,
            y: 6,
          }}
          contentShape="capsule"
          animation={{ animation: Animation.spring({ duration: 0.4, bounce: 0.2 }), value: refreshing }}
        >
          {refreshing
            ? <ProgressView controlSize="mini" tint={ERROR} />
            : (
              <Image
                systemName="arrow.triangle.2.circlepath"
                font="subheadline"
                fontWeight="semibold"
                foregroundStyle={ACCENT2}
              />
            )}
          <Text
            font="subheadline"
            fontWeight="semibold"
            foregroundStyle={refreshing ? ERROR : "label"}
          >
            {refreshing ? t("apps.stop") : t("apps.refreshAll")}
          </Text>
        </HStack>
      </Button>
    </HStack>
  )
}

export function AppsPage({ onSettings }: { onSettings: () => void }) {
  const dismiss = Navigation.useDismiss()
  useLiveTick()

  // The same deferred entrance the other pages use: a flag flipped straight from `onAppear` has no
  // painted starting state to interpolate from.
  const revealed = useObservable(false)
  const reveal = () => {
    setTimeout(() => revealed.setValue(true), 30)
  }
  useEffect(reveal, [])

  const box = (index: number) => ({
    spacing: 0,
    frame: { maxWidth: "infinity" as const, alignment: "leading" as const },
    ...cascadeProps(index, revealed.value === true),
  })

  const records = engine.installedApps
  const jobs = engine.refreshJobs
  const jobOf = new Map(jobs.map(job => [job.bundleId, job]))
  const refreshable = new Set(engine.refreshableApps.map(record => record.identifier))
  const refreshing = engine.isRefreshing

  return (
    <NavigationStack {...DARK_SCHEME}>
      <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
        <AppBackground />
        <ScrollView
          toolbar={pageToolbar(dismiss, onSettings)}
          frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
          scrollBounceBehavior="basedOnSize"
          safeAreaInset={{
            bottom: {
              content: (
                <FloatingRefreshPill
                  refreshing={refreshing}
                  count={refreshable.size}
                  onRefresh={() => {
                    withAnimation(Animation.spring({ duration: 0.35, bounce: 0.2 }), () => {
                      engine.refreshApps()
                    })
                  }}
                  onCancel={() => {
                    withAnimation(Animation.spring({ duration: 0.35, bounce: 0.2 }), () => {
                      engine.cancelRefresh()
                    })
                  }}
                />
              ),
            },
          }}
          onAppear={reveal}
        >
          <VStack spacing={18} frame={{ maxWidth: "infinity" }} padding={{ horizontal: 20, top: 20, bottom: 28 }}>
            <VStack {...box(0)}>
              <Text font="largeTitle" fontWeight="bold" frame={{ maxWidth: "infinity", alignment: "leading" }}>
                {t("tab.apps")}
              </Text>
            </VStack>

            <VStack {...box(1)}>
              <PanelCard>
                {records.length === 0
                  ? (
                    <Text
                      font="subheadline"
                      foregroundStyle="secondaryLabel"
                      multilineTextAlignment="leading"
                      frame={{ maxWidth: "infinity", alignment: "leading" }}
                    >
                      {t("apps.empty")}
                    </Text>
                  )
                  : (
                    <VStack alignment="leading" spacing={14} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                      {records.map(record => (
                        <AppRow
                          key={record.identifier}
                          record={record}
                          job={jobOf.get(record.identifier)}
                          canRefresh={refreshable.has(record.identifier)}
                        />
                      ))}
                    </VStack>
                  )}
              </PanelCard>
            </VStack>

            {records.length > 0 && refreshable.size === 0 && !refreshing
              ? (
                <VStack {...box(2)}>
                  <Text
                    font="caption"
                    foregroundStyle="tertiaryLabel"
                    multilineTextAlignment="leading"
                    frame={{ maxWidth: "infinity", alignment: "leading" }}
                  >
                    {t("apps.otherAccount")}
                  </Text>
                </VStack>
              )
              : null}
          </VStack>
        </ScrollView>
      </ZStack>
    </NavigationStack>
  )
}
