// Settings: the sheet the Swift app's `SettingsView` opens — the Apple ID it signs with, the device
// link, the language, and the activity log. Downloaded IPAs, Anisette Server and Advanced have no
// counterpart in this port.
import {
  Button, HStack, Image, List, Navigation, NavigationStack, Picker, ProgressView, ScrollView, Section,
  Text, TextField, Toolbar, ToolbarItem, VStack, useObservable,
} from "scripting"
import {
  t, getPreference, getLocale, setPreference, availableLocales, localeName,
  type LocalePreference, type LocaleId,
} from "../i18n"
import {
  DEFAULT_DEVICE_HOST, loadConnectionSettings, saveConnectionSettings, type TunnelSource,
} from "../connection"
import { ACCENT, ACCENT2, DARK_SCHEME, ERROR, OK, WARN } from "./theme"
import { engine, useLiveTick } from "./engine"

const LEVEL_TINT = {
  info: "secondaryLabel",
  ok: OK,
  warn: WARN,
  error: ERROR,
} as const

/** The log, newest first, in a monospaced console that scrolls on its own. */
function LogConsole({ tick }: { tick: number }) {
  const lines = engine.log
  void tick
  if (lines.length === 0) {
    return <Text font="caption" foregroundStyle="secondaryLabel">{t("log.empty")}</Text>
  }
  return (
    <ScrollView frame={{ height: 240, maxWidth: "infinity" }}>
      <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        {lines.map((line, index) => (
          <Text
            key={String(index)}
            font={{ name: "Menlo", size: 11 }}
            foregroundStyle={LEVEL_TINT[line.level]}
            multilineTextAlignment="leading"
          >
            {`${line.at.toLocaleTimeString()}  ${line.text}`}
          </Text>
        ))}
      </VStack>
    </ScrollView>
  )
}

/** One saved Apple ID: the one in use says so, and the others switch to it on a tap. */
function AccountRow({ email, active, disabled, onUse }: {
  email: string
  active: boolean
  disabled: boolean
  onUse: () => void
}) {
  const row = (
    <HStack spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
      <Image
        systemName="person.crop.circle.fill"
        font="title3"
        foregroundStyle={ACCENT}
        frame={{ width: 26 }}
      />
      <VStack alignment="leading" spacing={2} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <Text font="subheadline" fontWeight="semibold" foregroundStyle="label" lineLimit={1} truncationMode="middle">
          {email}
        </Text>
        <Text font="caption" foregroundStyle="secondaryLabel">
          {active ? t("settings.account.inUse") : t("settings.account.tapToUse")}
        </Text>
      </VStack>
      {active ? <Image systemName="checkmark" font="subheadline" fontWeight="bold" foregroundStyle={ACCENT2} /> : null}
    </HStack>
  )
  // One Button per row: the account in use is a plain row, since tapping it would sign in again.
  return active ? row : <Button action={onUse} disabled={disabled}>{row}</Button>
}

/** A read-only row: a label, and a value that may be long. */
export function SettingsPage() {
  const dismiss = Navigation.useDismiss()
  const tick = useLiveTick()

  const account = engine.savedAccount
  const accounts = engine.savedAccounts
  // A sign-in started from this page, or a gate that is running: both hold the account.
  const locked = engine.isRunning || engine.accountBusy
  const lineCount = engine.log.length

  // Read once, then kept here: the gates read the saved pair for themselves when they run.
  const source = useObservable<TunnelSource>(() => loadConnectionSettings().source)
  const host = useObservable<string>(() => loadConnectionSettings().host)

  /** The pair is saved as it is typed; what is stored is the normalised one. */
  function setSource(next: TunnelSource) {
    source.setValue(next)
    saveConnectionSettings({ source: next, host: host.value })
  }

  function setHost(next: string) {
    host.setValue(next)
    saveConnectionSettings({ source: source.value, host: next })
  }

  return (
    <NavigationStack {...DARK_SCHEME}>
      <List
        navigationTitle={t("button.settings")}
        navigationBarTitleDisplayMode="inline"
        toolbar={
          <Toolbar>
            <ToolbarItem placement="confirmationAction">
              <Button title={t("button.done")} action={dismiss} />
            </ToolbarItem>
          </Toolbar>
        }
      >
        <Section header={<Text>{t("settings.account")}</Text>}>
          {accounts.length === 0
            ? <Text font="subheadline" foregroundStyle="secondaryLabel" multilineTextAlignment="leading">
              {t("settings.account.empty")}
            </Text>
            : accounts.map(email => (
              <AccountRow
                key={email}
                email={email}
                active={email === account}
                disabled={locked}
                onUse={() => { void engine.useAccount(email) }}
              />
            ))}
          {engine.accountBusy
            ? <HStack spacing={10} frame={{ maxWidth: "infinity", alignment: "leading" }}>
              <ProgressView />
              <Text font="subheadline" foregroundStyle="secondaryLabel">{t("settings.account.signingIn")}</Text>
            </HStack>
            : <Button title={t("settings.account.add")} action={() => { void engine.addAccount() }} disabled={locked} />}
        </Section>

        {account === null
          ? null
          : <Section footer={<Text>{t("settings.account.forgetNote")}</Text>}>
            <Button
              title={t("settings.account.forget")}
              action={() => engine.forgetAccount()}
              disabled={locked}
            />
          </Section>}

        <Section header={<Text>{t("section.language")}</Text>}>
          <Picker
            title={t("section.language")}
            value={getPreference()}
            onChanged={(value: unknown) => setPreference(value as LocalePreference)}
          >
            <Text tag="system">{t("language.system", { name: localeName(getLocale()) })}</Text>
            {availableLocales.map((id: LocaleId) => (
              <Text key={id} tag={id}>{localeName(id)}</Text>
            ))}
          </Picker>
        </Section>

        <Section
          header={<Text>{t("settings.connection")}</Text>}
          footer={<Text>{t("settings.connection.note")}</Text>}
        >
          <Picker
            title={t("settings.connection.source")}
            value={source.value}
            onChanged={(value: unknown) => setSource(value === "proxyApp" ? "proxyApp" : "builtIn")}
          >
            <Text tag="builtIn">{t("settings.connection.builtIn")}</Text>
            <Text tag="proxyApp">{t("settings.connection.proxyApp")}</Text>
          </Picker>
        </Section>

        {source.value === "proxyApp"
          ? <Section
            header={<Text>{t("settings.connection.host")}</Text>}
            footer={<Text>{t("settings.connection.hostNote", { default: DEFAULT_DEVICE_HOST })}</Text>}
          >
            <TextField
              title=""
              value={host.value}
              prompt={DEFAULT_DEVICE_HOST}
              keyboardType="numbersAndPunctuation"
              onChanged={value => setHost(value)}
            />
          </Section>
          : null}

        <Section header={<Text>{t("settings.log.count", { count: lineCount })}</Text>}>
          <LogConsole tick={tick} />
          <Button
            title={t("button.copy")}
            action={() => {
              const text = engine.log
                .slice()
                .reverse()
                .map(l => `${l.at.toISOString()} [${l.level}] ${l.text}`)
                .join("\n")
              void Pasteboard.setString(text)
            }}
          />
          <Button title={t("button.clear")} action={() => engine.clearLog()} />
        </Section>
      </List>
    </NavigationStack>
  )
}
