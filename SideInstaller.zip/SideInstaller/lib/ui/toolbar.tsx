// The two buttons every page's bar carries: close on the left, settings on the right.
import { Button, Toolbar, ToolbarItem } from "scripting"
import { t } from "../i18n"

export function pageToolbar(dismiss: () => void, onSettings: () => void) {
  return (
    <Toolbar>
      <ToolbarItem placement="topBarLeading">
        <Button title={t("button.close")} systemImage="xmark" action={dismiss} />
      </ToolbarItem>
      <ToolbarItem placement="topBarTrailing">
        <Button title={t("button.settings")} systemImage="gearshape" action={onSettings} />
      </ToolbarItem>
    </Toolbar>
  )
}

/** A pushed page's bar: the stack draws the way back, so settings is all this adds. */
export function pushedPageToolbar(onSettings: () => void) {
  return (
    <Toolbar>
      <ToolbarItem placement="topBarTrailing">
        <Button title={t("button.settings")} systemImage="gearshape" action={onSettings} />
      </ToolbarItem>
    </Toolbar>
  )
}
