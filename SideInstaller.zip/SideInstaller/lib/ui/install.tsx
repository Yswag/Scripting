// Install: the front page. A brand header carrying the tunnel pill, what is being installed,
// whatever the run is waiting on, the call to action that grows into the run's progress card, the
// step timeline, and the advanced section. Laid out like the Swift app's `ContentView`.
import {
  Button, Circle, HStack, Image, Menu, Navigation, NavigationStack, Picker, ProgressView, Rectangle,
  RoundedRectangle, ScrollView, Spacer, Text, VStack, ZStack, gradient, useObservable, useEffect,
  type Color, type ShapeStyle,
} from "scripting"
import { reflectionState, type ReflectionState, type StepDefinition, type StepState } from "../engine"
import {
  INSTALL_SOURCES, RELEASE_CHANNELS, channelName, displayName as buildDisplayName, shortName,
  versionHasRemark, versionMenuTitle, versionTitle,
  type InstallSource, type ReleaseChannel,
} from "../builds"
import { t, type TranslationKey } from "../i18n"
import { dismissMilestone, engine, milestoneDismissed, useLiveTick } from "./engine"
import { PairingPopup } from "./pairing"
import { pageToolbar } from "./toolbar"
import {
  ACCENT, ACCENT2, AppBackground, BRAND, BrandHeader, CARD_APPEAR, CalloutCard, CircleChip,
  DARK_SCHEME, DisclosureChevron, ERROR, Field, MilestoneOverlay, OK, PanelCard, PopupCard, PrimaryButton, ROUNDED,
  SURFACE_SWAP, StatusPill, WARN, cardSurface, cascadeProps, tintGradient, withAlpha,
} from "./theme"

// MARK: - Step presentation

const NODE_GLYPH: Record<StepState, string> = {
  pending: "circle",
  running: "circle",
  done: "checkmark",
  failed: "xmark",
  blocked: "hand.tap.fill",
  skipped: "minus",
}

function nodeGlyph(state: StepState): string {
  return NODE_GLYPH[state]
}

function nodeFill(state: StepState): Color {
  if (state === "done") return OK
  if (state === "failed") return ERROR
  if (state === "blocked") return WARN
  return "clear"
}

function nodeStroke(state: StepState): Color {
  if (state === "done") return OK
  if (state === "failed") return ERROR
  if (state === "blocked") return WARN
  if (state === "running") return ACCENT
  return "separator"
}

function glyphColor(state: StepState): Color {
  if (state === "pending" || state === "skipped") return "tertiaryLabel"
  if (state === "running") return ACCENT
  return "white"
}

/** Breathing pulse node with animated ripple for the running step. */
function PulseNode() {
  const pulsing = useObservable(false)
  useEffect(() => {
    pulsing.setValue(true)
  }, [])

  return (
    <ZStack frame={{ width: 28, height: 28 }}>
      {/* 向外擴散的外圈光暈漣漪 */}
      <Circle
        frame={{ width: 28, height: 28 }}
        fill="clear"
        overlay={
          <Circle
            stroke={{
              shapeStyle: withAlpha(ACCENT, 0.75),
              strokeStyle: { lineWidth: 1.5 },
            }}
          />
        }
        scaleEffect={pulsing.value ? 1.55 : 1}
        opacity={pulsing.value ? 0 : 0.75}
        animation={{ animation: Animation.smooth({ duration: 0.9 }).repeatForever(true), value: pulsing.value }}
      />

      {/* 靜態外框底 */}
      <Circle
        frame={{ width: 28, height: 28 }}
        fill="clear"
        overlay={
          <Circle
            stroke={{
              shapeStyle: ACCENT,
              strokeStyle: { lineWidth: 1.5 },
            }}
          />
        }
      />

      {/* 中心呼吸發光藍點 */}
      <Circle
        frame={{ width: 10, height: 10 }}
        fill="#38BDF8"
        shadow={{ color: ACCENT, radius: 8 }}
        scaleEffect={pulsing.value ? 1.25 : 0.75}
        animation={{ animation: Animation.smooth({ duration: 0.9 }).repeatForever(true), value: pulsing.value }}
      />
    </ZStack>
  )
}

/** Status circle for a step. The running step gets an elegant breathing pulse core and ripple. */
function StepNode({ state }: { state: StepState }) {
  if (state === "running") {
    return <PulseNode />
  }

  return (
    <ZStack frame={{ width: 28, height: 28 }}>
      <Circle
        fill={nodeFill(state)}
        frame={{ width: 28, height: 28 }}
      />
      <Circle
        fill="clear"
        frame={{ width: 28, height: 28 }}
        overlay={
          <Circle
            stroke={{
              shapeStyle: nodeStroke(state),
              strokeStyle: { lineWidth: 1.5 },
            }}
          />
        }
      />
      <Image
        systemName={nodeGlyph(state)}
        font={13}
        fontWeight="bold"
        foregroundStyle={glyphColor(state)}
      />
    </ZStack>
  )
}

export function StepBadge({ state }: { state: StepState }) {
  if (state !== "blocked") return null
  return (
    <Text
      font="caption2" fontWeight="bold" foregroundStyle={WARN}
      padding={{ horizontal: 9, vertical: 4 }}
      background={<RoundedRectangle {...ROUNDED(11)} fill={withAlpha(WARN, 0.16)} />}
    >
      {t("state.blocked")}
    </Text>
  )
}

function targetShortName(): string {
  if (engine.installSource === "import") {
    return engine.importedFileName ?? t("install.import")
  }
  return shortName(engine.installSource)
}

function stepTitle(step: StepDefinition): string {
  if (step.id === "install") {
    return t("step.install.title", { name: targetShortName() })
  }
  return t(step.titleKey)
}

/** One row of the timeline: a status node, the step, and its detail line. */
function StepRow({ step, state, detail, isLast }: {
  step: StepDefinition
  state: StepState
  detail: string
  isLast: boolean
}) {
  return (
    <HStack
      alignment="top"
      spacing={14}
      frame={{ maxWidth: "infinity", minHeight: 46, alignment: "leading" }}
      padding={{ vertical: 6 }}
      animation={{ animation: Animation.smooth({ duration: 0.3 }), value: state }}
    >
      <VStack spacing={0} frame={{ width: 28, maxHeight: "infinity" }}>
        <StepNode state={state} />
        {isLast
          ? null
          : <Rectangle
            fill={state === "done" ? withAlpha(OK, 0.5) : "tertiarySystemFill"}
            frame={{ width: 2, maxHeight: "infinity" }}
          />}
      </VStack>

      <VStack alignment="leading" spacing={3} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <HStack spacing={8} frame={{ maxWidth: "infinity", minHeight: 28 }}>
          <Text
            font="subheadline"
            fontWeight={state === "pending" ? "regular" : "medium"}
            foregroundStyle={state === "pending" ? "secondaryLabel" : "label"}
          >
            {stepTitle(step)}
          </Text>
          <Spacer />
          <StepBadge state={state} />
        </HStack>
        {detail.length > 0
          ? <Text font="caption" foregroundStyle="secondaryLabel" multilineTextAlignment="leading">{detail}</Text>
          : null}
      </VStack>
    </HStack>
  )
}

/** The timeline closed: the step in flight, its place in the run, and its badge. */
function CurrentStepRow({ step, state, index, total }: {
  step: StepDefinition
  state: StepState
  index: number
  total: number
}) {
  return (
    <HStack spacing={14} frame={{ maxWidth: "infinity", alignment: "leading" }} padding={{ vertical: 9 }}>
      <StepNode state={state} />
      <VStack alignment="leading" spacing={1} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <Text font="subheadline" fontWeight="medium" lineLimit={1}>{stepTitle(step)}</Text>
        <Text font="caption2" foregroundStyle="secondaryLabel">{t("install.stepOf", { index, total })}</Text>
      </VStack>
      <Spacer />
      <StepBadge state={state} />
    </HStack>
  )
}

// MARK: - Progress

function progressFill(tint: Color): ShapeStyle {
  if (tint === ACCENT) {
    return gradient("linear", {
      colors: ["#38BDF8", "#2563EB"],
      startPoint: { x: 0, y: 0.5 },
      endPoint: { x: 1, y: 0.5 },
    })
  }
  if (tint === OK) {
    return gradient("linear", {
      colors: ["#34D399", "#059669"],
      startPoint: { x: 0, y: 0.5 },
      endPoint: { x: 1, y: 0.5 },
    })
  }
  if (tint === ERROR) {
    return gradient("linear", {
      colors: ["#F87171", "#DC2626"],
      startPoint: { x: 0, y: 0.5 },
      endPoint: { x: 1, y: 0.5 },
    })
  }
  return tintGradient(tint)
}

/** Gradient bar for the run: a slim illuminated fill over a deep translucent track. */
function ProgressBar({ progress, tint }: {
  progress: number
  tint: Color
}) {
  const clamped = Math.max(0.03, Math.min(1, progress))
  return (
    <VStack
      spacing={0}
      frame={{ maxWidth: "infinity", height: 7, alignment: "leading" }}
      background={<RoundedRectangle {...ROUNDED(3.5)} fill="rgba(255, 255, 255, 0.08)" />}
      clipShape={ROUNDED(3.5)}
    >
      <Rectangle
        fill={progressFill(tint)}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        shadow={{ color: withAlpha(tint, 0.65), radius: 8 }}
        scaleEffect={{ x: clamped, y: 1, anchor: { x: 0, y: 0.5 } }}
        animation={{ animation: Animation.smooth({ duration: 0.45 }), value: clamped }}
      />
    </VStack>
  )
}

// MARK: - Page pieces

/** Keep a private copy of the picked IPA for the installation step. */
let importing = false
async function importIpa(): Promise<void> {
  if (importing || engine.isRunning) return
  importing = true
  try {
    const [path] = await DocumentPicker.pickFiles({ types: ["public.data"], allowsMultipleSelection: false })
    if (path === undefined || engine.isRunning) return
    const name = path.split("/").pop() ?? ""
    if (!/\.ipa$/i.test(name)) {
      await Dialog.alert(t("install.importWrongExtension", { name }))
      return
    }
    const copy = `${FileManager.temporaryDirectory}/sideinstaller-import-${Date.now()}.ipa`
    await FileManager.copyFile(path, copy)
    const stat = FileManager.statSync(copy)
    if (stat.size <= 0) {
      FileManager.removeSync(copy)
      await Dialog.alert(t("install.importInvalid"))
      return
    }
    if (engine.isRunning || engine.installSource !== "import") FileManager.removeSync(copy)
    else engine.setImportedIpa({ path: copy, bytes: stat.size }, name)
  } catch (error) {
    await Dialog.alert(t("install.importFailed", { message: error instanceof Error ? error.message : String(error) }))
  } finally {
    importing = false
  }
}

/** What is being installed: which build, and which release track. */
function TargetCard({ disabled, onChanged }: { disabled: boolean, onChanged: () => void }) {
  useLiveTick()
  const sourceName = engine.installSource === "import"
    ? t("install.import")
    : buildDisplayName(engine.installSource)

  return (
    <PanelCard>
      <VStack alignment="leading" spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <HStack spacing={8}>
          <Image systemName="square.and.arrow.down.fill" font="headline" foregroundStyle={ACCENT} />
          <Text font="headline">{t("tab.install")}</Text>
        </HStack>

        <Menu
          disabled={disabled}
          label={
            <Field>
              <HStack frame={{ maxWidth: "infinity" }}>
                <Text lineLimit={1}>{sourceName}</Text>
                <Spacer />
                <Image systemName="chevron.up.chevron.down" font="footnote" fontWeight="semibold" />
              </HStack>
            </Field>
          }
        >
          <Picker
            title={t("tab.install")}
            value={engine.installSource}
            onChanged={(value: unknown) => {
              engine.setInstallSource(value as InstallSource | "import")
              if (value !== "import") onChanged()
            }}
          >
            {INSTALL_SOURCES.map(id => <Text key={id} tag={id}>{buildDisplayName(id)}</Text>)}
            <Text tag="import">{t("install.import")}</Text>
          </Picker>
        </Menu>

        {engine.installSource === "import"
          ? <VStack alignment="leading" spacing={6} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            <HStack frame={{ maxWidth: "infinity" }}>
              <Spacer />
              <Button title={t("install.importFile")} disabled={disabled} action={() => { void importIpa() }} />
              <Spacer />
            </HStack>
            {engine.importedFileName !== null
              ? <Text font="footnote" foregroundStyle="secondaryLabel">{engine.importedFileName}</Text>
              : null}
          </VStack>
          : <Picker
            title={t("install.channel")}
            value={engine.releaseChannel}
            onChanged={(value: unknown) => {
              engine.setReleaseChannel(value as ReleaseChannel)
              onChanged()
            }}
            disabled={disabled}
            pickerStyle="segmented"
          >
            {RELEASE_CHANNELS.map(id => <Text key={id} tag={id}>{t(channelName(id))}</Text>)}
          </Picker>}
      </VStack>
    </PanelCard>
  )
}

/** A red card for the step that stopped the run, or the one that cannot run at all. */
function RequirementCallout({ step, state }: { step: StepDefinition, state: StepState }) {
  const tint = state === "blocked" ? WARN : ERROR
  const glyph = state === "blocked" ? "wrench.and.screwdriver" : "exclamationmark.triangle.fill"
  return (
    <CalloutCard tint={tint}>
      <HStack alignment="top" spacing={14} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <Image systemName={glyph} font="title2" foregroundStyle={tint} />
        <VStack alignment="leading" spacing={6} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Text font="subheadline" fontWeight="semibold">{stepTitle(step)}</Text>
          <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment="leading">
            {engine.detailOf(step.id)}
          </Text>
        </VStack>
      </HStack>
    </CalloutCard>
  )
}

/**
 * The run as a card: how far it has got, the bar, and the timeline.
 */
function ProgressCard({ steps, doneCount, expanded, onToggle }: {
  steps: StepDefinition[]
  doneCount: number
  expanded: boolean
  onToggle: () => void
}) {
  // Subscribed here too: the rows read the engine's step states and details directly.
  useLiveTick()
  const total = steps.length
  const progress = total === 0 ? 0 : doneCount / total
  const failed = steps.some(step => engine.stateOf(step.id) === "failed")
  const finished = doneCount === total
  const tint = failed ? ERROR : finished ? OK : ACCENT
  const current = currentStepOf(steps)

  return (
    <VStack
      alignment="leading"
      spacing={0}
      frame={{ maxWidth: "infinity", alignment: "leading" }}
      clipShape={ROUNDED(22)}
      transition={SURFACE_SWAP}
      {...cardSurface(22)}
      overlay={<RoundedRectangle {...ROUNDED(22)} stroke={{ shapeStyle: withAlpha(tint, 0.38), strokeStyle: { lineWidth: 1 } }} />}
      shadow={{ color: withAlpha(tint, 0.22), radius: 18, x: 0, y: 4 }}
    >
      <VStack alignment="leading" spacing={16} frame={{ maxWidth: "infinity", alignment: "leading" }} padding={18}>
        <HStack spacing={12} frame={{ maxWidth: "infinity" }}>
          <Text font="headline" fontWeight="bold">{finished ? t("install.finished") : failed ? t("state.failed") : t("install.running")}</Text>
          <Spacer />
          <Text font="headline" fontWeight="bold" monospacedDigit foregroundStyle={tint}>{`${Math.round(progress * 100)}%`}</Text>
          <Button action={onToggle}>
            <CircleChip>
              <DisclosureChevron expanded={expanded} />
            </CircleChip>
          </Button>
        </HStack>

        <ProgressBar progress={progress} tint={tint} />

        <VStack spacing={0} frame={{ maxWidth: "infinity", alignment: "leading" }} animation={{ animation: Animation.smooth({ duration: 0.38 }), value: expanded }}>
          {expanded
            ? steps.map((step, index) => (
              <StepRow
                key={step.id}
                step={step}
                state={engine.stateOf(step.id)}
                detail={engine.detailOf(step.id)}
                isLast={index === total - 1}
              />
            ))
            : <CurrentStepRow
              step={current}
              state={engine.stateOf(current.id)}
              index={indexOf(steps, current)}
              total={total}
            />}
        </VStack>
      </VStack>
    </VStack>
  )
}

// MARK: - Page

/** The step in flight, or the last one that finished. */
function currentStepOf(steps: StepDefinition[]): StepDefinition {
  const live = steps.find(step => {
    const state = engine.stateOf(step.id)
    return state === "running" || state === "blocked" || state === "failed"
  })
  if (live !== undefined) return live
  for (let index = steps.length - 1; index >= 0; index--) {
    if (engine.stateOf(steps[index].id) === "done") return steps[index]
  }
  return steps[0]
}

function indexOf(steps: StepDefinition[], step: StepDefinition): number {
  return steps.findIndex(candidate => candidate.id === step.id) + 1
}

/** The call to action, and the progress card it becomes once a run has started. */
function InstallSurface({ showProgress, steps, doneCount, expanded, onToggle, label, enabled, onInstall }: {
  showProgress: boolean
  steps: StepDefinition[]
  doneCount: number
  expanded: boolean
  onToggle: () => void
  label: string
  enabled: boolean
  onInstall: () => void
}) {
  return showProgress
    ? <ProgressCard
      steps={steps}
      doneCount={doneCount}
      expanded={expanded}
      onToggle={onToggle}
    />
    : <PrimaryButton
      title={label}
      systemImage="square.and.arrow.down.fill"
      action={onInstall}
      disabled={!enabled}
    />
}

/** The build's releases, as the version picker offers them. */
function VersionPicker({ disabled }: { disabled: boolean }) {
  // Subscribed here, not just in the page: this component reads the engine directly and its props
  // never change, so nothing else would rebuild it when the catalogue arrives.
  useLiveTick()
  const source = engine.installSource
  if (source === "import") return null
  const channel = engine.releaseChannel
  const catalog = engine.catalogOf(source)
  const loading = engine.catalogLoading === source
  const failure = engine.catalogErrorOf(source)
  const latest = catalog?.latest[channel]
  const picked = engine.pickedTag
  const shown = engine.selectedVersion ?? latest
  const others = catalog?.others[channel] ?? []
  const title = t("install.version.title", { name: shortName(source) })
  const versionName = picked === undefined || picked === ""
    ? (latest === undefined
      ? t("install.version.latest")
      : t("install.version.latestWith", { version: versionTitle(latest) }))
    : (shown !== undefined ? versionTitle(shown) : picked)

  return (
    <VStack alignment="leading" spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
      <HStack spacing={8}>
        <Image systemName="clock.arrow.circlepath" font="subheadline" foregroundStyle={ACCENT2} />
        <Text font="subheadline" fontWeight="semibold">{title}</Text>
      </HStack>

      <Menu
        disabled={disabled}
        label={
          <Field>
            <HStack frame={{ maxWidth: "infinity" }}>
              <Text lineLimit={1}>{versionName}</Text>
              <Spacer />
              {loading
                ? <ProgressView />
                : <Image systemName="chevron.up.chevron.down" font="footnote" fontWeight="semibold" />}
            </HStack>
          </Field>
        }
      >
        <Picker
          key={`${source}|${channel}|${others.length}|${failure !== undefined}|${latest?.tag ?? ""}`}
          title={title}
          value={picked ?? ""}
          onChanged={(value: unknown) => {
            const tag = String(value)
            engine.setPickedTag(tag.length === 0 ? undefined : tag)
          }}
        >
          <Text tag="">
            {latest === undefined
              ? t("install.version.latest")
              : t("install.version.latestWith", { version: versionTitle(latest) })}
          </Text>
          {others.map(version => (
            <Text key={version.tag} tag={version.tag}>{versionMenuTitle(version)}</Text>
          ))}
        </Picker>
      </Menu>

      {shown !== undefined && versionHasRemark(shown)
        ? <HStack spacing={6} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Image systemName="info.circle" font="footnote" foregroundStyle="secondaryLabel" />
          <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment="leading">
            {versionMenuTitle(shown)}
          </Text>
        </HStack>
        : null}

      {failure !== undefined
        ? <VStack alignment="leading" spacing={6} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment="leading">
            {t("install.version.failed", { message: failure })}
          </Text>
          <Button action={() => { void engine.loadCatalog(source, true) }}>
            <Text font="footnote" fontWeight="semibold" foregroundStyle={ACCENT2}>
              {t("install.version.retry")}
            </Text>
          </Button>
        </VStack>
        : null}
    </VStack>
  )
}

/** The advanced section, folded away until its title is tapped: which release is being installed. */
function AdvancedSection({ expanded, onToggle, running }: {
  expanded: boolean
  onToggle: () => void
  running: boolean
}) {
  return (
    <VStack
      alignment="leading"
      spacing={14}
      frame={{ maxWidth: "infinity", alignment: "leading" }}
      padding={{ horizontal: 18 }}
    >
      <Button action={onToggle}>
        <HStack spacing={8} frame={{ maxWidth: "infinity" }}>
          <Image systemName="slider.horizontal.3" font="headline" foregroundStyle={ACCENT} />
          <Text font="headline" foregroundStyle="label">{t("section.advanced")}</Text>
          <Spacer />
          <DisclosureChevron expanded={expanded} />
        </HStack>
      </Button>

      {expanded
        ? <VStack
          alignment="leading"
          spacing={22}
          frame={{ maxWidth: "infinity", alignment: "leading" }}
          transition={CARD_APPEAR}
        >
          {engine.installSource !== "import" ? <VersionPicker disabled={running} /> : null}
        </VStack>
        : null}
    </VStack>
  )
}

/**
 * What the status pill says, one entry per state of the link. `noService` is the one that saves a
 * hunt: the reflection carries traffic, and only the device's remote-pairing port is missing.
 */
const TUNNEL_PILL: Record<ReflectionState, { key: TranslationKey, icon: string, color: Color }> = {
  active: { key: "pill.tunnelOn", icon: "checkmark.shield.fill", color: OK },
  noService: { key: "pill.tunnelNoService", icon: "exclamationmark.shield.fill", color: WARN },
  off: { key: "pill.tunnelOff", icon: "shield.slash.fill", color: ERROR },
  unknown: { key: "pill.tunnelUnknown", icon: "questionmark.circle.fill", color: "#8E8E93" },
}

/**
 * The certificate a LiveContainer needs before it runs anything, which only LiveContainer can take:
 * the install step leaves the URL, and this offers to open it.
 */
function CertificatePush() {
  const busy = useObservable(false)
  const state = engine.certificatePushState
  const send = async () => {
    busy.setValue(true)
    await engine.pushCertificate()
    busy.setValue(false)
  }

  return (
    <VStack spacing={10} frame={{ maxWidth: "infinity", alignment: "leading" }}>
      <Text font="headline" multilineTextAlignment="leading">{t("install.certificate.title")}</Text>
      <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment="leading">
        {t("install.certificate.body")}
      </Text>
      {state === "sent"
        ? <Text font="footnote" foregroundStyle={OK} multilineTextAlignment="leading">
          {t("install.certificate.sent")}
        </Text>
        : <VStack spacing={10} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <PrimaryButton
            title={t("install.certificate.button")}
            systemImage="key.fill"
            busy={busy.value === true}
            action={() => { void send() }}
          />
          {state === "failed"
            ? <Text font="footnote" foregroundStyle={WARN} multilineTextAlignment="leading">
              {t("install.certificate.failed")}
            </Text>
            : null}
        </VStack>}
    </VStack>
  )
}

/**
 * The popup that ends a run: what was installed, the trust step it needs before it opens, and — for
 * a LiveContainer — the certificate it still has to be given.
 */
export function FinishedPopup({ installed, onClose }: {
  installed: { name: string, version: string }
  onClose: () => void
}) {
  return (
    <PopupCard
      title={t("install.finished")}
      systemImage="checkmark.seal.fill"
      tint={OK}
      onClose={onClose}
    >
      <VStack alignment="leading" spacing={10} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <Text font="subheadline" multilineTextAlignment="leading">
          {t("install.done", { name: installed.name, version: installed.version })}
        </Text>
        <Text font="subheadline" multilineTextAlignment="leading">
          {t("install.trust", { name: installed.name })}
        </Text>
        {engine.certificatePush === null ? null : <CertificatePush />}
      </VStack>
    </PopupCard>
  )
}

export function InstallPage({ onSettings }: { onSettings: () => void }) {
  const dismiss = Navigation.useDismiss()
  useLiveTick()
  const stepsExpanded = useObservable(false)
  const advancedExpanded = useObservable(false)
  const progressDismissed = useObservable(false)
  // Bumped when a milestone's popup is closed: the flags live in the module, so nothing else would
  // rebuild the page for it.
  const milestoneTick = useObservable(0)

  const steps = engine.steps
  const total = steps.length
  const doneCount = engine.doneCount
  const running = engine.isRunning
  const nextStep = engine.currentStep
  const allDone = total > 0 && doneCount === total
  const showProgress = running || (!progressDismissed.value && doneCount > 0)
  const stoppedStep = steps.find(step => {
    const state = engine.stateOf(step.id)
    return state === "blocked" || state === "failed"
  }) ?? null
  const reflection = useObservable<ReflectionState>("unknown")
  const expanded = stepsExpanded.value === true
  const advanced = advancedExpanded.value === true

  // What the pill says: checked on arrival and every few seconds after, but not while a run is in
  // flight — the steps own the link then, and a probe would only add traffic to it.
  useEffect(() => {
    let live = true
    const check = async () => {
      if (engine.isRunning) return
      const next = await reflectionState()
      if (live) reflection.setValue(next)
    }
    void check()
    const timer = setInterval(() => { void check() }, 5000)
    return () => {
      live = false
      clearInterval(timer)
    }
  }, [])

  const cascade = stoppedStep !== null ? 3 : 2
  const current = currentStepOf(steps)

  // What the button names, and the label both buttons carry.
  const chosenVersion = engine.selectedVersion
  const targetName = engine.installSource === "import"
    ? engine.importedFileName ?? t("install.import")
    : chosenVersion === undefined
      ? shortName(engine.installSource)
      : `${shortName(engine.installSource)} ${versionTitle(chosenVersion)}`
  const installLabel = allDone ? t("button.allDone") : t("install.cta", { name: targetName })
  const handleDone = () => {
    withAnimation(Animation.smooth({ duration: 0.35 }), () => {
      progressDismissed.setValue(true)
      engine.reset("install")
    })
  }

  const loadCatalog = () => {
    if (engine.installSource !== "import") void engine.loadCatalog(engine.installSource)
  }

  // The prompt a milestone raises: the pairing step's while it runs, the finished run's once it is
  // over. What the finished one names comes from what the steps stored, so the popup is rebuilt from
  // state rather than held in a variable that a tab switch would drop.
  const installed = engine.installedApp
  const closeMilestone = (id: string) => {
    dismissMilestone(id)
    milestoneTick.setValue((milestoneTick.value ?? 0) + 1)
  }
  const milestone = allDone && installed !== null && !milestoneDismissed("installed")
    ? <FinishedPopup installed={installed} onClose={() => closeMilestone("installed")} />
    : engine.stateOf("pair") === "running" && !milestoneDismissed("pairing")
        ? <PairingPopup code={engine.pairingCode} onClose={() => closeMilestone("pairing")} />
        : null

  // The entrance: one switch, read here so the items are rebuilt on each render, with the stagger
  // carried by each item's own animation. The flip is deferred by a tick: a change made straight
  // from `onAppear` or an effect lands before the first frame, so there is no starting state to
  // interpolate from and the content simply appears.
  const revealed = useObservable(false)
  const reveal = () => {
    setTimeout(() => revealed.setValue(true), 30)
  }
  useEffect(reveal, [])
  const box = (index: number) => ({
    spacing: 0,
    frame: { maxWidth: "infinity" as const, alignment: "leading" as const },
    ...cascadeProps(index, revealed.value === true),
  })

  return (
    <NavigationStack {...DARK_SCHEME}>
      <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
        <AppBackground />
        <ScrollView
          toolbar={pageToolbar(dismiss, onSettings)}
          frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
          onAppear={reveal}
        >
          <VStack spacing={18} frame={{ maxWidth: "infinity" }} padding={20}>
            <VStack {...box(0)}>
              <BrandHeader
                icon="arrow.down.app.fill"
                title={t("app.title")}
                animateIcon={running}
                accessory={<StatusPill
                  text={t(TUNNEL_PILL[reflection.value].key)}
                  systemImage={TUNNEL_PILL[reflection.value].icon}
                  color={TUNNEL_PILL[reflection.value].color}
                />}
              />
            </VStack>

            <VStack {...box(1)}>
              <TargetCard
                disabled={running}
                onChanged={() => {
                  withAnimation(Animation.smooth({ duration: 0.3 }), () => {
                    progressDismissed.setValue(true)
                  })
                  loadCatalog()
                }}
              />
            </VStack>

            {stoppedStep !== null
              ? <VStack {...box(2)}>
                <RequirementCallout step={stoppedStep} state={engine.stateOf(stoppedStep.id)} />
              </VStack>
              : null}

            <VStack {...box(cascade)}>
              <InstallSurface
                showProgress={showProgress}
                steps={steps}
                doneCount={doneCount}
                expanded={expanded}
                onToggle={() => stepsExpanded.setValue(!expanded)}
                label={installLabel}
                enabled={nextStep !== null && !running && (engine.installSource !== "import" || engine.importedFileName !== null)}
                onInstall={() => {
                  progressDismissed.setValue(false)
                  void engine.runAll()
                }}
              />
            </VStack>

            {showProgress && !running
              ? <VStack {...box(cascade + 1)}>
                <PrimaryButton
                  title={allDone ? t("button.done") : installLabel}
                  systemImage={allDone ? "checkmark.circle.fill" : "square.and.arrow.down.fill"}
                  action={allDone ? handleDone : () => {
                    progressDismissed.setValue(false)
                    void engine.runAll()
                  }}
                  disabled={!allDone && (nextStep === null || (engine.installSource === "import" && engine.importedFileName === null))}
                  fill={allDone ? tintGradient(OK) : BRAND}
                  glow={allDone ? OK : ACCENT}
                />
              </VStack>
              : null}

            {engine.installSource !== "import"
              ? <VStack {...box(cascade + 2)}>
                <AdvancedSection
                  expanded={advanced}
                  onToggle={() => {
                    const open = !advanced
                    withAnimation(Animation.smooth({ duration: 0.3 }), () => {
                      advancedExpanded.setValue(open)
                    })
                    // The list is fetched when the section is opened, rather than on every render.
                    if (open) loadCatalog()
                  }}
                  running={running}
                />
              </VStack>
              : null}
          </VStack>
        </ScrollView>

        {milestone === null ? null : <MilestoneOverlay>{milestone}</MilestoneOverlay>}
      </ZStack>
    </NavigationStack>
  )
}
