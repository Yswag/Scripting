// The one engine the shell runs on, and the hook that re-renders a page when it logs or the
// language changes. A module of its own so the pages can share it without importing each other.
import { useEffect, useObservable } from "scripting"
import { createEngine, type Engine } from "../engine"
// The pairing code needs a surface a person in Settings can still read, and a Live Activity is one;
// the engine is told nothing about how it is drawn.
import { createPairingSurface } from "../../live_activity"
import { t, subscribeToLocale } from "../i18n"

export const engine: Engine = createEngine({ t, surface: createPairingSurface() })

/** Re-renders a page when the engine logs or the language changes. */
export function useLiveTick(): number {
  // An Observable, not useState: a state update made from an async continuation (the catalogue
  // arriving after a fetch, a step finishing) is not committed, so the page would stay stale until
  // something else re-rendered it.
  const tick = useObservable(0)
  useEffect(() => {
    const bump = () => {
      withAnimation(Animation.spring({ duration: 0.35, bounce: 0.15 }), () => {
        tick.setValue((tick.value ?? 0) + 1)
      })
    }
    const stopEngine = engine.subscribe(bump)
    const stopLocale = subscribeToLocale(bump)
    return () => {
      stopEngine()
      stopLocale()
    }
  }, [])
  return tick.value ?? 0
}

/**
 * The milestone popups a person has closed: pairing done, run finished. Module state rather than page
 * state, because switching tabs rebuilds the page and a prompt closed once must not come back.
 */
const dismissed = new Set<string>()

export function milestoneDismissed(id: string): boolean {
  return dismissed.has(id)
}

export function dismissMilestone(id: string): void {
  dismissed.add(id)
}
