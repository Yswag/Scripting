// The app's shared visual language: brand colours, the animated backdrop, and the cards, buttons,
// pills and headers every screen is built from. Ported from the Swift app's `Theme.swift`.
//
// Where SwiftUI reaches for `TimelineView`, this drives a clock instead; every other effect maps to
// a style prop. `Animation`, `Transition` and `withAnimation` are runtime globals, not exports.
import {
  Button, Capsule, Circle, HStack, Image, ProgressView, Rectangle, RoundedRectangle, Text, VStack, ZStack,
  gradient, useObservable, useEffect,
  type Color, type ShapeStyle, type VirtualNode,
} from "scripting"

// MARK: - Tokens

/** Primary brand colour, a deep blue. */
export const ACCENT = "#2170F5"
/** Secondary brand colour, the far end of the gradient. */
export const ACCENT2 = "#4DADFF"
/** Deep-navy halo behind each header icon, matching the icon art (#011A5C). */
export const GLOW = "#011A5C"

export const OK = "#30D158"
export const WARN = "#FF9F0A"
export const ERROR = "#FF453A"

/** `#RRGGBB` at `alpha`. Written without spaces: the colour type is a strict rgba() literal. */
export function withAlpha(hex: Color, alpha: number): Color {
  const value = hex as string
  const r = parseInt(value.slice(1, 3), 16)
  const g = parseInt(value.slice(3, 5), 16)
  const b = parseInt(value.slice(5, 7), 16)
  return `rgba(${r},${g},${b},${alpha})`
}

const CLEAR = "rgba(255,255,255,0)"

/** The signature diagonal gradient, used for the logo, the call to action and accents. */
export const BRAND = gradient("linear", {
  colors: [ACCENT, ACCENT2],
  startPoint: { x: 0, y: 0 },
  endPoint: { x: 1, y: 1 },
})

/** A diagonal gradient built from any tint, for tinted glyphs. */
export function tintGradient(color: Color) {
  return gradient("linear", {
    colors: [color, withAlpha(color, 0.72)],
    startPoint: { x: 0, y: 0 },
    endPoint: { x: 1, y: 1 },
  })
}

/** The system shapes the style props take, as data rather than as views. */
export const ROUNDED = (cornerRadius: number) => ({ type: "rect" as const, cornerRadius, style: "continuous" as const })

// MARK: - Colour scheme

/**
 * The app is dark by design: the backdrop is drawn black, so a page left following the system into
 * light mode would put black text — and the system's light bar fills — on it. Every page root pins
 * the scheme instead of adapting, which is what the Swift app does once, on its tab view. Spreading
 * this is enough: the system's own surfaces come along with it.
 */
export const DARK_SCHEME = { preferredColorScheme: "dark" as const }

// MARK: - Backdrop

/** Nine mesh colours: deep-navy corners with brighter blue blooms through the middle. */
const MESH_COLORS: Color[] = [GLOW, ACCENT, GLOW, ACCENT2, ACCENT, ACCENT2, GLOW, ACCENT2, GLOW]

/** The 3x3 control points at time `t`: corners pinned so the gradient fills the screen, the rest
 *  swaying on out-of-phase sine waves. */
function meshPoints(t: number) {
  const osc = (base: number, amp: number, speed: number, phase: number) =>
    base + amp * Math.sin(t * speed + phase)
  return [
    { x: 0, y: 0 },
    { x: osc(0.5, 0.18, 0.625, 0), y: 0 },
    { x: 1, y: 0 },
    { x: 0, y: osc(0.5, 0.18, 0.55, 1) },
    { x: osc(0.5, 0.12, 0.75, 2), y: osc(0.5, 0.12, 0.675, 3) },
    { x: 1, y: osc(0.5, 0.18, 0.6, 4) },
    { x: 0, y: 1 },
    { x: osc(0.5, 0.18, 0.65, 5), y: 1 },
    { x: 1, y: 1 },
  ]
}

/** How often the mesh is recomputed, in milliseconds. */
const MESH_FRAME = 1000 / 30

/**
 * The app's backdrop: OLED black under a slow, low-opacity blue mesh whose control points sway, and
 * over that the page's wash (`dark` is the Tools page's). Mount one per page, as its root.
 */
export function AppBackground({ dark = false }: { dark?: boolean }) {
  const clock = useObservable(0)
  useEffect(() => {
    const timer = setInterval(() => clock.setValue(Date.now() / 1000), MESH_FRAME)
    return () => clearInterval(timer)
  }, [])

  const fill = { maxWidth: "infinity" as const, maxHeight: "infinity" as const }
  // The three layers are overlaid (a VStack split the height between them, which is what put a black
  // band above the mesh), and each one escapes the safe area on its own so the backdrop reaches the
  // bars rather than stopping at the page's box.
  return (
    <ZStack frame={fill} allowsHitTesting={false}>
      <Rectangle fill="black" frame={fill} ignoresSafeArea />
      <Rectangle
        fill={gradient("mesh", { width: 3, height: 3, points: meshPoints(clock.value ?? 0), colors: MESH_COLORS })}
        blur={24}
        opacity={0.2}
        frame={fill}
        ignoresSafeArea
      />
      <Rectangle
        fill="black"
        opacity={dark ? 0.55 : 0}
        animation={{ animation: Animation.smooth({ duration: 0.55 }), value: dark }}
        frame={fill}
        ignoresSafeArea
      />
    </ZStack>
  )
}

// MARK: - Cards

/** A sheen that fades out down the pane, so a card has a surface at all. */
const CARD_WASH = gradient("linear", {
  colors: ["rgba(255,255,255,0.025)", CLEAR],
  startPoint: { x: 0.5, y: 0 },
  endPoint: { x: 0.5, y: 1 },
})

/** The rim: lit along the top, dim down the sides, catching light again at the foot. */
const CARD_RIM = gradient("linear", {
  stops: [
    { color: "rgba(255,255,255,0.38)", location: 0 },
    { color: "rgba(255,255,255,0.08)", location: 0.35 },
    { color: "rgba(255,255,255,0.05)", location: 0.8 },
    { color: "rgba(255,255,255,0.18)", location: 1 },
  ],
  startPoint: { x: 0.5, y: 0 },
  endPoint: { x: 0.5, y: 1 },
})

type Node = VirtualNode | VirtualNode[]

/**
 * A pane of glass with nothing in it: the backdrop shows through untouched under the faintest wash,
 * and the pane is drawn by its rim. Hand-drawn because the system's materials frost what is behind
 * them, which over this backdrop reads as grey. The fill is a sibling of the padding, not a
 * modifier on the same view, or it would stop at the content instead of the card's edge.
 */
export function CardSurface({ cornerRadius, fill, rim, inset, children }: {
  cornerRadius: number
  fill: ShapeStyle
  rim: ShapeStyle
  inset: number
  children: Node
}) {
  const shape = ROUNDED(cornerRadius)
  return (
    <HStack
      spacing={0}
      frame={{ maxWidth: "infinity", alignment: "leading" }}
      background={<RoundedRectangle {...shape} fill={fill} />}
      overlay={<RoundedRectangle {...shape} stroke={{ shapeStyle: rim, strokeStyle: { lineWidth: 1 } }} />}
    >
      <VStack alignment="leading" spacing={0} frame={{ maxWidth: "infinity", alignment: "leading" }} padding={inset}>
        {children}
      </VStack>
    </HStack>
  )
}

/** The neutral container every section sits in. */
export function PanelCard({ children }: { children: Node }) {
  return <CardSurface cornerRadius={22} fill={CARD_WASH} rim={CARD_RIM} inset={18}>{children}</CardSurface>
}

/**
 * The same surface as props, for a card that brings its own inset — the install progress card,
 * which reshapes between the call to action and the run.
 */
export function cardSurface(cornerRadius: number) {
  const shape = ROUNDED(cornerRadius)
  return {
    background: <RoundedRectangle {...shape} fill={CARD_WASH} />,
    overlay: <RoundedRectangle {...shape} stroke={{ shapeStyle: CARD_RIM, strokeStyle: { lineWidth: 1 } }} />,
  }
}

/** A `PanelCard` washed in a tint, for guidance, errors and success. */
export function CalloutCard({ tint, children }: { tint: Color, children: Node }) {
  return (
    <CardSurface cornerRadius={22} fill={withAlpha(tint, 0.12)} rim={withAlpha(tint, 0.35)} inset={18}>
      {children}
    </CardSurface>
  )
}

// MARK: - Popups

/**
 * The dimmed layer a popup floats in, centred. The page behind it stays where it was and takes no
 * taps, which is what makes it a prompt rather than one more card in the scroll.
 */
export function MilestoneOverlay({ children }: { children: VirtualNode }) {
  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <Rectangle
        fill="rgba(0,0,0,0.7)"
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        ignoresSafeArea
      />
      <VStack spacing={0} frame={{ maxWidth: 460, alignment: "leading" }} padding={{ horizontal: 20 }}>
        {children}
      </VStack>
    </ZStack>
  )
}

/** `color` as `#RRGGBB`, which every token here is. */
function rgb(color: Color, index: number): number {
  return parseInt((color as string).slice(1 + index * 2, 3 + index * 2), 16)
}

/**
 * The pane a milestone's message floats in: the port of the Swift app's `PopupCard`, which sits on the
 * system's secondary background with the tint over it. A page card is clear glass — the mesh is behind
 * it — but the page itself is behind this one, so nothing may read through.
 */
const popupFill = (tint: Color): Color => {
  // `secondarySystemBackground` in dark mode, with the tint mixed in rather than laid over it.
  const base = "#1C1C1E"
  const channel = (index: number) => Math.round(rgb(base, index) * 0.86 + rgb(tint, index) * 0.14)
  return `rgba(${channel(0)},${channel(1)},${channel(2)},1)`
}

/** A glyph, its title, the one way out, and whatever the milestone has to say. */
export function PopupCard({ title, systemImage, tint, onClose, children }: {
  title: string
  systemImage: string
  tint: Color
  onClose: () => void
  children?: Node
}) {
  return (
    <CardSurface cornerRadius={28} fill={popupFill(tint)} rim={withAlpha(tint, 0.45)} inset={20}>
      <VStack alignment="leading" spacing={16} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <HStack spacing={12} frame={{ maxWidth: "infinity" }}>
          <HStack spacing={0} background={<Circle fill={withAlpha(tint, 0.22)} />}>
            <Image systemName={systemImage} font="title3" fontWeight="semibold" foregroundStyle={tint} padding={9} />
          </HStack>
          <Text font="headline" multilineTextAlignment="leading" frame={{ maxWidth: "infinity", alignment: "leading" }}>
            {title}
          </Text>
          <Button action={onClose}>
            <CircleChip>
              <Image systemName="xmark" font="footnote" fontWeight="bold" foregroundStyle="secondaryLabel" />
            </CircleChip>
          </Button>
        </HStack>
        {children ?? null}
      </VStack>
    </CardSurface>
  )
}

// MARK: - Small components

/** A compact, colour-coded status capsule shown under a header. */
export function StatusPill({ text, systemImage, color }: {
  text: string
  systemImage: string
  color: Color
}) {
  return (
    <HStack spacing={0} background={<Capsule fill={withAlpha(color, 0.16)} />}>
      <HStack spacing={5} padding={{ horizontal: 12, vertical: 7 }}>
        <Image systemName={systemImage} font="caption" fontWeight="semibold" foregroundStyle={color} />
        <Text font="caption" fontWeight="semibold" foregroundStyle={color}>{text}</Text>
      </HStack>
    </HStack>
  )
}

/** "BETA" tag for unfinished features, sized to sit next to a title. */
export function BetaBadge() {
  return (
    <Text
      font="caption2" fontWeight="heavy" foregroundStyle={ACCENT2}
      padding={{ horizontal: 7, vertical: 3 }}
      background={<Capsule fill={withAlpha(ACCENT2, 0.16)} />}
      fixedSize
    >
      BETA
    </Text>
  )
}

/** The hero at the top of each screen: a glyph, the title, and an accessory. */
export function BrandHeader({ icon, title, subtitle, beta = false, animateIcon = false, accessory }: {
  icon: string
  title: string
  subtitle?: string
  beta?: boolean
  animateIcon?: boolean
  accessory?: Node
}) {
  return (
    <VStack spacing={14} frame={{ maxWidth: "infinity" }} padding={{ top: 8 }}>
      <ZStack frame={{ width: 86, height: 86 }}
        shadow={{ color: GLOW, radius: 20, x: 0, y: 12 }}
        clipShape={ROUNDED(23)}
        scaleEffect={animateIcon ? 1.04 : 1}
        animation={{ animation: Animation.smooth({ duration: 0.9 }).repeatForever(true), value: animateIcon }}
      >
        <Rectangle fill={BRAND} frame={{ width: 86, height: 86 }} />
        <Image systemName={icon} font={40} fontWeight="semibold" foregroundStyle="white" />
      </ZStack>

      <VStack spacing={4}>
        <HStack spacing={8}>
          <Text font="largeTitle" fontWeight="bold">{title}</Text>
          {beta ? <BetaBadge /> : null}
        </HStack>
        {subtitle !== undefined
          ? <Text font="subheadline" fontWeight="semibold" foregroundStyle="secondaryLabel">{subtitle}</Text>
          : null}
      </VStack>

      {accessory ?? null}
    </VStack>
  )
}

/** The small circled control the page headers and popups use. */
export function CircleChip({ children }: { children: Node }) {
  return (
    <HStack spacing={0} background={<Circle fill="rgba(255,255,255,0.08)" />} contentShape="circle">
      <HStack spacing={0} padding={7}>{children}</HStack>
    </HStack>
  )
}

/** Chevron that flips to point up while its section is open. */
export function DisclosureChevron({ expanded }: { expanded: boolean }) {
  return (
    <Image
      systemName="chevron.down" font="footnote" fontWeight="bold" foregroundStyle="secondaryLabel"
      rotationEffect={{ degrees: expanded ? 180 : 0, anchor: { x: 0.5, y: 0.5 } }}
      animation={{ animation: Animation.smooth({ duration: 0.3 }), value: expanded }}
    />
  )
}

/** 1pt rule, for the "or" divider and section separations. */
export function Hairline() {
  return <Rectangle fill="separator" frame={{ maxWidth: "infinity", height: 1 }} />
}

/** "or" divider between the file picker and the link field. */
export function OrDivider({ label }: { label: string }) {
  return (
    <HStack spacing={10} frame={{ maxWidth: "infinity" }} padding={{ vertical: 2 }}>
      <Hairline />
      <Text font="caption" fontWeight="semibold" foregroundStyle="secondaryLabel">{label}</Text>
      <Hairline />
    </HStack>
  )
}

/** A guide's numbered steps. */
export function NumberedSteps({ steps }: { steps: string[] }) {
  return (
    <VStack alignment="leading" spacing={10} frame={{ maxWidth: "infinity", alignment: "leading" }}>
      {steps.map((step, index) => (
        <HStack key={String(index)} alignment="top" spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
          <HStack spacing={0} background={<Circle fill={BRAND} />}>
            <Text font="caption" fontWeight="bold" monospacedDigit foregroundStyle="white"
              frame={{ width: 22, height: 22 }}>{String(index + 1)}</Text>
          </HStack>
          <Text font="subheadline" multilineTextAlignment="leading"
            frame={{ maxWidth: "infinity", alignment: "leading" }}>{step}</Text>
        </HStack>
      ))}
    </VStack>
  )
}

// MARK: - Fields

/** Tint of the inset field background behind pickers, buttons and text fields. */
export const FIELD_FILL = "rgba(255,255,255,0.07)"

/** Insets its content and fills the surface behind it, softer than a rounded border. */
export function Field({ children }: { children: Node }) {
  return (
    <HStack
      spacing={0}
      frame={{ maxWidth: "infinity" }}
      background={<RoundedRectangle {...ROUNDED(14)} fill={FIELD_FILL} />}
    >
      <HStack spacing={8} frame={{ maxWidth: "infinity", alignment: "leading" }} padding={{ horizontal: 14, vertical: 13 }}>
        {children}
      </HStack>
    </HStack>
  )
}

// MARK: - Buttons

/**
 * The full-width gradient call to action. Press feedback is the system's: Scripting has no custom
 * button style, so the label is styled rather than the button.
 */
export function PrimaryButton({ title, systemImage, action, disabled = false, busy = false, fill = BRAND, glow = ACCENT }: {
  title: string
  systemImage?: string
  action: () => void
  disabled?: boolean
  /** Swaps the glyph for a spinner, for a button whose work is already under way. */
  busy?: boolean
  fill?: ShapeStyle
  glow?: Color
}) {
  return (
    <Button action={action} disabled={disabled} frame={{ maxWidth: "infinity" }}>
      <HStack
        spacing={0}
        frame={{ maxWidth: "infinity" }}
        shadow={{ color: withAlpha(glow, 0.4), radius: 16, x: 0, y: 8 }}
        background={<RoundedRectangle {...ROUNDED(18)} fill={fill} />}
      >
        <HStack spacing={10} frame={{ maxWidth: "infinity" }} padding={{ vertical: 16 }}>
          {busy
            ? <ProgressView tint="white" />
            : systemImage !== undefined
              ? <Image systemName={systemImage} font="headline" foregroundStyle="white" />
              : null}
          <Text font="headline" fontWeight="semibold" foregroundStyle="white">{title}</Text>
        </HStack>
      </HStack>
    </Button>
  )
}

// MARK: - Transitions

/** The insert and remove a status card uses: a fading scale from the top. */
export const CARD_APPEAR = Transition.asymmetric(
  Transition.opacity()
    .combined(Transition.scale(0.96, { x: 0.5, y: 0 }))
    .combined(Transition.offset({ x: 0, y: -10 })),
  Transition.opacity().combined(Transition.scale(0.98, { x: 0.5, y: 0 })),
)

/** The install surface's two contents swapping as it reshapes. */
export const SURFACE_SWAP = Transition.opacity().combined(Transition.scale(0.97, { x: 0.5, y: 0 }))

/** A fade that is over before what is below has moved up into its place. */
export const QUICK_FADE = Transition.opacity().animation(Animation.easeOut(0.12))

/** The install button leaving as a run starts: up and under the progress card above it. */
export const TUCK_UNDER = Transition.opacity()
  .combined(Transition.scale(0.94, { x: 0.5, y: 0 }))
  .combined(Transition.offset({ x: 0, y: -28 }))
  .animation(Animation.easeOut(0.22))

// MARK: - Page entrance

/** 55 ms apart: enough to read as a cascade, quick enough not to drag. */
const CASCADE_STEP = 0.055

/**
 * One object's part in a page's entrance cascade, staggered by `index`, as props for the object
 * rather than as a wrapper component: a component is handed its children already built, so nothing
 * inside it is rebuilt when the page re-renders.
 *
 * Opacity and a short lift only. A scale was tried and made full-width cards read as if they were
 * growing out of a corner.
 */
export function cascadeProps(index: number, shown: boolean) {
  return {
    opacity: shown ? 1 : 0,
    offset: { x: 0, y: shown ? 0 : 16 },
    animation: {
      animation: Animation.smooth({ duration: 0.4, extraBounce: 0.1 }).delay(index * CASCADE_STEP),
      value: shown,
    },
  }
}
