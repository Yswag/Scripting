// Certificates: the page behind the Tools row of the same name. It lists the Apple ID's development
// certificates and revokes one — the Swift app's `CertsView`, which is the developer portal alone,
// so nothing here needs the device link.
import {
  Button, HStack, Image, Label, ProgressView, RoundedRectangle, ScrollView, Spacer, Text, VStack, ZStack,
  useObservable, useEffect,
} from "scripting"
import { getLocale, t } from "../i18n"
import { certificateKey, certificateName, type CertRow } from "../certs"
import { certificates, useCertificates } from "./cert-manager"
import { pushedPageToolbar } from "./toolbar"
import {
  ACCENT, AppBackground, BRAND, BrandHeader, ERROR, MilestoneOverlay, OK, PanelCard, PopupCard,
  PrimaryButton, ROUNDED, StatusPill, WARN, cascadeProps, tintGradient, withAlpha,
} from "./theme"

/** The confirmation revoking asks for: it cannot be undone, and it reaches every device. */
async function confirmRevoke(name: string): Promise<boolean> {
  // `Dialog` is a runtime global rather than an export, which is why it is reached this way.
  const answer = await (globalThis as any).Dialog.confirm({
    title: t("certs.revoke.title"),
    message: t("certs.revoke.message", { name }),
    confirmLabel: t("certs.revoke"),
    cancelLabel: t("button.cancel"),
  })
  return answer === true
}

/** The tag a certificate Apple no longer honours carries. */
function ExpiredBadge() {
  return (
    <Text
      font="caption2"
      fontWeight="bold"
      foregroundStyle={WARN}
      padding={{ horizontal: 9, vertical: 4 }}
      background={<RoundedRectangle {...ROUNDED(11)} fill={withAlpha(WARN, 0.16)} />}
      fixedSize
    >
      {t("certs.expired")}
    </Text>
  )
}

/** One certificate: what it is, when it dies, and the one thing that can be done to it. */
function CertCard({ row, revoking, disabled, onRevoke }: {
  row: CertRow
  revoking: boolean
  disabled: boolean
  onRevoke: () => void
}) {
  const certificate = row.certificate
  const named = certificateName(certificate)
  const serial = certificate.serialNumber ?? ""
  const expiry = certificate.expirationDate

  return (
    <PanelCard>
      <VStack alignment="leading" spacing={12} frame={{ maxWidth: "infinity", alignment: "leading" }}>
        <HStack alignment="top" spacing={12} frame={{ maxWidth: "infinity" }}>
          <Image
            systemName="seal.fill"
            font="title3"
            foregroundStyle={row.expired ? tintGradient(WARN) : BRAND}
          />
          <VStack alignment="leading" spacing={3} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            <Text font="subheadline" fontWeight="semibold" multilineTextAlignment="leading">
              {named === "" ? t("certs.unnamed") : named}
            </Text>
            {/* The machine Apple tagged it with, which is how a person tells their own certificate
                apart from one another tool left behind. */}
            {certificate.machineName === null || certificate.machineName === ""
              ? null
              : <Label
                title={certificate.machineName}
                systemImage="desktopcomputer"
                font="caption"
                foregroundStyle="secondaryLabel"
              />}
          </VStack>
          <Spacer />
          {row.expired ? <ExpiredBadge /> : null}
        </HStack>

        {expiry === null && serial === ""
          ? null
          : <VStack alignment="leading" spacing={4} frame={{ maxWidth: "infinity", alignment: "leading" }}>
            {expiry === null
              ? null
              : <Label
                title={t("certs.expires", {
                  date: expiry.toLocaleDateString(getLocale(), { dateStyle: "medium" }),
                })}
                systemImage="calendar"
                font="caption"
                foregroundStyle="secondaryLabel"
              />}
            {serial === ""
              ? null
              : <Label
                title={serial}
                systemImage="number"
                font="caption"
                foregroundStyle="secondaryLabel"
                lineLimit={1}
                truncationMode="middle"
              />}
          </VStack>}

        <Button action={onRevoke} disabled={revoking || disabled} frame={{ maxWidth: "infinity" }}>
          <HStack
            spacing={0}
            frame={{ maxWidth: "infinity" }}
            background={<RoundedRectangle {...ROUNDED(14)} fill={withAlpha(ERROR, 0.14)} />}
          >
            <HStack spacing={8} frame={{ maxWidth: "infinity" }} padding={{ vertical: 13 }}>
              {revoking
                ? <ProgressView tint={ERROR} />
                : <Image systemName="trash" font="subheadline" fontWeight="semibold" foregroundStyle={ERROR} />}
              <Text font="subheadline" fontWeight="medium" foregroundStyle={ERROR}>
                {revoking ? t("certs.revoking") : t("certs.revoke")}
              </Text>
            </HStack>
          </HStack>
        </Button>
      </VStack>
    </PanelCard>
  )
}

/** What an account with nothing left to revoke sees. */
function EmptyCertCard() {
  return (
    <PanelCard>
      <VStack spacing={8} frame={{ maxWidth: "infinity" }} padding={{ vertical: 8 }}>
        <Image systemName="checkmark.seal" font="largeTitle" foregroundStyle={ACCENT} />
        <Text font="headline">{t("certs.empty.title")}</Text>
        <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment="center">
          {t("certs.empty.body")}
        </Text>
      </VStack>
    </PanelCard>
  )
}

export function CertsPage({ onSettings }: { onSettings: () => void }) {
  useCertificates()
  const manager = certificates
  const busy = manager.busy
  const rows = manager.certs
  const team = manager.team
  // Counted out here so the row that is being revoked is not rebuilt from a stale read.
  const revoking = manager.revoking

  // The Swift app's `onAppear`: the list is fetched when the page opens, and only when that needs no
  // answer from the person.
  useEffect(() => {
    manager.autoLoad()
  }, [])

  const revoke = async (row: CertRow) => {
    const named = certificateName(row.certificate)
    if (await confirmRevoke(named === "" ? t("certs.unnamed") : named)) void manager.revoke(row)
  }

  // The same deferred entrance the other pages use: a flag flipped straight from `onAppear` has no
  // painted starting state, so the cascade would have nothing to interpolate from.
  const revealed = useObservable(false)
  const reveal = () => {
    setTimeout(() => revealed.setValue(true), 30)
  }
  useEffect(reveal, [])
  const box = (index: number) => ({
    spacing: 0,
    frame: { maxWidth: "infinity" as const, alignment: "leading" as const },
    ...cascadeProps(index, revealed.value === true),
  })

  // No `NavigationStack` of its own: the page is pushed onto the Tools one. Its backdrop keeps the
  // Tools level, which is the darker one.
  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <AppBackground dark />
      <ScrollView
        toolbar={pushedPageToolbar(onSettings)}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        scrollBounceBehavior="basedOnSize"
        onAppear={reveal}
      >
        <VStack spacing={18} frame={{ maxWidth: "infinity" }} padding={20}>
          <VStack {...box(0)}>
            <BrandHeader
              icon="checkmark.seal.fill"
              title={t("tool.certificates")}
              accessory={team === null
                ? undefined
                : <StatusPill
                  text={t("certs.team", { name: team.name, teamId: team.teamId })}
                  systemImage="person.2.fill"
                  color={OK}
                />}
            />
          </VStack>

          <VStack {...box(1)}>
            <PrimaryButton
              title={manager.working
                ? manager.signedIn ? t("certs.refreshing") : t("certs.signingIn")
                : manager.loaded ? t("certs.refresh") : t("certs.load")}
              systemImage={manager.loaded ? "arrow.clockwise" : "list.bullet.rectangle.fill"}
              busy={manager.working}
              action={() => { void manager.load() }}
              disabled={busy}
            />
          </VStack>

          {rows.length > 0
            ? <VStack spacing={14} frame={{ maxWidth: "infinity" }}>
              <VStack {...box(2)}>
                <HStack frame={{ maxWidth: "infinity", alignment: "leading" }}>
                  {/* A count only: Apple does not say how many the account may hold. */}
                  <Text font="subheadline" fontWeight="semibold" foregroundStyle="secondaryLabel">
                    {t("certs.count", { count: rows.length })}
                  </Text>
                  <Spacer />
                </HStack>
              </VStack>

              {rows.map((row, index) => (
                <VStack key={certificateKey(row.certificate)} {...box(3 + index)}>
                  <CertCard
                    row={row}
                    revoking={revoking === certificateKey(row.certificate)}
                    disabled={busy}
                    onRevoke={() => { void revoke(row) }}
                  />
                </VStack>
              ))}
            </VStack>
            : manager.loaded && !manager.working
              ? <VStack {...box(2)}><EmptyCertCard /></VStack>
              : null}
        </VStack>
      </ScrollView>

      {manager.failure === null
        ? null
        : <MilestoneOverlay>
          <PopupCard
            title={t("tool.certificates")}
            systemImage="exclamationmark.triangle.fill"
            tint={ERROR}
            onClose={() => manager.closeFailure()}
          >
            <Text font="subheadline" multilineTextAlignment="leading">
              {t(manager.failure.key, manager.failure.params)}
            </Text>
          </PopupCard>
        </MilestoneOverlay>}
    </ZStack>
  )
}
