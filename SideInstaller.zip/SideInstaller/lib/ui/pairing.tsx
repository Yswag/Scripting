// Pairing: the page behind the Tools row of the same name. It generates the pairing file this iPhone
// needs and exports it, which is the half of the Swift app's `PairingView` that does not need the
// device link — writing the file into an installed app does, and is not here.
import {
  Button, HStack, Image, RoundedRectangle, ScrollView, Text, VStack, ZStack, useObservable, useEffect,
} from "scripting"
import { t } from "../i18n"
import type { PairingExportFormat } from "../rpp"
import type { Bytes } from "../util"
import { engine, useLiveTick } from "./engine"
import { pushedPageToolbar } from "./toolbar"
import {
  ACCENT, AppBackground, BrandHeader, ERROR, FIELD_FILL, MilestoneOverlay, NumberedSteps, OK,
  PanelCard, PopupCard, PrimaryButton, ROUNDED, StatusPill, WARN, cascadeProps,
} from "./theme"

/**
 * What the pairing step puts up: where to go in Settings, and — once the device is at its own prompt —
 * the code it is asking for. The original app draws the same two cards, the code one only from the
 * moment the device asks, which is why it can be missing here for the first seconds.
 */
export function PairingPopup({ code, onClose }: { code: string | null, onClose: () => void }) {
  return (
    <VStack spacing={14} frame={{ maxWidth: "infinity", alignment: "leading" }}>
      {code === null
        ? null
        : <PopupCard title={t("activity.pair.title")} systemImage="lock.iphone" tint={WARN} onClose={onClose}>
          <VStack spacing={10} frame={{ maxWidth: "infinity" }}>
            <Text font={{ name: "Menlo", size: 40 }} fontWeight="bold" foregroundStyle={WARN}>{code}</Text>
            <Text font="footnote" foregroundStyle="secondaryLabel" multilineTextAlignment="center">
              {t("activity.pair.alert.body")}
            </Text>
          </VStack>
        </PopupCard>}

      <PopupCard title={t("step.pair.title")} systemImage="lock.iphone" tint={ACCENT} onClose={onClose}>
        {/* One step per line: the catalogue holds plain strings, so the list is the key on its newlines. */}
        <NumberedSteps steps={t("step.pair.cardSteps").split("\n")} />
      </PopupCard>
    </VStack>
  )
}

/** A card's title: its glyph, then the name. */
function SectionTitle({ title, systemImage }: { title: string, systemImage: string }) {
  return (
    <HStack spacing={8}>
      <Image systemName={systemImage} font="headline" foregroundStyle={ACCENT} />
      <Text font="headline">{title}</Text>
    </HStack>
  )
}

/** A full-width pairing-record action. */
function PairingActionButton({ disabled, action, title, systemImage }: {
  disabled: boolean, action: () => void, title: string, systemImage: string
}) {
  return (
    <Button action={action} disabled={disabled} frame={{ maxWidth: "infinity" }}>
      <HStack
        spacing={0}
        frame={{ maxWidth: "infinity" }}
        background={<RoundedRectangle {...ROUNDED(14)} fill={FIELD_FILL} />}
      >
        <HStack spacing={8} frame={{ maxWidth: "infinity" }} padding={{ vertical: 13 }}>
          <Image systemName={systemImage} font="subheadline" fontWeight="semibold" foregroundStyle={ACCENT} />
          <Text font="subheadline" fontWeight="semibold" foregroundStyle={ACCENT}>{title}</Text>
        </HStack>
      </HStack>
    </Button>
  )
}

export function PairingPage({ onSettings }: { onSettings: () => void }) {
  useLiveTick()

  // Whether the run in flight is one this page started, which is what its two result popups answer to:
  // a run started on the Install page reports there.
  const pressed = useObservable(false)
  const exists = engine.hasPairingRecord
  const device = engine.pairedDevice
  const generating = engine.stateOf("pair") === "running"
  const cancelled = engine.failureKeyOf("pair") === "step.pair.cancelled"
  const failed = engine.stateOf("pair") === "failed" && !cancelled
  const finishedHere = pressed.value === true && !generating

  const generate = () => {
    // A run already in flight is not this button's to start, and `runStep` would refuse it anyway.
    if (engine.isRunning) return
    pressed.setValue(true)
    void engine.runStep("pair", true)
  }

  // A device that has not dialled in yet can still be given up on; the code card's close is that.
  const giveUp = () => engine.cancelPairing()

  const closeResult = () => pressed.setValue(false)

  const importRecord = async (clipboard: boolean) => {
    try {
      const input = clipboard ? await Pasteboard.getString() : null
      const files = clipboard ? [] : await DocumentPicker.pickFiles({ types: ["public.data", "public.item"], allowsMultipleSelection: false })
      if (clipboard ? !input : files.length === 0) return
      // The runtime's byte reader returns an ArrayBuffer despite its types.
      const raw: any = clipboard ? null : FileManager.readAsBytesSync(files[0])
      const bytes: Bytes | string = clipboard
        ? input!
        : raw instanceof Uint8Array ? raw : new Uint8Array(raw as ArrayBuffer)
      if (engine.hasPairingRecord && !await Dialog.confirm({
        title: t("pairing.replaceTitle"), message: t("pairing.replaceMessage"),
        confirmLabel: t("pairing.replaceConfirm"),
      })) return
      await engine.importPairingRecord(bytes)
      await Dialog.alert(t("pairing.imported"))
    } catch (error) {
      await Dialog.alert(t("pairing.importFailed", { message: error instanceof Error ? error.message : String(error) }))
    }
  }

  const exportFile = async () => {
    const formats: PairingExportFormat[] = ["xml", "binary", "json"]
    const choice = await Dialog.actionSheet({
      title: t("pairing.export"),
      actions: [
        { label: "XML plist" },
        { label: "Binary plist" },
        { label: "JSON" },
      ],
    })
    // Some runtimes return -1 rather than null for Cancel; never pass it to the file picker.
    if (choice !== 0 && choice !== 1 && choice !== 2) return
    const format = formats[choice]
    const output = engine.pairingExport(format)
    if (output === null) return
    try {
      const data = typeof output === "string" ? Data.fromString(output) : Data.fromUint8Array(output)
      if (data === null) throw new Error("Could not encode pairing record")
      await DocumentPicker.exportFiles({ files: [{ data, name: `SideInstaller-pairing.${format === "json" ? "json" : "mobiledevicepairing"}` }] })
    } catch (error) {
      await Dialog.alert(t("pairing.exportFailed", { message: error instanceof Error ? error.message : String(error) }))
    }
  }

  const exportClipboard = async () => {
    try {
      const output = engine.pairingExport("xml")
      if (typeof output === "string") await Pasteboard.setString(output)
    } catch (error) {
      await Dialog.alert(t("pairing.exportFailed", { message: error instanceof Error ? error.message : String(error) }))
    }
  }

  const popup = generating
    ? <PairingPopup code={engine.pairingCode} onClose={giveUp} />
    : !finishedHere || cancelled
      ? null
      : failed
        ? <PopupCard
          title={t("pairing.error.title")}
          systemImage="exclamationmark.triangle.fill"
          tint={ERROR}
          onClose={closeResult}
        >
          <Text font="subheadline" multilineTextAlignment="leading">{engine.detailOf("pair")}</Text>
        </PopupCard>
        : exists
          ? <PopupCard
            title={t("tool.pairing")}
            systemImage="checkmark.seal.fill"
            tint={OK}
            onClose={closeResult}
          >
            <Text font="subheadline" multilineTextAlignment="leading">{t("pairing.ready")}</Text>
          </PopupCard>
          : null

  // The same deferred entrance the other pages use: a flag flipped straight from `onAppear` has no
  // painted starting state, so the cascade would have nothing to interpolate from.
  const revealed = useObservable(false)
  const reveal = () => {
    setTimeout(() => revealed.setValue(true), 30)
  }
  useEffect(reveal, [])
  const box = (index: number) => ({
    spacing: 0,
    frame: { maxWidth: "infinity" as const, alignment: "leading" as const },
    ...cascadeProps(index, revealed.value === true),
  })

  // No `NavigationStack` of its own: the page is pushed onto the Tools one, and the system draws the
  // way back. The backdrop keeps the Tools level, which is the darker one.
  return (
    <ZStack frame={{ maxWidth: "infinity", maxHeight: "infinity" }}>
      <AppBackground dark />
      <ScrollView
        toolbar={pushedPageToolbar(onSettings)}
        frame={{ maxWidth: "infinity", maxHeight: "infinity" }}
        scrollBounceBehavior="basedOnSize"
        onAppear={reveal}
      >
        <VStack spacing={18} frame={{ maxWidth: "infinity" }} padding={20}>
          <VStack {...box(0)}>
            <BrandHeader
              icon="lock.doc.fill"
              title={t("tool.pairing")}
              accessory={<StatusPill
                text={device !== null
                  ? device.name
                  : exists ? t("pairing.fileReady") : t("pairing.fileNone")}
                systemImage={device !== null ? "iphone" : exists ? "checkmark.seal.fill" : "lock.slash.fill"}
                color={device !== null || exists ? OK : WARN}
              />}
            />
          </VStack>

          <VStack {...box(1)}>
            <PanelCard>
              <VStack alignment="leading" spacing={14} frame={{ maxWidth: "infinity", alignment: "leading" }}>
                <SectionTitle title={t("pairing.file")} systemImage="lock.doc.fill" />

                <PrimaryButton
                  title={generating
                    ? t("pairing.generating")
                    : exists ? t("pairing.regenerate") : t("pairing.generate")}
                  systemImage={exists ? "arrow.clockwise" : "lock.iphone"}
                  busy={generating}
                  action={generate}
                  disabled={engine.isRunning}
                />

                <PairingActionButton disabled={engine.isRunning} action={() => { void importRecord(false) }} title={t("pairing.importFile")} systemImage="square.and.arrow.down" />
                <PairingActionButton disabled={engine.isRunning} action={() => { void importRecord(true) }} title={t("pairing.importClipboard")} systemImage="doc.on.clipboard" />
                {exists ? <PairingActionButton disabled={engine.isRunning} action={() => { void exportFile() }} title={t("pairing.export")} systemImage="square.and.arrow.up" /> : null}
                {exists ? <PairingActionButton disabled={engine.isRunning} action={() => { void exportClipboard() }} title={t("pairing.exportClipboard")} systemImage="clipboard" /> : null}
              </VStack>
            </PanelCard>
          </VStack>
        </VStack>
      </ScrollView>

      {popup === null ? null : <MilestoneOverlay>{popup}</MilestoneOverlay>}
    </ZStack>
  )
}
