// The Entitlements tool: the developer-portal capabilities Apple can grant an App ID. The port of
// the Swift app's catalogue and its `EntitlementsManager` — a portal call alone, so nothing here
// touches the device.
//
// What Apple accepts lands on the App ID, and only the *next* profile carries it: the app has to be
// signed and installed again. This tool does neither, and it never reads back what an App ID already
// holds — the picker starts from those remote flags and offers no way to turn a capability off.
import type { TranslationKey } from "./i18n"
import { APP_GROUP_FEATURE, type AppId, type CapabilityResult, type PortalClient, type Team } from "./apple"
import { StepError, type LogLevel } from "./engine"
import type { PlistDict } from "./util"

// MARK: - the catalogue

/** Which half of the picker a capability sits in. */
export type CapabilityGroup = "memory" | "other"

/** The groups in the order the picker draws them. */
export const CAPABILITY_GROUPS: readonly CapabilityGroup[] = ["memory", "other"]

/**
 * A developer-portal capability as this tool offers it.
 *
 * `name` is Apple's own feature name and is deliberately not translated — it is what the portal
 * calls the thing. `recommended` is the default selection, not a claim that an account gets it.
 */
export interface Capability {
  /** Apple's capability id, e.g. `INCREASED_MEMORY_LIMIT`. */
  id: string
  name: string
  group: CapabilityGroup
  /** On by default: what a sideloaded app usually wants, and what free Apple IDs are known to get. */
  recommended: boolean
}

/**
 * The twelve capabilities the Swift app offers — the three memory ones on by default, the rest under
 * a Beta heading. The paid-only ones (Push, iCloud, Associated Domains …) are left out entirely.
 *
 * Each is its own request, so a capability the account may not have fails alone. That is also why
 * the Beta half is shown at all: Apple, not this list, decides what a team may enable.
 */
export const CAPABILITIES: readonly Capability[] = [
  { id: "INCREASED_MEMORY_LIMIT", name: "Increased Memory Limit", group: "memory", recommended: true },
  { id: "EXTENDED_VIRTUAL_ADDRESSING", name: "Extended Virtual Addressing", group: "memory", recommended: true },
  { id: "INCREASED_DEBUGGING_MEMORY_LIMIT", name: "Increased Debugging Memory Limit", group: "memory", recommended: true },

  { id: "APP_GROUPS", name: "App Groups", group: "other", recommended: false },
  { id: "GAME_CENTER", name: "Game Center", group: "other", recommended: false },
  { id: "IN_APP_PURCHASE", name: "In-App Purchase", group: "other", recommended: false },
  { id: "INTER_APP_AUDIO", name: "Inter-App Audio", group: "other", recommended: false },
  { id: "HEALTHKIT", name: "HealthKit", group: "other", recommended: false },
  { id: "HOMEKIT", name: "HomeKit", group: "other", recommended: false },
  { id: "PERSONAL_VPN", name: "Personal VPN", group: "other", recommended: false },
  { id: "WIRELESS_ACCESSORY_CONFIGURATION", name: "Wireless Accessory Configuration", group: "other", recommended: false },
  { id: "DATA_PROTECTION", name: "Data Protection", group: "other", recommended: false },
]

/** The default selection: the capabilities upstream ticks when the picker opens. */
export function recommendedCapabilityIds(): Set<string> {
  return new Set(CAPABILITIES.filter(capability => capability.recommended).map(capability => capability.id))
}

/** Apple uses a legacy plist feature key for App Groups; other catalog ids use their own key. */
export function featureKeysForCapability(id: string): string[] {
  return id === APP_GROUPS_CAPABILITY ? [id, APP_GROUP_FEATURE] : [id]
}

/** Whether the latest App ID listing says Apple has enabled this capability. */
export function remoteCapabilityEnabled(features: PlistDict, id: string): boolean {
  return featureKeysForCapability(id).some(key => features[key] === true)
}

/** The catalog entries Apple currently reports as enabled. */
export function remoteEnabledCapabilityIds(features: PlistDict): Set<string> {
  return new Set(CAPABILITIES
    .filter(capability => remoteCapabilityEnabled(features, capability.id))
    .map(capability => capability.id))
}

/** Start from Apple's enabled state, using recommendations only where the portal has no answer. */
export function initialCapabilitySelection(features: PlistDict): Set<string> {
  const selected = remoteEnabledCapabilityIds(features)
  for (const capability of CAPABILITIES) {
    const hasRemoteValue = featureKeysForCapability(capability.id).some(key => features[key] !== undefined)
    if (!hasRemoteValue && capability.recommended) selected.add(capability.id)
  }
  return selected
}

/** Every id in the catalogue, which is what "select all" picks. */
export function allCapabilityIds(): Set<string> {
  return new Set(CAPABILITIES.map(capability => capability.id))
}

export function capabilitiesIn(group: CapabilityGroup): Capability[] {
  return CAPABILITIES.filter(capability => capability.group === group)
}

/** What a capability is called, falling back to its id for one this catalogue does not list. */
export function capabilityName(id: string): string {
  return CAPABILITIES.find(capability => capability.id === id)?.name ?? id
}

/** The App Groups capability: Apple accepting it grants no group by itself. */
export const APP_GROUPS_CAPABILITY = "APP_GROUPS"

// MARK: - what the portal hands back

/** One App ID on the team, as `listAppIds` gives it. */
export interface AppIdentifier {
  /** Apple's opaque id — what the capability call addresses. */
  appIdId: string
  /** The reverse-DNS bundle identifier. */
  identifier: string
  name: string
  /** The feature flags Apple returned for this App ID. */
  features: PlistDict
}

/** The line a row is headed with: the name Apple holds, else the identifier. */
export function appDisplayName(app: AppIdentifier): string {
  return app.name === "" ? app.identifier : app.name
}

/** What Apple said about one capability — one entry per request, refusals included. */
export type CapabilityOutcome = CapabilityResult

/** What the results popup shows: the App ID Apple answered about, and its per-capability answers. */
export interface EntitlementReport {
  app: AppIdentifier
  outcomes: CapabilityOutcome[]
}

// MARK: - the tool

/** What the tool needs from the app it runs in. Injected, so a test can answer without a portal. */
export interface EntitlementsHost {
  /** The Apple ID this device uses, or null when none has signed in. */
  account(): string | null
  /** A portal client for `email` from the session already saved, or null when there is none usable. */
  savedPortal(email: string): Promise<PortalClient | null>
  /** Signs `email` in — password, then the second factor — and saves the session. */
  signIn(email: string): Promise<boolean>
  say(key: TranslationKey, params?: Record<string, string | number>, level?: LogLevel): void
}

/**
 * The team's App IDs, and the one thing that can be done to them: ask Apple for capabilities.
 *
 * Fields are read by the page and written only here, which is as close as this gets to upstream's
 * `private(set)`. An overall failure (`failure`) and Apple's per-capability answers (`outcomes`) are
 * deliberately separate: "the batch did not go out" and "Apple refused this one" are different news.
 */
export class Entitlements {
  /** The App IDs the page draws, including Apple's current feature flags; empty until a list has arrived. */
  apps: AppIdentifier[] = []
  /** The team the App IDs belong to, once a list has been fetched. */
  team: Team | null = null
  /** A session is held, so a refresh needs nothing from the person. */
  signedIn = false
  /** A sign-in or a list is under way. */
  working = false
  /** The `appIdId` Apple is being asked about right now, or null. */
  applyingId: string | null = null
  /** True once a list has arrived — tells "not loaded" apart from "no App IDs". */
  loaded = false
  /** Last run's per-capability answers, keyed by App ID. Kept until the account changes. */
  outcomes: Record<string, CapabilityOutcome[]> = {}
  /** Why the last action failed as a whole, as a key the page resolves. */
  failure: StepError | null = null
  /** The App ID whose results are on screen, from the last run until that popup is closed. */
  reportedId: string | null = null

  private client: PortalClient | null = null
  private clientEmail: string | null = null
  private teamId: string | null = null
  private didAutoLoad = false
  private readonly listeners = new Set<() => void>()
  private readonly host: EntitlementsHost

  constructor(host: EntitlementsHost) {
    this.host = host
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => {
      this.listeners.delete(listener)
    }
  }

  private notify() {
    for (const listener of this.listeners) listener()
  }

  /** Whether something is in flight: the page disables its controls while one is. */
  get busy(): boolean {
    return this.working || this.applyingId !== null
  }

  /** What Apple answered on the last run, or null when no results are on screen. */
  report(): EntitlementReport | null {
    if (this.reportedId === null) return null
    const outcomes = this.outcomes[this.reportedId]
    const app = this.apps.find(entry => entry.appIdId === this.reportedId)
    if (outcomes === undefined || app === undefined) return null
    return { app, outcomes }
  }

  closeReport() {
    this.reportedId = null
    this.notify()
  }

  closeFailure() {
    this.failure = null
    this.notify()
  }

  /**
   * The list, fetched once when the page first opens — and only when that costs no questions.
   *
   * Upstream's `autoLoad` runs when it already holds the password. Here the same condition is a
   * saved session that still works, so a page opened on a device nobody has signed in on stays
   * quiet instead of putting up a password prompt nobody asked for.
   */
  autoLoad() {
    if (this.didAutoLoad || this.loaded || this.busy) return
    this.didAutoLoad = true
    void this.load(false)
  }

  /** Signs in when it must, then lists. `interactive` is what allows the password to be asked for. */
  async load(interactive = true) {
    if (this.busy) return
    const email = this.host.account()
    if (email === null) {
      // Nothing to sign in as. A person who pressed the button is told; a page that opened by
      // itself says nothing, as upstream's auto-load does with no credentials to use.
      if (interactive) this.fail(new StepError("entitlements.noAccount"))
      return
    }

    this.working = true
    this.failure = null
    this.host.say("entitlements.log.loading")
    this.notify()

    try {
      const client = await this.clientFor(email, interactive)
      // A null client has already said why, unless nothing was asked — which is not a failure.
      if (client === null) return
      await this.list(client)
    } catch (error) {
      this.fail(this.wrap(error, "entitlements.listFailed"))
    } finally {
      this.working = false
      this.notify()
    }
  }

  /**
   * Asks Apple for `ids` on `app`. Each is its own request, so the answer is per capability rather
   * than one pass or fail; what is stored is Apple's answer, not an expectation that anything works.
   */
  async enable(ids: string[], app: AppIdentifier) {
    const client = this.client
    if (this.busy || ids.length === 0 || client === null) return
    if (!this.ownsCurrentAccount()) {
      this.dropSession()
      this.fail(new StepError("entitlements.sessionChanged"))
      return
    }

    this.applyingId = app.appIdId
    this.failure = null
    this.reportedId = null
    delete this.outcomes[app.appIdId]
    this.host.say("entitlements.log.enabling", { count: ids.length, identifier: app.identifier })
    this.notify()

    try {
      const outcomes = await client.enableCapabilities(await this.teamFor(client), app.appIdId, ids)
      this.outcomes[app.appIdId] = outcomes
      this.reportedId = app.appIdId
      this.host.say("entitlements.log.enabled", {
        identifier: app.identifier,
        granted: outcomes.filter(outcome => outcome.ok).length,
        total: outcomes.length,
      }, outcomes.some(outcome => outcome.ok) ? "ok" : "warn")
    } catch (error) {
      this.fail(this.wrap(error, "entitlements.enableFailed"))
    } finally {
      this.applyingId = null
      this.notify()
    }
  }

  /**
   * The account's client: the one in hand when it belongs to this account, else whatever can be
   * opened. A client for another Apple ID is dropped, with what it listed and answered — that is
   * the previous account's app list, not this one's.
   */
  private async clientFor(email: string, interactive: boolean): Promise<PortalClient | null> {
    if (this.client !== null && this.clientEmail?.toLowerCase() === email.toLowerCase()) return this.client
    this.dropSession()

    let client = await this.host.savedPortal(email)
    if (client === null && interactive) {
      // Upstream signs in here with the password it holds. This port asks for it, through the same
      // sign-in Settings and the gates use.
      this.host.say("entitlements.log.signingIn", { email })
      if (!(await this.host.signIn(email))) {
        this.fail(new StepError("entitlements.signInFailed", { email }))
        return null
      }
      client = await this.host.savedPortal(email)
      if (client === null) {
        this.fail(new StepError("entitlements.noSession", { email }))
        return null
      }
    }
    if (client === null) return null

    this.client = client
    this.clientEmail = email
    this.signedIn = true
    return client
  }

  /** Lets the session go, and everything the previous account left on the page with it. */
  private ownsCurrentAccount(): boolean {
    const account = this.host.account()
    return account !== null && this.clientEmail !== null
      && account.toLowerCase() === this.clientEmail.toLowerCase()
  }

  private dropSession() {
    this.client = null
    this.clientEmail = null
    this.teamId = null
    this.team = null
    this.signedIn = false
    this.apps = []
    this.outcomes = {}
    this.reportedId = null
    this.loaded = false
    this.failure = null
  }

  /**
   * The team the App IDs are listed under, asked for once.
   *
   * The first one, as the Swift app's sign-in takes it: a free Apple ID has exactly one, and picking
   * among a real team's is the Install page's question, not this tool's.
   */
  private async teamFor(client: PortalClient): Promise<string> {
    if (this.teamId !== null) return this.teamId
    const team = (await client.listTeams())[0]
    if (team === undefined) throw new StepError("entitlements.noTeams")
    this.team = team
    this.teamId = team.teamId
    this.host.say("entitlements.log.team", { name: team.name, teamId: team.teamId })
    return team.teamId
  }

  /** One list, as the page draws it. Throws what the portal threw, for the caller to wrap. */
  private async list(client: PortalClient) {
    const listing = await client.listAppIds(await this.teamFor(client))
    this.apps = listing.appIds
      .map(toAppIdentifier)
      .sort((a, b) => appDisplayName(a).localeCompare(appDisplayName(b), undefined, { sensitivity: "base" }))
    this.loaded = true
    this.host.say("entitlements.log.listed", { count: this.apps.length }, "ok")
  }

  /**
   * A failure as the page shows it.
   *
   * A step error already carries the right key — "this account is on no team" is not a list that
   * failed — so only a raw one from the portal or the network is wrapped in the caller's key.
   */
  private wrap(error: unknown, key: TranslationKey): StepError {
    if (error instanceof StepError) return error
    return new StepError(key, { message: error instanceof Error ? error.message : String(error) })
  }

  private fail(error: StepError) {
    this.failure = error
    // The failure is itself a key, so the log reads as the sentence a person would have seen.
    this.host.say(error.key, error.params, "error")
    this.notify()
  }
}

/** The fields a page needs out of a portal listing, including the feature flags shown by the picker. */
function toAppIdentifier(app: AppId): AppIdentifier {
  return { appIdId: app.appIdId, identifier: app.identifier, name: app.name, features: app.features }
}
