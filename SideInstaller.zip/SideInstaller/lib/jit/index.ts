// JIT: attach a debugger to an installed app and answer the region requests it makes, which is
// what makes the app JIT-capable. The protocol layers below (RemoteXPC, the debug proxy's packets)
// stay inside.
export {
  APP_SERVICE,
  AppService,
  AppServiceError,
  type LaunchOptions,
  type ProcessToken,
} from "./appservice"
export {
  DEBUG_PROXY_SERVICE,
  EnableJITError,
  enableJIT,
  type EnableJITOptions,
  type EnableJITResult,
  type EnableStep,
} from "./enable"
export {
  scriptForAppName,
  isKnownAppName,
  regionTargetOf,
  type JitScript,
} from "./scripts"
export {
  DebugProxy,
  REGISTER,
  breakpointImmediate,
  checksumOf,
  encodePacket,
  isBreakpoint,
  littleEndianHex,
  parseStopReply,
  regionWritePackets,
  valueFromLittleEndianHex,
  type DebugProxyOptions,
  type StopReply,
} from "./rsp"
