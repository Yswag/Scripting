// Enabling JIT for one app: launch it under the debugger, answer its requests for executable
// regions, then let go.
//
// Two things make the process JIT-capable, and neither is ours to grant:
//   - attaching a debugger, which sets the debug flag the kernel checks (every device);
//   - preparing each executable region through that connection, which is what a device with TXM
//     requires before the app may run code out of it.
// The app asks for the second by executing a `brk` with its arguments in x0/x1 and a command in
// x16; this answers those stops and resumes it. An app that asks for nothing is simply resumed.
import type { DeviceLink } from "../rsd"
import { AppService } from "./appservice"
import { Clock } from "./clock"
import { type JitScript, regionTargetOf } from "./scripts"
import {
  DebugProxy,
  REGISTER,
  breakpointImmediate,
  isBreakpoint,
  parseStopReply,
  withDeadline,
} from "./rsp"

/** Where RSD exposes debugserver. */
export const DEBUG_PROXY_SERVICE = "com.apple.internal.dt.remote.debugproxy"

/** `brk #0x69` — the original request: x0 is the region, x1 its size. */
const BRK_LEGACY = 0x69
/** `brk #0x68` — the original way a script payload was handed over. */
const BRK_SCRIPT = 0x68
/** `brk #0xf00d` — the current one: the command is in x16. */
const BRK_UNIVERSAL = 0xf00d
/** `brk #0x70` — Geode's instruction patch: x0 destination, x1 source, x2 size. */
const BRK_PATCH = 0x70
/** `brk #0x71` — Geode's "let go". */
const BRK_DETACH = 0x71

/** What Geode's region request falls back to when it names no size. */
const GEODE_DEFAULT_REGION = 0x10000n
/** How much Geode's patch copies per packet. */
const PATCH_CHUNK = 0x4000n
/** Past this a patch freezes the app, so the reference script refuses it and so does this. */
const PATCH_LIMIT = 4n * 1024n * 1024n
/** How many requests Geode may not know before the session is given up. */
const GEODE_UNKNOWN_LIMIT = 10
/** How many times a wait may replace its connection before the session is given up. */
const RENEW_LIMIT = 8

const COMMAND_DETACH = 0n
const COMMAND_PREPARE_REGION = 1n

/** A cap on the work one attach may do, so a chatty target cannot hold the session open. */
const MAX_REGIONS = 256
/** Stops that lead nowhere still cost a round trip; this keeps a spin from running forever. */
const MAX_STOPS = 512

/** The literal the reference script puts in `x0` for the old request: "not here, use JIT26". */
const LEGACY_REFUSED = "E0000069"
export type EnableStep = "launch" | "attach" | "regions" | "detach"

export interface EnableJITOptions {
  bundleIdentifier: string
  /** Progress, in the caller's words. */
  onStep?: (step: EnableStep, detail?: string) => void
  /** Each packet the debugger stops on, for a log that can be read after the fact. */
  onTrace?: (line: string) => void
  /** How long the app may take to ask for its first region, and between regions. */
  windowMs?: number
  /** How long a single debug proxy packet may take. */
  timeoutMs?: number
  /** Which debug script the app speaks; see `scriptForAppName`. */
  script?: JitScript
}

export interface EnableJITResult {
  pid: number
  /** How many executable regions were prepared. */
  regions: number
}

export class EnableJITError extends Error {
  constructor(readonly stage: EnableStep, message: string) {
    super(message)
  }
}

export async function enableJIT(link: DeviceLink, options: EnableJITOptions): Promise<EnableJITResult> {
  const say = options.onStep ?? (() => {})
  const trace = options.onTrace ?? (() => {})
  const timeoutMs = options.timeoutMs ?? 10_000
  const windowMs = options.windowMs ?? 5_000
  const script = options.script ?? "universal"

  // Armed here, on the main queue: every later wait happens in a continuation, where a timer of its
  // own cannot be created.
  const clock = new Clock()
  clock.start()

  let stage: EnableStep = "launch"
  let session: DebugSession | null = null
  try {
    const app = await AppService.connect(link)
    let pid: number
    try {
      pid = await app.launch(options.bundleIdentifier, { startStopped: true })
    } finally {
      await app.close()
    }
    say("launch", String(pid))

    stage = "attach"
    say("attach")
    const open = () => openDebugProxy(link, pid, { timeoutMs, clock, trace })
    session = { proxy: await open(), open }
    trace(`script: ${script}`)

    stage = "regions"
    const regions = await answerRegionRequests(session, clock, windowMs, say, trace, script)
    return { pid, regions }
  } catch (error) {
    if (error instanceof EnableJITError) throw error
    throw new EnableJITError(stage, error instanceof Error ? error.message : String(error))
  } finally {
    if (session !== null) {
      if (session.proxy.isAttached) {
        say("detach")
        try {
          await session.proxy.detach()
        } catch {
          // The target may already be gone; the connection is what matters now.
        }
      }
      await session.proxy.close()
    }
    clock.stop()
  }
}

/** One debug proxy connection, from the handshake to the attach. */
async function openDebugProxy(
  link: DeviceLink,
  pid: number,
  options: { timeoutMs: number, clock: Clock, trace: (line: string) => void },
): Promise<DebugProxy> {
  const proxy = new DebugProxy(await link.open(DEBUG_PROXY_SERVICE), {
    timeoutMs: options.timeoutMs,
    clock: options.clock,
  })
  // The handshake goes: acknowledge the connection twice, turn acks off, then attach.
  await proxy.acknowledge()
  await proxy.acknowledge()
  await proxy.startNoAckMode()
  const attached = await proxy.attach(pid)
  options.trace(`attach: ${short(attached)}`)
  return proxy
}

/**
 * Answers `brk` stops until the app says it is done or the window closes.
 *
 * A device without TXM sends no stops at all: the attach alone was the whole job, so the target is
 * interrupted and this returns zero regions.
 */
async function answerRegionRequests(
  session: DebugSession,
  clock: Clock,
  windowMs: number,
  say: (step: EnableStep, detail?: string) => void,
  trace: (line: string) => void,
  script: JitScript,
): Promise<number> {
  let regions = 0
  let attempts = 0
  let unknown = 0
  trace(`waiting up to ${Math.round(windowMs / 1000)}s for the app to ask`)
  let stop = await nextStop(session, clock, windowMs, trace)
  while (stop !== null) {
    if (++attempts > MAX_STOPS) {
      trace(`${MAX_STOPS} stops without a region — giving up`)
      break
    }

    const reply = parseStopReply(stop)
    if (reply === null) {
      if (stop.startsWith("W") || stop.startsWith("X")) {
        trace(`the target is gone: ${short(stop)}`)
        break
      }
      // Anything else — an empty packet, a console line — is not a reason to give up.
      trace(`not a stop reply: ${short(stop)} — asking again`)
      stop = await nextStop(session, clock, windowMs, trace)
      continue
    }

    const thread = reply.thread
    const pc = reply.registers.get(REGISTER.pc)
    if (thread === null || pc === undefined) {
      trace(`a stop without a thread or a pc: ${short(stop)} — asking again`)
      stop = await nextStop(session, clock, windowMs, trace)
      continue
    }

    const x0 = reply.registers.get(REGISTER.x0) ?? 0n
    const x1 = reply.registers.get(REGISTER.x1) ?? 0n
    const x16 = reply.registers.get(REGISTER.x16) ?? 0n

    const word = await readInstruction(session.proxy, pc)
    if (!isBreakpoint(word)) {
      // Something other than a request stopped the target: let it run on, signal intact.
      trace(`stop at pc=0x${pc.toString(16)} (signal ${reply.signal}) is not a brk — running on`)
      stop = await nextStop(session, clock, windowMs, trace, { signal: reply.signal, thread })
      continue
    }

    const immediate = breakpointImmediate(word)
    trace(`brk 0x${immediate.toString(16)} at 0x${pc.toString(16)} tid=0x${thread.toString(16)}, x0=0x${x0.toString(16)} x1=0x${x1.toString(16)} x16=0x${x16.toString(16)}`)

    const context: StopContext = { proxy: session.proxy, script, thread, pc, registers: reply.registers, trace }
    const outcome = await answerStop(context, immediate)

    if (outcome === "prepared") {
      regions++
      say("regions", String(regions))
      const target = regionTargetOf(script)
      if (target !== null && regions >= target) {
        trace(`the ${script} script is done after ${regions} region(s)`)
        break
      }
      if (regions >= MAX_REGIONS) break
    } else if (outcome === "detach") {
      trace("the script is done")
      break
    } else if (outcome === "unknown") {
      // A request this script does not answer: let the app run on with the signal it stopped with.
      unknown++
      if (script === "geode" && unknown >= GEODE_UNKNOWN_LIMIT) {
        trace(`${GEODE_UNKNOWN_LIMIT} requests this script does not know — giving up`)
        break
      }
      stop = await nextStop(session, clock, windowMs, trace, { signal: reply.signal, thread })
      continue
    }
    stop = await nextStop(session, clock, windowMs, trace)
  }
  return regions
}

/** One debug proxy connection and a way to replace it after the transport gives up. */
interface DebugSession {
  proxy: DebugProxy
  open: () => Promise<DebugProxy>
}

/** What a stop asked for, once it has been answered. */
type StopOutcome = "resume" | "prepared" | "detach" | "unknown"

interface StopContext {
  proxy: DebugProxy
  script: JitScript
  thread: bigint
  pc: bigint
  registers: Map<number, bigint>
  trace: (line: string) => void
}

/** Answers one `brk`, in the dialect the app speaks. */
async function answerStop(context: StopContext, immediate: number): Promise<StopOutcome> {
  if (context.script === "legacy" || context.script === "maciOS") return answerOldRequest(context, immediate)
  if (context.script === "geode") return answerGeode(context, immediate)
  return answerUniversal(context, immediate)
}

/** The current dialect: `brk #0xf00d`, with the command in x16. */
async function answerUniversal(context: StopContext, immediate: number): Promise<StopOutcome> {
  const { proxy, thread, pc, trace } = context

  if (immediate === BRK_UNIVERSAL) {
    await skipBreakpoint(proxy, thread, pc)
    const command = context.registers.get(REGISTER.x16) ?? 0n
    if (command === COMMAND_DETACH) {
      trace("the app asks to detach")
      return "detach"
    }
    if (command !== COMMAND_PREPARE_REGION) {
      trace(`command ${command} is a script this cannot run`)
      return "resume"
    }
    const address = await prepareNamedRegion(context, true)
    await proxy.writeRegister(REGISTER.x0, thread, address)
    return "prepared"
  }

  if (immediate === BRK_LEGACY) {
    await skipBreakpoint(proxy, thread, pc)
    // The reply is an error code, which is how an app learns to use the JIT26 calls instead.
    await proxy.writeRegisterRaw(REGISTER.x0, thread, LEGACY_REFUSED)
    trace("the old request was answered with 0xE0000069")
    return "resume"
  }

  if (immediate === BRK_SCRIPT) {
    await skipBreakpoint(proxy, thread, pc)
    trace("a script payload is not run here")
    return "resume"
  }

  return "unknown"
}

/** The old protocol: `brk #0x69` names a region, and maciOS reads its address back out of x0. */
async function answerOldRequest(context: StopContext, immediate: number): Promise<StopOutcome> {
  if (immediate !== BRK_LEGACY) return "unknown"

  const address = await prepareNamedRegion(context, false)
  if (context.script === "maciOS") {
    await context.proxy.writeRegister(REGISTER.x0, context.thread, address)
  }
  await skipBreakpoint(context.proxy, context.thread, context.pc)
  return "prepared"
}

/** Geode: a region request, an instruction patch, and its own way of saying stop. */
async function answerGeode(context: StopContext, immediate: number): Promise<StopOutcome> {
  const { proxy, thread, pc, trace } = context

  if (immediate === BRK_DETACH) {
    trace("the app asks to detach")
    return "detach"
  }

  if (immediate === BRK_LEGACY) {
    const named = context.registers.get(REGISTER.x1) ?? 0n
    const region = {
      ...context,
      registers: new Map(context.registers).set(REGISTER.x1, named > 0n ? named : GEODE_DEFAULT_REGION),
    }
    await prepareNamedRegion(region, false)
    await skipBreakpoint(proxy, thread, pc)
    return "prepared"
  }

  if (immediate === BRK_PATCH) {
    await copyPatchedInstructions(context)
    await skipBreakpoint(proxy, thread, pc)
    return "prepared"
  }

  return "unknown"
}

/** `brk #0x70`: copies x2 bytes from x1 to x0, a packet at a time. */
async function copyPatchedInstructions(context: StopContext): Promise<void> {
  const { proxy, trace } = context
  const destination = context.registers.get(REGISTER.x0) ?? 0n
  const source = context.registers.get(REGISTER.x1) ?? 0n
  const size = context.registers.get(REGISTER.x2) ?? 10n

  if (size > PATCH_LIMIT) {
    trace(`a patch of 0x${size.toString(16)} bytes is too large — skipped`)
    return
  }

  for (let done = 0n; done < size; done += PATCH_CHUNK) {
    const chunk = size - done < PATCH_CHUNK ? size - done : PATCH_CHUNK
    const bytes = await proxy.readMemory(source + done, Number(chunk))
    await proxy.writeMemory(destination + done, bytes)
  }
  trace(`copied 0x${size.toString(16)} bytes to 0x${destination.toString(16)}`)
}

/** Writes one byte into every page of the region the request named. */
async function prepareNamedRegion(context: StopContext, allocateWhenNameless: boolean): Promise<bigint> {
  const address = context.registers.get(REGISTER.x0) ?? 0n
  const size = context.registers.get(REGISTER.x1) ?? 0n
  if (size <= 0n) return address

  const start = allocateWhenNameless && address === 0n
    ? await context.proxy.allocateExecutable(size)
    : address
  const refused = await context.proxy.prepareRegion(start, size)
  if (refused > 0) context.trace(`${refused} page(s) of 0x${start.toString(16)} would not take the write`)
  return start
}

/** Moves the target past the `brk` it stopped on, or it stops again on the same instruction. */
async function skipBreakpoint(proxy: DebugProxy, thread: bigint, pc: bigint): Promise<void> {
  await proxy.writeRegister(REGISTER.pc, thread, pc + 4n)
}

/**
 * The next stop, or null once the window closes — at which point the target is stopped again.
 *
 * A connection that stopped answering is replaced rather than ending the session: an app may sit
 * idle for longer than the tunnel allows a read to block, and coming back is cheaper than starting
 * over (the app keeps the debug flag and nothing was prepared yet).
 */
async function nextStop(
  session: DebugSession,
  clock: Clock,
  windowMs: number,
  trace: (line: string) => void,
  resume?: { signal: number, thread: bigint },
): Promise<string | null> {
  for (let attempt = 0; ; attempt++) {
    const { proxy } = session
    // A stop that was not a request keeps its signal: dropping it would change what the app sees.
    const work = resume === undefined
      ? () => proxy.continueUntilStop(windowMs)
      : () => proxy.continueWithSignal(resume.signal, resume.thread)

    try {
      return await withDeadline(clock, windowMs, "the app asking for JIT", work)
    } catch (error) {
      if (isDeadline(error) || attempt >= RENEW_LIMIT) {
        trace(error instanceof Error ? error.message : String(error))
        await stopTarget(proxy, clock)
        return null
      }

      trace(`the connection stopped answering (${messageOf(error)}) — re-attaching`)
      try {
        await proxy.close()
      } catch {
        // Whatever went wrong, the connection is being replaced anyway.
      }
      session.proxy = await session.open()
    }
  }
}

/** Whether a wait ran out of time, rather than the connection failing under it. */
function isDeadline(error: unknown): boolean {
  return error instanceof Error && error.name === "DeadlineExceeded"
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

/** A packet as a log line: enough to recognise it, not the whole reply. */
function short(text: string): string {
  const flat = text.replace(/\s+/g, " ").trim()
  return flat.length > 120 ? `${flat.slice(0, 120)}…` : flat
}

/** Interrupts the target so a detach leaves it in a known state. */
async function stopTarget(proxy: DebugProxy, clock: Clock): Promise<void> {
  try {
    await proxy.interrupt()
    await withDeadline(clock, 2_000, "the target stopping", () => proxy.readPacket())
  } catch {
    // Detaching stops it anyway.
  }
}

async function readInstruction(proxy: DebugProxy, pc: bigint): Promise<number> {
  const bytes = await proxy.readMemory(pc, 4)
  return (bytes[0] | (bytes[1] << 8) | (bytes[2] << 16) | (bytes[3] << 24)) >>> 0
}
