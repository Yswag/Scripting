// Which debug script an app speaks, by its display name.
//
// Not every app asks for JIT the same way: the `brk` immediate it uses and what its arguments mean
// differ, and answering with the wrong dialect leaves it waiting. The grouping is StikDebug's
// AutoScriptAssignments.
export type JitScript = "universal" | "geode" | "legacy" | "maciOS"

/** Emulators that use the current `brk #0xf00d` calls. */
const UNIVERSAL_APPS = [
  "Amethyst",
  "MeloNX",
  "XeniOS",
  "MeloCafé",
  "Manic EMU",
  "DukeX",
  "TachyonU",
  "touchHLE",
  "HyperHLE",
  "Applesauce",
  "RPCS3",
  "AetherPS4",
  "Husk",
]

/** Geode, which also patches instructions through `brk #0x70`. */
const GEODE_APPS = ["Geode"]

/** The old `brk #0x69` protocol, one region and then done. */
const LEGACY_APPS = ["UTM", "DolphiniOS", "Flycast", "ARMSX2 iOS"]

/** The old protocol again, but the region address is handed back and three requests are expected. */
const MACIOS_APPS = ["maciOS"]

/**
 * The script for an app of that name. Anything unlisted is taken to speak the current one: it is
 * what the newer apps use, and its answer to the old request tells the app to switch.
 */
export function scriptForAppName(name: string): JitScript {
  const trimmed = name.trim()
  if (GEODE_APPS.includes(trimmed)) return "geode"
  if (LEGACY_APPS.includes(trimmed)) return "legacy"
  if (MACIOS_APPS.includes(trimmed)) return "maciOS"
  return "universal"
}

/** How many regions a script expects before it lets go, or null when the app says so itself. */
export function regionTargetOf(script: JitScript): number | null {
  if (script === "legacy") return 1
  if (script === "maciOS") return 3
  return null
}

/** Whether the name is one the table knows, which is only useful for a log line. */
export function isKnownAppName(name: string): boolean {
  const trimmed = name.trim()
  return UNIVERSAL_APPS.includes(trimmed)
    || GEODE_APPS.includes(trimmed)
    || LEGACY_APPS.includes(trimmed)
    || MACIOS_APPS.includes(trimmed)
}
