// The CoreDevice app service: launching an app and learning its pid.
//
// It is a plain RemoteXPC conversation with one request per call — no Instruments (DTX) layer —
// which is why this is the road to a pid on iOS 17.4+.
import { randomBytes, utf8, writeXml } from "../util"
import { RemoteXpcSession, requireService, type DeviceLink } from "../rsd"
import {
  xpcArray,
  xpcBool,
  xpcData,
  xpcDictionary,
  xpcEmptyDictionary,
  xpcInt64,
  xpcString,
  xpcUInt64,
  type XpcValue,
} from "../rpp"

/** Where the app service lives in the RSD service table. */
export const APP_SERVICE = "com.apple.coredevice.appservice"

const LAUNCH_FEATURE = "com.apple.coredevice.feature.launchapplication"
const LIST_PROCESSES_FEATURE = "com.apple.coredevice.feature.listprocesses"

/** The CoreDevice protocol version a client announces. */
const CORE_DEVICE_VERSION = "629.3"

export interface LaunchOptions {
  /** Start the process stopped, so a debugger can attach before it runs a single instruction. */
  startStopped?: boolean
  /** Replace a running instance. Off keeps whatever the person already has open. */
  terminateExisting?: boolean
}

export interface ProcessToken {
  pid: number
  executable: string | null
}

/** A feature the device refused; its `CoreDevice.error` is carried, not swallowed. */
export class AppServiceError extends Error {
  constructor(readonly feature: string, message: string) {
    super(message)
  }
}

export class AppService {
  private constructor(private readonly session: RemoteXpcSession) {}

  static async connect(link: DeviceLink): Promise<AppService> {
    requireService(link.handshake, APP_SERVICE)
    return new AppService(await RemoteXpcSession.open(await link.open(APP_SERVICE)))
  }

  /** The pid of a launched (or already running) app. */
  async launch(bundleIdentifier: string, options: LaunchOptions = {}): Promise<number> {
    const output = await this.invoke(LAUNCH_FEATURE, launchInput(bundleIdentifier, options))
    const token = asRecord(output.processToken, "processToken")
    const pid = asNumber(token.processIdentifier)
    if (pid === null) throw new Error("the app service launched the app without a pid")
    return pid
  }

  async listProcesses(): Promise<ProcessToken[]> {
    const output = await this.invoke(LIST_PROCESSES_FEATURE, xpcEmptyDictionary)
    const tokens = output.processTokens
    if (!Array.isArray(tokens)) throw new Error("the app service listed no processes")
    return tokens.map(entry => {
      const token = asRecord(entry, "processToken")
      const executable = token.executableURL === undefined
        ? null
        : asRecord(token.executableURL, "executableURL").relative
      return {
        pid: asNumber(token.processIdentifier) ?? 0,
        executable: typeof executable === "string" ? executable : null,
      }
    })
  }

  async close(): Promise<void> {
    await this.session.close()
  }

  /** One feature call: the request envelope, then `CoreDevice.output` out of the reply. */
  private async invoke(feature: string, input: XpcValue): Promise<Record<string, unknown>> {
    await this.session.send(request(feature, input))
    const reply = asRecord(await this.session.receive(), "reply")

    const output = reply["CoreDevice.output"]
    if (output === undefined) {
      const error = reply["CoreDevice.error"]
      throw new AppServiceError(feature, error === undefined
        ? "the app service answered without an output"
        : describe(error))
    }
    return asRecord(output, "CoreDevice.output")
  }
}

function request(feature: string, input: XpcValue): XpcValue {
  return xpcDictionary([
    ["CoreDevice.CoreDeviceDDIProtocolVersion", xpcInt64(0n)],
    ["CoreDevice.action", xpcEmptyDictionary],
    ["CoreDevice.coreDeviceVersion", versionValue(CORE_DEVICE_VERSION)],
    ["CoreDevice.deviceIdentifier", xpcString(randomUuid())],
    ["CoreDevice.featureIdentifier", xpcString(feature)],
    ["CoreDevice.input", input],
    ["CoreDevice.invocationIdentifier", xpcString(randomUuid())],
  ])
}

/** `629.3` as the structured version the device compares against. */
function versionValue(version: string): XpcValue {
  const parts = version.split(".").map(part => BigInt(Number.parseInt(part, 10)))
  return xpcDictionary([
    ["originalComponentsCount", xpcInt64(BigInt(parts.length))],
    ["components", xpcArray(parts.map(part => xpcUInt64(part)))],
    ["stringValue", xpcString(version)],
  ])
}

function launchInput(bundleIdentifier: string, options: LaunchOptions): XpcValue {
  return xpcDictionary([
    [
      "applicationSpecifier",
      xpcDictionary([
        ["bundleIdentifier", xpcDictionary([["_0", xpcString(bundleIdentifier)]])],
      ]),
    ],
    [
      "options",
      xpcDictionary([
        ["arguments", xpcArray([])],
        ["environmentVariables", xpcEmptyDictionary],
        ["standardIOUsesPseudoterminals", xpcBool(true)],
        ["startStopped", xpcBool(options.startStopped ?? true)],
        ["terminateExisting", xpcBool(options.terminateExisting ?? false)],
        ["user", xpcDictionary([["active", xpcBool(true)]])],
        // An empty plist as data: the device decodes platform options from one, even when empty.
        ["platformSpecificOptions", xpcData(utf8(writeXml({})))],
      ]),
    ],
    ["standardIOIdentifiers", xpcEmptyDictionary],
  ])
}

function randomUuid(): string {
  const bytes = randomBytes(16)
  const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("")
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`
}

function asRecord(value: unknown, label: string): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value) || value instanceof Uint8Array) {
    throw new Error(`the app service's ${label} was ${describe(value)}`)
  }
  return value as Record<string, unknown>
}

function asNumber(value: unknown): number | null {
  if (typeof value === "number") return value
  if (typeof value === "bigint") return Number(value)
  return null
}

function describe(value: unknown): string {
  if (value === undefined) return "absent"
  if (value === null) return "null"
  if (value instanceof Uint8Array) return `${value.length} bytes`
  try {
    return JSON.stringify(value)
  } catch {
    return String(value)
  }
}
