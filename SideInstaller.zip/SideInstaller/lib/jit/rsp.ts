// The GDB remote serial protocol, as far as JIT needs it: packets, stop replies, registers, and the
// memory writes that prepare an executable region.
//
// debugserver speaks this over RSD's debug proxy. Packets are `$<body>#<checksum>` and every reply
// is acknowledged with `+` until `QStartNoAckMode` turns that off; the bodies here are all ASCII,
// so nothing needs the `}` escaping a binary payload would.
import { type Bytes, concat, fromHex, fromUtf8, toHex, utf8 } from "../util"
import type { ByteStream } from "../rsd"
import type { Clock } from "./clock"

const ACK = 0x2b
const NACK = 0x2d
const PACKET_START = 0x24
const PACKET_END = 0x23

/** The byte that stops a running target. */
export const INTERRUPT = new Uint8Array([0x03])

/** A tunnel connection hands back at most this much per read. */
const READ_LIMIT = 16384

/** 16 KiB: the page size a region is prepared one page at a time. */
export const REGION_PAGE = 16384

/** arm64 register numbers as debugserver numbers them. */
export const REGISTER = {
  x0: 0,
  x1: 1,
  x2: 2,
  x16: 16,
  sp: 31,
  pc: 32,
} as const

export function checksumOf(text: string): string {
  let sum = 0
  for (const byte of utf8(text)) sum = (sum + byte) & 0xff
  return sum.toString(16).padStart(2, "0")
}

export function encodePacket(text: string): Bytes {
  return utf8(`$${text}#${checksumOf(text)}`)
}

/** A stop reply: the `T` packet debugserver sends when the target stops. */
export interface StopReply {
  /** The signal that stopped it — 5 for the breakpoint instruction. */
  signal: number
  thread: bigint | null
  /** Register number to its value, as the reply carried it. */
  registers: Map<number, bigint>
}

/**
 * `T05thread:f1a;00:0000...;01:...;20:...;` as a stop reply.
 *
 * A `W`/`X` reply (the process exited) and anything else is not a stop and comes back as null.
 */
export function parseStopReply(text: string): StopReply | null {
  if (!text.startsWith("T") || text.length < 3) return null
  const signal = Number.parseInt(text.slice(1, 3), 16)
  if (!Number.isInteger(signal)) return null

  const registers = new Map<number, bigint>()
  let thread: bigint | null = null
  for (const field of text.slice(3).split(";")) {
    const at = field.indexOf(":")
    if (at <= 0) continue
    const key = field.slice(0, at)
    const value = field.slice(at + 1)
    if (key === "thread") {
      thread = BigInt(`0x${value}`)
      continue
    }
    if (!/^[0-9a-f]{1,2}$/i.test(key) || !/^[0-9a-f]+$/i.test(value)) continue
    registers.set(Number.parseInt(key, 16), valueFromLittleEndianHex(value))
  }
  return { signal, thread, registers }
}

/** A register value the way debugserver spells it: its 8 bytes, least significant first. */
export function littleEndianHex(value: bigint): string {
  let rest = value
  let out = ""
  for (let index = 0; index < 8; index++) {
    out += Number(rest & 0xffn).toString(16).padStart(2, "0")
    rest >>= 8n
  }
  return out
}

export function valueFromLittleEndianHex(hex: string): bigint {
  let value = 0n
  for (let at = hex.length - 2; at >= 0; at -= 2) value = (value << 8n) | BigInt(Number.parseInt(hex.substr(at, 2), 16))
  return value
}

/** arm64 `brk #imm`: `11010100 010 imm16 00000`. */
const BRK_MASK = 0xffe0001f
const BRK_BASE = 0xd4200000

export function isBreakpoint(word: number): boolean {
  return ((word & BRK_MASK) >>> 0) === BRK_BASE
}

export function breakpointImmediate(word: number): number {
  return ((word >>> 5) & 0xffff) >>> 0
}

/**
 * The raw packets that prepare a region: one single-byte write per page.
 *
 * This is what the debugger contributes to JIT on a device with TXM — every page of the region is
 * touched through the debug connection before the app may run code out of it. Sent in a batch
 * because a region is hundreds of pages, and each packet is answered with `OK`.
 */
export function regionWritePackets(start: bigint, size: bigint): { bytes: Bytes, count: number } {
  const count = size <= 0n ? 0 : Number((size - 1n) / BigInt(REGION_PAGE) + 1n)
  const out = new Uint8Array(count * 19)
  let address = start
  for (let index = 0; index < count; index++) {
    const at = index * 19
    const body = `M${addressHex(address)},1:69`
    out[at] = PACKET_START
    out.set(utf8(body), at + 1)
    out[at + 1 + body.length] = PACKET_END
    out.set(utf8(checksumOf(body)), at + 1 + body.length + 1)
    address += BigInt(REGION_PAGE)
  }
  return { bytes: out, count }
}

/**
 * An address as these packets spell it: nine hex digits, most significant first.
 *
 * Nine rather than sixteen because that is what the debugger's extension expects; a device address
 * is 36 bits.
 */
export function addressHex(address: bigint): string {
  return address.toString(16).padStart(9, "0")
}

export interface DebugProxyOptions {
  /** How long one packet may take before the call gives up. */
  timeoutMs?: number
  /** How many region-write packets are sent before their replies are drained. */
  batchSize?: number
  /** Delays that work outside the main JS queue. */
  clock?: Clock | null
}

/**
 * One debug proxy connection, as a client of debugserver.
 *
 * The stream is read through a buffer of our own: a reply can arrive split across reads, and the
 * `m` packet's answer is two characters per byte asked for.
 */
export class DebugProxy {
  private buffered: Bytes = new Uint8Array(0)
  private ackMode = true
  private attached = false
  private readonly timeoutMs: number
  private readonly batchSize: number
  private readonly clock: Clock | null

  constructor(private readonly stream: ByteStream, options: DebugProxyOptions = {}) {
    this.timeoutMs = options.timeoutMs ?? 10_000
    this.batchSize = options.batchSize ?? 128
    this.clock = options.clock ?? null
  }

  get isAttached(): boolean {
    return this.attached
  }

  /** `vAttach;<pid>`: from here on the target is stopped and ours to command. */
  async attach(pid: number): Promise<string> {
    const reply = await this.send(`vAttach;${pid.toString(16)}`)
    if (reply.startsWith("E")) throw new Error(`the debug proxy refused pid ${pid}: ${reply}`)
    this.attached = true
    return reply
  }

  /** `D`: let go. The target resumes, and the debug flag it gained stays on the process. */
  async detach(): Promise<string> {
    const reply = await this.send("D")
    this.attached = false
    return reply
  }

  async close(): Promise<void> {
    if (this.stream.close !== undefined) await this.stream.close()
  }

  /** Turns acknowledgements off, which is what lets region writes go out in a batch. */
  async startNoAckMode(): Promise<void> {
    await this.send("QStartNoAckMode")
    this.ackMode = false
  }

  /** A bare `+`. The debug proxy expects the connection to be acknowledged before a handshake. */
  async acknowledge(): Promise<void> {
    await this.sendRaw(utf8("+"))
  }

  async send(command: string, deadlineMs?: number): Promise<string> {
    await this.sendRaw(encodePacket(command))
    return this.readPacket(deadlineMs)
  }

  async sendRaw(bytes: Bytes): Promise<void> {
    await this.stream.write(bytes)
  }

  /** The next complete packet's body, with the framing and acknowledgement taken care of. */
  async readPacket(deadlineMs?: number): Promise<string> {
    return withDeadline(this.clock, deadlineMs ?? this.timeoutMs, "the debug proxy's reply", async () => {
      packet: for (;;) {
        const start = await this.nextByte()
        if (start === ACK) continue
        if (start === NACK) throw new Error("the debug proxy rejected a packet")
        if (start !== PACKET_START) continue

        const body: Bytes[] = []
        for (;;) {
          const byte = await this.nextByte()
          if (byte !== PACKET_END) {
            body.push(new Uint8Array([byte]))
            continue
          }

          const checksum = await this.take(2)
          const text = fromUtf8(concat(...body))
          // The two checksum bytes are swallowed, not checked: the framing is `$`…`#`, and a
          // reply that arrives in pieces still parses by it.
          void checksum
          if (this.ackMode) await this.sendRaw(utf8("+"))
          // `$#00` carries nothing — it is not the reply, so keep waiting for one that does.
          if (text.length === 0) continue packet
          return text
        }
      }
    })
  }

  async interrupt(): Promise<void> {
    await this.sendRaw(INTERRUPT)
  }

  /** `c`, stopping when the target hits a breakpoint. */
  /**
   * `c`, stopping when the target hits a breakpoint.
   *
   * The wait belongs to the caller: an app may take a long while before it asks for anything, and
   * that is not a proxy that has gone quiet.
   */
  async continueUntilStop(deadlineMs?: number): Promise<string> {
    return this.send("c", deadlineMs)
  }

  async continueWithSignal(signal: number, thread: bigint): Promise<string> {
    return this.send(`vCont;S${signal.toString(16).padStart(2, "0")}:${thread.toString(16)}`)
  }

  async readMemory(address: bigint, length: number): Promise<Bytes> {
    const text = await this.send(`m${address.toString(16)},${length.toString(16)}`)
    if (text.startsWith("E")) throw new Error(`reading ${length} bytes at 0x${address.toString(16)} failed: ${text}`)
    return fromHex(text)
  }

  async writeMemory(address: bigint, data: Bytes): Promise<void> {
    const reply = await this.send(`M${address.toString(16)},${data.length.toString(16)}:${toHex(data)}`)
    if (reply !== "OK") throw new Error(`writing at 0x${address.toString(16)} failed: ${reply}`)
  }

  async writeRegister(register: number, thread: bigint, value: bigint): Promise<void> {
    const reply = await this.send(
      `P${register.toString(16)}=${littleEndianHex(value)};thread:${thread.toString(16)};`)
    if (reply !== "OK") throw new Error(`writing register ${register} failed: ${reply}`)
  }

  /** `P<reg>=<hex>` with the value spelled out as given — some callers pass the bytes they were told. */
  async writeRegisterRaw(register: number, thread: bigint, hex: string): Promise<void> {
    const reply = await this.send(`P${register.toString(16)}=${hex};thread:${thread.toString(16)};`)
    if (reply !== "OK") throw new Error(`writing register ${register} failed: ${reply}`)
  }

  /** `_M<size>,rx`: memory the debug server allocates inside the target, already executable. */
  async allocateExecutable(size: bigint): Promise<bigint> {
    const text = await this.send(`_M${size.toString(16)},rx`)
    if (text.startsWith("E") || !/^[0-9a-f]+$/i.test(text)) {
      throw new Error(`allocating ${size} bytes of executable memory failed: ${text}`)
    }
    return BigInt(`0x${text}`)
  }

  /**
   * Touches every page of a region through the debug connection.
   *
   * The replies are `OK` one per packet, so a batch is written in one go and then drained — one
   * round trip per 128 pages instead of one per page.
   */
  /**
   * `M<addr>,1:69` into one byte of every page of the region.
   *
   * The replies are drained but not judged: a page that will not take the write is the app's
   * problem to notice, and the reference client ignores them the same way. The count of replies
   * that were not `OK` comes back so the caller can say something about it.
   */
  async prepareRegion(start: bigint, size: bigint): Promise<number> {
    const { bytes, count } = regionWritePackets(start, size)
    if (count === 0) return 0

    let refused = 0
    for (let sent = 0; sent < count; sent += this.batchSize) {
      const inBatch = Math.min(this.batchSize, count - sent)
      const from = sent * 19
      await this.sendRaw(bytes.subarray(from, from + inBatch * 19))
      for (let index = 0; index < inBatch; index++) {
        if ((await this.readPacket()) !== "OK") refused++
      }
    }
    return refused
  }

  private async nextByte(): Promise<number> {
    while (this.buffered.length === 0) await this.fill()
    const byte = this.buffered[0]
    this.buffered = this.buffered.subarray(1)
    return byte
  }

  private async take(count: number): Promise<Bytes> {
    while (this.buffered.length < count) await this.fill()
    const head = this.buffered.subarray(0, count)
    this.buffered = this.buffered.subarray(count)
    return head
  }

  private async fill(): Promise<void> {
    const chunk = await this.stream.read(READ_LIMIT)
    if (chunk === null) throw new Error("the debug proxy closed the connection")
    this.buffered = concat(this.buffered, chunk)
  }
}

/**
 * Runs `work` with a deadline.
 *
 * With a clock the wait works from any continuation; without one the timer is armed before `work`
 * starts, which only works while still on the main queue.
 */
export function withDeadline<T>(clock: Clock | null, ms: number, label: string, work: () => Promise<T>): Promise<T> {
  const timedOut = new Error(`${label} timed out after ${Math.round(ms / 1000)}s`)
  // A wait that ran out of time is not the same as a connection that stopped answering.
  timedOut.name = "DeadlineExceeded"

  if (clock !== null) {
    return Promise.race([work(), clock.after(ms).then(() => {
      throw timedOut
    })])
  }

  let handle: number | null = null
  const timer = new Promise<never>((_, reject) => {
    handle = setTimeout(() => reject(timedOut), ms)
  })
  return Promise.race([work(), timer]).finally(() => {
    if (handle !== null) clearTimeout(handle)
  })
}
