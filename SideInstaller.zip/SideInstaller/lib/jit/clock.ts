// Delays that survive leaving the main JS queue.
//
// `setTimeout` cannot be created from a socket continuation — the runtime answers "Timer requires
// its active script on the main JS execution queue" — and every wait after the first read happens
// exactly there. So one interval is armed while the flow is still on the main queue, and every
// later delay is a waiter this interval resolves.
export class Clock {
  private handle: number | null = null
  private readonly waiters = new Set<{ at: number, done: () => void }>()

  /** Arms the single interval. Must be called before the flow awaits anything. */
  start(stepMs = 200): void {
    if (this.handle !== null) return
    this.handle = setInterval(() => {
      const now = Date.now()
      for (const waiter of [...this.waiters]) {
        if (now < waiter.at) continue
        this.waiters.delete(waiter)
        waiter.done()
      }
    }, stepMs)
  }

  /** Stops the interval. Waiters that are still pending are released rather than left hanging. */
  stop(): void {
    if (this.handle !== null) clearInterval(this.handle)
    this.handle = null
    for (const waiter of [...this.waiters]) {
      this.waiters.delete(waiter)
      waiter.done()
    }
  }

  /** Resolves after `ms`; returns at once if the clock has already been stopped. */
  after(ms: number): Promise<void> {
    return new Promise(resolve => {
      this.waiters.add({ at: Date.now() + ms, done: resolve })
    })
  }
}
