// The image mounter: the other way a developer image is mounted, and the only way to ask whether
// one already is.
//
// A cryptex and a mounted image disagree about `/System/Developer`: installing a cryptex over an
// image the mounter put there is refused with `mkdir custom mount path: /System/Developer [17: File
// exists]`, and `copy-installed` (which only lists cryptexes) does not see it. So the question is
// asked here before anything is installed.
import type { PlistDict } from "../util"
import { PlistStream, requireService, rsdCheckin, type DeviceLink } from "../rsd"

/** Where the image mounter listens. It needs no developer image of its own. */
export const IMAGE_MOUNTER_SERVICE = "com.apple.mobile.mobile_image_mounter.shim.remote"

/**
 * The image types the device reports as mounted, e.g. `["Personalized"]`.
 *
 * Any entry at all means an image is mounted there: the caller asks "is one mounted", not "which".
 * An empty list is an answer, not a failure.
 */
export async function mountedImageTypes(link: DeviceLink): Promise<string[]> {
  requireService(link.handshake, IMAGE_MOUNTER_SERVICE)

  const stream = await link.open(IMAGE_MOUNTER_SERVICE)
  try {
    await rsdCheckin(stream, "sideinstaller-ddi")
    const plists = new PlistStream(stream)
    await plists.send({ Command: "CopyDevices" })

    const reply = await plists.receive()
    // `CopyDevices` answers with `EntryList`, one dictionary per mounted image.
    const entries = reply?.EntryList
    if (!Array.isArray(entries)) return []

    return entries.map(imageTypeOf).filter(type => type.length > 0)
  } finally {
    if (stream.close !== undefined) await stream.close()
  }
}

/** An entry's image type: `DiskImageType`, which `mount_image` spells `ImageType`. */
function imageTypeOf(entry: unknown): string {
  if (entry === null || typeof entry !== "object" || Array.isArray(entry) || entry instanceof Uint8Array) {
    return ""
  }
  const dict = entry as PlistDict
  const type = dict.DiskImageType ?? dict.ImageType
  return typeof type === "string" ? type : ""
}
