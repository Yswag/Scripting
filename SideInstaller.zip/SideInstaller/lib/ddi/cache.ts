// The five files a Cryptex1 developer image is made of, and how they reach this device.
//
// They are cached in `Documents/DDI` and only fetched when missing: a mounted image survives until
// the device reboots, and the files are tens of megabytes.
import type { Bytes } from "../util"

export interface DdiDownloader {
  /** Fetches `url` to `destination`, reporting progress as a fraction when it can. */
  download(url: string, destination: string, onProgress?: (fraction: number) => void): Promise<void>
}

export interface DdiFile {
  /** What the progress line calls it. */
  name: string
  file: string
  url: string
}

const BASE = "https://github.com/doronz88/DeveloperDiskImage/raw/refs/heads/main/PersonalizedImages/Xcode_iOS_DDI_Cryptex"

/** One queue for these files, so a transfer is not scheduled twice. */
const QUEUE_IDENTIFIER = "sideinstaller-ddi"

export const DDI_FILES: DdiFile[] = [
  { name: "build manifest", file: "BuildManifest.plist", url: `${BASE}/BuildManifest.plist` },
  { name: "image", file: "Image.dmg", url: `${BASE}/Image.dmg` },
  { name: "trust cache", file: "Image.dmg.trustcache", url: `${BASE}/Image.dmg.trustcache` },
  { name: "cryptex info", file: "Image.dmg.cryptex_info", url: `${BASE}/Image.dmg.cryptex_info` },
  { name: "root hash", file: "Image.dmg.root_hash", url: `${BASE}/Image.dmg.root_hash` },
]

function fm(): any {
  const manager: any = (globalThis as any).FileManager
  if (manager === undefined) throw new Error("this build has no file access")
  return manager
}

/** Where the image's files live. */
export function ddiDirectory(): string {
  return `${fm().documentsDirectory}/DDI`
}

/** Whether every file of the image is already on disk. */
export function ddiFilesReady(directory = ddiDirectory()): boolean {
  const manager = fm()
  return DDI_FILES.every(item => manager.existsSync(`${directory}/${item.file}`))
}

/** Downloads whatever is missing, then returns the directory. */
export async function ensureDdiFiles(
  downloader: DdiDownloader,
  onProgress?: (index: number, fraction: number) => void,
): Promise<string> {
  const manager = fm()
  const directory = ddiDirectory()
  if (!manager.existsSync(directory)) manager.createDirectorySync(directory, true)

  for (const [index, item] of DDI_FILES.entries()) {
    const destination = `${directory}/${item.file}`
    if (manager.existsSync(destination)) continue
    await downloader.download(item.url, destination, fraction => onProgress?.(index, fraction))
  }
  return directory
}

/** One of the image's files as bytes. */
export function readDdiFile(directory: string, file: string): Bytes {
  const raw: any = fm().readAsBytesSync(`${directory}/${file}`)
  if (raw instanceof Uint8Array) return raw
  return new Uint8Array(raw as ArrayBuffer)
}

/** The download queue the app already has: background transfers, retries and progress. */
export function nativeDdiDownloader(): DdiDownloader {
  return {
    async download(url, destination, onProgress) {
      const manager: any = (globalThis as any).DownloadManager
      if (manager === undefined) throw new Error("this build has no download manager")
      const queue = await manager.open({ identifier: QUEUE_IDENTIFIER })

      // A finished record whose file is gone would be answered with that missing file, not a
      // download; drop the record so the transfer happens again.
      const previous = await queue.getTaskByURL?.(url)
      if (previous !== null && previous !== undefined) {
        const snapshot = await previous.getSnapshot()
        if (snapshot?.state === "completed" && fm().existsSync(destination) !== true) {
          await previous.remove()
        }
      }

      const task = await queue.download({ url, destination })
      if (onProgress !== undefined) {
        task.onProgress = (progress: any) => onProgress(progress.fractionCompleted ?? 0)
      }
      try {
        await task.waitUntilFinished()
      } finally {
        if (onProgress !== undefined) task.onProgress = undefined
      }
    },
  }
}

/** Drops this image's download records, so files deleted by hand are fetched again. */
export async function forgetDdiDownloads(): Promise<void> {
  const manager: any = (globalThis as any).DownloadManager
  if (manager === undefined) return
  const queue = await manager.open({ identifier: QUEUE_IDENTIFIER })
  for (const item of DDI_FILES) {
    const task = await queue.getTaskByURL?.(item.url)
    if (task !== null && task !== undefined) await task.remove()
  }
}
