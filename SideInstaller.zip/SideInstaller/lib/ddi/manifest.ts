// The build manifest behind a Cryptex1 developer image: which identity is the DDI, where its four
// payloads sit, and the tags Apple's ticket server wants for that identity.
import { type PlistDict, type PlistValue } from "../util"

/** The identity a Cryptex1 developer image lives in, named by the tail of its variant. */
const CRYPTEX_VARIANT_SUFFIX = "Developer Disk Image Cryptex"

/** The four payloads an install sends, as keys in the identity's `Manifest`. */
const PAYLOAD_KEYS = {
  image: "Cryptex1,GenericDmg",
  trustcache: "Cryptex1,GenericTrustCache",
  info: "Cryptex1,CryptexInfoPlist",
  volumehash: "Cryptex1,GenericVolume",
} as const

/** The tags copied into the ticket request exactly as the manifest spells them. */
const PASSTHROUGH_TAGS = [
  "Cryptex1,Type",
  "Cryptex1,SubType",
  "Cryptex1,UseProductClass",
  "Cryptex1,NonceDomain",
  "Cryptex1,Version",
  "Cryptex1,PreauthorizationVersion",
] as const

export interface CryptexIdentity {
  /** The build identity dictionary. */
  identity: PlistDict
  /** The nonce domain this image is personalized against. */
  nonceDomain: bigint
  /** Payload paths, relative to the manifest's directory. */
  payloads: { image: string, trustcache: string, info: string, volumehash: string }
  /** What an install sends as `cryptex1-properties`. */
  properties: CryptexProperties
}

/**
 * The parameters an install carries, kept as the values that go on the wire.
 *
 * The two integers are unsigned 64-bit on the wire; sent as signed ones the daemon rejects the
 * whole request.
 */
export interface CryptexProperties {
  useProductClass: PlistValue
  subType: bigint
  nonceDomain: bigint
  version: PlistValue
  preauthVersion: PlistValue
}

/** The one identity in a developer image's manifest that describes a cryptex. */
export function readCryptexIdentity(manifest: PlistDict): CryptexIdentity {
  const identities = manifest.BuildIdentities
  if (!Array.isArray(identities)) throw new Error("the build manifest has no BuildIdentities")

  const identity = identities
    .map(value => (isDict(value) ? value : null))
    .find(entry => {
      const variant = entry === null ? undefined : strOf(entry.Info, "Variant")
      return variant !== undefined && variant.endsWith(CRYPTEX_VARIANT_SUFFIX)
    })
  if (identity === undefined || identity === null) {
    throw new Error("the build manifest has no developer image cryptex identity")
  }

  const payloads = {
    image: payloadPath(identity, PAYLOAD_KEYS.image),
    trustcache: payloadPath(identity, PAYLOAD_KEYS.trustcache),
    info: payloadPath(identity, PAYLOAD_KEYS.info),
    volumehash: payloadPath(identity, PAYLOAD_KEYS.volumehash),
  }

  return {
    identity,
    nonceDomain: unsigned(required(identity, "Cryptex1,NonceDomain"), "Cryptex1,NonceDomain"),
    payloads,
    properties: cryptexProperties(identity),
  }
}

/**
 * The ticket request for that identity.
 *
 * A Cryptex1 ticket does not describe the device the way an AP ticket does — the UDID alone
 * identifies it — and each personalized component contributes nothing but its digest. The generic
 * image is declared not personalized and is left out.
 */
export function cryptexTicketTags(identity: PlistDict, chip: PlistDict, nonce: Uint8Array): PlistDict {
  const tags: PlistDict = {
    "@Cryptex1,Ticket": true,
    "Cryptex1,ChipID": number(required(identity, "Cryptex1,ChipID"), "Cryptex1,ChipID"),
    "Cryptex1,ProductClass": number(required(identity, "Cryptex1,ProductClass"), "Cryptex1,ProductClass"),
  }
  for (const key of PASSTHROUGH_TAGS) tags[key] = required(identity, key)
  tags["Cryptex1,Nonce"] = nonce
  tags["Cryptex1,ProductionMode"] = flag(required(chip, "img4_chip_cpro"), "img4_chip_cpro")
  tags["Cryptex1,UDID"] = cryptexUdid(chip)
  tags["Cryptex1,UniqueTagList"] = new Uint8Array(0)

  const manifest = required(identity, "Manifest")
  if (!isDict(manifest)) throw new Error("the cryptex identity has no Manifest")
  for (const [key, entry] of Object.entries(manifest)) {
    if (!key.startsWith("Cryptex1,") || !isDict(entry)) continue
    if (!flag(entry.Info === undefined ? false : dictOf(entry.Info, key).Personalize ?? false, key)) continue
    const digest = required(entry, "Digest")
    tags[key] = { Digest: digest }
  }
  return tags
}

/**
 * `Cryptex1,UDID`: the chip id and the ECID, each 8 bytes big-endian.
 *
 * Eight bytes each regardless of the value, so the pair is always 16 bytes.
 */
export function cryptexUdid(chip: PlistDict): Uint8Array {
  const out = new Uint8Array(16)
  const write = (value: bigint, at: number) => {
    let rest = value
    for (let index = 7; index >= 0; index--) {
      out[at + index] = Number(rest & 0xffn)
      rest >>= 8n
    }
  }
  write(unsigned(required(chip, "img4_chip_chip"), "img4_chip_chip"), 0)
  write(unsigned(required(chip, "img4_chip_ecid"), "img4_chip_ecid"), 8)
  return out
}

/** The nonce the daemon wraps in a small header: two bytes, the nonce, then its length. */
export function unwrapNonce(blob: Uint8Array): Uint8Array {
  if (blob.length < 6) throw new Error(`a cryptex nonce is at least 6 bytes, got ${blob.length}`)
  const length = blob[blob.length - 4] |
    (blob[blob.length - 3] << 8) |
    (blob[blob.length - 2] << 16) |
    (blob[blob.length - 1] << 24)
  if (length <= 0 || 2 + length > blob.length) {
    throw new Error(`a cryptex nonce names ${length} bytes inside ${blob.length}`)
  }
  return blob.subarray(2, 2 + length)
}

function cryptexProperties(identity: PlistDict): CryptexProperties {
  return {
    useProductClass: required(identity, "Cryptex1,UseProductClass"),
    subType: unsigned(required(identity, "Cryptex1,SubType"), "Cryptex1,SubType"),
    nonceDomain: unsigned(required(identity, "Cryptex1,NonceDomain"), "Cryptex1,NonceDomain"),
    version: required(identity, "Cryptex1,Version"),
    // The daemon's name for it; the manifest spells it out.
    preauthVersion: required(identity, "Cryptex1,PreauthorizationVersion"),
  }
}

function payloadPath(identity: PlistDict, key: string): string {
  const manifest = required(identity, "Manifest")
  if (!isDict(manifest)) throw new Error("the cryptex identity has no Manifest")
  const entry = required(manifest, key)
  if (!isDict(entry)) throw new Error(`${key} is not a manifest entry`)
  const path = strOf(entry.Info, "Path")
  if (path === undefined) throw new Error(`the build manifest has no path for ${key}`)
  return path
}

function isDict(value: PlistValue | undefined): value is PlistDict {
  return value !== null && value !== undefined && typeof value === "object"
    && !Array.isArray(value) && !(value instanceof Uint8Array) && !(value instanceof Date)
}

function dictOf(value: PlistValue, label: string): PlistDict {
  if (!isDict(value)) throw new Error(`${label} is not a dictionary`)
  return value
}

function required(dict: PlistDict, key: string): PlistValue {
  const value = dict[key]
  if (value === undefined) throw new Error(`the build manifest has no ${key}`)
  return value
}

function strOf(value: PlistValue | undefined, key: string): string | undefined {
  if (!isDict(value)) return undefined
  const entry = value[key]
  return typeof entry === "string" ? entry : undefined
}

/** A manifest number: an integer, or a `0x`-prefixed string. */
function unsigned(value: PlistValue, label: string): bigint {
  if (typeof value === "bigint") return value
  if (typeof value === "number" && Number.isInteger(value)) return BigInt(value)
  if (typeof value === "string") {
    const text = value.trim()
    const parsed = text.toLowerCase().startsWith("0x")
      ? BigInt(text)
      : BigInt(Number.parseInt(text, 10))
    return parsed
  }
  throw new Error(`${label} is not an unsigned integer`)
}

function number(value: PlistValue, label: string): number {
  const parsed = unsigned(value, label)
  if (parsed > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error(`${label} is too large for a number`)
  return Number(parsed)
}

/** A flag a manifest spells as a boolean or as an integer. */
function flag(value: PlistValue, label: string): boolean {
  if (typeof value === "boolean") return value
  if (typeof value === "number") return value !== 0
  if (typeof value === "bigint") return value !== 0n
  throw new Error(`${label} is neither a boolean nor an integer`)
}
