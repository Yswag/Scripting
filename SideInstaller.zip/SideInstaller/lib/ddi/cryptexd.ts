// cryptexd: the daemon that installs the developer image on iOS 26.4 and later.
//
// One routine per connection — the daemon closes it after answering — and an install pushes its
// five payloads as XPC file transfers on streams of their own.
import { type Bytes, type PlistDict } from "../util"
import { RemoteXpcSession, requireService, type DeviceLink } from "../rsd"
import {
  xpcBool,
  xpcDictionary,
  xpcFileTransfer,
  xpcFromPlist,
  xpcString,
  xpcUInt64,
  type XpcDictionaryEntry,
  type XpcValue,
} from "../rpp"
import { unwrapNonce, type CryptexProperties } from "./manifest"

/** Where the daemon listens in the RSD service table. */
export const CRYPTEXD_SERVICE = "com.apple.security.cryptexd.remote"

/** The identifier the developer image is installed under. */
export const DDI_CRYPTEX_IDENTIFIER = "com.apple.MobileAsset.DDI"

const CLIENT_VERSION = 3
const DDI_IMAGE_TYPE_INDEX = 10
const DDI_PERSISTENCE = 2
const DDI_NONCE_PERSISTENCE = 1

export interface CryptexPayloads {
  image: Bytes
  trustcache: Bytes
  im4m: Bytes
  info: Bytes
  volumehash: Bytes
  /** The `Cryptex1,*` parameters the install carries. */
  properties: CryptexProperties
}

/** A routine the daemon refused, with its own words. */
export class CryptexdError extends Error {
  constructor(readonly routine: string, message: string) {
    super(message)
  }
}

/** The device's AppleImage4 chip instance, as `read-personalization-id` reports it. */
export async function readPersonalizationIdentifiers(link: DeviceLink): Promise<PlistDict> {
  const argv = await invoke(link, "read-personalization-id", xpcDictionary([]))
  if (argv === null) throw new CryptexdError("read-personalization-id", "the daemon named no identifiers")
  return argv as PlistDict
}

/** The cryptex nonce for one nonce domain, unwrapped from the daemon's little header. */
export async function cryptexNonce(link: DeviceLink, handle: bigint): Promise<Bytes> {
  const argv = await invoke(link, "get-nonce", xpcDictionary([["nonce-domain-handle", xpcUInt64(handle)]]))
  const nonce = argv === null ? undefined : argv.nonce
  if (!(nonce instanceof Uint8Array)) {
    throw new CryptexdError("get-nonce", "the daemon answered without a nonce")
  }
  return unwrapNonce(nonce)
}

/** The installed developer image's version, or null when there is none. */
export async function installedDeveloperImage(link: DeviceLink): Promise<string | null> {
  const argv = await invoke(link, "copy-installed", xpcDictionary([]))
  const list = argv === null ? undefined : argv["remote-cryptex-array"]
  if (!Array.isArray(list)) return null
  for (const entry of list) {
    if (entry === null || typeof entry !== "object" || Array.isArray(entry)) continue
    const record = entry as Record<string, unknown>
    if (record["remote-cryptex-identifier"] !== DDI_CRYPTEX_IDENTIFIER) continue
    const version = record["remote-cryptex-version"]
    return typeof version === "string" ? version : ""
  }
  return null
}

/** Personalizes and installs the image; the daemon replies only once it has every payload. */
export async function installCryptex(link: DeviceLink, payloads: CryptexPayloads): Promise<void> {
  const transfers: Array<[string, Bytes]> = [
    ["image", payloads.image],
    ["trustcache", payloads.trustcache],
    ["im4m", payloads.im4m],
    ["info", payloads.info],
    ["volumehash", payloads.volumehash],
  ]

  const argv: XpcDictionaryEntry[] = [
    ["auth", xpcUInt64(0n)],
    ["client-version", xpcUInt64(BigInt(CLIENT_VERSION))],
    ["cryptex1-properties", propertiesValue(payloads.properties)],
    ["image-type-index", xpcFromPlist(DDI_IMAGE_TYPE_INDEX)],
    ["nonce-persistence", xpcUInt64(BigInt(DDI_NONCE_PERSISTENCE))],
    ["persistence", xpcUInt64(BigInt(DDI_PERSISTENCE))],
  ]
  transfers.forEach(([key, payload], index) => {
    const size: XpcValue = xpcDictionary([["s", xpcUInt64(BigInt(payload.length))]])
    argv.push([key, xpcFileTransfer(BigInt(index + 1), size)])
  })

  await withDaemon(link, async session => {
    await session.send(xpcDictionary([["routine", xpcString("install")], ["argv", xpcDictionary(argv)]]))
    for (const [index, [, payload]] of transfers.entries()) {
      await session.sendFileTransfer(index, BigInt(index + 1), payload)
    }
    unwrapReply("install", await session.receive())
  })
}

/**
 * `cryptex1-properties` as Xcode sends it.
 *
 * `SubType` and `NonceDomain` must be unsigned 64-bit: as signed ones the daemon rejects the whole
 * request with `Cryptex1,NonceDomain [79: Inappropriate file type or format]`.
 */
function propertiesValue(properties: CryptexProperties): XpcValue {
  return xpcDictionary([
    ["Cryptex1,UseProductClass", xpcFromPlist(properties.useProductClass)],
    ["MountedCryptex", xpcBool(false)],
    ["Cryptex1,SubType", xpcUInt64(properties.subType)],
    ["Cryptex1,NonceDomain", xpcUInt64(properties.nonceDomain)],
    ["Cryptex1,Version", xpcFromPlist(properties.version)],
    ["Cryptex1,PreauthVersion", xpcFromPlist(properties.preauthVersion)],
  ])
}

/** One routine, on a connection of its own. */
async function invoke(link: DeviceLink, routine: string, argv: XpcValue): Promise<Record<string, unknown> | null> {
  return withDaemon(link, async session => {
    await session.send(xpcDictionary([["routine", xpcString(routine)], ["argv", argv]]))
    return unwrapReply(routine, await session.receive())
  })
}

async function withDaemon<T>(link: DeviceLink, body: (session: RemoteXpcSession) => Promise<T>): Promise<T> {
  requireService(link.handshake, CRYPTEXD_SERVICE)
  const session = await RemoteXpcSession.open(await link.open(CRYPTEXD_SERVICE))
  try {
    return await body(session)
  } finally {
    await session.close()
  }
}

/**
 * Whatever else the daemon said, besides the description and the code.
 *
 * A refusal carries more fields than the two that make the sentence; when it names no identifier
 * (`[anonymous]`) those are the only place the reason shows up.
 */
function extra(detail: Record<string, unknown>): string {
  const rest: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(detail)) {
    if (key === "cferr_code" || key === "cferr_domain" || key === "cferr_userinfo") continue
    rest[key] = value
  }
  const info = detail.cferr_userinfo
  if (info !== null && typeof info === "object" && !Array.isArray(info)) {
    for (const [key, value] of Object.entries(info as Record<string, unknown>)) {
      if (key === "NSLocalizedDescription") continue
      rest[`userinfo.${key}`] = value
    }
  }
  const keys = Object.keys(rest)
  if (keys.length === 0) return ""
  try {
    const text = JSON.stringify(rest)
    return ` — ${text.length > 300 ? `${text.slice(0, 300)}…` : text}`
  } catch {
    return ` — ${keys.join(", ")}`
  }
}

/** `argv` out of a reply, or the daemon's error, which is how a refusal is spelled. */
function unwrapReply(routine: string, reply: unknown): Record<string, unknown> | null {
  if (reply === null || typeof reply !== "object" || Array.isArray(reply)) {
    throw new CryptexdError(routine, "the daemon's reply was not a dictionary")
  }
  const dict = reply as Record<string, unknown>

  const failure = dict.cferr
  if (failure !== null && typeof failure === "object" && !Array.isArray(failure)) {
    const detail = failure as Record<string, unknown>
    const info = detail.cferr_userinfo
    const description = info !== null && typeof info === "object" && !Array.isArray(info)
      ? (info as Record<string, unknown>).NSLocalizedDescription
      : undefined
    const domain = detail.cferr_domain
    const code = detail.cferr_code
    const said = typeof description === "string" ? description : "failed"
    throw new CryptexdError(routine, `${routine} failed: ${said} (${String(domain)}: ${String(code)})${extra(detail)}`)
  }

  const error = dict.error
  if (typeof error === "number" && error !== 0) {
    throw new CryptexdError(routine, `errno ${error}`)
  }

  const argv = dict.argv
  if (argv === undefined || argv === null) return null
  if (typeof argv !== "object" || Array.isArray(argv)) {
    throw new CryptexdError(routine, "the daemon's argv was not a dictionary")
  }
  return argv as Record<string, unknown>
}
