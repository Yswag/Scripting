// Apple's ticket server, asked for the one thing a cryptex needs signed: its Cryptex1 ticket.
//
// TSS answers a form-encoded status line with the signed plist after `REQUEST_STRING=`, not JSON
// and not a plist body.
import { fromUtf8, parsePlist, randomBytes, writeXml, type Bytes, type PlistDict } from "../util"

const TSS_ENDPOINT = "https://gs.apple.com/TSS/controller?action=2"
const CLIENT_VERSION = "libauthinstall-1033.0.2"

export interface TssOptions {
  /** For tests: where the request goes instead of Apple. */
  endpoint?: string
  /** For tests: the transport. */
  post?: (url: string, body: string) => Promise<string>
}

/** A Cryptex1 ticket, signed for the identity and nonce the tags name. */
export async function fetchCryptexTicket(tags: PlistDict, options: TssOptions = {}): Promise<Bytes> {
  const request: PlistDict = {
    "@HostPlatformInfo": "mac",
    "@VersionInfo": CLIENT_VERSION,
    "@UUID": upperUuid(),
    ...tags,
  }

  const body = writeXml(request)
  const post = options.post ?? ((url, text) => postXml(url, text))
  const response = await post(options.endpoint ?? TSS_ENDPOINT, body)

  // A refusal is `STATUS=<n>&MESSAGE=<text>` with no ticket behind it.
  const text = response.trimStart()
  if (!text.includes("REQUEST_STRING=")) {
    throw new Error(`the ticket server refused the request: ${summarise(response)}`)
  }
  const head = text.split("REQUEST_STRING=")[0]
  if (!head.startsWith("STATUS=0") || !head.includes("SUCCESS")) {
    throw new Error(`the ticket server answered ${summarise(head)}`)
  }

  const payload = text.split("REQUEST_STRING=")[1]
  const parsed = parsePlist(payload)
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed) || parsed instanceof Uint8Array) {
    throw new Error("the ticket server's plist was not a dictionary")
  }
  const reply = parsed as PlistDict
  // Current releases name the ticket after the component; older ones still call it the AP ticket.
  const ticket = reply["Cryptex1,Ticket"] ?? reply.ApImg4Ticket
  if (!(ticket instanceof Uint8Array)) {
    throw new Error("the ticket server answered without a Cryptex1 ticket")
  }
  return ticket
}

async function postXml(url: string, body: string): Promise<string> {
  const anyGlobal: any = globalThis
  if (anyGlobal.fetch === undefined) throw new Error("this build has no network")
  const response: any = await anyGlobal.fetch(url, {
    method: "POST",
    headers: {
      "Cache-Control": "no-cache",
      "Content-type": 'text/xml; charset="utf-8"',
      "User-Agent": "InetURL/1.0",
    },
    body,
    timeout: 30,
    debugLabel: "tss",
  })
  if (response.ok === false) throw new Error(`the ticket server answered HTTP ${response.status}`)
  return fromUtf8(new Uint8Array(await response.arrayBuffer()))
}

/** The first part of a refusal, which is the part that says why. */
function summarise(text: string): string {
  const line = text.split("&REQUEST_STRING=")[0].trim()
  return line.length > 300 ? `${line.slice(0, 300)}…` : line
}

function upperUuid(): string {
  const bytes = randomBytes(16)
  const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, "0")).join("").toUpperCase()
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`
}
