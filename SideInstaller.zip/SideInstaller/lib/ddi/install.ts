// Mounting the developer image: without it the debug proxy and the app service are not in the
// device's service table at all, so nothing that needs a debugger can run.
//
// On iOS 26.4 and later the image is a cryptex: the device signs nothing itself, Apple's ticket
// server signs a Cryptex1 ticket for this device's nonce, and cryptexd installs it. A mounted image
// survives until the device reboots.
import { asDict, parsePlist } from "../util"
import { requireService, type DeviceLink } from "../rsd"
import { DDI_FILES, ensureDdiFiles, nativeDdiDownloader, readDdiFile, type DdiDownloader } from "./cache"
import { CRYPTEXD_SERVICE, cryptexNonce, installCryptex, installedDeveloperImage, readPersonalizationIdentifiers } from "./cryptexd"
import { cryptexTicketTags, readCryptexIdentity } from "./manifest"
import { mountedImageTypes } from "./mounter"
import { fetchCryptexTicket, type TssOptions } from "./tss"

export type DdiStage = "check" | "download" | "identify" | "nonce" | "ticket" | "install" | "verify"

export interface EnsureDdiOptions {
  /** Where the files come from. Defaults to this app's download queue. */
  downloader?: DdiDownloader
  /** For tests: the ticket server. */
  tss?: TssOptions
  onProgress?: (stage: DdiStage, detail?: string) => void
}

export interface EnsureDdiResult {
  /** What the device says it has mounted. */
  version: string
  /** Whether this run installed it, rather than finding it already there. */
  installed: boolean
}

/** The image could not be checked, fetched or installed, and this says which. */
export class DdiError extends Error {
  constructor(readonly stage: DdiStage, message: string) {
    super(message)
  }
}

/** The image installed on the device, or null when there is none. */
export async function developerImageVersion(link: DeviceLink): Promise<string | null> {
  return installedDeveloperImage(link)
}

/**
 * Makes sure the device has a developer image mounted, installing one if it does not.
 *
 * Everything about this is slow on the first run — the image is tens of megabytes and the ticket
 * is one round trip to Apple — so each stage is reported.
 */
export async function ensureDeveloperImage(
  link: DeviceLink,
  options: EnsureDdiOptions = {},
): Promise<EnsureDdiResult> {
  const say = options.onProgress ?? (() => {})
  let stage: DdiStage = "check"

  try {
    const mounted = await developerImageVersion(link)
    if (mounted !== null) return { version: mounted, installed: false }

    // An image the mounter put there is not a cryptex, so it is invisible above — and installing
    // a cryptex over it is refused. Either way the services it provides are already up.
    stage = "check"
    let byMounter: string[] = []
    try {
      byMounter = await mountedImageTypes(link)
      say("check", byMounter.length > 0 ? `mounted: ${byMounter.join(", ")}` : "mounted: none")
    } catch (error) {
      say("check", `the image mounter could not be asked: ${error instanceof Error ? error.message : String(error)}`)
    }
    if (byMounter.length > 0) return { version: byMounter.join(", "), installed: false }

    requireCryptexSupport()
    requireService(link.handshake, CRYPTEXD_SERVICE)

    stage = "download"
    say("download")
    let reported = -1
    const downloader = options.downloader ?? nativeDdiDownloader()
    const directory = await ensureDdiFiles(downloader, (index, fraction) => {
      // One line every quarter of a file: a per-percent report would bury everything else.
      const percent = Math.round(fraction * 100)
      if (percent === reported || percent % 25 !== 0) return
      reported = percent
      say("download", `${DDI_FILES[index].name} ${percent}%`)
    })

    const manifest = asDict(parsePlist(readDdiFile(directory, "BuildManifest.plist")))
    let cryptex: ReturnType<typeof readCryptexIdentity>
    try {
      cryptex = readCryptexIdentity(manifest)
    } catch (error) {
      throw new DdiError("download", error instanceof Error ? error.message : String(error))
    }

    stage = "identify"
    say("identify")
    const chip = await readPersonalizationIdentifiers(link)

    stage = "nonce"
    say("nonce")
    const nonce = await cryptexNonce(link, cryptex.nonceDomain)

    stage = "ticket"
    say("ticket")
    const ticket = await fetchCryptexTicket(cryptexTicketTags(cryptex.identity, chip, nonce), options.tss)
    say("ticket", `${ticket.length} bytes`)

    stage = "install"
    say("install")
    const payloads = {
      image: readDdiFile(directory, cryptex.payloads.image),
      trustcache: readDdiFile(directory, cryptex.payloads.trustcache),
      im4m: ticket,
      info: readDdiFile(directory, cryptex.payloads.info),
      volumehash: readDdiFile(directory, cryptex.payloads.volumehash),
      properties: cryptex.properties,
    }
    say("install", `${payloads.image.length} bytes`)
    await installCryptex(link, payloads)

    stage = "verify"
    say("verify")
    const version = await developerImageVersion(link)
    if (version === null) throw new DdiError("verify", "the device did not list the image afterwards")
    return { version, installed: true }
  } catch (error) {
    if (error instanceof DdiError) throw error
    throw new DdiError(stage, error instanceof Error ? error.message : String(error))
  }
}

/**
 * Before 26.4 the image is personalized piece by piece and mounted by the image mounter, which
 * this does not implement. Saying so beats an error from a daemon that was asked the wrong thing.
 */
function requireCryptexSupport(): void {
  const version = String((globalThis as any).Device?.systemVersion ?? "")
  const [major, minor] = version.split(".").map(part => Number.parseInt(part, 10))
  if (Number.isFinite(major) && (major > 26 || (major === 26 && minor >= 4))) return
  throw new DdiError(
    "check",
    `this iOS version (${version.length > 0 ? version : "unknown"}) mounts its developer image a different way, which this does not do yet`,
  )
}
