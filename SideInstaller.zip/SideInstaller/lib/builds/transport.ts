// The package's one place that touches the network.
import { fetch } from "scripting"
import { fromUtf8 } from "../util"
import type { GetJson } from "./catalog"

const API_HEADERS: Record<string, string> = {
  Accept: "application/vnd.github+json",
  "User-Agent": "SideInstaller",
}

/** GET returning parsed JSON. A refusal comes back as its status, with the body as text. */
export const getJson: GetJson = async (url, headers = API_HEADERS) => {
  const response: any = await fetch(url, { headers, timeout: 30, debugLabel: "github" })
  const text = fromUtf8(new Uint8Array(await response.arrayBuffer()))
  const status: number = response.status
  if (status < 200 || status >= 300) return { status, body: text }
  return { status, body: JSON.parse(text) }
}

/**
 * True when GitHub turns down a request for the repo's own page: taken down, private, blocked or
 * not being served. False when it cannot be told — no answer, or a rate limit.
 */
export async function repoGone(pageUrl: string): Promise<boolean> {
  try {
    const response: any = await fetch(pageUrl, {
      method: "HEAD",
      headers: { "User-Agent": "SideInstaller" },
      timeout: 15,
      debugLabel: "github page",
    })
    const status: number = response.status
    return (status < 200 || status >= 300) && status !== 429
  } catch {
    return false
  }
}
