// Which build to install, and where its IPA comes from. Ported from the Swift app's
// `SideStoreDownloader`.
//
// Madeira and a user-supplied `.ipa` are not offered yet: one is pinned to a link outside GitHub,
// the other needs a file importer.
import type { TranslationKey } from "../i18n"

/** Which release track to pull the IPA from. */
export type ReleaseChannel = "stable" | "nightly"

export const RELEASE_CHANNELS: ReleaseChannel[] = ["stable", "nightly"]

/** A copy of a build's IPA on someone else's repository, for while the build's own is gone. */
export interface Mirror {
  /** GitHub "owner/repo" holding the copy. */
  repo: string
  url: string
  assetName: string
  /** The channel the copied build was published on. */
  channel: ReleaseChannel
  /** SHA-256 of the one file accepted from there, in lowercase hex. */
  sha256: string
}

/** What to install: SideStore, LiveContainer with SideStore, or LiveContainer alone. */
export type InstallSource = "sideStore" | "liveContainer" | "liveContainerPlain"

export const INSTALL_SOURCES: InstallSource[] = ["sideStore", "liveContainer", "liveContainerPlain"]

interface SourceFacts {
  /** GitHub "owner/repo" whose release holds the IPA. */
  repo: string
  /** Published `.ipa` asset name, used to build the direct download URL. */
  assetName: string
  /** Filename stem for a downloaded copy. */
  fileStem: string
  /** The copy to take while `repo` is gone from GitHub. */
  mirror?: Mirror
}

const FACTS: Record<InstallSource, SourceFacts> = {
  sideStore: {
    repo: "SideStore/SideStore",
    assetName: "SideStore.ipa",
    fileStem: "SideStore",
  },
  liveContainer: {
    repo: "LiveContainer/LiveContainer",
    assetName: "LiveContainer+SideStore.ipa",
    fileStem: "LiveContainer+SideStore",
    // LiveContainer's organisation was hidden from GitHub in October 2026; this is its last
    // nightly (18 September 2026, commit 4dbe0f9), put up by someone who is not a maintainer, so
    // only that one file is taken, and only by its hash.
    mirror: {
      repo: "LiveContainerMirror/LiveContainer",
      url: "https://github.com/LiveContainerMirror/LiveContainer/releases/download/nightly/LiveContainer+SideStore.ipa",
      assetName: "LiveContainer+SideStore.ipa",
      channel: "nightly",
      sha256: "bec41bc21d75a0f2e85a0aa589ce5772e24e410deb017486758a3bc0503c8de7",
    },
  },
  liveContainerPlain: {
    repo: "LiveContainer/LiveContainer",
    assetName: "LiveContainer.ipa",
    fileStem: "LiveContainer",
    // The same release the combined build comes from, and the same one-file-by-hash rule.
    mirror: {
      repo: "LiveContainerMirror/LiveContainer",
      url: "https://github.com/LiveContainerMirror/LiveContainer/releases/download/nightly/LiveContainer.ipa",
      assetName: "LiveContainer.ipa",
      channel: "nightly",
      sha256: "a45932c71e1ee491215106608518a7148c2050d9867de5e660c4ceec91870d7f",
    },
  },
}

const DISPLAY_NAMES: Record<InstallSource, string> = {
  sideStore: "SideStore",
  liveContainer: "LiveContainer + SideStore",
  liveContainerPlain: "LiveContainer",
}

const SHORT_NAMES: Record<InstallSource, string> = {
  sideStore: "SideStore",
  liveContainer: "SS + LiveContainer",
  liveContainerPlain: "LiveContainer",
}

/** Full name, for the log. */
export function displayName(source: InstallSource): string {
  return DISPLAY_NAMES[source]
}

/** Short label, for the picker and the button. */
export function shortName(source: InstallSource): string {
  return SHORT_NAMES[source]
}

/** Label for the channel picker. */
export function channelName(channel: ReleaseChannel): TranslationKey {
  return channel === "stable" ? "channel.stable" : "channel.nightly"
}

export function repo(source: InstallSource): string {
  return FACTS[source].repo
}

export function assetFileName(source: InstallSource): string {
  return FACTS[source].assetName
}

export function mirrorOf(source: InstallSource): Mirror | undefined {
  return FACTS[source].mirror
}

/** Stores the build's own page, which has no hourly limit as the API does. */
export function repoPage(source: InstallSource): string {
  return `https://github.com/${FACTS[source].repo}`
}

/**
 * Direct github.com download URL, preferred over the API. Stable is resolved by GitHub, since
 * `/releases/latest` skips pre-releases; the nightly tag is fixed, so nothing needs resolving.
 */
export function downloadURL(source: InstallSource, channel: ReleaseChannel): string {
  const base = `https://github.com/${FACTS[source].repo}/releases`
  const asset = FACTS[source].assetName
  return channel === "stable"
    ? `${base}/latest/download/${asset}`
    : `${base}/download/nightly/${asset}`
}

/** GitHub Releases API URL for a channel, used only when the direct download 404s. */
export function releaseAPI(source: InstallSource, channel: ReleaseChannel): string {
  const base = `https://api.github.com/repos/${FACTS[source].repo}/releases`
  return channel === "stable" ? `${base}/latest` : `${base}/tags/nightly`
}

/** Every release of a repo, newest first, for the version picker. */
export function releasesAPI(source: InstallSource, count: number): string {
  return `https://api.github.com/repos/${FACTS[source].repo}/releases?per_page=${count}`
}

/** Local filename for a downloaded IPA, e.g. "SideStore-nightly.ipa". */
export function fileName(source: InstallSource, channel: ReleaseChannel, version?: string): string {
  const stem = FACTS[source].fileStem
  const suffix = channel === "nightly" ? "-nightly" : ""
  if (version === undefined) return `${stem}${suffix}.ipa`
  // A tag can hold a path separator.
  return `${stem}${suffix} (${version.replace(/\//g, "-")}).ipa`
}

/** One asset of a GitHub release, as much of it as this needs. */
export interface GHAsset {
  name: string
  browser_download_url: string
  size?: number
}

/** Pick the right `.ipa` asset out of a release's assets. */
export function selectAsset(source: InstallSource, assets: GHAsset[]): GHAsset | null {
  if (source === "sideStore") {
    // Publishes a single `.ipa` per release.
    return assets.find(asset => asset.name.endsWith(".ipa")) ?? null
  }
  // Prefer the published name, in case the asset is renamed later. One release carries both
  // LiveContainer builds, so the one without SideStore is never the file that names SideStore.
  const preferred = assets.find(asset => asset.name === FACTS[source].assetName)
  if (preferred !== undefined) return preferred
  const candidates = assets.filter(asset => asset.name.endsWith(".ipa"))
  return source === "liveContainerPlain"
    ? candidates.find(asset => !asset.name.toLowerCase().includes("sidestore")) ?? null
    : candidates.find(asset => asset.name.toLowerCase().includes("sidestore")) ?? null
}
