// The door into the build-selection package: what to install, where its IPA comes from, and which
// release the version picker offers.
export {
  INSTALL_SOURCES, RELEASE_CHANNELS,
  assetFileName, channelName, displayName, downloadURL, fileName, mirrorOf, releaseAPI, releasesAPI,
  repo, repoPage, selectAsset, shortName,
  type GHAsset, type InstallSource, type Mirror, type ReleaseChannel,
} from "./sources"

export {
  buildCatalog, channelOf, channelRelease, fetchReleases, releaseCatalog, versionHasRemark,
  versionMenuTitle, versionTitle,
  type GHRelease, type GetJson, type JsonResult, type ReleaseCatalog, type ReleaseVersion,
} from "./catalog"

export { searchFor, type BuildSearch, type BuildSearchDeps, type Candidate } from "./search"

export { getJson, repoGone } from "./transport"

export { fileSha256 } from "./verify"
