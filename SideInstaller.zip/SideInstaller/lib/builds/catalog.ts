// A build's releases on GitHub, sorted into what the version picker offers. Ported from the Swift
// app's `ReleaseCatalog`.
import {
  releaseAPI, releasesAPI, selectAsset,
  type GHAsset, type InstallSource, type ReleaseChannel,
} from "./sources"

/** A GitHub release, as much of it as this needs. */
export interface GHRelease {
  tag_name: string
  assets: GHAsset[]
  /** Optional so a response that omits it still decodes. */
  prerelease?: boolean
  /** The release's title, which can carry a warning: "0.6.4 (DO NOT USE)". */
  name?: string
  draft?: boolean
}

/** One release of a build, as the version picker offers it. */
export interface ReleaseVersion {
  /** The release's tag, e.g. "0.6.3" or "nightly". */
  tag: string
  name: string
  assetName: string
  assetURL: string
}

function sameText(a: string, b: string): boolean {
  return a.toLowerCase() === b.toLowerCase()
}

/** Short label: the tag, or the title when the two differ only in case ("Alpha"). */
export function versionTitle(version: ReleaseVersion): string {
  return sameText(version.name, version.tag) ? version.name : version.tag
}

/** Menu label: the whole title when it starts with the tag, so a maintainer's remark shows. */
export function versionMenuTitle(version: ReleaseVersion): string {
  if (version.name.length === 0 || sameText(version.name, version.tag)) return versionTitle(version)
  return version.name.toLowerCase().startsWith(version.tag.toLowerCase())
    ? version.name
    : `${version.tag} – ${version.name}`
}

/** True when the title says more than the version. */
export function versionHasRemark(version: ReleaseVersion): boolean {
  return versionMenuTitle(version) !== versionTitle(version)
}

export interface ReleaseCatalog {
  /** The release "Latest" installs on each channel, when the list has it. */
  latest: Partial<Record<ReleaseChannel, ReleaseVersion>>
  /** Each channel's other releases carrying the build, newest first. */
  others: Record<ReleaseChannel, ReleaseVersion[]>
  /** When the list was fetched. */
  fetched: number
}

/**
 * Nightly for a pre-release, whether GitHub flags it or its version says so ("0.7.0-alpha");
 * stable for a plain version number. Other tags ("auto-update-test") belong on neither.
 */
export function channelOf(release: GHRelease): ReleaseChannel | null {
  const tag = release.tag_name
  const numbered = /^v?\d/.test(tag)
  // Semantic versioning puts a pre-release label after the first hyphen.
  const labelled = tag.split("-").slice(1).join("-").match(/[A-Za-z]/) !== null
  if (release.prerelease === true || (numbered && labelled)) return "nightly"
  return numbered ? "stable" : null
}

/** `releases` newest first, the order GitHub answers in. */
export function buildCatalog(source: InstallSource, releases: GHRelease[], fetched: number): ReleaseCatalog {
  const offered: { release: GHRelease, version: ReleaseVersion }[] = []
  for (const release of releases) {
    if (release.draft === true) continue
    const asset = selectAsset(source, release.assets)
    if (asset === null) continue
    offered.push({
      release,
      version: {
        tag: release.tag_name,
        name: (release.name ?? "").trim(),
        assetName: asset.name,
        assetURL: asset.browser_download_url,
      },
    })
  }

  // Resolved as the download resolves "Latest": GitHub's newest full release, and the fixed nightly
  // tag, otherwise the newest of either kind.
  const latest: Partial<Record<ReleaseChannel, ReleaseVersion>> = {}
  const firstStable = offered.find(entry => entry.release.prerelease !== true)
  if (firstStable !== undefined) latest.stable = firstStable.version
  const nightly = offered.find(entry => entry.release.tag_name === "nightly") ?? offered[0]
  if (nightly !== undefined) latest.nightly = nightly.version

  const others: Record<ReleaseChannel, ReleaseVersion[]> = { stable: [], nightly: [] }
  for (const entry of offered) {
    const channel = channelOf(entry.release)
    if (channel === null) continue
    if (entry.version.tag === latest[channel]?.tag) continue
    others[channel].push(entry.version)
  }

  return { latest, others, fetched }
}

// MARK: - the API

export interface JsonResult {
  status: number
  body: unknown
}

/** One GET returning parsed JSON. Injected so the catalogue can be tested without a network. */
export type GetJson = (url: string, headers?: Record<string, string>) => Promise<JsonResult>

/** GitHub's answer, unwrapped: a status and whatever it sent. */
function releasesOf(result: JsonResult): GHRelease[] {
  if (result.status === 404) throw new Error(`github 404 ${String(result.body ?? "")}`.trim())
  if (result.status < 200 || result.status >= 300) {
    throw new Error(`github ${result.status} ${String(result.body ?? "")}`.trim())
  }
  if (!Array.isArray(result.body)) throw new Error("github sent something other than a release list")
  return result.body as GHRelease[]
}

/** A repo's `count` newest releases, newest first. */
export async function fetchReleases(source: InstallSource, count: number, getJson: GetJson): Promise<GHRelease[]> {
  return releasesOf(await getJson(releasesAPI(source, count)))
}

/** Every release of `source` the version picker can offer, from one API call. */
export async function releaseCatalog(source: InstallSource, getJson: GetJson, now: number): Promise<ReleaseCatalog> {
  const releases = await fetchReleases(source, 100, getJson)
  return buildCatalog(source, releases, now)
}

/** The channel's own release, for the download's fallback when the direct link 404s. */
export async function channelRelease(source: InstallSource, channel: ReleaseChannel, getJson: GetJson): Promise<GHRelease | null> {
  const result = await getJson(releaseAPI(source, channel))
  // A repo with no nightly tag answers 404: a missing channel, not a status.
  if (result.status === 404) return null
  if (result.status < 200 || result.status >= 300) {
    throw new Error(`github ${result.status} ${String(result.body ?? "")}`.trim())
  }
  return result.body as GHRelease
}
