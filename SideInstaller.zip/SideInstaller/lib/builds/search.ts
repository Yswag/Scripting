// Where the install step looks for the build's IPA, in the order the Swift app's downloader tries
// them: the direct link, the API when the asset has been renamed, a scan of the repo's other
// releases when that channel has no such build, and a copy on someone else's repository when the
// build is gone from GitHub altogether.
import type { TranslationKey } from "../i18n"
import {
  channelRelease, fetchReleases, type GetJson, type ReleaseVersion,
} from "./catalog"
import {
  assetFileName, displayName, downloadURL, mirrorOf, repo, repoPage, selectAsset,
  type InstallSource, type ReleaseChannel,
} from "./sources"

/** One place the IPA might be. */
export interface Candidate {
  url: string
  name: string
  /** The channel the file is published on, which the mirror can disagree with. */
  channel: ReleaseChannel
  origin: "direct" | "api" | "scan" | "mirror"
  /** Set for a mirror: only the file with this SHA-256 is accepted from there. */
  sha256?: string
}

export interface BuildSearchDeps {
  getJson: GetJson
  /** True when the repo's own page is not answering: taken down, private or blocked. */
  repoGone: (pageUrl: string) => Promise<boolean>
  log: (key: TranslationKey, params?: Record<string, string | number>) => void
  /** The channel's name in the active language, since the log lines are read by a person. */
  channelLabel: (channel: ReleaseChannel) => string
}

/** The places left to try. `next` is called again only after a download failed. */
export interface BuildSearch {
  next(failure?: { status: number }): Promise<Candidate | null>
}

/** How many releases the scan looks through, newest first. */
const SCAN_COUNT = 20

/**
 * The candidates for `source` on `channel`, `version` being the release picked under Advanced.
 * A picked version has no fallbacks: anything else would install a build nobody asked for.
 */
export function searchFor(
  source: InstallSource,
  channel: ReleaseChannel,
  version: ReleaseVersion | undefined,
  deps: BuildSearchDeps,
): BuildSearch {
  let step = 0

  return {
    async next(failure) {
      if (version !== undefined) {
        if (step > 0) return null
        step = 1
        return { url: version.assetURL, name: version.assetName, channel, origin: "direct" }
      }

      if (step === 0) {
        step = 1
        return { url: downloadURL(source, channel), name: assetFileName(source), channel, origin: "direct" }
      }

      // The link failed: either the asset was renamed, or the repository itself is gone.
      if (step === 1) {
        step = 2
        const mirror = mirrorOf(source)
        if (mirror !== undefined && failure?.status === 404 && await deps.repoGone(repoPage(source))) {
          deps.log("build.fromMirror", {
            repo: repo(source), mirror: mirror.repo, channel: deps.channelLabel(mirror.channel),
          })
          return {
            url: mirror.url, name: mirror.assetName, channel: mirror.channel,
            origin: "mirror", sha256: mirror.sha256,
          }
        }
        deps.log("build.askApi", { name: assetFileName(source) })
        const release = await channelRelease(source, channel, deps.getJson)
        const asset = release === null ? null : selectAsset(source, release.assets)
        if (release !== null && asset !== null) {
          return { url: asset.browser_download_url, name: asset.name, channel, origin: "api" }
        }
      }

      if (step === 2) {
        step = 3
        deps.log("build.scanReleases", { name: displayName(source), repo: repo(source) })
        const releases = await fetchReleases(source, SCAN_COUNT, deps.getJson)
        for (const release of releases) {
          // A stable request never falls back to a pre-release.
          if (channel === "stable" && release.prerelease === true) continue
          const asset = selectAsset(source, release.assets)
          if (asset === null) continue
          const served: ReleaseChannel = release.prerelease === true ? "nightly" : "stable"
          deps.log("build.fromOtherRelease", {
            name: displayName(source), asset: asset.name, tag: release.tag_name, channel: deps.channelLabel(served),
          })
          return { url: asset.browser_download_url, name: asset.name, channel: served, origin: "scan" }
        }
      }

      return null
    },
  }
}
