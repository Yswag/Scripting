// The mirror's contract: only the one file it is trusted for is accepted from it.
import { sha256, toHex } from "../util"

/** SHA-256 of a file, lowercase hex, or null when it cannot be read. */
export function fileSha256(path: string): string | null {
  const manager: any = (globalThis as any).FileManager
  if (manager === undefined) return null
  try {
    const raw: any = manager.readAsBytesSync(path)
    const bytes: Uint8Array = raw instanceof Uint8Array ? raw : new Uint8Array(raw)
    return toHex(sha256(bytes))
  } catch {
    return null
  }
}
