// RemotePairing protocol: pair-setup (SRP6a + Ed25519), pair-verify (X25519 ECDH), streaming
// channel, and Bonjour discovery. Internal encoding (TLV/OPACK/ChaCha20-Poly1305/XPC) is hidden.

export { PairSetupHost, type RPPeer, SocketPeer } from "./pairsetup"
export { PairVerifyClient } from "./pairverify"
export {
  PairStore, pairingFileToXml, pairingFileFromXml, parsePairingRecord, exportPairingRecord,
  type PairingFile, type PairingExportFormat,
} from "./pairstore"
export { StreamChannel, createListenerPort } from "./stream"
export {
  publishPairableHost,
  pairableHostTxt,
  seesOwnPairableHost,
  PAIRABLE_HOST_TYPE,
  TXT_KEYS_EXPECTED,
} from "./bonjour"

// XPC is exposed for RSD layer
export type { XpcMessage, XpcValue } from "./xpc"
export {
  ROOT_CHANNEL,
  decodeXpcBody,
  decodeXpcMessage,
  deviceHandshakeFrame,
  parseHttp2Frame,
  rsdHandshakeFrames,
} from "./xpc"
