// What the device actually holds, read against the records this app kept.
//
// The list is a record of what this app installed — not a reading of the device — so an app that
// another tool re-signed, or one that was deleted, still carries a countdown here. This is the check
// that catches it: one look at installation_proxy and misagent, on request, and the answer is kept
// on the record so the row can say what it is without asking again.
//
// Two facts decide it, and neither needs the app's signature read off its binary:
//   • the app is signed as some `TeamID.bundleID`, which its `application-identifier` entitlement
//     states — a team that is not ours means someone else signed it;
//   • the device holds a profile for that App ID, and the one we last installed expires when the
//     record says it does — anything older means our install is not the one in force.
import { asDict, str, type PlistDict } from "../util"
import type { DeviceState, InstalledRecord } from "./record"

/** One installed app, as `installation_proxy` describes it. */
export interface DeviceApp {
  bundleIdentifier: string
  /** The team Apple believes signed it; null when the reply carried no entitlements. */
  teamIdentifier: string | null
}

/** One profile the device holds, as `misagent` describes it. */
export interface DeviceProfile {
  /** The App ID it covers, with the team prefix already taken off. */
  applicationIdentifier: string
  expirationDate: Date | null
}

/** Everything one look at the device answered. */
export interface DeviceFacts {
  apps: DeviceApp[]
  profiles: DeviceProfile[]
}

/**
 * "TEAMID.com.example.app.TEAMID" → the team, and the App ID it covers.
 *
 * Apple always writes the team first, which is what makes the split safe: the rest of the string is
 * the App ID exactly as this app records it.
 */
export function splitApplicationIdentifier(value: string): { team: string, applicationIdentifier: string } | null {
  const dot = value.indexOf(".")
  if (dot <= 0 || dot === value.length - 1) return null
  return { team: value.slice(0, dot), applicationIdentifier: value.slice(dot + 1) }
}

/** The app's entitlements, or null when the reply carried none this reader understands. */
function entitlementsOf(info: PlistDict): PlistDict | null {
  const value = info.Entitlements
  if (value === undefined || value === null) return null
  try {
    return asDict(value)
  } catch {
    return null
  }
}

/** One app as `installation_proxy` describes it: the bundle id it answered under, and its team. */
export function deviceAppFrom(bundleIdentifier: string, info: PlistDict): DeviceApp {
  const entitlements = entitlementsOf(info)
  const team = entitlements === null ? undefined : str(entitlements, "com.apple.developer.team-identifier")
  if (typeof team === "string" && team.length > 0) return { bundleIdentifier, teamIdentifier: team }
  const application = entitlements === null ? undefined : str(entitlements, "application-identifier")
  const split = typeof application === "string" ? splitApplicationIdentifier(application) : null
  return { bundleIdentifier, teamIdentifier: split?.team ?? null }
}

/**
 * What the device says about one record.
 *
 * `missing` is the app not being there at all — refreshing would cut a profile for an App ID no app
 * is using. `foreign` is it being there under another team's signature, which our profile cannot
 * apply to. `stale` is the app being ours while the profile in force is older than the record, so
 * the last install did not land or was replaced.
 */
export function deviceStateOf(record: InstalledRecord, facts: DeviceFacts): DeviceState {
  const app = facts.apps.find(candidate => candidate.bundleIdentifier === record.identifier)
  if (app === undefined) return "missing"

  const ours = record.teamId.trim()
  if (app.teamIdentifier !== null && ours.length > 0 && app.teamIdentifier.toUpperCase() !== ours.toUpperCase()) {
    return "foreign"
  }

  const held = facts.profiles.filter(candidate => candidate.applicationIdentifier === record.identifier)
  let latest: number | null = null
  for (const profile of held) {
    const at = profile.expirationDate?.getTime() ?? null
    if (at === null) continue
    if (latest === null || at > latest) latest = at
  }
  // A profile with no expiry is no evidence either way; an app with none of ours is not covered.
  if (latest === null) return "stale"

  const recorded = record.expiresAt === null ? null : Date.parse(record.expiresAt)
  if (recorded === null || Number.isNaN(recorded)) return "ours"
  return latest < recorded ? "stale" : "ours"
}

/** Whether a record in this state is worth a refresh request at all. */
export function refreshableOnDevice(state: DeviceState): boolean {
  return state !== "missing" && state !== "foreign"
}
