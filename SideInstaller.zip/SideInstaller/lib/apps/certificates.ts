// Whether the certificate an app was signed with is still one Apple honours.
//
// SideStore asks this before every refresh (its updateAppCertificate → verifyCertificate steps): a
// profile cut for a certificate Apple no longer honours installs fine and leaves an app that will
// not launch, so the refresh stops there and the row says why instead of quietly spending a request.
//
// That verification is two questions — is the serial in the portal's list, and if it is not, what
// does OCSP say. The listing is exactly the set Apple still honours, so membership answers the
// first; for the rest, the expiry kept beside the serial separates "revoked" from "expired" without
// the round trip. A record written before any of this was kept answers "unknown", which lets the
// refresh run as it always did.
import type { CertificateStatus, InstalledRecord } from "./record"

/** A certificate as the portal lists it, cut down to what this decides on. */
export interface ListedCertificate {
  serialNumber: string | null
  expirationDate: Date | null
}

/** One reading of a certificate, against one listing. */
export interface CertificateReading {
  serial: string | null
  expiresAt: Date | null
  listed: ListedCertificate[]
  now?: Date
}

/** Serials are hex and Apple is not consistent about case or padding, so they are compared folded. */
function fold(serial: string): string {
  return serial.trim().toLowerCase()
}

function dateOf(iso: string | null): Date | null {
  if (iso === null) return null
  const date = new Date(iso)
  return Number.isNaN(date.getTime()) ? null : date
}

/**
 * What this certificate is, in the terms the pill and the refresh use.
 *
 * A serial in Apple's list is valid — that list *is* the set that may still sign. Anything else has
 * ended one of two ways, and the expiry kept on the record says which one.
 */
export function certificateStatusOf(reading: CertificateReading): CertificateStatus {
  const serial = reading.serial?.trim() ?? ""
  if (serial.length === 0) return "unknown"
  const listed = reading.listed.some(certificate =>
    certificate.serialNumber !== null && fold(certificate.serialNumber) === fold(serial))
  if (listed) return "valid"
  const now = reading.now ?? new Date()
  if (reading.expiresAt !== null && reading.expiresAt.getTime() <= now.getTime()) return "expired"
  return "revoked"
}

/** The same reading, taken from a record. */
export function statusOfRecord(
  record: InstalledRecord, listed: ListedCertificate[], now = new Date(),
): CertificateStatus {
  return certificateStatusOf({
    serial: record.certificateSerial,
    expiresAt: dateOf(record.certificateExpiresAt),
    listed,
    now,
  })
}

/** Whether a new profile cannot help: these two need the app signed again. */
export function certificateBlocksRefresh(status: CertificateStatus): boolean {
  return status === "revoked" || status === "expired"
}
