// The Apps page's model: the records this app keeps of what it installed, and the countdown on the
// profile each one is running under. Pure — no device, no UI.
export {
  expiryOf, installedRecords, recordAfterRefresh, recordOfInstall, rememberInstalled,
  saveInstalledRecords, updateInstalledDates,
  type InstallFacts, type InstalledRecord,
} from "./record"
export {
  countNeedingRefresh, daysLeft, daysUntil, isExpired, urgencyOf,
  type ExpiryUrgency,
} from "./expiry"
