// The Apps page's model: the records this app keeps of what it installed, and the countdown on the
// profile each one is running under. Pure — no device, no UI.
export {
  expiryOf, forgetInstalled, installedRecords, loadRefreshScope, recordAfterRefresh, recordOfInstall, rememberInstalled,
  saveInstalledRecords, saveRefreshScope, updateInstalledDates,
  type InstallFacts, type InstalledRecord, type RefreshScope,
} from "./record"
export {
  countNeedingRefresh, daysLeft, daysUntil, isExpired, urgencyOf,
  type ExpiryUrgency,
} from "./expiry"
