// How long a record has left, in the bands the list colours by. Pure arithmetic on a date.
import { expiryOf, type InstalledRecord } from "./record"

/**
 * Urgency bands, scaled to a free profile's seven days, as the apps that came before this one
 * (SideStore, AltStore) band them.
 */
export type ExpiryUrgency = "expired" | "critical" | "soon" | "later" | "comfortable" | "unknown"

/** Calendar days until a date: 1 means it goes tomorrow, negative once it has passed. */
export function daysUntil(date: Date | null, now = new Date()): number | null {
  if (date === null) return null
  const start = new Date(now.getTime())
  start.setHours(0, 0, 0, 0)
  const end = new Date(date.getTime())
  end.setHours(0, 0, 0, 0)
  return Math.round((end.getTime() - start.getTime()) / 86_400_000)
}

/** Days left on a record, or null when its profile carried no expiry. */
export function daysLeft(record: InstalledRecord, now = new Date()): number | null {
  return daysUntil(expiryOf(record), now)
}

export function isExpired(record: InstalledRecord, now = new Date()): boolean {
  const expiry = expiryOf(record)
  return expiry !== null && expiry.getTime() <= now.getTime()
}

export function urgencyOf(record: InstalledRecord, now = new Date()): ExpiryUrgency {
  if (isExpired(record, now)) return "expired"
  const days = daysLeft(record, now)
  if (days === null) return "unknown"
  if (days <= 1) return "critical"
  if (days <= 3) return "soon"
  if (days <= 5) return "later"
  return "comfortable"
}

/** How many apps run out within a day, which is what the header warns about. */
export function countNeedingRefresh(records: InstalledRecord[], now = new Date()): number {
  return records.filter(record => {
    const band = urgencyOf(record, now)
    return band === "expired" || band === "critical"
  }).length
}
