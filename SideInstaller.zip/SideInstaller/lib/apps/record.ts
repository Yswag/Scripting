// What this app has installed on the device, as records of its own.
//
// The list a person sees is these records, not a read of the device: what an install knows — the App
// ID it registered, the profile it was signed with, the name and version — is written down once, and
// a refresh only replaces the expiry. That is what makes the page open instantly, work with no
// device link, and show only the apps this app put there.
import type { ProvisioningProfile } from "../sign"
import type { KeyValueStore } from "../util"
import { globalStore } from "../util"

/** Where the records live. One key, one array, so a rewrite is one `set`. */
const KEY = "apps.installed"

/**
 * What the portal last said about the certificate an app was signed with.
 *
 * A profile cut for a certificate Apple no longer honours installs fine and leaves an app that will
 * not launch, so this is the fact that decides whether a refresh is worth attempting at all.
 */
export type CertificateStatus = "valid" | "revoked" | "expired" | "unknown"

const CERTIFICATE_STATUSES: CertificateStatus[] = ["valid", "revoked", "expired", "unknown"]

/**
 * What the device last said about the app behind a record.
 *
 * The list is a record of what this app installed, so an app re-signed by another tool — or removed
 * altogether — would still carry a countdown here. This is the answer to that, kept on the record so
 * a row can say it without asking the device again.
 */
export type DeviceState = "ours" | "missing" | "foreign" | "stale" | "unknown"

const DEVICE_STATES: DeviceState[] = ["ours", "missing", "foreign", "stale", "unknown"]

/** One app this app installed, and everything a refresh needs to renew it. */
export interface InstalledRecord {
  /** The App ID it was signed as: `<the IPA's bundle id>.<team id>`, which is also its bundle id. */
  identifier: string
  /** What the IPA calls itself, for the list. */
  name: string
  version: string
  /** The App Group that App ID holds, when the profile granted one. */
  appGroup: string | null
  /** The profile's expiry, in ISO form: this is the countdown. */
  expiresAt: string | null
  /** When that profile was issued. */
  refreshedAt: string
  /** The team and the Apple ID it was signed with, so another account's apps are left alone. */
  teamId: string
  account: string
  /** The serial of the certificate the signature carries — what Apple is asked about. */
  certificateSerial: string | null
  /** When Apple stops honouring it. Keeps "revoked" and "expired" apart without asking anyone. */
  certificateExpiresAt: string | null
  /** The last reading of the two above, as the pill shows it. */
  certificateStatus: CertificateStatus
  /** What the device said the last time it was asked: ours, gone, someone else's, or another profile. */
  deviceState: DeviceState
  /** When it was asked, so the page can tell a fresh answer from an old one. */
  checkedAt: string | null
}

/** What an install tells the store. */
export interface InstallFacts {
  identifier: string
  name: string
  version: string
  appGroup: string | null
  teamId: string
  account: string
  profile: ProvisioningProfile
  /** The certificate the install signed with: the serial and its expiry, as the portal listed it. */
  certificateSerial: string | null
  certificateExpiresAt: Date | null
  now?: Date
}

/**
 * The record an install leaves.
 *
 * The expiry comes from the profile that was signed with, which is what the device holds now.
 */
export function recordOfInstall(facts: InstallFacts): InstalledRecord {
  const now = facts.now ?? new Date()
  return {
    identifier: facts.identifier,
    name: facts.name,
    version: facts.version,
    appGroup: facts.appGroup,
    expiresAt: facts.profile.expirationDate?.toISOString() ?? null,
    refreshedAt: (facts.profile.plist.CreationDate instanceof Date
      ? facts.profile.plist.CreationDate
      : now).toISOString(),
    teamId: facts.teamId,
    account: facts.account,
    certificateSerial: facts.certificateSerial,
    certificateExpiresAt: facts.certificateExpiresAt?.toISOString() ?? null,
    // An install only gets here with a certificate the portal listed a moment ago.
    certificateStatus: "valid",
    // A fresh install is this app's own doing; only a device check can say more.
    deviceState: "unknown",
    checkedAt: null,
  }
}

/** The same record with a new profile's dates, which is all a refresh changes. */
export function recordAfterRefresh(record: InstalledRecord, profile: ProvisioningProfile, now = new Date()): InstalledRecord {
  return {
    ...record,
    expiresAt: profile.expirationDate?.toISOString() ?? null,
    refreshedAt: (profile.plist.CreationDate instanceof Date
      ? profile.plist.CreationDate
      : now).toISOString(),
  }
}

/** The expiry as a date, or null when the profile carried none. */
export function expiryOf(record: InstalledRecord): Date | null {
  if (record.expiresAt === null) return null
  const date = new Date(record.expiresAt)
  return Number.isNaN(date.getTime()) ? null : date
}

/**
 * Every record, in the order they were first installed.
 *
 * Records written before the certificate was kept get the empties here rather than at every reader:
 * an old record knows nothing about its certificate, which is "unknown", not "valid".
 */
export function installedRecords(store: KeyValueStore = globalStore()): InstalledRecord[] {
  const saved = store.get<InstalledRecord[]>(KEY)
  if (!Array.isArray(saved)) return []
  return saved
    .filter(record => typeof record?.identifier === "string" && record.identifier.length > 0)
    .map(record => ({
      ...record,
      certificateSerial: record.certificateSerial ?? null,
      certificateExpiresAt: record.certificateExpiresAt ?? null,
      certificateStatus: CERTIFICATE_STATUSES.includes(record.certificateStatus)
        ? record.certificateStatus
        : "unknown",
      deviceState: DEVICE_STATES.includes(record.deviceState) ? record.deviceState : "unknown",
      checkedAt: record.checkedAt ?? null,
    }))
}

/** The records, wholesale. */
export function saveInstalledRecords(records: InstalledRecord[], store: KeyValueStore = globalStore()): void {
  store.set(KEY, records)
}

/** Adds or replaces one record, keeping the list's order. */
export function rememberInstalled(record: InstalledRecord, store: KeyValueStore = globalStore()): InstalledRecord[] {
  const records = installedRecords(store)
  const index = records.findIndex(existing => existing.identifier === record.identifier)
  if (index < 0) records.push(record)
  else records[index] = record
  saveInstalledRecords(records, store)
  return records
}

/** Replaces the dates of a record that is already there. Returns the list as it now stands. */
export function updateInstalledDates(
  identifier: string,
  profile: ProvisioningProfile,
  now = new Date(),
  store: KeyValueStore = globalStore(),
): InstalledRecord[] {
  const records = installedRecords(store)
  const index = records.findIndex(record => record.identifier === identifier)
  if (index < 0) return records
  records[index] = recordAfterRefresh(records[index], profile, now)
  saveInstalledRecords(records, store)
  return records
}

/**
 * Records what the portal said about a record's certificate.
 *
 * Kept on the record, so the pill can show a revoked app without asking Apple again on every open.
 */
export function updateCertificateStatus(
  identifier: string,
  status: CertificateStatus,
  store: KeyValueStore = globalStore(),
): InstalledRecord[] {
  const records = installedRecords(store)
  const index = records.findIndex(record => record.identifier === identifier)
  if (index < 0) return records
  records[index] = { ...records[index], certificateStatus: status }
  saveInstalledRecords(records, store)
  return records
}

/**
 * Records what the device said about the apps behind these records, in one write.
 *
 * The device answers about the whole device at once, so this takes the answers together: one `set`
 * rather than one per row.
 */
export function updateDeviceStates(
  states: { identifier: string, state: DeviceState }[],
  now = new Date(),
  store: KeyValueStore = globalStore(),
): InstalledRecord[] {
  const records = installedRecords(store)
  const byIdentifier = new Map(states.map(entry => [entry.identifier, entry.state]))
  let changed = false
  const next = records.map(record => {
    const state = byIdentifier.get(record.identifier)
    if (state === undefined) return record
    changed = true
    return { ...record, deviceState: state, checkedAt: now.toISOString() }
  })
  if (changed) saveInstalledRecords(next, store)
  return next
}

/** Drops one record — an app that is no longer on the device. Returns the list as it now stands. */
export function forgetInstalled(identifier: string, store: KeyValueStore = globalStore()): InstalledRecord[] {
  const records = installedRecords(store).filter(record => record.identifier !== identifier)
  saveInstalledRecords(records, store)
  return records
}

const REFRESH_SCOPE_KEY = "apps.refreshScope"

export type RefreshScope = "currentAccount" | "allAccounts"

export function loadRefreshScope(store: KeyValueStore = globalStore()): RefreshScope {
  const saved = store.get<string>(REFRESH_SCOPE_KEY)
  return saved === "allAccounts" ? "allAccounts" : "currentAccount"
}

export function saveRefreshScope(scope: RefreshScope, store: KeyValueStore = globalStore()): void {
  store.set(REFRESH_SCOPE_KEY, scope === "allAccounts" ? "allAccounts" : "currentAccount")
}
