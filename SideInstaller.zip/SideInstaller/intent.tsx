// The Shortcut entry point: renew the profiles of the apps this device signed, with no page open.
//
// It runs in this app (`runInApp` in script.json) but not in the foreground, which is what a
// background refresh needs: the records and the saved session are already here. What it does not do
// is bring the VPN up — a shortcut that starts one behind the person is a surprise — so a run with
// nothing live answers with a message instead.
import { Intent, Script } from "scripting"
import { createEngine } from "./lib/engine"
import { initI18n, t } from "./lib/i18n"

/** Past this a run is not going to answer; the system's own limit is close behind it. */
const RUN_LIMIT_MS = 25_000

/**
 * The optional text a Shortcut passes: app identifiers or names, separated by spaces or commas.
 *
 * A Shortcut with nothing wired into the action leaves `shortcutParameter` undefined rather than
 * null, and one that names apps may hand the text over either way, so both are read.
 */
function wantedApps(): string[] {
  const parameter = Intent.shortcutParameter as { type?: unknown, value?: unknown } | null | undefined
  let text = ""
  if (parameter !== null && parameter !== undefined && parameter.type === "text") {
    text = typeof parameter.value === "string" ? parameter.value : String(parameter.value ?? "")
  } else {
    const texts = Intent.textsParameter
    if (Array.isArray(texts) && texts.length > 0) text = String(texts[0] ?? "")
  }
  return text.split(/[\s,]+/).map(value => value.trim()).filter(value => value.length > 0)
}

async function run() {
  await initI18n()

  const wanted = wantedApps()
  const engine = createEngine({ t })
  const refreshable = engine.refreshableApps
  const identifiers = wanted.length === 0
    ? undefined
    : refreshable
      .filter(record => wanted.includes(record.identifier) || wanted.includes(record.name))
      .map(record => record.identifier)

  // Naming an app that is not here is worth saying, rather than refreshing everything instead.
  if (identifiers !== undefined && identifiers.length === 0) {
    Script.exit(Intent.text(t("intent.none", { wanted: wanted.join(", ") })))
    return
  }

  const pending = engine.refreshApps(identifiers, { background: true })
  const summary = await Promise.race([
    pending,
    new Promise<null>(resolve => {
      setTimeout(() => resolve(null), RUN_LIMIT_MS)
    }),
  ])
  if (summary === null) {
    Script.exit(Intent.text(t("intent.timeout")))
    return
  }

  Script.exit(Intent.text(
    summary.message ?? t("intent.done", { refreshed: summary.refreshed, total: summary.total }),
  ))
}

run().catch(error => {
  Script.exit(Intent.text(error instanceof Error ? error.message : String(error)))
})
