// Entry point. Everything before the first render is here: the permission prompts, the saved
// language, and presenting the shell (`lib/ui/`).
import { Script, Navigation } from "scripting"
import { initI18n } from "./lib/i18n"
import { RootView } from "./lib/ui"

async function run() {
  // Ask for everything the script can need up front, here in the entry point where a person
  // is present to answer. `requestAccess` is per-script, so a module doing this itself would
  // raise a prompt nobody can dismiss when the module runs unattended.
  await Script.requestAccess(["fileSystem", "vpn", "localDevVPN"] as any)
  // Only now is `Storage` readable; before the grant settles it hands out an empty store.
  await initI18n()
  // Over full screen rather than a sheet: the pages draw their own backdrop from edge to edge, and
  // a sheet would push them into its own rounded card.
  await Navigation.present({ element: <RootView />, modalPresentationStyle: "overFullScreen" })
  Script.exit()
}

run()
